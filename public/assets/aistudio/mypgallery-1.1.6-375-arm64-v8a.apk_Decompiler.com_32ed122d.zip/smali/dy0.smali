###### Class defpackage.dy0 (dy0)
.class public final Ldy0;
.super Landroid/widget/FrameLayout;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final f:Lc1;

.field public final g:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lc1;Landroid/view/View;)V
    .registers 4

    .line 1
    invoke-direct {p0, p1}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Ldy0;->f:Lc1;

    .line 5
    .line 6
    iput-object p3, p0, Ldy0;->g:Landroid/view/View;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final requestSendAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 4

    .line 1
    iget-object v0, p0, Ldy0;->f:Lc1;

    .line 2
    .line 3
    iget-object v0, v0, Lc1;->a:Lio/flutter/view/b;

    .line 4
    .line 5
    if-nez v0, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x0

    .line 8
    return p0

    .line 9
    :cond_8
    iget-object p0, p0, Ldy0;->g:Landroid/view/View;

    .line 10
    .line 11
    invoke-virtual {v0, p0, p1, p2}, Lio/flutter/view/b;->a(Landroid/view/View;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    return p0
.end method
