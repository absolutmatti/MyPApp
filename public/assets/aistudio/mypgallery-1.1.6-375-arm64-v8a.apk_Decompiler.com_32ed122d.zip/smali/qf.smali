###### Class defpackage.qf (qf)
.class public final Lqf;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lsz;
.implements Ltz;
.implements Luz;
.implements Lvz;
.implements Lwz;


# instance fields
.field public final f:I

.field public final g:Z

.field public h:Lsz;

.field public i:Lko0;

.field public j:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(IZLsz;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lqf;->f:I

    .line 5
    .line 6
    iput-boolean p2, p0, Lqf;->g:Z

    .line 7
    .line 8
    iput-object p3, p0, Lqf;->h:Lsz;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Lwf;I)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Lqf;->f:I

    .line 2
    .line 3
    invoke-virtual {p2, v0}, Lwf;->A(I)Lwf;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, p2}, Lqf;->f(Lwf;)V

    .line 7
    .line 8
    .line 9
    invoke-virtual {p2, p0}, Lwf;->b(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x1

    .line 14
    if-eqz v0, :cond_15

    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-static {v0, v1}, Lr30;->h(II)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    goto :goto_19

    .line 22
    :cond_15
    invoke-static {v1, v1}, Lr30;->h(II)I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    :goto_19
    or-int/2addr v0, p3

    .line 27
    iget-object v1, p0, Lqf;->h:Lsz;

    .line 28
    .line 29
    const/4 v2, 0x3

    .line 30
    invoke-static {v2, v1}, Lt51;->d(ILjava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    check-cast v1, Ltz;

    .line 34
    .line 35
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-interface {v1, p1, p2, v0}, Ltz;->d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {p2}, Lwf;->h()Lko0;

    .line 44
    .line 45
    .line 46
    move-result-object p2

    .line 47
    if-eqz p2, :cond_37

    .line 48
    .line 49
    new-instance v1, Lpf;

    .line 50
    .line 51
    invoke-direct {v1, p0, p1, p3}, Lpf;-><init>(Lqf;Ljava/lang/Object;I)V

    .line 52
    .line 53
    .line 54
    iput-object v1, p2, Lko0;->d:Lsz;

    .line 55
    .line 56
    :cond_37
    return-object v0
.end method

.method public final bridge synthetic d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p2, Lwf;

    .line 2
    .line 3
    check-cast p3, Ljava/lang/Number;

    .line 4
    .line 5
    invoke-virtual {p3}, Ljava/lang/Number;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p3

    .line 9
    invoke-virtual {p0, p1, p2, p3}, Lqf;->c(Ljava/lang/Object;Lwf;I)Ljava/lang/Object;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    check-cast p1, Lwf;

    .line 2
    .line 3
    check-cast p2, Ljava/lang/Number;

    .line 4
    .line 5
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    iget v0, p0, Lqf;->f:I

    .line 10
    .line 11
    invoke-virtual {p1, v0}, Lwf;->A(I)Lwf;

    .line 12
    .line 13
    .line 14
    invoke-virtual {p0, p1}, Lqf;->f(Lwf;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1, p0}, Lwf;->b(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    const/4 v1, 0x0

    .line 22
    const/4 v2, 0x2

    .line 23
    if-eqz v0, :cond_1d

    .line 24
    .line 25
    invoke-static {v2, v1}, Lr30;->h(II)I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    goto :goto_22

    .line 30
    :cond_1d
    const/4 v0, 0x1

    .line 31
    invoke-static {v0, v1}, Lr30;->h(II)I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    :goto_22
    or-int/2addr p2, v0

    .line 36
    iget-object v0, p0, Lqf;->h:Lsz;

    .line 37
    .line 38
    invoke-static {v2, v0}, Lt51;->d(ILjava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 42
    .line 43
    .line 44
    move-result-object p2

    .line 45
    invoke-interface {v0, p1, p2}, Lsz;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p2

    .line 49
    invoke-virtual {p1}, Lwf;->h()Lko0;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    if-eqz p1, :cond_3b

    .line 54
    .line 55
    invoke-static {v2, p0}, Lt51;->d(ILjava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    iput-object p0, p1, Lko0;->d:Lsz;

    .line 59
    .line 60
    :cond_3b
    return-object p2
.end method

.method public final f(Lwf;)V
    .registers 6

    .line 1
    iget-boolean v0, p0, Lqf;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_65

    .line 4
    .line 5
    invoke-virtual {p1}, Lwf;->l()Lko0;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    if-eqz p1, :cond_65

    .line 10
    .line 11
    iget v0, p1, Lko0;->a:I

    .line 12
    .line 13
    or-int/lit8 v0, v0, 0x1

    .line 14
    .line 15
    iput v0, p1, Lko0;->a:I

    .line 16
    .line 17
    iget-object v0, p0, Lqf;->i:Lko0;

    .line 18
    .line 19
    if-eqz v0, :cond_63

    .line 20
    .line 21
    invoke-virtual {v0}, Lko0;->a()Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    if-eqz v1, :cond_63

    .line 26
    .line 27
    if-eq v0, p1, :cond_63

    .line 28
    .line 29
    iget-object v0, v0, Lko0;->c:Ld4;

    .line 30
    .line 31
    iget-object v1, p1, Lko0;->c:Ld4;

    .line 32
    .line 33
    invoke-static {v0, v1}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_27

    .line 38
    .line 39
    goto :goto_63

    .line 40
    :cond_27
    iget-object v0, p0, Lqf;->j:Ljava/util/ArrayList;

    .line 41
    .line 42
    if-nez v0, :cond_36

    .line 43
    .line 44
    new-instance v0, Ljava/util/ArrayList;

    .line 45
    .line 46
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 47
    .line 48
    .line 49
    iput-object v0, p0, Lqf;->j:Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 52
    .line 53
    .line 54
    return-void

    .line 55
    :cond_36
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 56
    .line 57
    .line 58
    move-result p0

    .line 59
    const/4 v1, 0x0

    .line 60
    :goto_3b
    if-ge v1, p0, :cond_5f

    .line 61
    .line 62
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v2

    .line 66
    check-cast v2, Lko0;

    .line 67
    .line 68
    if-eqz v2, :cond_5b

    .line 69
    .line 70
    invoke-virtual {v2}, Lko0;->a()Z

    .line 71
    .line 72
    .line 73
    move-result v3

    .line 74
    if-eqz v3, :cond_5b

    .line 75
    .line 76
    if-eq v2, p1, :cond_5b

    .line 77
    .line 78
    iget-object v2, v2, Lko0;->c:Ld4;

    .line 79
    .line 80
    iget-object v3, p1, Lko0;->c:Ld4;

    .line 81
    .line 82
    invoke-static {v2, v3}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    if-eqz v2, :cond_58

    .line 87
    .line 88
    goto :goto_5b

    .line 89
    :cond_58
    add-int/lit8 v1, v1, 0x1

    .line 90
    .line 91
    goto :goto_3b

    .line 92
    :cond_5b
    :goto_5b
    invoke-virtual {v0, v1, p1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    return-void

    .line 96
    :cond_5f
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_63
    :goto_63
    iput-object p1, p0, Lqf;->i:Lko0;

    .line 101
    .line 102
    :cond_65
    return-void
.end method
