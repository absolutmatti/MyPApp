###### Class defpackage.dc0 (dc0)
.class public final Ldc0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:Lm4;

.field public final synthetic b:Lfc0;


# direct methods
.method public constructor <init>(Lfc0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldc0;->b:Lfc0;

    .line 5
    .line 6
    return-void
.end method
