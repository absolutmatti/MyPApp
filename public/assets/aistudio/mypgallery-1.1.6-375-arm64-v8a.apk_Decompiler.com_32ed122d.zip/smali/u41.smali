###### Class defpackage.u41 (u41)
.class public abstract Lu41;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Lw41;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lw41;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Lmb1;->z:Lw4;

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-static {}, Le5;->a()Landroid/webkit/TracingController;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    iput-object v1, v0, Lw41;->a:Landroid/webkit/TracingController;

    .line 16
    .line 17
    const/4 v1, 0x0

    .line 18
    iput-object v1, v0, Lw41;->b:Lorg/chromium/support_lib_boundary/TracingControllerBoundaryInterface;

    .line 19
    .line 20
    sput-object v0, Lu41;->a:Lw41;

    .line 21
    .line 22
    return-void
.end method
