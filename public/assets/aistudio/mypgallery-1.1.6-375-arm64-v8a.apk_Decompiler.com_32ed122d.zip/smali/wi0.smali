###### Class defpackage.wi0 (wi0)
.class public final Lwi0;
.super Lxi0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final c:Lwi0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lwi0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    invoke-direct {v0, v3, v1, v2}, Lxi0;-><init>(III)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lwi0;->c:Lwi0;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a(Lcd;Lt8;Loy0;Lzf;)V
    .registers 5

    .line 1
    const/4 p0, 0x0

    .line 2
    invoke-virtual {p1, p0}, Lcd;->c(I)I

    .line 3
    .line 4
    .line 5
    move-result p1

    .line 6
    :goto_5
    if-ge p0, p1, :cond_d

    .line 7
    .line 8
    invoke-virtual {p2}, Lt8;->c()V

    .line 9
    .line 10
    .line 11
    add-int/lit8 p0, p0, 0x1

    .line 12
    .line 13
    goto :goto_5

    .line 14
    :cond_d
    return-void
.end method

.method public final b(I)Ljava/lang/String;
    .registers 2

    .line 1
    if-nez p1, :cond_5

    .line 2
    .line 3
    const-string p0, "count"

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    invoke-super {p0, p1}, Lxi0;->b(I)Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0
.end method
