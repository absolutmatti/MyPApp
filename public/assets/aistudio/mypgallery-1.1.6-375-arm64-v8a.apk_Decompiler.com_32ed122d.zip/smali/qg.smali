###### Class defpackage.qg (qg)
.class public final Lqg;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lmg;


# instance fields
.field public final f:Lel0;

.field public final g:Lel0;

.field public final h:Ljava/lang/ThreadLocal;

.field public final i:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final j:J


# direct methods
.method public constructor <init>(Lu6;)V
    .registers 6

    .line 83
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 84
    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    iput-object v0, p0, Lqg;->h:Ljava/lang/ThreadLocal;

    .line 85
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object v0, p0, Lqg;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 86
    sget-object v0, Lxo;->f:Lmp;

    .line 87
    sget-object v0, Lzo;->i:Lzo;

    invoke-virtual {v0, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v2

    if-gtz v2, :cond_24

    .line 88
    sget v0, Lyo;->a:I

    const-wide v2, 0xdf8475800L

    goto :goto_2a

    :cond_24
    const-wide/16 v2, 0x1e

    .line 89
    invoke-static {v2, v3, v0}, Lsa;->S(JLzo;)J

    move-result-wide v2

    .line 90
    :goto_2a
    iput-wide v2, p0, Lqg;->j:J

    .line 91
    new-instance v0, Lel0;

    new-instance v2, Log;

    invoke-direct {v2, v1, p1}, Log;-><init>(ILjava/lang/Object;)V

    const/4 p1, 0x1

    invoke-direct {v0, p1, v2}, Lel0;-><init>(ILoz;)V

    iput-object v0, p0, Lqg;->f:Lel0;

    .line 92
    iput-object v0, p0, Lqg;->g:Lel0;

    return-void
.end method

.method public constructor <init>(Lu6;Ljava/lang/String;I)V
    .registers 8

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    new-instance v0, Ljava/lang/ThreadLocal;

    .line 8
    .line 9
    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lqg;->h:Ljava/lang/ThreadLocal;

    .line 13
    .line 14
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 15
    .line 16
    const/4 v1, 0x0

    .line 17
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 18
    .line 19
    .line 20
    iput-object v0, p0, Lqg;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 21
    .line 22
    sget-object v0, Lxo;->f:Lmp;

    .line 23
    .line 24
    sget-object v0, Lzo;->i:Lzo;

    .line 25
    .line 26
    invoke-virtual {v0, v0}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 27
    .line 28
    .line 29
    move-result v2

    .line 30
    if-gtz v2, :cond_27

    .line 31
    .line 32
    sget v0, Lyo;->a:I

    .line 33
    .line 34
    const-wide v2, 0xdf8475800L

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    goto :goto_2d

    .line 40
    :cond_27
    const-wide/16 v2, 0x1e

    .line 41
    .line 42
    invoke-static {v2, v3, v0}, Lsa;->S(JLzo;)J

    .line 43
    .line 44
    .line 45
    move-result-wide v2

    .line 46
    :goto_2d
    iput-wide v2, p0, Lqg;->j:J

    .line 47
    .line 48
    if-lez p3, :cond_4b

    .line 49
    .line 50
    new-instance v0, Lel0;

    .line 51
    .line 52
    new-instance v2, Lng;

    .line 53
    .line 54
    invoke-direct {v2, p1, p2, v1}, Lng;-><init>(Lu6;Ljava/lang/String;I)V

    .line 55
    .line 56
    .line 57
    invoke-direct {v0, p3, v2}, Lel0;-><init>(ILoz;)V

    .line 58
    .line 59
    .line 60
    iput-object v0, p0, Lqg;->f:Lel0;

    .line 61
    .line 62
    new-instance p3, Lel0;

    .line 63
    .line 64
    new-instance v0, Lng;

    .line 65
    .line 66
    const/4 v1, 0x1

    .line 67
    invoke-direct {v0, p1, p2, v1}, Lng;-><init>(Lu6;Ljava/lang/String;I)V

    .line 68
    .line 69
    .line 70
    invoke-direct {p3, v1, v0}, Lel0;-><init>(ILoz;)V

    .line 71
    .line 72
    .line 73
    iput-object p3, p0, Lqg;->g:Lel0;

    .line 74
    .line 75
    return-void

    .line 76
    :cond_4b
    const-string p0, "Maximum number of readers must be greater than 0"

    .line 77
    .line 78
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 79
    .line 80
    .line 81
    const/4 p0, 0x0

    .line 82
    throw p0
.end method


# virtual methods
.method public final a(Z)V
    .registers 5

    .line 1
    if-eqz p1, :cond_5

    .line 2
    .line 3
    const-string p1, "reader"

    .line 4
    .line 5
    goto :goto_7

    .line 6
    :cond_5
    const-string p1, "writer"

    .line 7
    .line 8
    :goto_7
    new-instance v0, Ljava/lang/StringBuilder;

    .line 9
    .line 10
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 11
    .line 12
    .line 13
    new-instance v1, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v2, "Timed out attempting to acquire a "

    .line 16
    .line 17
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " connection."

    .line 24
    .line 25
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p1

    .line 32
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 33
    .line 34
    .line 35
    const-string p1, "\n\nWriter pool:\n"

    .line 36
    .line 37
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    iget-object p1, p0, Lqg;->g:Lel0;

    .line 41
    .line 42
    invoke-virtual {p1, v0}, Lel0;->c(Ljava/lang/StringBuilder;)V

    .line 43
    .line 44
    .line 45
    const-string p1, "Reader pool:"

    .line 46
    .line 47
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    .line 49
    .line 50
    const/16 p1, 0xa

    .line 51
    .line 52
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 53
    .line 54
    .line 55
    iget-object p0, p0, Lqg;->f:Lel0;

    .line 56
    .line 57
    invoke-virtual {p0, v0}, Lel0;->c(Ljava/lang/StringBuilder;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    const/4 p1, 0x5

    .line 65
    invoke-static {p1, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 66
    .line 67
    .line 68
    const/4 p0, 0x0

    .line 69
    throw p0
.end method

.method public final close()V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x1

    .line 3
    iget-object v2, p0, Lqg;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v2, v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_14

    .line 10
    .line 11
    iget-object v0, p0, Lqg;->f:Lel0;

    .line 12
    .line 13
    invoke-virtual {v0}, Lel0;->b()V

    .line 14
    .line 15
    .line 16
    iget-object p0, p0, Lqg;->g:Lel0;

    .line 17
    .line 18
    invoke-virtual {p0}, Lel0;->b()V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public final o(ZLsz;Lsh;)Ljava/lang/Object;
    .registers 21

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    move-object/from16 v0, p3

    .line 8
    .line 9
    instance-of v4, v0, Lpg;

    .line 10
    .line 11
    if-eqz v4, :cond_1b

    .line 12
    .line 13
    move-object v4, v0

    .line 14
    check-cast v4, Lpg;

    .line 15
    .line 16
    iget v5, v4, Lpg;->r:I

    .line 17
    .line 18
    const/high16 v6, -0x80000000

    .line 19
    .line 20
    and-int v7, v5, v6

    .line 21
    .line 22
    if-eqz v7, :cond_1b

    .line 23
    .line 24
    sub-int/2addr v5, v6

    .line 25
    iput v5, v4, Lpg;->r:I

    .line 26
    .line 27
    goto :goto_20

    .line 28
    :cond_1b
    new-instance v4, Lpg;

    .line 29
    .line 30
    invoke-direct {v4, v1, v0}, Lpg;-><init>(Lqg;Lsh;)V

    .line 31
    .line 32
    .line 33
    :goto_20
    iget-object v5, v4, Lsh;->g:Lyh;

    .line 34
    .line 35
    iget-object v0, v4, Lpg;->p:Ljava/lang/Object;

    .line 36
    .line 37
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v6

    .line 41
    iget v7, v4, Lpg;->r:I

    .line 42
    .line 43
    const-string v8, "ROLLBACK TRANSACTION"

    .line 44
    .line 45
    const/4 v10, 0x4

    .line 46
    const/4 v11, 0x3

    .line 47
    const/4 v12, 0x2

    .line 48
    const/4 v13, 0x1

    .line 49
    const/4 v14, 0x0

    .line 50
    if-eqz v7, :cond_7c

    .line 51
    .line 52
    if-eq v7, v13, :cond_78

    .line 53
    .line 54
    if-eq v7, v12, :cond_74

    .line 55
    .line 56
    if-eq v7, v11, :cond_53

    .line 57
    .line 58
    if-ne v7, v10, :cond_4d

    .line 59
    .line 60
    iget-object v1, v4, Lpg;->j:Ljava/io/Serializable;

    .line 61
    .line 62
    check-cast v1, Lvo0;

    .line 63
    .line 64
    iget-object v2, v4, Lpg;->i:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v2, Lel0;

    .line 67
    .line 68
    :try_start_43
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V
    :try_end_46
    .catchall {:try_start_43 .. :try_end_46} :catchall_48

    .line 69
    .line 70
    .line 71
    goto/16 :goto_194

    .line 72
    .line 73
    :catchall_48
    move-exception v0

    .line 74
    move-object v12, v1

    .line 75
    :goto_4a
    move-object v1, v0

    .line 76
    goto/16 :goto_1c3

    .line 77
    .line 78
    :cond_4d
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 79
    .line 80
    invoke-static {v0}, Lm0;->g(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    return-object v14

    .line 84
    :cond_53
    iget-boolean v1, v4, Lpg;->o:Z

    .line 85
    .line 86
    iget-object v2, v4, Lpg;->n:Lvo0;

    .line 87
    .line 88
    iget-object v5, v4, Lpg;->m:Lyh;

    .line 89
    .line 90
    iget-object v3, v4, Lpg;->l:Lvo0;

    .line 91
    .line 92
    iget-object v7, v4, Lpg;->k:Lel0;

    .line 93
    .line 94
    iget-object v11, v4, Lpg;->j:Ljava/io/Serializable;

    .line 95
    .line 96
    check-cast v11, Lsz;

    .line 97
    .line 98
    iget-object v12, v4, Lpg;->i:Ljava/lang/Object;

    .line 99
    .line 100
    check-cast v12, Lqg;

    .line 101
    .line 102
    :try_start_65
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V
    :try_end_68
    .catchall {:try_start_65 .. :try_end_68} :catchall_6c

    .line 103
    .line 104
    .line 105
    move-object v0, v3

    .line 106
    move-object v3, v11

    .line 107
    goto/16 :goto_123

    .line 108
    .line 109
    :catchall_6c
    move-exception v0

    .line 110
    move-object v15, v2

    .line 111
    move v2, v1

    .line 112
    move-object v1, v12

    .line 113
    move-object v12, v3

    .line 114
    move-object v3, v11

    .line 115
    goto/16 :goto_129

    .line 116
    .line 117
    :cond_74
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    return-object v0

    .line 121
    :cond_78
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    return-object v0

    .line 125
    :cond_7c
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 126
    .line 127
    .line 128
    iget-object v0, v1, Lqg;->i:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 129
    .line 130
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    if-nez v0, :cond_1ea

    .line 135
    .line 136
    iget-object v0, v1, Lqg;->h:Ljava/lang/ThreadLocal;

    .line 137
    .line 138
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v7

    .line 142
    check-cast v7, Lnl0;

    .line 143
    .line 144
    sget-object v15, Llg;->g:Liq0;

    .line 145
    .line 146
    if-nez v7, :cond_a2

    .line 147
    .line 148
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    .line 150
    .line 151
    invoke-interface {v5, v15}, Lyh;->q(Lxh;)Lwh;

    .line 152
    .line 153
    .line 154
    move-result-object v7

    .line 155
    check-cast v7, Llg;

    .line 156
    .line 157
    if-eqz v7, :cond_a1

    .line 158
    .line 159
    iget-object v7, v7, Llg;->f:Lnl0;

    .line 160
    .line 161
    goto :goto_a2

    .line 162
    :cond_a1
    move-object v7, v14

    .line 163
    :cond_a2
    :goto_a2
    if-eqz v7, :cond_e7

    .line 164
    .line 165
    if-nez v2, :cond_b1

    .line 166
    .line 167
    iget-boolean v1, v7, Lnl0;->b:Z

    .line 168
    .line 169
    if-nez v1, :cond_ab

    .line 170
    .line 171
    goto :goto_b1

    .line 172
    :cond_ab
    const-string v0, "Cannot upgrade connection from reader to writer"

    .line 173
    .line 174
    invoke-static {v13, v0}, Lhh1;->H(ILjava/lang/String;)V

    .line 175
    .line 176
    .line 177
    throw v14

    .line 178
    :cond_b1
    :goto_b1
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 179
    .line 180
    .line 181
    invoke-interface {v5, v15}, Lyh;->q(Lxh;)Lwh;

    .line 182
    .line 183
    .line 184
    move-result-object v1

    .line 185
    if-nez v1, :cond_dc

    .line 186
    .line 187
    new-instance v1, Llg;

    .line 188
    .line 189
    invoke-direct {v1, v7}, Llg;-><init>(Lnl0;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 193
    .line 194
    .line 195
    new-instance v2, Lq31;

    .line 196
    .line 197
    invoke-direct {v2, v7, v0}, Lq31;-><init>(Lnl0;Ljava/lang/ThreadLocal;)V

    .line 198
    .line 199
    .line 200
    invoke-static {v1, v2}, Lsa;->M(Lwh;Lyh;)Lyh;

    .line 201
    .line 202
    .line 203
    move-result-object v0

    .line 204
    new-instance v1, Lq8;

    .line 205
    .line 206
    const/4 v2, 0x6

    .line 207
    invoke-direct {v1, v3, v7, v14, v2}, Lq8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 208
    .line 209
    .line 210
    iput v13, v4, Lpg;->r:I

    .line 211
    .line 212
    invoke-static {v0, v1, v4}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v0

    .line 216
    if-ne v0, v6, :cond_db

    .line 217
    .line 218
    goto/16 :goto_192

    .line 219
    .line 220
    :cond_db
    return-object v0

    .line 221
    :cond_dc
    iput v12, v4, Lpg;->r:I

    .line 222
    .line 223
    invoke-interface {v3, v7, v4}, Lsz;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v0

    .line 227
    if-ne v0, v6, :cond_e6

    .line 228
    .line 229
    goto/16 :goto_192

    .line 230
    .line 231
    :cond_e6
    return-object v0

    .line 232
    :cond_e7
    if-eqz v2, :cond_ed

    .line 233
    .line 234
    iget-object v0, v1, Lqg;->f:Lel0;

    .line 235
    .line 236
    :goto_eb
    move-object v7, v0

    .line 237
    goto :goto_f0

    .line 238
    :cond_ed
    iget-object v0, v1, Lqg;->g:Lel0;

    .line 239
    .line 240
    goto :goto_eb

    .line 241
    :goto_f0
    new-instance v12, Lvo0;

    .line 242
    .line 243
    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    .line 244
    .line 245
    .line 246
    :try_start_f5
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 247
    .line 248
    .line 249
    new-instance v15, Lvo0;

    .line 250
    .line 251
    invoke-direct {v15}, Ljava/lang/Object;-><init>()V
    :try_end_fd
    .catchall {:try_start_f5 .. :try_end_fd} :catchall_1c0

    .line 252
    .line 253
    .line 254
    :try_start_fd
    iget-wide v9, v1, Lqg;->j:J

    .line 255
    .line 256
    new-instance v0, Lpc;

    .line 257
    .line 258
    invoke-direct {v0, v15, v7, v14, v13}, Lpc;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 259
    .line 260
    .line 261
    iput-object v1, v4, Lpg;->i:Ljava/lang/Object;

    .line 262
    .line 263
    move-object v13, v3

    .line 264
    check-cast v13, Ljava/io/Serializable;

    .line 265
    .line 266
    iput-object v13, v4, Lpg;->j:Ljava/io/Serializable;

    .line 267
    .line 268
    iput-object v7, v4, Lpg;->k:Lel0;

    .line 269
    .line 270
    iput-object v12, v4, Lpg;->l:Lvo0;

    .line 271
    .line 272
    iput-object v5, v4, Lpg;->m:Lyh;

    .line 273
    .line 274
    iput-object v15, v4, Lpg;->n:Lvo0;

    .line 275
    .line 276
    iput-boolean v2, v4, Lpg;->o:Z

    .line 277
    .line 278
    iput v11, v4, Lpg;->r:I

    .line 279
    .line 280
    invoke-static {v9, v10, v0, v4}, Lsa;->W(JLpc;Lpg;)Ljava/lang/Object;

    .line 281
    .line 282
    .line 283
    move-result-object v0
    :try_end_11b
    .catchall {:try_start_fd .. :try_end_11b} :catchall_128

    .line 284
    if-ne v0, v6, :cond_11f

    .line 285
    .line 286
    goto/16 :goto_192

    .line 287
    .line 288
    :cond_11f
    move-object v0, v12

    .line 289
    move-object v12, v1

    .line 290
    move v1, v2

    .line 291
    move-object v2, v15

    .line 292
    :goto_123
    move-object v15, v2

    .line 293
    move v2, v1

    .line 294
    move-object v1, v0

    .line 295
    move-object v0, v14

    .line 296
    goto :goto_12e

    .line 297
    :catchall_128
    move-exception v0

    .line 298
    :goto_129
    move-object/from16 v16, v12

    .line 299
    .line 300
    move-object v12, v1

    .line 301
    move-object/from16 v1, v16

    .line 302
    .line 303
    :goto_12e
    :try_start_12e
    iget-object v9, v15, Lvo0;->f:Ljava/lang/Object;

    .line 304
    .line 305
    check-cast v9, Ltg;

    .line 306
    .line 307
    if-eqz v9, :cond_156

    .line 308
    .line 309
    new-instance v10, Lnl0;

    .line 310
    .line 311
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 312
    .line 313
    .line 314
    iput-object v5, v9, Ltg;->h:Lyh;

    .line 315
    .line 316
    new-instance v5, Ljava/lang/Throwable;

    .line 317
    .line 318
    invoke-direct {v5}, Ljava/lang/Throwable;-><init>()V

    .line 319
    .line 320
    .line 321
    iput-object v5, v9, Ltg;->i:Ljava/lang/Throwable;

    .line 322
    .line 323
    iget-object v5, v12, Lqg;->f:Lel0;

    .line 324
    .line 325
    iget-object v11, v12, Lqg;->g:Lel0;

    .line 326
    .line 327
    if-eq v5, v11, :cond_14c

    .line 328
    .line 329
    if-eqz v2, :cond_14c

    .line 330
    .line 331
    const/4 v5, 0x1

    .line 332
    goto :goto_14d

    .line 333
    :cond_14c
    const/4 v5, 0x0

    .line 334
    :goto_14d
    invoke-direct {v10, v9, v5}, Lnl0;-><init>(Ltg;Z)V

    .line 335
    .line 336
    .line 337
    goto :goto_157

    .line 338
    :catchall_151
    move-exception v0

    .line 339
    move-object v12, v1

    .line 340
    move-object v2, v7

    .line 341
    goto/16 :goto_4a

    .line 342
    .line 343
    :cond_156
    move-object v10, v14

    .line 344
    :goto_157
    iput-object v10, v1, Lvo0;->f:Ljava/lang/Object;

    .line 345
    .line 346
    instance-of v5, v0, Lx31;

    .line 347
    .line 348
    if-nez v5, :cond_1bc

    .line 349
    .line 350
    if-nez v0, :cond_1bb

    .line 351
    .line 352
    if-eqz v10, :cond_1b3

    .line 353
    .line 354
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 355
    .line 356
    .line 357
    new-instance v0, Llg;

    .line 358
    .line 359
    invoke-direct {v0, v10}, Llg;-><init>(Lnl0;)V

    .line 360
    .line 361
    .line 362
    iget-object v2, v12, Lqg;->h:Ljava/lang/ThreadLocal;

    .line 363
    .line 364
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 365
    .line 366
    .line 367
    new-instance v5, Lq31;

    .line 368
    .line 369
    invoke-direct {v5, v10, v2}, Lq31;-><init>(Lnl0;Ljava/lang/ThreadLocal;)V

    .line 370
    .line 371
    .line 372
    invoke-static {v0, v5}, Lsa;->M(Lwh;Lyh;)Lyh;

    .line 373
    .line 374
    .line 375
    move-result-object v0

    .line 376
    new-instance v2, Lq8;

    .line 377
    .line 378
    const/4 v5, 0x7

    .line 379
    invoke-direct {v2, v3, v1, v14, v5}, Lq8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 380
    .line 381
    .line 382
    iput-object v7, v4, Lpg;->i:Ljava/lang/Object;

    .line 383
    .line 384
    iput-object v1, v4, Lpg;->j:Ljava/io/Serializable;

    .line 385
    .line 386
    iput-object v14, v4, Lpg;->k:Lel0;

    .line 387
    .line 388
    iput-object v14, v4, Lpg;->l:Lvo0;

    .line 389
    .line 390
    iput-object v14, v4, Lpg;->m:Lyh;

    .line 391
    .line 392
    iput-object v14, v4, Lpg;->n:Lvo0;

    .line 393
    .line 394
    const/4 v3, 0x4

    .line 395
    iput v3, v4, Lpg;->r:I

    .line 396
    .line 397
    invoke-static {v0, v2, v4}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 398
    .line 399
    .line 400
    move-result-object v0
    :try_end_190
    .catchall {:try_start_12e .. :try_end_190} :catchall_151

    .line 401
    if-ne v0, v6, :cond_193

    .line 402
    .line 403
    :goto_192
    return-object v6

    .line 404
    :cond_193
    move-object v2, v7

    .line 405
    :goto_194
    :try_start_194
    iget-object v1, v1, Lvo0;->f:Ljava/lang/Object;

    .line 406
    .line 407
    check-cast v1, Lnl0;

    .line 408
    .line 409
    if-eqz v1, :cond_1b2

    .line 410
    .line 411
    iget-object v3, v1, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 412
    .line 413
    const/4 v4, 0x0

    .line 414
    const/4 v5, 0x1

    .line 415
    invoke-virtual {v3, v4, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 416
    .line 417
    .line 418
    move-result v3
    :try_end_1a2
    .catchall {:try_start_194 .. :try_end_1a2} :catchall_1b2

    .line 419
    if-eqz v3, :cond_1a9

    .line 420
    .line 421
    :try_start_1a4
    iget-object v3, v1, Lnl0;->a:Ltg;

    .line 422
    .line 423
    invoke-static {v3, v8}, Lhh1;->o(Loq0;Ljava/lang/String;)V
    :try_end_1a9
    .catch Landroid/database/SQLException; {:try_start_1a4 .. :try_end_1a9} :catch_1a9
    .catchall {:try_start_1a4 .. :try_end_1a9} :catchall_1b2

    .line 424
    .line 425
    .line 426
    :catch_1a9
    :cond_1a9
    :try_start_1a9
    iget-object v1, v1, Lnl0;->a:Ltg;

    .line 427
    .line 428
    iput-object v14, v1, Ltg;->h:Lyh;

    .line 429
    .line 430
    iput-object v14, v1, Ltg;->i:Ljava/lang/Throwable;

    .line 431
    .line 432
    invoke-virtual {v2, v1}, Lel0;->d(Ltg;)V
    :try_end_1b2
    .catchall {:try_start_1a9 .. :try_end_1b2} :catchall_1b2

    .line 433
    .line 434
    .line 435
    :catchall_1b2
    :cond_1b2
    return-object v0

    .line 436
    :cond_1b3
    :try_start_1b3
    const-string v0, "Required value was null."

    .line 437
    .line 438
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 439
    .line 440
    invoke-direct {v2, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 441
    .line 442
    .line 443
    throw v2

    .line 444
    :cond_1bb
    throw v0

    .line 445
    :cond_1bc
    invoke-virtual {v12, v2}, Lqg;->a(Z)V

    .line 446
    .line 447
    .line 448
    throw v14
    :try_end_1c0
    .catchall {:try_start_1b3 .. :try_end_1c0} :catchall_151

    .line 449
    :catchall_1c0
    move-exception v0

    .line 450
    move-object v1, v0

    .line 451
    move-object v2, v7

    .line 452
    :goto_1c3
    :try_start_1c3
    throw v1
    :try_end_1c4
    .catchall {:try_start_1c3 .. :try_end_1c4} :catchall_1c4

    .line 453
    :catchall_1c4
    move-exception v0

    .line 454
    move-object v3, v0

    .line 455
    :try_start_1c6
    iget-object v0, v12, Lvo0;->f:Ljava/lang/Object;

    .line 456
    .line 457
    check-cast v0, Lnl0;

    .line 458
    .line 459
    if-eqz v0, :cond_1e9

    .line 460
    .line 461
    iget-object v4, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 462
    .line 463
    const/4 v5, 0x0

    .line 464
    const/4 v6, 0x1

    .line 465
    invoke-virtual {v4, v5, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    .line 466
    .line 467
    .line 468
    move-result v4
    :try_end_1d4
    .catchall {:try_start_1c6 .. :try_end_1d4} :catchall_1e5

    .line 469
    if-eqz v4, :cond_1db

    .line 470
    .line 471
    :try_start_1d6
    iget-object v4, v0, Lnl0;->a:Ltg;

    .line 472
    .line 473
    invoke-static {v4, v8}, Lhh1;->o(Loq0;Ljava/lang/String;)V
    :try_end_1db
    .catch Landroid/database/SQLException; {:try_start_1d6 .. :try_end_1db} :catch_1db
    .catchall {:try_start_1d6 .. :try_end_1db} :catchall_1e5

    .line 474
    .line 475
    .line 476
    :catch_1db
    :cond_1db
    :try_start_1db
    iget-object v0, v0, Lnl0;->a:Ltg;

    .line 477
    .line 478
    iput-object v14, v0, Ltg;->h:Lyh;

    .line 479
    .line 480
    iput-object v14, v0, Ltg;->i:Ljava/lang/Throwable;

    .line 481
    .line 482
    invoke-virtual {v2, v0}, Lel0;->d(Ltg;)V
    :try_end_1e4
    .catchall {:try_start_1db .. :try_end_1e4} :catchall_1e5

    .line 483
    .line 484
    .line 485
    goto :goto_1e9

    .line 486
    :catchall_1e5
    move-exception v0

    .line 487
    invoke-static {v1, v0}, Lsa;->c(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    .line 488
    .line 489
    .line 490
    :cond_1e9
    :goto_1e9
    throw v3

    .line 491
    :cond_1ea
    const/16 v0, 0x15

    .line 492
    .line 493
    const-string v1, "Connection pool is closed"

    .line 494
    .line 495
    invoke-static {v0, v1}, Lhh1;->H(ILjava/lang/String;)V

    .line 496
    .line 497
    .line 498
    throw v14
.end method

###### Class defpackage.ng (ng)
.class public final synthetic Lng;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Loz;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lu6;

.field public final synthetic h:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lu6;Ljava/lang/String;I)V
    .registers 4

    .line 1
    iput p3, p0, Lng;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lng;->g:Lu6;

    .line 4
    .line 5
    iput-object p2, p0, Lng;->h:Ljava/lang/String;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lng;->f:I

    .line 2
    .line 3
    iget-object v1, p0, Lng;->h:Ljava/lang/String;

    .line 4
    .line 5
    iget-object p0, p0, Lng;->g:Lu6;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_18

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v1}, Lu6;->b(Ljava/lang/String;)Loq0;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0

    .line 15
    :pswitch_e
    invoke-virtual {p0, v1}, Lu6;->b(Ljava/lang/String;)Loq0;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    const-string v0, "PRAGMA query_only = 1"

    .line 20
    .line 21
    invoke-static {p0, v0}, Lhh1;->o(Loq0;Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    return-object p0

    .line 25
    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
