###### Class defpackage.de0 (de0)
.class public final Lde0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Les0;


# static fields
.field public static final o:[I

.field public static final p:Lsun/misc/Unsafe;


# instance fields
.field public final a:[I

.field public final b:[Ljava/lang/Object;

.field public final c:I

.field public final d:I

.field public final e:Lxd0;

.field public final f:Z

.field public final g:Z

.field public final h:[I

.field public final i:I

.field public final j:I

.field public final k:Lng0;

.field public final l:Le90;

.field public final m:Lp61;

.field public final n:Lrb0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const/4 v0, 0x0

    .line 2
    new-array v0, v0, [I

    .line 3
    .line 4
    sput-object v0, Lde0;->o:[I

    .line 5
    .line 6
    invoke-static {}, Lk71;->j()Lsun/misc/Unsafe;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sput-object v0, Lde0;->p:Lsun/misc/Unsafe;

    .line 11
    .line 12
    return-void
.end method

.method public constructor <init>([I[Ljava/lang/Object;IILxd0;Z[IIILng0;Le90;Lp61;Lfs;Lrb0;)V
    .registers 15

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    iput-object p1, p0, Lde0;->a:[I

    .line 3
    iput-object p2, p0, Lde0;->b:[Ljava/lang/Object;

    .line 4
    iput p3, p0, Lde0;->c:I

    .line 5
    iput p4, p0, Lde0;->d:I

    .line 6
    instance-of p1, p5, Lr00;

    iput-boolean p1, p0, Lde0;->f:Z

    .line 7
    iput-boolean p6, p0, Lde0;->g:Z

    .line 8
    iput-object p7, p0, Lde0;->h:[I

    .line 9
    iput p8, p0, Lde0;->i:I

    .line 10
    iput p9, p0, Lde0;->j:I

    .line 11
    iput-object p10, p0, Lde0;->k:Lng0;

    .line 12
    iput-object p11, p0, Lde0;->l:Le90;

    .line 13
    iput-object p12, p0, Lde0;->m:Lp61;

    .line 14
    iput-object p5, p0, Lde0;->e:Lxd0;

    .line 15
    iput-object p14, p0, Lde0;->n:Lrb0;

    return-void
.end method

.method public static C(Ldo0;Lng0;Le90;Lp61;Lfs;Lrb0;)Lde0;
    .registers 7

    .line 1
    instance-of v0, p0, Ldo0;

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-static/range {p0 .. p5}, Lde0;->D(Ldo0;Lng0;Le90;Lp61;Lfs;Lrb0;)Lde0;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0

    .line 10
    :cond_9
    invoke-static {}, Lm0;->o()V

    .line 11
    .line 12
    .line 13
    const/4 p0, 0x0

    .line 14
    return-object p0
.end method

.method public static D(Ldo0;Lng0;Le90;Lp61;Lfs;Lrb0;)Lde0;
    .registers 40

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Ldo0;->d:I

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    and-int/2addr v1, v2

    .line 7
    const/4 v3, 0x0

    .line 8
    if-ne v1, v2, :cond_b

    .line 9
    .line 10
    move v10, v3

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    move v10, v2

    .line 13
    :goto_c
    iget-object v1, v0, Ldo0;->b:Ljava/lang/String;

    .line 14
    .line 15
    invoke-virtual {v1}, Ljava/lang/String;->length()I

    .line 16
    .line 17
    .line 18
    move-result v4

    .line 19
    invoke-virtual {v1, v3}, Ljava/lang/String;->charAt(I)C

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    const v6, 0xd800

    .line 24
    .line 25
    .line 26
    if-lt v5, v6, :cond_26

    .line 27
    .line 28
    move v5, v2

    .line 29
    :goto_1c
    add-int/lit8 v7, v5, 0x1

    .line 30
    .line 31
    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    if-lt v5, v6, :cond_27

    .line 36
    .line 37
    move v5, v7

    .line 38
    goto :goto_1c

    .line 39
    :cond_26
    move v7, v2

    .line 40
    :cond_27
    add-int/lit8 v5, v7, 0x1

    .line 41
    .line 42
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 43
    .line 44
    .line 45
    move-result v7

    .line 46
    const/16 v8, 0xd

    .line 47
    .line 48
    if-lt v7, v6, :cond_47

    .line 49
    .line 50
    and-int/lit16 v7, v7, 0x1fff

    .line 51
    .line 52
    move v9, v8

    .line 53
    :goto_34
    add-int/lit8 v11, v5, 0x1

    .line 54
    .line 55
    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    .line 56
    .line 57
    .line 58
    move-result v5

    .line 59
    if-lt v5, v6, :cond_44

    .line 60
    .line 61
    and-int/lit16 v5, v5, 0x1fff

    .line 62
    .line 63
    shl-int/2addr v5, v9

    .line 64
    or-int/2addr v7, v5

    .line 65
    add-int/lit8 v9, v9, 0xd

    .line 66
    .line 67
    move v5, v11

    .line 68
    goto :goto_34

    .line 69
    :cond_44
    shl-int/2addr v5, v9

    .line 70
    or-int/2addr v7, v5

    .line 71
    move v5, v11

    .line 72
    :cond_47
    if-nez v7, :cond_58

    .line 73
    .line 74
    sget-object v7, Lde0;->o:[I

    .line 75
    .line 76
    move/from16 v17, v2

    .line 77
    .line 78
    move v2, v3

    .line 79
    move v12, v2

    .line 80
    move v13, v12

    .line 81
    move v14, v13

    .line 82
    move v15, v14

    .line 83
    move-object v11, v7

    .line 84
    move v9, v8

    .line 85
    move v7, v15

    .line 86
    move v8, v7

    .line 87
    goto/16 :goto_16a

    .line 88
    .line 89
    :cond_58
    add-int/lit8 v7, v5, 0x1

    .line 90
    .line 91
    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    .line 92
    .line 93
    .line 94
    move-result v5

    .line 95
    if-lt v5, v6, :cond_76

    .line 96
    .line 97
    and-int/lit16 v5, v5, 0x1fff

    .line 98
    .line 99
    move v9, v8

    .line 100
    :goto_63
    add-int/lit8 v11, v7, 0x1

    .line 101
    .line 102
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 103
    .line 104
    .line 105
    move-result v7

    .line 106
    if-lt v7, v6, :cond_73

    .line 107
    .line 108
    and-int/lit16 v7, v7, 0x1fff

    .line 109
    .line 110
    shl-int/2addr v7, v9

    .line 111
    or-int/2addr v5, v7

    .line 112
    add-int/lit8 v9, v9, 0xd

    .line 113
    .line 114
    move v7, v11

    .line 115
    goto :goto_63

    .line 116
    :cond_73
    shl-int/2addr v7, v9

    .line 117
    or-int/2addr v5, v7

    .line 118
    move v7, v11

    .line 119
    :cond_76
    add-int/lit8 v9, v7, 0x1

    .line 120
    .line 121
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 122
    .line 123
    .line 124
    move-result v7

    .line 125
    if-lt v7, v6, :cond_94

    .line 126
    .line 127
    and-int/lit16 v7, v7, 0x1fff

    .line 128
    .line 129
    move v11, v8

    .line 130
    :goto_81
    add-int/lit8 v12, v9, 0x1

    .line 131
    .line 132
    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    .line 133
    .line 134
    .line 135
    move-result v9

    .line 136
    if-lt v9, v6, :cond_91

    .line 137
    .line 138
    and-int/lit16 v9, v9, 0x1fff

    .line 139
    .line 140
    shl-int/2addr v9, v11

    .line 141
    or-int/2addr v7, v9

    .line 142
    add-int/lit8 v11, v11, 0xd

    .line 143
    .line 144
    move v9, v12

    .line 145
    goto :goto_81

    .line 146
    :cond_91
    shl-int/2addr v9, v11

    .line 147
    or-int/2addr v7, v9

    .line 148
    move v9, v12

    .line 149
    :cond_94
    add-int/lit8 v11, v9, 0x1

    .line 150
    .line 151
    invoke-virtual {v1, v9}, Ljava/lang/String;->charAt(I)C

    .line 152
    .line 153
    .line 154
    move-result v9

    .line 155
    if-lt v9, v6, :cond_b2

    .line 156
    .line 157
    and-int/lit16 v9, v9, 0x1fff

    .line 158
    .line 159
    move v12, v8

    .line 160
    :goto_9f
    add-int/lit8 v13, v11, 0x1

    .line 161
    .line 162
    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    .line 163
    .line 164
    .line 165
    move-result v11

    .line 166
    if-lt v11, v6, :cond_af

    .line 167
    .line 168
    and-int/lit16 v11, v11, 0x1fff

    .line 169
    .line 170
    shl-int/2addr v11, v12

    .line 171
    or-int/2addr v9, v11

    .line 172
    add-int/lit8 v12, v12, 0xd

    .line 173
    .line 174
    move v11, v13

    .line 175
    goto :goto_9f

    .line 176
    :cond_af
    shl-int/2addr v11, v12

    .line 177
    or-int/2addr v9, v11

    .line 178
    move v11, v13

    .line 179
    :cond_b2
    add-int/lit8 v12, v11, 0x1

    .line 180
    .line 181
    invoke-virtual {v1, v11}, Ljava/lang/String;->charAt(I)C

    .line 182
    .line 183
    .line 184
    move-result v11

    .line 185
    if-lt v11, v6, :cond_d0

    .line 186
    .line 187
    and-int/lit16 v11, v11, 0x1fff

    .line 188
    .line 189
    move v13, v8

    .line 190
    :goto_bd
    add-int/lit8 v14, v12, 0x1

    .line 191
    .line 192
    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    .line 193
    .line 194
    .line 195
    move-result v12

    .line 196
    if-lt v12, v6, :cond_cd

    .line 197
    .line 198
    and-int/lit16 v12, v12, 0x1fff

    .line 199
    .line 200
    shl-int/2addr v12, v13

    .line 201
    or-int/2addr v11, v12

    .line 202
    add-int/lit8 v13, v13, 0xd

    .line 203
    .line 204
    move v12, v14

    .line 205
    goto :goto_bd

    .line 206
    :cond_cd
    shl-int/2addr v12, v13

    .line 207
    or-int/2addr v11, v12

    .line 208
    move v12, v14

    .line 209
    :cond_d0
    add-int/lit8 v13, v12, 0x1

    .line 210
    .line 211
    invoke-virtual {v1, v12}, Ljava/lang/String;->charAt(I)C

    .line 212
    .line 213
    .line 214
    move-result v12

    .line 215
    if-lt v12, v6, :cond_ee

    .line 216
    .line 217
    and-int/lit16 v12, v12, 0x1fff

    .line 218
    .line 219
    move v14, v8

    .line 220
    :goto_db
    add-int/lit8 v15, v13, 0x1

    .line 221
    .line 222
    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    .line 223
    .line 224
    .line 225
    move-result v13

    .line 226
    if-lt v13, v6, :cond_eb

    .line 227
    .line 228
    and-int/lit16 v13, v13, 0x1fff

    .line 229
    .line 230
    shl-int/2addr v13, v14

    .line 231
    or-int/2addr v12, v13

    .line 232
    add-int/lit8 v14, v14, 0xd

    .line 233
    .line 234
    move v13, v15

    .line 235
    goto :goto_db

    .line 236
    :cond_eb
    shl-int/2addr v13, v14

    .line 237
    or-int/2addr v12, v13

    .line 238
    move v13, v15

    .line 239
    :cond_ee
    add-int/lit8 v14, v13, 0x1

    .line 240
    .line 241
    invoke-virtual {v1, v13}, Ljava/lang/String;->charAt(I)C

    .line 242
    .line 243
    .line 244
    move-result v13

    .line 245
    if-lt v13, v6, :cond_10e

    .line 246
    .line 247
    and-int/lit16 v13, v13, 0x1fff

    .line 248
    .line 249
    move v15, v8

    .line 250
    :goto_f9
    add-int/lit8 v16, v14, 0x1

    .line 251
    .line 252
    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    .line 253
    .line 254
    .line 255
    move-result v14

    .line 256
    if-lt v14, v6, :cond_10a

    .line 257
    .line 258
    and-int/lit16 v14, v14, 0x1fff

    .line 259
    .line 260
    shl-int/2addr v14, v15

    .line 261
    or-int/2addr v13, v14

    .line 262
    add-int/lit8 v15, v15, 0xd

    .line 263
    .line 264
    move/from16 v14, v16

    .line 265
    .line 266
    goto :goto_f9

    .line 267
    :cond_10a
    shl-int/2addr v14, v15

    .line 268
    or-int/2addr v13, v14

    .line 269
    move/from16 v14, v16

    .line 270
    .line 271
    :cond_10e
    add-int/lit8 v15, v14, 0x1

    .line 272
    .line 273
    invoke-virtual {v1, v14}, Ljava/lang/String;->charAt(I)C

    .line 274
    .line 275
    .line 276
    move-result v14

    .line 277
    if-lt v14, v6, :cond_131

    .line 278
    .line 279
    and-int/lit16 v14, v14, 0x1fff

    .line 280
    .line 281
    move/from16 v16, v8

    .line 282
    .line 283
    :goto_11a
    add-int/lit8 v17, v15, 0x1

    .line 284
    .line 285
    invoke-virtual {v1, v15}, Ljava/lang/String;->charAt(I)C

    .line 286
    .line 287
    .line 288
    move-result v15

    .line 289
    if-lt v15, v6, :cond_12c

    .line 290
    .line 291
    and-int/lit16 v15, v15, 0x1fff

    .line 292
    .line 293
    shl-int v15, v15, v16

    .line 294
    .line 295
    or-int/2addr v14, v15

    .line 296
    add-int/lit8 v16, v16, 0xd

    .line 297
    .line 298
    move/from16 v15, v17

    .line 299
    .line 300
    goto :goto_11a

    .line 301
    :cond_12c
    shl-int v15, v15, v16

    .line 302
    .line 303
    or-int/2addr v14, v15

    .line 304
    move/from16 v15, v17

    .line 305
    .line 306
    :cond_131
    add-int/lit8 v16, v15, 0x1

    .line 307
    .line 308
    invoke-virtual {v1, v15}, Ljava/lang/String;->charAt(I)C

    .line 309
    .line 310
    .line 311
    move-result v15

    .line 312
    if-lt v15, v6, :cond_159

    .line 313
    .line 314
    and-int/lit16 v15, v15, 0x1fff

    .line 315
    .line 316
    move/from16 v17, v2

    .line 317
    .line 318
    move/from16 v2, v16

    .line 319
    .line 320
    move/from16 v16, v8

    .line 321
    .line 322
    :goto_141
    add-int/lit8 v18, v2, 0x1

    .line 323
    .line 324
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 325
    .line 326
    .line 327
    move-result v2

    .line 328
    if-lt v2, v6, :cond_153

    .line 329
    .line 330
    and-int/lit16 v2, v2, 0x1fff

    .line 331
    .line 332
    shl-int v2, v2, v16

    .line 333
    .line 334
    or-int/2addr v15, v2

    .line 335
    add-int/lit8 v16, v16, 0xd

    .line 336
    .line 337
    move/from16 v2, v18

    .line 338
    .line 339
    goto :goto_141

    .line 340
    :cond_153
    shl-int v2, v2, v16

    .line 341
    .line 342
    or-int/2addr v15, v2

    .line 343
    move/from16 v16, v18

    .line 344
    .line 345
    goto :goto_15b

    .line 346
    :cond_159
    move/from16 v17, v2

    .line 347
    .line 348
    :goto_15b
    add-int v2, v15, v13

    .line 349
    .line 350
    add-int/2addr v2, v14

    .line 351
    new-array v2, v2, [I

    .line 352
    .line 353
    mul-int/lit8 v14, v5, 0x2

    .line 354
    .line 355
    add-int/2addr v14, v7

    .line 356
    move v7, v9

    .line 357
    move v9, v8

    .line 358
    move v8, v11

    .line 359
    move-object v11, v2

    .line 360
    move v2, v5

    .line 361
    move/from16 v5, v16

    .line 362
    .line 363
    :goto_16a
    sget-object v3, Lde0;->p:Lsun/misc/Unsafe;

    .line 364
    .line 365
    iget-object v9, v0, Ldo0;->c:[Ljava/lang/Object;

    .line 366
    .line 367
    iget-object v6, v0, Ldo0;->a:Lxd0;

    .line 368
    .line 369
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 370
    .line 371
    .line 372
    move-result-object v6

    .line 373
    move/from16 v20, v2

    .line 374
    .line 375
    mul-int/lit8 v2, v12, 0x3

    .line 376
    .line 377
    new-array v2, v2, [I

    .line 378
    .line 379
    mul-int/lit8 v12, v12, 0x2

    .line 380
    .line 381
    new-array v12, v12, [Ljava/lang/Object;

    .line 382
    .line 383
    add-int/2addr v13, v15

    .line 384
    move/from16 v24, v13

    .line 385
    .line 386
    move/from16 v23, v15

    .line 387
    .line 388
    const/16 v21, 0x0

    .line 389
    .line 390
    const/16 v22, 0x0

    .line 391
    .line 392
    :goto_187
    if-ge v5, v4, :cond_3be

    .line 393
    .line 394
    add-int/lit8 v25, v5, 0x1

    .line 395
    .line 396
    invoke-virtual {v1, v5}, Ljava/lang/String;->charAt(I)C

    .line 397
    .line 398
    .line 399
    move-result v5

    .line 400
    move-object/from16 v26, v2

    .line 401
    .line 402
    const v2, 0xd800

    .line 403
    .line 404
    .line 405
    if-lt v5, v2, :cond_1bb

    .line 406
    .line 407
    and-int/lit16 v5, v5, 0x1fff

    .line 408
    .line 409
    move/from16 v2, v25

    .line 410
    .line 411
    const/16 v25, 0xd

    .line 412
    .line 413
    :goto_19c
    add-int/lit8 v27, v2, 0x1

    .line 414
    .line 415
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 416
    .line 417
    .line 418
    move-result v2

    .line 419
    move/from16 v28, v4

    .line 420
    .line 421
    const v4, 0xd800

    .line 422
    .line 423
    .line 424
    if-lt v2, v4, :cond_1b5

    .line 425
    .line 426
    and-int/lit16 v2, v2, 0x1fff

    .line 427
    .line 428
    shl-int v2, v2, v25

    .line 429
    .line 430
    or-int/2addr v5, v2

    .line 431
    add-int/lit8 v25, v25, 0xd

    .line 432
    .line 433
    move/from16 v2, v27

    .line 434
    .line 435
    move/from16 v4, v28

    .line 436
    .line 437
    goto :goto_19c

    .line 438
    :cond_1b5
    shl-int v2, v2, v25

    .line 439
    .line 440
    or-int/2addr v5, v2

    .line 441
    move/from16 v2, v27

    .line 442
    .line 443
    goto :goto_1bf

    .line 444
    :cond_1bb
    move/from16 v28, v4

    .line 445
    .line 446
    move/from16 v2, v25

    .line 447
    .line 448
    :goto_1bf
    add-int/lit8 v4, v2, 0x1

    .line 449
    .line 450
    invoke-virtual {v1, v2}, Ljava/lang/String;->charAt(I)C

    .line 451
    .line 452
    .line 453
    move-result v2

    .line 454
    move/from16 v25, v4

    .line 455
    .line 456
    const v4, 0xd800

    .line 457
    .line 458
    .line 459
    if-lt v2, v4, :cond_1f1

    .line 460
    .line 461
    and-int/lit16 v2, v2, 0x1fff

    .line 462
    .line 463
    move/from16 v4, v25

    .line 464
    .line 465
    const/16 v25, 0xd

    .line 466
    .line 467
    :goto_1d2
    add-int/lit8 v27, v4, 0x1

    .line 468
    .line 469
    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    .line 470
    .line 471
    .line 472
    move-result v4

    .line 473
    move/from16 v29, v2

    .line 474
    .line 475
    const v2, 0xd800

    .line 476
    .line 477
    .line 478
    if-lt v4, v2, :cond_1ea

    .line 479
    .line 480
    and-int/lit16 v2, v4, 0x1fff

    .line 481
    .line 482
    shl-int v2, v2, v25

    .line 483
    .line 484
    or-int v2, v29, v2

    .line 485
    .line 486
    add-int/lit8 v25, v25, 0xd

    .line 487
    .line 488
    move/from16 v4, v27

    .line 489
    .line 490
    goto :goto_1d2

    .line 491
    :cond_1ea
    shl-int v2, v4, v25

    .line 492
    .line 493
    or-int v2, v29, v2

    .line 494
    .line 495
    move/from16 v4, v27

    .line 496
    .line 497
    goto :goto_1f3

    .line 498
    :cond_1f1
    move/from16 v4, v25

    .line 499
    .line 500
    :goto_1f3
    move/from16 v25, v5

    .line 501
    .line 502
    and-int/lit16 v5, v2, 0xff

    .line 503
    .line 504
    move/from16 v27, v7

    .line 505
    .line 506
    and-int/lit16 v7, v2, 0x400

    .line 507
    .line 508
    if-eqz v7, :cond_203

    .line 509
    .line 510
    add-int/lit8 v7, v21, 0x1

    .line 511
    .line 512
    aput v22, v11, v21

    .line 513
    .line 514
    move/from16 v21, v7

    .line 515
    .line 516
    :cond_203
    const/16 v7, 0x33

    .line 517
    .line 518
    move/from16 v31, v8

    .line 519
    .line 520
    if-lt v5, v7, :cond_2a2

    .line 521
    .line 522
    add-int/lit8 v7, v4, 0x1

    .line 523
    .line 524
    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    .line 525
    .line 526
    .line 527
    move-result v4

    .line 528
    const v8, 0xd800

    .line 529
    .line 530
    .line 531
    if-lt v4, v8, :cond_232

    .line 532
    .line 533
    and-int/lit16 v4, v4, 0x1fff

    .line 534
    .line 535
    const/16 v32, 0xd

    .line 536
    .line 537
    :goto_218
    add-int/lit8 v33, v7, 0x1

    .line 538
    .line 539
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 540
    .line 541
    .line 542
    move-result v7

    .line 543
    if-lt v7, v8, :cond_22d

    .line 544
    .line 545
    and-int/lit16 v7, v7, 0x1fff

    .line 546
    .line 547
    shl-int v7, v7, v32

    .line 548
    .line 549
    or-int/2addr v4, v7

    .line 550
    add-int/lit8 v32, v32, 0xd

    .line 551
    .line 552
    move/from16 v7, v33

    .line 553
    .line 554
    const v8, 0xd800

    .line 555
    .line 556
    .line 557
    goto :goto_218

    .line 558
    :cond_22d
    shl-int v7, v7, v32

    .line 559
    .line 560
    or-int/2addr v4, v7

    .line 561
    move/from16 v7, v33

    .line 562
    .line 563
    :cond_232
    add-int/lit8 v8, v5, -0x33

    .line 564
    .line 565
    move/from16 v32, v4

    .line 566
    .line 567
    const/16 v4, 0x9

    .line 568
    .line 569
    if-eq v8, v4, :cond_253

    .line 570
    .line 571
    const/16 v4, 0x11

    .line 572
    .line 573
    if-ne v8, v4, :cond_23f

    .line 574
    .line 575
    goto :goto_253

    .line 576
    :cond_23f
    const/16 v4, 0xc

    .line 577
    .line 578
    if-ne v8, v4, :cond_260

    .line 579
    .line 580
    if-nez v10, :cond_260

    .line 581
    .line 582
    div-int/lit8 v4, v22, 0x3

    .line 583
    .line 584
    mul-int/lit8 v4, v4, 0x2

    .line 585
    .line 586
    add-int/lit8 v4, v4, 0x1

    .line 587
    .line 588
    add-int/lit8 v8, v14, 0x1

    .line 589
    .line 590
    aget-object v14, v9, v14

    .line 591
    .line 592
    aput-object v14, v12, v4

    .line 593
    .line 594
    :goto_251
    move v14, v8

    .line 595
    goto :goto_260

    .line 596
    :cond_253
    :goto_253
    div-int/lit8 v4, v22, 0x3

    .line 597
    .line 598
    mul-int/lit8 v4, v4, 0x2

    .line 599
    .line 600
    add-int/lit8 v4, v4, 0x1

    .line 601
    .line 602
    add-int/lit8 v8, v14, 0x1

    .line 603
    .line 604
    aget-object v14, v9, v14

    .line 605
    .line 606
    aput-object v14, v12, v4

    .line 607
    .line 608
    goto :goto_251

    .line 609
    :cond_260
    :goto_260
    mul-int/lit8 v4, v32, 0x2

    .line 610
    .line 611
    aget-object v8, v9, v4

    .line 612
    .line 613
    move/from16 v29, v4

    .line 614
    .line 615
    instance-of v4, v8, Ljava/lang/reflect/Field;

    .line 616
    .line 617
    if-eqz v4, :cond_26e

    .line 618
    .line 619
    check-cast v8, Ljava/lang/reflect/Field;

    .line 620
    .line 621
    :goto_26c
    move v4, v7

    .line 622
    goto :goto_277

    .line 623
    :cond_26e
    check-cast v8, Ljava/lang/String;

    .line 624
    .line 625
    invoke-static {v6, v8}, Lde0;->P(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 626
    .line 627
    .line 628
    move-result-object v8

    .line 629
    aput-object v8, v9, v29

    .line 630
    .line 631
    goto :goto_26c

    .line 632
    :goto_277
    invoke-virtual {v3, v8}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    .line 633
    .line 634
    .line 635
    move-result-wide v7

    .line 636
    long-to-int v7, v7

    .line 637
    add-int/lit8 v8, v29, 0x1

    .line 638
    .line 639
    move/from16 v29, v4

    .line 640
    .line 641
    aget-object v4, v9, v8

    .line 642
    .line 643
    move/from16 v30, v7

    .line 644
    .line 645
    instance-of v7, v4, Ljava/lang/reflect/Field;

    .line 646
    .line 647
    if-eqz v7, :cond_28b

    .line 648
    .line 649
    check-cast v4, Ljava/lang/reflect/Field;

    .line 650
    .line 651
    goto :goto_293

    .line 652
    :cond_28b
    check-cast v4, Ljava/lang/String;

    .line 653
    .line 654
    invoke-static {v6, v4}, Lde0;->P(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 655
    .line 656
    .line 657
    move-result-object v4

    .line 658
    aput-object v4, v9, v8

    .line 659
    .line 660
    :goto_293
    invoke-virtual {v3, v4}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    .line 661
    .line 662
    .line 663
    move-result-wide v7

    .line 664
    long-to-int v4, v7

    .line 665
    move/from16 v7, v30

    .line 666
    .line 667
    move/from16 v30, v29

    .line 668
    .line 669
    move/from16 v29, v7

    .line 670
    .line 671
    move v7, v4

    .line 672
    const/4 v4, 0x0

    .line 673
    goto/16 :goto_389

    .line 674
    .line 675
    :cond_2a2
    add-int/lit8 v7, v14, 0x1

    .line 676
    .line 677
    aget-object v8, v9, v14

    .line 678
    .line 679
    check-cast v8, Ljava/lang/String;

    .line 680
    .line 681
    invoke-static {v6, v8}, Lde0;->P(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 682
    .line 683
    .line 684
    move-result-object v8

    .line 685
    move/from16 v32, v7

    .line 686
    .line 687
    const/16 v7, 0x9

    .line 688
    .line 689
    if-eq v5, v7, :cond_310

    .line 690
    .line 691
    const/16 v7, 0x11

    .line 692
    .line 693
    if-ne v5, v7, :cond_2b7

    .line 694
    .line 695
    goto :goto_310

    .line 696
    :cond_2b7
    const/16 v7, 0x1b

    .line 697
    .line 698
    if-eq v5, v7, :cond_303

    .line 699
    .line 700
    const/16 v7, 0x31

    .line 701
    .line 702
    if-ne v5, v7, :cond_2c0

    .line 703
    .line 704
    goto :goto_303

    .line 705
    :cond_2c0
    const/16 v7, 0xc

    .line 706
    .line 707
    if-eq v5, v7, :cond_2f4

    .line 708
    .line 709
    const/16 v7, 0x1e

    .line 710
    .line 711
    if-eq v5, v7, :cond_2f4

    .line 712
    .line 713
    const/16 v7, 0x2c

    .line 714
    .line 715
    if-ne v5, v7, :cond_2cd

    .line 716
    .line 717
    goto :goto_2f4

    .line 718
    :cond_2cd
    const/16 v7, 0x32

    .line 719
    .line 720
    if-ne v5, v7, :cond_31c

    .line 721
    .line 722
    add-int/lit8 v7, v23, 0x1

    .line 723
    .line 724
    aput v22, v11, v23

    .line 725
    .line 726
    div-int/lit8 v23, v22, 0x3

    .line 727
    .line 728
    mul-int/lit8 v23, v23, 0x2

    .line 729
    .line 730
    add-int/lit8 v29, v14, 0x2

    .line 731
    .line 732
    aget-object v30, v9, v32

    .line 733
    .line 734
    aput-object v30, v12, v23

    .line 735
    .line 736
    move/from16 v30, v7

    .line 737
    .line 738
    and-int/lit16 v7, v2, 0x800

    .line 739
    .line 740
    if-eqz v7, :cond_2f1

    .line 741
    .line 742
    add-int/lit8 v23, v23, 0x1

    .line 743
    .line 744
    add-int/lit8 v7, v14, 0x3

    .line 745
    .line 746
    aget-object v14, v9, v29

    .line 747
    .line 748
    aput-object v14, v12, v23

    .line 749
    .line 750
    move v14, v7

    .line 751
    :goto_2ee
    move/from16 v23, v30

    .line 752
    .line 753
    goto :goto_31e

    .line 754
    :cond_2f1
    move/from16 v14, v29

    .line 755
    .line 756
    goto :goto_2ee

    .line 757
    :cond_2f4
    :goto_2f4
    if-nez v10, :cond_31c

    .line 758
    .line 759
    div-int/lit8 v7, v22, 0x3

    .line 760
    .line 761
    mul-int/lit8 v7, v7, 0x2

    .line 762
    .line 763
    add-int/lit8 v7, v7, 0x1

    .line 764
    .line 765
    add-int/lit8 v14, v14, 0x2

    .line 766
    .line 767
    aget-object v29, v9, v32

    .line 768
    .line 769
    aput-object v29, v12, v7

    .line 770
    .line 771
    goto :goto_31e

    .line 772
    :cond_303
    :goto_303
    div-int/lit8 v7, v22, 0x3

    .line 773
    .line 774
    mul-int/lit8 v7, v7, 0x2

    .line 775
    .line 776
    add-int/lit8 v7, v7, 0x1

    .line 777
    .line 778
    add-int/lit8 v14, v14, 0x2

    .line 779
    .line 780
    aget-object v29, v9, v32

    .line 781
    .line 782
    aput-object v29, v12, v7

    .line 783
    .line 784
    goto :goto_31e

    .line 785
    :cond_310
    :goto_310
    div-int/lit8 v7, v22, 0x3

    .line 786
    .line 787
    mul-int/lit8 v7, v7, 0x2

    .line 788
    .line 789
    add-int/lit8 v7, v7, 0x1

    .line 790
    .line 791
    invoke-virtual {v8}, Ljava/lang/reflect/Field;->getType()Ljava/lang/Class;

    .line 792
    .line 793
    .line 794
    move-result-object v14

    .line 795
    aput-object v14, v12, v7

    .line 796
    .line 797
    :cond_31c
    move/from16 v14, v32

    .line 798
    .line 799
    :goto_31e
    invoke-virtual {v3, v8}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    .line 800
    .line 801
    .line 802
    move-result-wide v7

    .line 803
    long-to-int v7, v7

    .line 804
    and-int/lit16 v8, v2, 0x1000

    .line 805
    .line 806
    move/from16 v29, v7

    .line 807
    .line 808
    const/16 v7, 0x1000

    .line 809
    .line 810
    if-ne v8, v7, :cond_375

    .line 811
    .line 812
    const/16 v7, 0x11

    .line 813
    .line 814
    if-gt v5, v7, :cond_375

    .line 815
    .line 816
    add-int/lit8 v7, v4, 0x1

    .line 817
    .line 818
    invoke-virtual {v1, v4}, Ljava/lang/String;->charAt(I)C

    .line 819
    .line 820
    .line 821
    move-result v4

    .line 822
    const v8, 0xd800

    .line 823
    .line 824
    .line 825
    if-lt v4, v8, :cond_354

    .line 826
    .line 827
    and-int/lit16 v4, v4, 0x1fff

    .line 828
    .line 829
    const/16 v19, 0xd

    .line 830
    .line 831
    :goto_33e
    add-int/lit8 v30, v7, 0x1

    .line 832
    .line 833
    invoke-virtual {v1, v7}, Ljava/lang/String;->charAt(I)C

    .line 834
    .line 835
    .line 836
    move-result v7

    .line 837
    if-lt v7, v8, :cond_350

    .line 838
    .line 839
    and-int/lit16 v7, v7, 0x1fff

    .line 840
    .line 841
    shl-int v7, v7, v19

    .line 842
    .line 843
    or-int/2addr v4, v7

    .line 844
    add-int/lit8 v19, v19, 0xd

    .line 845
    .line 846
    move/from16 v7, v30

    .line 847
    .line 848
    goto :goto_33e

    .line 849
    :cond_350
    shl-int v7, v7, v19

    .line 850
    .line 851
    or-int/2addr v4, v7

    .line 852
    goto :goto_356

    .line 853
    :cond_354
    move/from16 v30, v7

    .line 854
    .line 855
    :goto_356
    mul-int/lit8 v7, v20, 0x2

    .line 856
    .line 857
    div-int/lit8 v19, v4, 0x20

    .line 858
    .line 859
    add-int v19, v19, v7

    .line 860
    .line 861
    aget-object v7, v9, v19

    .line 862
    .line 863
    instance-of v8, v7, Ljava/lang/reflect/Field;

    .line 864
    .line 865
    if-eqz v8, :cond_365

    .line 866
    .line 867
    check-cast v7, Ljava/lang/reflect/Field;

    .line 868
    .line 869
    goto :goto_36d

    .line 870
    :cond_365
    check-cast v7, Ljava/lang/String;

    .line 871
    .line 872
    invoke-static {v6, v7}, Lde0;->P(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 873
    .line 874
    .line 875
    move-result-object v7

    .line 876
    aput-object v7, v9, v19

    .line 877
    .line 878
    :goto_36d
    invoke-virtual {v3, v7}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    .line 879
    .line 880
    .line 881
    move-result-wide v7

    .line 882
    long-to-int v7, v7

    .line 883
    rem-int/lit8 v4, v4, 0x20

    .line 884
    .line 885
    goto :goto_37b

    .line 886
    :cond_375
    const v7, 0xfffff

    .line 887
    .line 888
    .line 889
    move/from16 v30, v4

    .line 890
    .line 891
    const/4 v4, 0x0

    .line 892
    :goto_37b
    const/16 v8, 0x12

    .line 893
    .line 894
    if-lt v5, v8, :cond_389

    .line 895
    .line 896
    const/16 v8, 0x31

    .line 897
    .line 898
    if-gt v5, v8, :cond_389

    .line 899
    .line 900
    add-int/lit8 v8, v24, 0x1

    .line 901
    .line 902
    aput v29, v11, v24

    .line 903
    .line 904
    move/from16 v24, v8

    .line 905
    .line 906
    :cond_389
    :goto_389
    add-int/lit8 v8, v22, 0x1

    .line 907
    .line 908
    aput v25, v26, v22

    .line 909
    .line 910
    add-int/lit8 v19, v22, 0x2

    .line 911
    .line 912
    move-object/from16 v25, v1

    .line 913
    .line 914
    and-int/lit16 v1, v2, 0x200

    .line 915
    .line 916
    if-eqz v1, :cond_398

    .line 917
    .line 918
    const/high16 v1, 0x20000000

    .line 919
    .line 920
    goto :goto_399

    .line 921
    :cond_398
    const/4 v1, 0x0

    .line 922
    :goto_399
    and-int/lit16 v2, v2, 0x100

    .line 923
    .line 924
    if-eqz v2, :cond_3a0

    .line 925
    .line 926
    const/high16 v2, 0x10000000

    .line 927
    .line 928
    goto :goto_3a1

    .line 929
    :cond_3a0
    const/4 v2, 0x0

    .line 930
    :goto_3a1
    or-int/2addr v1, v2

    .line 931
    shl-int/lit8 v2, v5, 0x14

    .line 932
    .line 933
    or-int/2addr v1, v2

    .line 934
    or-int v1, v1, v29

    .line 935
    .line 936
    aput v1, v26, v8

    .line 937
    .line 938
    add-int/lit8 v22, v22, 0x3

    .line 939
    .line 940
    shl-int/lit8 v1, v4, 0x14

    .line 941
    .line 942
    or-int/2addr v1, v7

    .line 943
    aput v1, v26, v19

    .line 944
    .line 945
    move-object/from16 v1, v25

    .line 946
    .line 947
    move-object/from16 v2, v26

    .line 948
    .line 949
    move/from16 v7, v27

    .line 950
    .line 951
    move/from16 v4, v28

    .line 952
    .line 953
    move/from16 v5, v30

    .line 954
    .line 955
    move/from16 v8, v31

    .line 956
    .line 957
    goto/16 :goto_187

    .line 958
    .line 959
    :cond_3be
    move-object/from16 v26, v2

    .line 960
    .line 961
    move/from16 v27, v7

    .line 962
    .line 963
    move/from16 v31, v8

    .line 964
    .line 965
    new-instance v4, Lde0;

    .line 966
    .line 967
    iget-object v9, v0, Ldo0;->a:Lxd0;

    .line 968
    .line 969
    move-object/from16 v14, p1

    .line 970
    .line 971
    move-object/from16 v16, p3

    .line 972
    .line 973
    move-object/from16 v17, p4

    .line 974
    .line 975
    move-object/from16 v18, p5

    .line 976
    .line 977
    move-object v6, v12

    .line 978
    move v12, v15

    .line 979
    move-object/from16 v5, v26

    .line 980
    .line 981
    move-object/from16 v15, p2

    .line 982
    .line 983
    invoke-direct/range {v4 .. v18}, Lde0;-><init>([I[Ljava/lang/Object;IILxd0;Z[IIILng0;Le90;Lp61;Lfs;Lrb0;)V

    .line 984
    .line 985
    .line 986
    return-object v4
.end method

.method public static E(I)J
    .registers 3

    .line 1
    const v0, 0xfffff

    .line 2
    .line 3
    .line 4
    and-int/2addr p0, v0

    .line 5
    int-to-long v0, p0

    .line 6
    return-wide v0
.end method

.method public static F(JLjava/lang/Object;)I
    .registers 4

    .line 1
    sget-object v0, Lk71;->c:Lh71;

    .line 2
    .line 3
    invoke-virtual {v0, p0, p1, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Integer;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 10
    .line 11
    .line 12
    move-result p0

    .line 13
    return p0
.end method

.method public static G(JLjava/lang/Object;)J
    .registers 4

    .line 1
    sget-object v0, Lk71;->c:Lh71;

    .line 2
    .line 3
    invoke-virtual {v0, p0, p1, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/lang/Long;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    .line 10
    .line 11
    .line 12
    move-result-wide p0

    .line 13
    return-wide p0
.end method

.method public static P(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    .registers 7

    .line 1
    :try_start_0
    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 2
    .line 3
    .line 4
    move-result-object p0
    :try_end_4
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_4} :catch_5

    .line 5
    return-object p0

    .line 6
    :catch_5
    invoke-virtual {p0}, Ljava/lang/Class;->getDeclaredFields()[Ljava/lang/reflect/Field;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    array-length v1, v0

    .line 11
    const/4 v2, 0x0

    .line 12
    :goto_b
    if-ge v2, v1, :cond_1d

    .line 13
    .line 14
    aget-object v3, v0, v2

    .line 15
    .line 16
    invoke-virtual {v3}, Ljava/lang/reflect/Field;->getName()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object v4

    .line 20
    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v4

    .line 24
    if-eqz v4, :cond_1a

    .line 25
    .line 26
    return-object v3

    .line 27
    :cond_1a
    add-int/lit8 v2, v2, 0x1

    .line 28
    .line 29
    goto :goto_b

    .line 30
    :cond_1d
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    invoke-static {p1, p0, v0}, Lm0;->e(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 39
    .line 40
    .line 41
    const/4 p0, 0x0

    .line 42
    return-object p0
.end method

.method public static V(I)I
    .registers 2

    .line 1
    const/high16 v0, 0xff00000

    .line 2
    .line 3
    and-int/2addr p0, v0

    .line 4
    ushr-int/lit8 p0, p0, 0x14

    .line 5
    .line 6
    return p0
.end method

.method public static Z(ILjava/lang/Object;Ldb0;)V
    .registers 4

    .line 1
    instance-of v0, p1, Ljava/lang/String;

    .line 2
    .line 3
    if-eqz v0, :cond_e

    .line 4
    .line 5
    check-cast p1, Ljava/lang/String;

    .line 6
    .line 7
    iget-object p2, p2, Ldb0;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p2, Lde;

    .line 10
    .line 11
    invoke-virtual {p2, p0, p1}, Lde;->A(ILjava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_e
    check-cast p1, Lqb;

    .line 16
    .line 17
    invoke-virtual {p2, p0, p1}, Ldb0;->x(ILqb;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public static l(Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-static {p0}, Lde0;->u(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    const-string v0, "Mutating immutable message: "

    .line 9
    .line 10
    invoke-static {p0, v0}, Lm0;->w(Ljava/lang/Object;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public static m([BIILnd1;Ljava/lang/Class;Lz8;)I
    .registers 7

    .line 1
    invoke-virtual {p3}, Ljava/lang/Enum;->ordinal()I

    .line 2
    .line 3
    .line 4
    move-result p3

    .line 5
    const/4 v0, 0x0

    .line 6
    packed-switch p3, :pswitch_data_b0

    .line 7
    .line 8
    .line 9
    :pswitch_8
    const-string p0, "unsupported field type."

    .line 10
    .line 11
    invoke-static {p0}, Lm0;->t(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    return v0

    .line 15
    :pswitch_e
    invoke-static {p0, p1, p5}, Ln40;->v([BILz8;)I

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    iget-wide p1, p5, Lz8;->b:J

    .line 20
    .line 21
    invoke-static {p1, p2}, Lwd;->c(J)J

    .line 22
    .line 23
    .line 24
    move-result-wide p1

    .line 25
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    iput-object p1, p5, Lz8;->c:Ljava/lang/Object;

    .line 30
    .line 31
    return p0

    .line 32
    :pswitch_1f
    invoke-static {p0, p1, p5}, Ln40;->t([BILz8;)I

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    iget p1, p5, Lz8;->a:I

    .line 37
    .line 38
    invoke-static {p1}, Lwd;->b(I)I

    .line 39
    .line 40
    .line 41
    move-result p1

    .line 42
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    iput-object p1, p5, Lz8;->c:Ljava/lang/Object;

    .line 47
    .line 48
    return p0

    .line 49
    :pswitch_30
    invoke-static {p0, p1, p5}, Ln40;->i([BILz8;)I

    .line 50
    .line 51
    .line 52
    move-result p0

    .line 53
    return p0

    .line 54
    :pswitch_35
    sget-object p3, Lhn0;->c:Lhn0;

    .line 55
    .line 56
    invoke-virtual {p3, p4}, Lhn0;->a(Ljava/lang/Class;)Les0;

    .line 57
    .line 58
    .line 59
    move-result-object p3

    .line 60
    invoke-static {p3, p0, p1, p2, p5}, Ln40;->m(Les0;[BIILz8;)I

    .line 61
    .line 62
    .line 63
    move-result p0

    .line 64
    return p0

    .line 65
    :pswitch_40
    invoke-static {p0, p1, p5}, Ln40;->p([BILz8;)I

    .line 66
    .line 67
    .line 68
    move-result p0

    .line 69
    return p0

    .line 70
    :pswitch_45
    invoke-static {p0, p1, p5}, Ln40;->v([BILz8;)I

    .line 71
    .line 72
    .line 73
    move-result p0

    .line 74
    iget-wide p1, p5, Lz8;->b:J

    .line 75
    .line 76
    const-wide/16 p3, 0x0

    .line 77
    .line 78
    cmp-long p1, p1, p3

    .line 79
    .line 80
    if-eqz p1, :cond_52

    .line 81
    .line 82
    const/4 v0, 0x1

    .line 83
    :cond_52
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    iput-object p1, p5, Lz8;->c:Ljava/lang/Object;

    .line 88
    .line 89
    return p0

    .line 90
    :pswitch_59
    invoke-static {p1, p0}, Ln40;->j(I[B)I

    .line 91
    .line 92
    .line 93
    move-result p0

    .line 94
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 95
    .line 96
    .line 97
    move-result-object p0

    .line 98
    iput-object p0, p5, Lz8;->c:Ljava/lang/Object;

    .line 99
    .line 100
    add-int/lit8 p1, p1, 0x4

    .line 101
    .line 102
    return p1

    .line 103
    :pswitch_66
    invoke-static {p1, p0}, Ln40;->k(I[B)J

    .line 104
    .line 105
    .line 106
    move-result-wide p2

    .line 107
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 108
    .line 109
    .line 110
    move-result-object p0

    .line 111
    iput-object p0, p5, Lz8;->c:Ljava/lang/Object;

    .line 112
    .line 113
    add-int/lit8 p1, p1, 0x8

    .line 114
    .line 115
    return p1

    .line 116
    :pswitch_73
    invoke-static {p0, p1, p5}, Ln40;->t([BILz8;)I

    .line 117
    .line 118
    .line 119
    move-result p0

    .line 120
    iget p1, p5, Lz8;->a:I

    .line 121
    .line 122
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    iput-object p1, p5, Lz8;->c:Ljava/lang/Object;

    .line 127
    .line 128
    return p0

    .line 129
    :pswitch_80
    invoke-static {p0, p1, p5}, Ln40;->v([BILz8;)I

    .line 130
    .line 131
    .line 132
    move-result p0

    .line 133
    iget-wide p1, p5, Lz8;->b:J

    .line 134
    .line 135
    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 136
    .line 137
    .line 138
    move-result-object p1

    .line 139
    iput-object p1, p5, Lz8;->c:Ljava/lang/Object;

    .line 140
    .line 141
    return p0

    .line 142
    :pswitch_8d
    invoke-static {p1, p0}, Ln40;->j(I[B)I

    .line 143
    .line 144
    .line 145
    move-result p0

    .line 146
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 147
    .line 148
    .line 149
    move-result p0

    .line 150
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 151
    .line 152
    .line 153
    move-result-object p0

    .line 154
    iput-object p0, p5, Lz8;->c:Ljava/lang/Object;

    .line 155
    .line 156
    add-int/lit8 p1, p1, 0x4

    .line 157
    .line 158
    return p1

    .line 159
    :pswitch_9e
    invoke-static {p1, p0}, Ln40;->k(I[B)J

    .line 160
    .line 161
    .line 162
    move-result-wide p2

    .line 163
    invoke-static {p2, p3}, Ljava/lang/Double;->longBitsToDouble(J)D

    .line 164
    .line 165
    .line 166
    move-result-wide p2

    .line 167
    invoke-static {p2, p3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 168
    .line 169
    .line 170
    move-result-object p0

    .line 171
    iput-object p0, p5, Lz8;->c:Ljava/lang/Object;

    .line 172
    .line 173
    add-int/lit8 p1, p1, 0x8

    .line 174
    .line 175
    return p1

    .line 176
    nop

    .line 177
    :pswitch_data_b0
    .packed-switch 0x0
        :pswitch_9e
        :pswitch_8d
        :pswitch_80
        :pswitch_80
        :pswitch_73
        :pswitch_66
        :pswitch_59
        :pswitch_45
        :pswitch_40
        :pswitch_8
        :pswitch_35
        :pswitch_30
        :pswitch_73
        :pswitch_73
        :pswitch_59
        :pswitch_66
        :pswitch_1f
        :pswitch_e
    .end packed-switch
.end method

.method public static u(Ljava/lang/Object;)Z
    .registers 2

    .line 1
    if-nez p0, :cond_4

    .line 2
    .line 3
    const/4 p0, 0x0

    .line 4
    return p0

    .line 5
    :cond_4
    instance-of v0, p0, Lr00;

    .line 6
    .line 7
    if-eqz v0, :cond_f

    .line 8
    .line 9
    check-cast p0, Lr00;

    .line 10
    .line 11
    invoke-virtual {p0}, Lr00;->isMutable()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    return p0

    .line 16
    :cond_f
    const/4 p0, 0x1

    .line 17
    return p0
.end method

.method public static w(Lr00;J)Ljava/util/List;
    .registers 4

    .line 1
    sget-object v0, Lk71;->c:Lh71;

    .line 2
    .line 3
    invoke-virtual {v0, p1, p2, p0}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Ljava/util/List;

    .line 8
    .line 9
    return-object p0
.end method


# virtual methods
.method public final A(ILjava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    invoke-virtual {p0, p1}, Lde0;->q(I)Les0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, p1}, Lde0;->W(I)I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const v2, 0xfffff

    .line 10
    .line 11
    .line 12
    and-int/2addr v1, v2

    .line 13
    int-to-long v1, v1

    .line 14
    invoke-virtual {p0, p1, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    if-nez p0, :cond_18

    .line 19
    .line 20
    invoke-interface {v0}, Les0;->d()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p0

    .line 24
    return-object p0

    .line 25
    :cond_18
    sget-object p0, Lde0;->p:Lsun/misc/Unsafe;

    .line 26
    .line 27
    invoke-virtual {p0, p2, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p0}, Lde0;->u(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    if-eqz p1, :cond_25

    .line 36
    .line 37
    return-object p0

    .line 38
    :cond_25
    invoke-interface {v0}, Les0;->d()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-eqz p0, :cond_2e

    .line 43
    .line 44
    invoke-interface {v0, p1, p0}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    return-object p1
.end method

.method public final B(IILjava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    invoke-virtual {p0, p2}, Lde0;->q(I)Les0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0, p1, p2, p3}, Lde0;->v(IILjava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    if-nez p1, :cond_f

    .line 10
    .line 11
    invoke-interface {v0}, Les0;->d()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0

    .line 16
    :cond_f
    sget-object p1, Lde0;->p:Lsun/misc/Unsafe;

    .line 17
    .line 18
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 19
    .line 20
    .line 21
    move-result p0

    .line 22
    const p2, 0xfffff

    .line 23
    .line 24
    .line 25
    and-int/2addr p0, p2

    .line 26
    int-to-long v1, p0

    .line 27
    invoke-virtual {p1, p3, v1, v2}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {p0}, Lde0;->u(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result p1

    .line 35
    if-eqz p1, :cond_25

    .line 36
    .line 37
    return-object p0

    .line 38
    :cond_25
    invoke-interface {v0}, Les0;->d()Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object p1

    .line 42
    if-eqz p0, :cond_2e

    .line 43
    .line 44
    invoke-interface {v0, p1, p0}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    return-object p1
.end method

.method public final H(Ljava/lang/Object;[BIIIJLz8;)I
    .registers 19

    .line 1
    move-wide/from16 v0, p6

    .line 2
    .line 3
    move-object/from16 v5, p8

    .line 4
    .line 5
    sget-object v2, Lde0;->p:Lsun/misc/Unsafe;

    .line 6
    .line 7
    invoke-virtual {p0, p5}, Lde0;->p(I)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object v3

    .line 11
    invoke-virtual {v2, p1, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    iget-object p0, p0, Lde0;->n:Lrb0;

    .line 16
    .line 17
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    move-object p0, v4

    .line 21
    check-cast p0, Lob0;

    .line 22
    .line 23
    iget-boolean p0, p0, Lob0;->f:Z

    .line 24
    .line 25
    if-nez p0, :cond_27

    .line 26
    .line 27
    sget-object p0, Lob0;->g:Lob0;

    .line 28
    .line 29
    invoke-virtual {p0}, Lob0;->b()Lob0;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-static {p0, v4}, Lrb0;->b(Ljava/lang/Object;Ljava/lang/Object;)Lob0;

    .line 34
    .line 35
    .line 36
    invoke-virtual {v2, p1, v0, v1, p0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 37
    .line 38
    .line 39
    move-object v4, p0

    .line 40
    :cond_27
    check-cast v3, Llb0;

    .line 41
    .line 42
    iget-object p0, v3, Llb0;->a:Ld8;

    .line 43
    .line 44
    move-object p1, v4

    .line 45
    check-cast p1, Lob0;

    .line 46
    .line 47
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    iget v1, v5, Lz8;->a:I

    .line 52
    .line 53
    if-ltz v1, :cond_95

    .line 54
    .line 55
    sub-int v2, p4, v0

    .line 56
    .line 57
    if-gt v1, v2, :cond_95

    .line 58
    .line 59
    add-int v6, v0, v1

    .line 60
    .line 61
    iget-object v7, p0, Ld8;->h:Ljava/lang/Object;

    .line 62
    .line 63
    const-string v1, ""

    .line 64
    .line 65
    move-object v8, v1

    .line 66
    move-object v9, v7

    .line 67
    :goto_42
    if-ge v0, v6, :cond_8a

    .line 68
    .line 69
    add-int/lit8 v1, v0, 0x1

    .line 70
    .line 71
    aget-byte v0, p2, v0

    .line 72
    .line 73
    if-gez v0, :cond_50

    .line 74
    .line 75
    invoke-static {v0, p2, v1, v5}, Ln40;->s(I[BILz8;)I

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    iget v0, v5, Lz8;->a:I

    .line 80
    .line 81
    :cond_50
    ushr-int/lit8 v2, v0, 0x3

    .line 82
    .line 83
    and-int/lit8 v3, v0, 0x7

    .line 84
    .line 85
    const/4 v4, 0x1

    .line 86
    if-eq v2, v4, :cond_72

    .line 87
    .line 88
    const/4 v4, 0x2

    .line 89
    if-eq v2, v4, :cond_5b

    .line 90
    .line 91
    goto :goto_85

    .line 92
    :cond_5b
    iget-object v2, p0, Ld8;->g:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v2, Lnd1;

    .line 95
    .line 96
    iget v4, v2, Lnd1;->g:I

    .line 97
    .line 98
    if-ne v3, v4, :cond_85

    .line 99
    .line 100
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    .line 102
    .line 103
    move-result-object v4

    .line 104
    move-object v0, p2

    .line 105
    move-object v3, v2

    .line 106
    move v2, p4

    .line 107
    invoke-static/range {v0 .. v5}, Lde0;->m([BIILnd1;Ljava/lang/Class;Lz8;)I

    .line 108
    .line 109
    .line 110
    move-result v1

    .line 111
    iget-object v9, v5, Lz8;->c:Ljava/lang/Object;

    .line 112
    .line 113
    :goto_70
    move v0, v1

    .line 114
    goto :goto_42

    .line 115
    :cond_72
    iget-object v2, p0, Ld8;->f:Ljava/lang/Object;

    .line 116
    .line 117
    check-cast v2, Lnd1;

    .line 118
    .line 119
    iget v4, v2, Lnd1;->g:I

    .line 120
    .line 121
    if-ne v3, v4, :cond_85

    .line 122
    .line 123
    const/4 v4, 0x0

    .line 124
    move-object v0, p2

    .line 125
    move-object v3, v2

    .line 126
    move v2, p4

    .line 127
    invoke-static/range {v0 .. v5}, Lde0;->m([BIILnd1;Ljava/lang/Class;Lz8;)I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    iget-object v8, v5, Lz8;->c:Ljava/lang/Object;

    .line 132
    .line 133
    goto :goto_70

    .line 134
    :cond_85
    :goto_85
    invoke-static {v0, p2, v1, p4, v5}, Ln40;->V(I[BIILz8;)I

    .line 135
    .line 136
    .line 137
    move-result v0

    .line 138
    goto :goto_42

    .line 139
    :cond_8a
    if-ne v0, v6, :cond_90

    .line 140
    .line 141
    invoke-virtual {p1, v8, v9}, Lob0;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    return v6

    .line 145
    :cond_90
    invoke-static {}, La50;->f()La50;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    throw p0

    .line 150
    :cond_95
    invoke-static {}, La50;->g()La50;

    .line 151
    .line 152
    .line 153
    move-result-object p0

    .line 154
    throw p0
.end method

.method public final I(Ljava/lang/Object;[BIIIIIIIJILz8;)I
    .registers 30

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v9, p6

    move/from16 v2, p7

    move-wide/from16 v3, p10

    move/from16 v10, p12

    .line 1
    sget-object v5, Lde0;->p:Lsun/misc/Unsafe;

    add-int/lit8 v6, v10, 0x2

    .line 2
    iget-object v7, v0, Lde0;->a:[I

    aget v6, v7, v6

    const v7, 0xfffff

    and-int/2addr v6, v7

    int-to-long v6, v6

    const/4 v8, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    packed-switch p9, :pswitch_data_1c0

    :cond_1f
    move/from16 v0, p3

    goto/16 :goto_1be

    :pswitch_23
    const/4 v3, 0x3

    if-ne v2, v3, :cond_1f

    .line 3
    invoke-virtual {v0, v9, v10, v1}, Lde0;->B(IILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    and-int/lit8 v3, p5, -0x8

    or-int/lit8 v7, v3, 0x4

    .line 4
    invoke-virtual {v0, v10}, Lde0;->q(I)Les0;

    move-result-object v3

    move-object/from16 v4, p2

    move/from16 v5, p3

    move/from16 v6, p4

    move-object/from16 v8, p13

    .line 5
    invoke-static/range {v2 .. v8}, Ln40;->L(Ljava/lang/Object;Les0;[BIIILz8;)I

    move-result v3

    .line 6
    invoke-virtual {v0, v9, v10, v1, v2}, Lde0;->U(IILjava/lang/Object;Ljava/lang/Object;)V

    return v3

    :pswitch_42
    move-object/from16 v11, p2

    move/from16 v8, p3

    move-object/from16 v13, p13

    if-nez v2, :cond_5f

    .line 7
    invoke-static {v11, v8, v13}, Ln40;->v([BILz8;)I

    move-result v0

    .line 8
    iget-wide v10, v13, Lz8;->b:J

    invoke-static {v10, v11}, Lwd;->c(J)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 9
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :cond_5f
    move v0, v8

    goto/16 :goto_1be

    :pswitch_62
    move-object/from16 v11, p2

    move/from16 v8, p3

    move-object/from16 v13, p13

    if-nez v2, :cond_5f

    .line 10
    invoke-static {v11, v8, v13}, Ln40;->t([BILz8;)I

    move-result v0

    .line 11
    iget v2, v13, Lz8;->a:I

    invoke-static {v2}, Lwd;->b(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 12
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_7f
    move-object/from16 v11, p2

    move/from16 v8, p3

    move-object/from16 v13, p13

    if-nez v2, :cond_5f

    .line 13
    invoke-static {v11, v8, v13}, Ln40;->t([BILz8;)I

    move-result v2

    .line 14
    iget v8, v13, Lz8;->a:I

    .line 15
    invoke-virtual {v0, v10}, Lde0;->o(I)V

    .line 16
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {v5, v1, v3, v4, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 17
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v2

    :pswitch_9b
    move-object/from16 v11, p2

    move/from16 v8, p3

    move-object/from16 v13, p13

    if-ne v2, v12, :cond_5f

    .line 18
    invoke-static {v11, v8, v13}, Ln40;->i([BILz8;)I

    move-result v0

    .line 19
    iget-object v2, v13, Lz8;->c:Ljava/lang/Object;

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 20
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_b0
    move-object/from16 v11, p2

    move/from16 v8, p3

    move-object/from16 v13, p13

    if-ne v2, v12, :cond_5f

    .line 21
    invoke-virtual {v0, v9, v10, v1}, Lde0;->B(IILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    .line 22
    invoke-virtual {v0, v10}, Lde0;->q(I)Les0;

    move-result-object v3

    move/from16 v6, p4

    move v5, v8

    move-object v4, v11

    move-object v7, v13

    .line 23
    invoke-static/range {v2 .. v7}, Ln40;->M(Ljava/lang/Object;Les0;[BIILz8;)I

    move-result v3

    .line 24
    invoke-virtual {v0, v9, v10, v1, v2}, Lde0;->U(IILjava/lang/Object;Ljava/lang/Object;)V

    return v3

    :pswitch_cd
    move-object/from16 v10, p2

    move/from16 v0, p3

    move-object/from16 v8, p13

    if-ne v2, v12, :cond_1be

    .line 25
    invoke-static {v10, v0, v8}, Ln40;->t([BILz8;)I

    move-result v0

    .line 26
    iget v2, v8, Lz8;->a:I

    if-nez v2, :cond_e3

    .line 27
    const-string v2, ""

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    goto :goto_104

    :cond_e3
    const/high16 v8, 0x20000000

    and-int v8, p8, v8

    if-eqz v8, :cond_f9

    add-int v8, v0, v2

    .line 28
    sget-object v11, La81;->a:Lfo0;

    invoke-virtual {v11, v10, v0, v8}, Lfo0;->B([BII)Z

    move-result v8

    if-eqz v8, :cond_f4

    goto :goto_f9

    .line 29
    :cond_f4
    invoke-static {}, La50;->b()La50;

    move-result-object v0

    throw v0

    .line 30
    :cond_f9
    :goto_f9
    new-instance v8, Ljava/lang/String;

    sget-object v11, Ll40;->a:Ljava/nio/charset/Charset;

    invoke-direct {v8, v10, v0, v2, v11}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 31
    invoke-virtual {v5, v1, v3, v4, v8}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/2addr v0, v2

    .line 32
    :goto_104
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_108
    move-object/from16 v10, p2

    move/from16 v0, p3

    move-object/from16 v8, p13

    if-nez v2, :cond_1be

    .line 33
    invoke-static {v10, v0, v8}, Ln40;->v([BILz8;)I

    move-result v0

    .line 34
    iget-wide v12, v8, Lz8;->b:J

    const-wide/16 v14, 0x0

    cmp-long v2, v12, v14

    if-eqz v2, :cond_11d

    goto :goto_11e

    :cond_11d
    const/4 v11, 0x0

    :goto_11e
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 35
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_129
    move-object/from16 v10, p2

    move/from16 v0, p3

    if-ne v2, v8, :cond_1be

    .line 36
    invoke-static {v0, v10}, Ln40;->j(I[B)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v0, 0x4

    .line 37
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_140
    move-object/from16 v10, p2

    move/from16 v0, p3

    if-ne v2, v11, :cond_1be

    .line 38
    invoke-static {v0, v10}, Ln40;->k(I[B)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v0, 0x8

    .line 39
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_157
    move-object/from16 v10, p2

    move/from16 v0, p3

    move-object/from16 v8, p13

    if-nez v2, :cond_1be

    .line 40
    invoke-static {v10, v0, v8}, Ln40;->t([BILz8;)I

    move-result v0

    .line 41
    iget v2, v8, Lz8;->a:I

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 42
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_170
    move-object/from16 v10, p2

    move/from16 v0, p3

    move-object/from16 v8, p13

    if-nez v2, :cond_1be

    .line 43
    invoke-static {v10, v0, v8}, Ln40;->v([BILz8;)I

    move-result v0

    .line 44
    iget-wide v10, v8, Lz8;->b:J

    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 45
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_189
    move-object/from16 v10, p2

    move/from16 v0, p3

    if-ne v2, v8, :cond_1be

    .line 46
    invoke-static {v0, v10}, Ln40;->j(I[B)I

    move-result v2

    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v2

    .line 47
    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v0, 0x4

    .line 48
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    return v0

    :pswitch_1a4
    move-object/from16 v10, p2

    move/from16 v0, p3

    if-ne v2, v11, :cond_1be

    .line 49
    invoke-static {v0, v10}, Ln40;->k(I[B)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v10

    .line 50
    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    invoke-virtual {v5, v1, v3, v4, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    add-int/lit8 v0, v0, 0x8

    .line 51
    invoke-virtual {v5, v1, v6, v7, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    :cond_1be
    :goto_1be
    return v0

    nop

    :pswitch_data_1c0
    .packed-switch 0x33
        :pswitch_1a4
        :pswitch_189
        :pswitch_170
        :pswitch_170
        :pswitch_157
        :pswitch_140
        :pswitch_129
        :pswitch_108
        :pswitch_cd
        :pswitch_b0
        :pswitch_9b
        :pswitch_157
        :pswitch_7f
        :pswitch_129
        :pswitch_140
        :pswitch_62
        :pswitch_42
        :pswitch_23
    .end packed-switch
.end method

.method public final J(Ljava/lang/Object;[BIIILz8;)I
    .registers 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v3, p2

    .line 6
    .line 7
    move/from16 v4, p4

    .line 8
    .line 9
    move/from16 v14, p5

    .line 10
    .line 11
    move-object/from16 v13, p6

    .line 12
    .line 13
    invoke-static {v2}, Lde0;->l(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sget-object v1, Lde0;->p:Lsun/misc/Unsafe;

    .line 17
    .line 18
    move/from16 v5, p3

    .line 19
    .line 20
    const/4 v6, -0x1

    .line 21
    const/4 v7, 0x0

    .line 22
    const v8, 0xfffff

    .line 23
    .line 24
    .line 25
    const/4 v9, 0x0

    .line 26
    const/4 v12, 0x0

    .line 27
    :goto_1a
    if-ge v5, v4, :cond_452

    .line 28
    .line 29
    add-int/lit8 v12, v5, 0x1

    .line 30
    .line 31
    aget-byte v5, v3, v5

    .line 32
    .line 33
    if-gez v5, :cond_28

    .line 34
    .line 35
    invoke-static {v5, v3, v12, v13}, Ln40;->s(I[BILz8;)I

    .line 36
    .line 37
    .line 38
    move-result v12

    .line 39
    iget v5, v13, Lz8;->a:I

    .line 40
    .line 41
    :cond_28
    move/from16 v25, v12

    .line 42
    .line 43
    move v12, v5

    .line 44
    move/from16 v5, v25

    .line 45
    .line 46
    const v16, 0xfffff

    .line 47
    .line 48
    .line 49
    ushr-int/lit8 v15, v12, 0x3

    .line 50
    .line 51
    and-int/lit8 v11, v12, 0x7

    .line 52
    .line 53
    iget v10, v0, Lde0;->d:I

    .line 54
    .line 55
    const/16 p3, 0x3

    .line 56
    .line 57
    iget v3, v0, Lde0;->c:I

    .line 58
    .line 59
    if-le v15, v6, :cond_4b

    .line 60
    .line 61
    div-int/lit8 v7, v7, 0x3

    .line 62
    .line 63
    if-lt v15, v3, :cond_47

    .line 64
    .line 65
    if-gt v15, v10, :cond_47

    .line 66
    .line 67
    invoke-virtual {v0, v15, v7}, Lde0;->S(II)I

    .line 68
    .line 69
    .line 70
    move-result v3

    .line 71
    goto :goto_48

    .line 72
    :cond_47
    const/4 v3, -0x1

    .line 73
    :goto_48
    const/4 v10, 0x0

    .line 74
    :goto_49
    const/4 v6, -0x1

    .line 75
    goto :goto_58

    .line 76
    :cond_4b
    if-lt v15, v3, :cond_55

    .line 77
    .line 78
    if-gt v15, v10, :cond_55

    .line 79
    .line 80
    const/4 v10, 0x0

    .line 81
    invoke-virtual {v0, v15, v10}, Lde0;->S(II)I

    .line 82
    .line 83
    .line 84
    move-result v3

    .line 85
    goto :goto_49

    .line 86
    :cond_55
    const/4 v10, 0x0

    .line 87
    const/4 v3, -0x1

    .line 88
    goto :goto_49

    .line 89
    :goto_58
    if-ne v3, v6, :cond_68

    .line 90
    .line 91
    move/from16 v19, v6

    .line 92
    .line 93
    move/from16 v23, v8

    .line 94
    .line 95
    move v7, v10

    .line 96
    move/from16 v18, v7

    .line 97
    .line 98
    move v6, v15

    .line 99
    move-object v8, v0

    .line 100
    move-object v15, v1

    .line 101
    move-object v10, v2

    .line 102
    move v2, v12

    .line 103
    goto/16 :goto_41a

    .line 104
    .line 105
    :cond_68
    add-int/lit8 v7, v3, 0x1

    .line 106
    .line 107
    iget-object v6, v0, Lde0;->a:[I

    .line 108
    .line 109
    aget v7, v6, v7

    .line 110
    .line 111
    move/from16 v18, v10

    .line 112
    .line 113
    invoke-static {v7}, Lde0;->V(I)I

    .line 114
    .line 115
    .line 116
    move-result v10

    .line 117
    and-int v4, v7, v16

    .line 118
    .line 119
    move/from16 v19, v5

    .line 120
    .line 121
    int-to-long v4, v4

    .line 122
    move-wide/from16 v20, v4

    .line 123
    .line 124
    const/16 v4, 0x11

    .line 125
    .line 126
    if-gt v10, v4, :cond_304

    .line 127
    .line 128
    add-int/lit8 v4, v3, 0x2

    .line 129
    .line 130
    aget v4, v6, v4

    .line 131
    .line 132
    ushr-int/lit8 v6, v4, 0x14

    .line 133
    .line 134
    const/4 v5, 0x1

    .line 135
    shl-int v22, v5, v6

    .line 136
    .line 137
    and-int v4, v4, v16

    .line 138
    .line 139
    if-eq v4, v8, :cond_9e

    .line 140
    .line 141
    move/from16 v6, v16

    .line 142
    .line 143
    if-eq v8, v6, :cond_94

    .line 144
    .line 145
    int-to-long v5, v8

    .line 146
    invoke-virtual {v1, v2, v5, v6, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 147
    .line 148
    .line 149
    :cond_94
    int-to-long v5, v4

    .line 150
    invoke-virtual {v1, v2, v5, v6}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 151
    .line 152
    .line 153
    move-result v9

    .line 154
    move/from16 v23, v4

    .line 155
    .line 156
    :goto_9b
    move/from16 v24, v9

    .line 157
    .line 158
    goto :goto_a1

    .line 159
    :cond_9e
    move/from16 v23, v8

    .line 160
    .line 161
    goto :goto_9b

    .line 162
    :goto_a1
    const/4 v4, 0x5

    .line 163
    packed-switch v10, :pswitch_data_486

    .line 164
    .line 165
    .line 166
    move-object/from16 v9, p2

    .line 167
    .line 168
    move-object v10, v1

    .line 169
    move-object v1, v2

    .line 170
    move-object v7, v13

    .line 171
    move/from16 v8, v19

    .line 172
    .line 173
    const/16 v17, -0x1

    .line 174
    .line 175
    move v13, v3

    .line 176
    goto/16 :goto_2f7

    .line 177
    .line 178
    :pswitch_b1
    move/from16 v4, p3

    .line 179
    .line 180
    if-ne v11, v4, :cond_e4

    .line 181
    .line 182
    invoke-virtual {v0, v3, v2}, Lde0;->A(ILjava/lang/Object;)Ljava/lang/Object;

    .line 183
    .line 184
    .line 185
    move-result-object v4

    .line 186
    shl-int/lit8 v5, v15, 0x3

    .line 187
    .line 188
    or-int/lit8 v8, v5, 0x4

    .line 189
    .line 190
    move-object v5, v4

    .line 191
    invoke-virtual {v0, v3}, Lde0;->q(I)Les0;

    .line 192
    .line 193
    .line 194
    move-result-object v4

    .line 195
    move/from16 v7, p4

    .line 196
    .line 197
    move-object v9, v13

    .line 198
    move/from16 v6, v19

    .line 199
    .line 200
    const/16 v17, -0x1

    .line 201
    .line 202
    move v13, v3

    .line 203
    move-object v3, v5

    .line 204
    move-object/from16 v5, p2

    .line 205
    .line 206
    invoke-static/range {v3 .. v9}, Ln40;->L(Ljava/lang/Object;Les0;[BIIILz8;)I

    .line 207
    .line 208
    .line 209
    move-result v4

    .line 210
    move-object v7, v5

    .line 211
    invoke-virtual {v0, v2, v13, v3}, Lde0;->T(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    or-int v3, v24, v22

    .line 215
    .line 216
    move-object v5, v9

    .line 217
    move v9, v3

    .line 218
    move-object v3, v7

    .line 219
    move v7, v13

    .line 220
    move-object v13, v5

    .line 221
    move v5, v4

    .line 222
    move v6, v15

    .line 223
    move/from16 v8, v23

    .line 224
    .line 225
    move/from16 v4, p4

    .line 226
    .line 227
    goto/16 :goto_1a

    .line 228
    .line 229
    :cond_e4
    move-object v9, v13

    .line 230
    const/16 v17, -0x1

    .line 231
    .line 232
    move v13, v3

    .line 233
    move-object v10, v1

    .line 234
    move-object v1, v2

    .line 235
    move-object v7, v9

    .line 236
    move/from16 v8, v19

    .line 237
    .line 238
    move-object/from16 v9, p2

    .line 239
    .line 240
    goto/16 :goto_2f7

    .line 241
    .line 242
    :pswitch_f1
    move-object/from16 v7, p2

    .line 243
    .line 244
    move-object v9, v13

    .line 245
    const/16 v17, -0x1

    .line 246
    .line 247
    move v13, v3

    .line 248
    move/from16 v3, v19

    .line 249
    .line 250
    if-nez v11, :cond_11a

    .line 251
    .line 252
    invoke-static {v7, v3, v9}, Ln40;->v([BILz8;)I

    .line 253
    .line 254
    .line 255
    move-result v8

    .line 256
    iget-wide v3, v9, Lz8;->b:J

    .line 257
    .line 258
    invoke-static {v3, v4}, Lwd;->c(J)J

    .line 259
    .line 260
    .line 261
    move-result-wide v5

    .line 262
    move-wide/from16 v3, v20

    .line 263
    .line 264
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    .line 265
    .line 266
    .line 267
    move-object v10, v2

    .line 268
    or-int v2, v24, v22

    .line 269
    .line 270
    move/from16 v4, p4

    .line 271
    .line 272
    move-object v3, v7

    .line 273
    move v5, v8

    .line 274
    move v7, v13

    .line 275
    move v6, v15

    .line 276
    move/from16 v8, v23

    .line 277
    .line 278
    move-object v13, v9

    .line 279
    move v9, v2

    .line 280
    :goto_117
    move-object v2, v10

    .line 281
    goto/16 :goto_1a

    .line 282
    .line 283
    :cond_11a
    move-object v8, v9

    .line 284
    move-object v9, v7

    .line 285
    move-object v7, v8

    .line 286
    move-object v10, v1

    .line 287
    move-object v1, v2

    .line 288
    :goto_11f
    move v8, v3

    .line 289
    goto/16 :goto_2f7

    .line 290
    .line 291
    :pswitch_122
    move-object/from16 v7, p2

    .line 292
    .line 293
    move-object v10, v2

    .line 294
    move-object v9, v13

    .line 295
    move-wide/from16 v5, v20

    .line 296
    .line 297
    const/16 v17, -0x1

    .line 298
    .line 299
    move v13, v3

    .line 300
    move/from16 v3, v19

    .line 301
    .line 302
    if-nez v11, :cond_14c

    .line 303
    .line 304
    invoke-static {v7, v3, v9}, Ln40;->t([BILz8;)I

    .line 305
    .line 306
    .line 307
    move-result v2

    .line 308
    iget v3, v9, Lz8;->a:I

    .line 309
    .line 310
    invoke-static {v3}, Lwd;->b(I)I

    .line 311
    .line 312
    .line 313
    move-result v3

    .line 314
    invoke-virtual {v1, v10, v5, v6, v3}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 315
    .line 316
    .line 317
    :goto_13c
    or-int v3, v24, v22

    .line 318
    .line 319
    move-object v4, v9

    .line 320
    move v9, v3

    .line 321
    move-object v3, v7

    .line 322
    move v7, v13

    .line 323
    move-object v13, v4

    .line 324
    move/from16 v4, p4

    .line 325
    .line 326
    move v5, v2

    .line 327
    move-object v2, v10

    .line 328
    :goto_147
    move v6, v15

    .line 329
    :goto_148
    move/from16 v8, v23

    .line 330
    .line 331
    goto/16 :goto_1a

    .line 332
    .line 333
    :cond_14c
    move-object v8, v10

    .line 334
    move-object v10, v1

    .line 335
    move-object v1, v8

    .line 336
    move-object v8, v9

    .line 337
    move-object v9, v7

    .line 338
    move-object v7, v8

    .line 339
    goto :goto_11f

    .line 340
    :pswitch_153
    move-object/from16 v7, p2

    .line 341
    .line 342
    move-object v10, v2

    .line 343
    move-object v9, v13

    .line 344
    move-wide/from16 v5, v20

    .line 345
    .line 346
    const/16 v17, -0x1

    .line 347
    .line 348
    move v13, v3

    .line 349
    move/from16 v3, v19

    .line 350
    .line 351
    if-nez v11, :cond_14c

    .line 352
    .line 353
    invoke-static {v7, v3, v9}, Ln40;->t([BILz8;)I

    .line 354
    .line 355
    .line 356
    move-result v2

    .line 357
    iget v3, v9, Lz8;->a:I

    .line 358
    .line 359
    invoke-virtual {v0, v13}, Lde0;->o(I)V

    .line 360
    .line 361
    .line 362
    invoke-virtual {v1, v10, v5, v6, v3}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 363
    .line 364
    .line 365
    goto :goto_13c

    .line 366
    :pswitch_16d
    move-object/from16 v7, p2

    .line 367
    .line 368
    move-object v10, v2

    .line 369
    move-object v9, v13

    .line 370
    move-wide/from16 v5, v20

    .line 371
    .line 372
    const/4 v2, 0x2

    .line 373
    const/16 v17, -0x1

    .line 374
    .line 375
    move v13, v3

    .line 376
    move/from16 v3, v19

    .line 377
    .line 378
    if-ne v11, v2, :cond_14c

    .line 379
    .line 380
    invoke-static {v7, v3, v9}, Ln40;->i([BILz8;)I

    .line 381
    .line 382
    .line 383
    move-result v2

    .line 384
    iget-object v3, v9, Lz8;->c:Ljava/lang/Object;

    .line 385
    .line 386
    invoke-virtual {v1, v10, v5, v6, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 387
    .line 388
    .line 389
    goto :goto_13c

    .line 390
    :pswitch_185
    move-object/from16 v7, p2

    .line 391
    .line 392
    move-object v10, v2

    .line 393
    move-object v9, v13

    .line 394
    const/4 v2, 0x2

    .line 395
    const/16 v17, -0x1

    .line 396
    .line 397
    move v13, v3

    .line 398
    move/from16 v3, v19

    .line 399
    .line 400
    if-ne v11, v2, :cond_1b9

    .line 401
    .line 402
    move-object v2, v1

    .line 403
    invoke-virtual {v0, v13, v10}, Lde0;->A(ILjava/lang/Object;)Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    move-result-object v1

    .line 407
    move-object v4, v2

    .line 408
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 409
    .line 410
    .line 411
    move-result-object v2

    .line 412
    move/from16 v5, p4

    .line 413
    .line 414
    move-object v8, v4

    .line 415
    move-object v6, v9

    .line 416
    move v4, v3

    .line 417
    move-object v3, v7

    .line 418
    invoke-static/range {v1 .. v6}, Ln40;->M(Ljava/lang/Object;Les0;[BIILz8;)I

    .line 419
    .line 420
    .line 421
    move-result v2

    .line 422
    move-object v9, v3

    .line 423
    move-object v3, v1

    .line 424
    move-object v1, v6

    .line 425
    invoke-virtual {v0, v10, v13, v3}, Lde0;->T(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 426
    .line 427
    .line 428
    :goto_1ab
    or-int v3, v24, v22

    .line 429
    .line 430
    move-object v4, v9

    .line 431
    move v9, v3

    .line 432
    move-object v3, v4

    .line 433
    move/from16 v4, p4

    .line 434
    .line 435
    move v5, v2

    .line 436
    move-object v2, v10

    .line 437
    move v7, v13

    .line 438
    move v6, v15

    .line 439
    move-object v13, v1

    .line 440
    move-object v1, v8

    .line 441
    goto :goto_148

    .line 442
    :cond_1b9
    move-object v8, v1

    .line 443
    move-object v1, v9

    .line 444
    move-object v9, v7

    .line 445
    :cond_1bc
    move-object v7, v1

    .line 446
    move-object v1, v10

    .line 447
    move-object v10, v8

    .line 448
    goto/16 :goto_11f

    .line 449
    .line 450
    :pswitch_1c1
    move-object/from16 v9, p2

    .line 451
    .line 452
    move-object v8, v1

    .line 453
    move-object v10, v2

    .line 454
    move-object v1, v13

    .line 455
    move-wide/from16 v5, v20

    .line 456
    .line 457
    const/4 v2, 0x2

    .line 458
    const/16 v17, -0x1

    .line 459
    .line 460
    move v13, v3

    .line 461
    move/from16 v3, v19

    .line 462
    .line 463
    if-ne v11, v2, :cond_1bc

    .line 464
    .line 465
    const/high16 v2, 0x20000000

    .line 466
    .line 467
    and-int/2addr v2, v7

    .line 468
    if-nez v2, :cond_1da

    .line 469
    .line 470
    invoke-static {v9, v3, v1}, Ln40;->o([BILz8;)I

    .line 471
    .line 472
    .line 473
    move-result v2

    .line 474
    goto :goto_1de

    .line 475
    :cond_1da
    invoke-static {v9, v3, v1}, Ln40;->p([BILz8;)I

    .line 476
    .line 477
    .line 478
    move-result v2

    .line 479
    :goto_1de
    iget-object v3, v1, Lz8;->c:Ljava/lang/Object;

    .line 480
    .line 481
    invoke-virtual {v8, v10, v5, v6, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 482
    .line 483
    .line 484
    goto :goto_1ab

    .line 485
    :pswitch_1e4
    move-object/from16 v9, p2

    .line 486
    .line 487
    move-object v8, v1

    .line 488
    move-object v10, v2

    .line 489
    move-object v1, v13

    .line 490
    move-wide/from16 v5, v20

    .line 491
    .line 492
    const/16 v17, -0x1

    .line 493
    .line 494
    move v13, v3

    .line 495
    move/from16 v3, v19

    .line 496
    .line 497
    if-nez v11, :cond_1bc

    .line 498
    .line 499
    invoke-static {v9, v3, v1}, Ln40;->v([BILz8;)I

    .line 500
    .line 501
    .line 502
    move-result v2

    .line 503
    iget-wide v3, v1, Lz8;->b:J

    .line 504
    .line 505
    const-wide/16 v19, 0x0

    .line 506
    .line 507
    cmp-long v3, v3, v19

    .line 508
    .line 509
    if-eqz v3, :cond_200

    .line 510
    .line 511
    const/4 v3, 0x1

    .line 512
    goto :goto_202

    .line 513
    :cond_200
    move/from16 v3, v18

    .line 514
    .line 515
    :goto_202
    sget-object v4, Lk71;->c:Lh71;

    .line 516
    .line 517
    invoke-virtual {v4, v10, v5, v6, v3}, Lh71;->m(Ljava/lang/Object;JZ)V

    .line 518
    .line 519
    .line 520
    goto :goto_1ab

    .line 521
    :pswitch_208
    move-object/from16 v9, p2

    .line 522
    .line 523
    move-object v8, v1

    .line 524
    move-object v10, v2

    .line 525
    move-object v1, v13

    .line 526
    move-wide/from16 v5, v20

    .line 527
    .line 528
    const/16 v17, -0x1

    .line 529
    .line 530
    move v13, v3

    .line 531
    move/from16 v3, v19

    .line 532
    .line 533
    if-ne v11, v4, :cond_1bc

    .line 534
    .line 535
    invoke-static {v3, v9}, Ln40;->j(I[B)I

    .line 536
    .line 537
    .line 538
    move-result v2

    .line 539
    invoke-virtual {v8, v10, v5, v6, v2}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 540
    .line 541
    .line 542
    add-int/lit8 v5, v3, 0x4

    .line 543
    .line 544
    or-int v2, v24, v22

    .line 545
    .line 546
    move/from16 v4, p4

    .line 547
    .line 548
    move-object v3, v9

    .line 549
    move v7, v13

    .line 550
    move v6, v15

    .line 551
    move-object v13, v1

    .line 552
    move v9, v2

    .line 553
    move-object v1, v8

    .line 554
    move-object v2, v10

    .line 555
    goto/16 :goto_148

    .line 556
    .line 557
    :pswitch_22c
    move-object/from16 v9, p2

    .line 558
    .line 559
    move-object v8, v1

    .line 560
    move-object v10, v2

    .line 561
    move-object v1, v13

    .line 562
    move-wide/from16 v5, v20

    .line 563
    .line 564
    const/4 v2, 0x1

    .line 565
    const/16 v17, -0x1

    .line 566
    .line 567
    move v13, v3

    .line 568
    move/from16 v3, v19

    .line 569
    .line 570
    if-ne v11, v2, :cond_258

    .line 571
    .line 572
    move-wide/from16 v20, v5

    .line 573
    .line 574
    invoke-static {v3, v9}, Ln40;->k(I[B)J

    .line 575
    .line 576
    .line 577
    move-result-wide v5

    .line 578
    move-object v7, v1

    .line 579
    move-object v1, v8

    .line 580
    move-object v2, v10

    .line 581
    move v8, v3

    .line 582
    move-wide/from16 v3, v20

    .line 583
    .line 584
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    .line 585
    .line 586
    .line 587
    add-int/lit8 v5, v8, 0x8

    .line 588
    .line 589
    :goto_24c
    or-int v3, v24, v22

    .line 590
    .line 591
    move-object v4, v9

    .line 592
    move v9, v3

    .line 593
    move-object v3, v4

    .line 594
    move v4, v13

    .line 595
    move-object v13, v7

    .line 596
    move v7, v4

    .line 597
    move/from16 v4, p4

    .line 598
    .line 599
    goto/16 :goto_147

    .line 600
    .line 601
    :cond_258
    move-object v7, v1

    .line 602
    move-object v1, v8

    .line 603
    move v8, v3

    .line 604
    move-object/from16 v25, v10

    .line 605
    .line 606
    move-object v10, v1

    .line 607
    move-object/from16 v1, v25

    .line 608
    .line 609
    goto/16 :goto_2f7

    .line 610
    .line 611
    :pswitch_262
    move-object/from16 v9, p2

    .line 612
    .line 613
    move-object v7, v13

    .line 614
    move/from16 v8, v19

    .line 615
    .line 616
    const/16 v17, -0x1

    .line 617
    .line 618
    move v13, v3

    .line 619
    move-wide/from16 v3, v20

    .line 620
    .line 621
    if-nez v11, :cond_278

    .line 622
    .line 623
    invoke-static {v9, v8, v7}, Ln40;->t([BILz8;)I

    .line 624
    .line 625
    .line 626
    move-result v5

    .line 627
    iget v6, v7, Lz8;->a:I

    .line 628
    .line 629
    invoke-virtual {v1, v2, v3, v4, v6}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 630
    .line 631
    .line 632
    goto :goto_24c

    .line 633
    :cond_278
    move-object v10, v1

    .line 634
    :cond_279
    move-object v1, v2

    .line 635
    goto/16 :goto_2f7

    .line 636
    .line 637
    :pswitch_27c
    move-object/from16 v9, p2

    .line 638
    .line 639
    move-object v7, v13

    .line 640
    move/from16 v8, v19

    .line 641
    .line 642
    const/16 v17, -0x1

    .line 643
    .line 644
    move v13, v3

    .line 645
    move-wide/from16 v3, v20

    .line 646
    .line 647
    if-nez v11, :cond_278

    .line 648
    .line 649
    invoke-static {v9, v8, v7}, Ln40;->v([BILz8;)I

    .line 650
    .line 651
    .line 652
    move-result v8

    .line 653
    iget-wide v5, v7, Lz8;->b:J

    .line 654
    .line 655
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    .line 656
    .line 657
    .line 658
    move-object v10, v1

    .line 659
    or-int v1, v24, v22

    .line 660
    .line 661
    move v3, v13

    .line 662
    move-object v13, v7

    .line 663
    move v7, v3

    .line 664
    move/from16 v4, p4

    .line 665
    .line 666
    move v5, v8

    .line 667
    :goto_29a
    move-object v3, v9

    .line 668
    move v6, v15

    .line 669
    move/from16 v8, v23

    .line 670
    .line 671
    move v9, v1

    .line 672
    :goto_29f
    move-object v1, v10

    .line 673
    goto/16 :goto_1a

    .line 674
    .line 675
    :pswitch_2a2
    move-object/from16 v9, p2

    .line 676
    .line 677
    move-object v10, v1

    .line 678
    move-object v7, v13

    .line 679
    move/from16 v8, v19

    .line 680
    .line 681
    move-wide/from16 v5, v20

    .line 682
    .line 683
    const/16 v17, -0x1

    .line 684
    .line 685
    move v13, v3

    .line 686
    if-ne v11, v4, :cond_279

    .line 687
    .line 688
    invoke-static {v8, v9}, Ln40;->j(I[B)I

    .line 689
    .line 690
    .line 691
    move-result v1

    .line 692
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 693
    .line 694
    .line 695
    move-result v1

    .line 696
    sget-object v3, Lk71;->c:Lh71;

    .line 697
    .line 698
    invoke-virtual {v3, v2, v5, v6, v1}, Lh71;->p(Ljava/lang/Object;JF)V

    .line 699
    .line 700
    .line 701
    add-int/lit8 v5, v8, 0x4

    .line 702
    .line 703
    or-int v1, v24, v22

    .line 704
    .line 705
    move v3, v13

    .line 706
    move-object v13, v7

    .line 707
    move v7, v3

    .line 708
    move/from16 v4, p4

    .line 709
    .line 710
    goto :goto_29a

    .line 711
    :pswitch_2c6
    move-object/from16 v9, p2

    .line 712
    .line 713
    move-object v10, v1

    .line 714
    move-object v7, v13

    .line 715
    move/from16 v8, v19

    .line 716
    .line 717
    move-wide/from16 v5, v20

    .line 718
    .line 719
    const/4 v1, 0x1

    .line 720
    const/16 v17, -0x1

    .line 721
    .line 722
    move v13, v3

    .line 723
    if-ne v11, v1, :cond_279

    .line 724
    .line 725
    invoke-static {v8, v9}, Ln40;->k(I[B)J

    .line 726
    .line 727
    .line 728
    move-result-wide v3

    .line 729
    invoke-static {v3, v4}, Ljava/lang/Double;->longBitsToDouble(J)D

    .line 730
    .line 731
    .line 732
    move-result-wide v3

    .line 733
    sget-object v1, Lk71;->c:Lh71;

    .line 734
    .line 735
    move-wide/from16 v25, v5

    .line 736
    .line 737
    move-wide v5, v3

    .line 738
    move-wide/from16 v3, v25

    .line 739
    .line 740
    invoke-virtual/range {v1 .. v6}, Lh71;->o(Ljava/lang/Object;JD)V

    .line 741
    .line 742
    .line 743
    move-object v1, v2

    .line 744
    add-int/lit8 v5, v8, 0x8

    .line 745
    .line 746
    or-int v2, v24, v22

    .line 747
    .line 748
    move v3, v13

    .line 749
    move-object v13, v7

    .line 750
    move v7, v3

    .line 751
    move/from16 v4, p4

    .line 752
    .line 753
    move-object v3, v9

    .line 754
    move v6, v15

    .line 755
    move/from16 v8, v23

    .line 756
    .line 757
    move v9, v2

    .line 758
    move-object v2, v1

    .line 759
    goto :goto_29f

    .line 760
    :goto_2f7
    move v5, v8

    .line 761
    move v2, v12

    .line 762
    move v7, v13

    .line 763
    move v6, v15

    .line 764
    move/from16 v19, v17

    .line 765
    .line 766
    move/from16 v9, v24

    .line 767
    .line 768
    move-object v8, v0

    .line 769
    move-object v15, v10

    .line 770
    move-object v10, v1

    .line 771
    goto/16 :goto_41a

    .line 772
    .line 773
    :cond_304
    move-object v5, v2

    .line 774
    move-object v2, v1

    .line 775
    move-object v1, v5

    .line 776
    move v13, v3

    .line 777
    move/from16 v3, v19

    .line 778
    .line 779
    move-wide/from16 v5, v20

    .line 780
    .line 781
    const/16 v17, -0x1

    .line 782
    .line 783
    const/16 v4, 0x1b

    .line 784
    .line 785
    if-ne v10, v4, :cond_366

    .line 786
    .line 787
    const/4 v4, 0x2

    .line 788
    if-ne v11, v4, :cond_354

    .line 789
    .line 790
    invoke-virtual {v2, v1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 791
    .line 792
    .line 793
    move-result-object v4

    .line 794
    check-cast v4, Li40;

    .line 795
    .line 796
    move-object v7, v4

    .line 797
    check-cast v7, Lx;

    .line 798
    .line 799
    iget-boolean v7, v7, Lx;->f:Z

    .line 800
    .line 801
    if-nez v7, :cond_334

    .line 802
    .line 803
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 804
    .line 805
    .line 806
    move-result v7

    .line 807
    if-nez v7, :cond_32b

    .line 808
    .line 809
    const/16 v7, 0xa

    .line 810
    .line 811
    goto :goto_32d

    .line 812
    :cond_32b
    mul-int/lit8 v7, v7, 0x2

    .line 813
    .line 814
    :goto_32d
    invoke-interface {v4, v7}, Li40;->a(I)Li40;

    .line 815
    .line 816
    .line 817
    move-result-object v4

    .line 818
    invoke-virtual {v2, v1, v5, v6, v4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 819
    .line 820
    .line 821
    :cond_334
    move-object v6, v4

    .line 822
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 823
    .line 824
    .line 825
    move-result-object v1

    .line 826
    move v4, v12

    .line 827
    move-object v12, v2

    .line 828
    move v2, v4

    .line 829
    move/from16 v5, p4

    .line 830
    .line 831
    move-object/from16 v7, p6

    .line 832
    .line 833
    move v4, v3

    .line 834
    move-object/from16 v3, p2

    .line 835
    .line 836
    invoke-static/range {v1 .. v7}, Ln40;->n(Les0;I[BIILi40;Lz8;)I

    .line 837
    .line 838
    .line 839
    move-result v1

    .line 840
    move/from16 v4, p4

    .line 841
    .line 842
    move v5, v1

    .line 843
    move-object v1, v12

    .line 844
    move v7, v13

    .line 845
    move v6, v15

    .line 846
    move-object/from16 v13, p6

    .line 847
    .line 848
    move v12, v2

    .line 849
    move-object/from16 v2, p1

    .line 850
    .line 851
    goto/16 :goto_1a

    .line 852
    .line 853
    :cond_354
    move/from16 v25, v12

    .line 854
    .line 855
    move-object v12, v2

    .line 856
    move/from16 v2, v25

    .line 857
    .line 858
    move/from16 v23, v8

    .line 859
    .line 860
    move/from16 p3, v15

    .line 861
    .line 862
    move/from16 v19, v17

    .line 863
    .line 864
    move/from16 v17, v9

    .line 865
    .line 866
    move-object v15, v12

    .line 867
    move v12, v13

    .line 868
    move v9, v2

    .line 869
    goto/16 :goto_3e0

    .line 870
    .line 871
    :cond_366
    move/from16 v25, v12

    .line 872
    .line 873
    move-object v12, v2

    .line 874
    move/from16 v2, v25

    .line 875
    .line 876
    const/16 v1, 0x31

    .line 877
    .line 878
    if-gt v10, v1, :cond_3b7

    .line 879
    .line 880
    move/from16 v23, v8

    .line 881
    .line 882
    move v1, v9

    .line 883
    int-to-long v8, v7

    .line 884
    move/from16 v4, p4

    .line 885
    .line 886
    move v7, v13

    .line 887
    move/from16 p3, v15

    .line 888
    .line 889
    move/from16 v19, v17

    .line 890
    .line 891
    move-object/from16 v13, p6

    .line 892
    .line 893
    move/from16 v17, v1

    .line 894
    .line 895
    move-object v15, v12

    .line 896
    move-object/from16 v1, p1

    .line 897
    .line 898
    move/from16 v25, v2

    .line 899
    .line 900
    move-object/from16 v2, p2

    .line 901
    .line 902
    move-wide/from16 v26, v5

    .line 903
    .line 904
    move/from16 v5, v25

    .line 905
    .line 906
    move v6, v11

    .line 907
    move-wide/from16 v11, v26

    .line 908
    .line 909
    invoke-virtual/range {v0 .. v13}, Lde0;->L(Ljava/lang/Object;[BIIIIIJIJLz8;)I

    .line 910
    .line 911
    .line 912
    move-result v6

    .line 913
    move v9, v5

    .line 914
    move v12, v7

    .line 915
    if-eq v6, v3, :cond_3aa

    .line 916
    .line 917
    :goto_394
    move-object/from16 v0, p0

    .line 918
    .line 919
    move-object/from16 v2, p1

    .line 920
    .line 921
    move-object/from16 v3, p2

    .line 922
    .line 923
    move/from16 v4, p4

    .line 924
    .line 925
    move-object/from16 v13, p6

    .line 926
    .line 927
    move v5, v6

    .line 928
    move v7, v12

    .line 929
    move-object v1, v15

    .line 930
    move/from16 v8, v23

    .line 931
    .line 932
    move/from16 v6, p3

    .line 933
    .line 934
    move v12, v9

    .line 935
    move/from16 v9, v17

    .line 936
    .line 937
    goto/16 :goto_1a

    .line 938
    .line 939
    :cond_3aa
    move-object/from16 v8, p0

    .line 940
    .line 941
    move-object/from16 v10, p1

    .line 942
    .line 943
    move v5, v6

    .line 944
    move v2, v9

    .line 945
    move v7, v12

    .line 946
    move/from16 v9, v17

    .line 947
    .line 948
    move/from16 v6, p3

    .line 949
    .line 950
    goto/16 :goto_41a

    .line 951
    .line 952
    :cond_3b7
    move-wide/from16 v20, v5

    .line 953
    .line 954
    move/from16 v23, v8

    .line 955
    .line 956
    move v6, v11

    .line 957
    move/from16 p3, v15

    .line 958
    .line 959
    move/from16 v19, v17

    .line 960
    .line 961
    move/from16 v17, v9

    .line 962
    .line 963
    move-object v15, v12

    .line 964
    move v12, v13

    .line 965
    move v9, v2

    .line 966
    const/16 v0, 0x32

    .line 967
    .line 968
    if-ne v10, v0, :cond_3ec

    .line 969
    .line 970
    const/4 v2, 0x2

    .line 971
    if-ne v6, v2, :cond_3e0

    .line 972
    .line 973
    move-object/from16 v0, p0

    .line 974
    .line 975
    move-object/from16 v1, p1

    .line 976
    .line 977
    move-object/from16 v2, p2

    .line 978
    .line 979
    move/from16 v4, p4

    .line 980
    .line 981
    move-object/from16 v8, p6

    .line 982
    .line 983
    move v5, v12

    .line 984
    move-wide/from16 v6, v20

    .line 985
    .line 986
    invoke-virtual/range {v0 .. v8}, Lde0;->H(Ljava/lang/Object;[BIIIJLz8;)I

    .line 987
    .line 988
    .line 989
    move-result v6

    .line 990
    if-eq v6, v3, :cond_3aa

    .line 991
    .line 992
    goto :goto_394

    .line 993
    :cond_3e0
    :goto_3e0
    move-object/from16 v8, p0

    .line 994
    .line 995
    move-object/from16 v10, p1

    .line 996
    .line 997
    move/from16 v6, p3

    .line 998
    .line 999
    move v5, v3

    .line 1000
    move v2, v9

    .line 1001
    :goto_3e8
    move v7, v12

    .line 1002
    move/from16 v9, v17

    .line 1003
    .line 1004
    goto :goto_41a

    .line 1005
    :cond_3ec
    move-object/from16 v0, p0

    .line 1006
    .line 1007
    move-object/from16 v1, p1

    .line 1008
    .line 1009
    move-object/from16 v2, p2

    .line 1010
    .line 1011
    move/from16 v4, p4

    .line 1012
    .line 1013
    move-object/from16 v13, p6

    .line 1014
    .line 1015
    move v8, v7

    .line 1016
    move v5, v9

    .line 1017
    move v9, v10

    .line 1018
    move-wide/from16 v10, v20

    .line 1019
    .line 1020
    move v7, v6

    .line 1021
    move/from16 v6, p3

    .line 1022
    .line 1023
    invoke-virtual/range {v0 .. v13}, Lde0;->I(Ljava/lang/Object;[BIIIIIIIJILz8;)I

    .line 1024
    .line 1025
    .line 1026
    move-result v7

    .line 1027
    move-object v8, v0

    .line 1028
    move-object v10, v1

    .line 1029
    move v2, v5

    .line 1030
    if-eq v7, v3, :cond_418

    .line 1031
    .line 1032
    move-object/from16 v3, p2

    .line 1033
    .line 1034
    move/from16 v4, p4

    .line 1035
    .line 1036
    move-object/from16 v13, p6

    .line 1037
    .line 1038
    move v5, v7

    .line 1039
    move-object v0, v8

    .line 1040
    move v7, v12

    .line 1041
    move-object v1, v15

    .line 1042
    move/from16 v9, v17

    .line 1043
    .line 1044
    move/from16 v8, v23

    .line 1045
    .line 1046
    move v12, v2

    .line 1047
    goto/16 :goto_117

    .line 1048
    .line 1049
    :cond_418
    move v5, v7

    .line 1050
    goto :goto_3e8

    .line 1051
    :goto_41a
    if-ne v2, v14, :cond_427

    .line 1052
    .line 1053
    if-eqz v14, :cond_427

    .line 1054
    .line 1055
    move/from16 v4, p4

    .line 1056
    .line 1057
    move v12, v2

    .line 1058
    :goto_421
    move/from16 v0, v23

    .line 1059
    .line 1060
    const v6, 0xfffff

    .line 1061
    .line 1062
    .line 1063
    goto :goto_45a

    .line 1064
    :cond_427
    move-object v0, v10

    .line 1065
    check-cast v0, Lr00;

    .line 1066
    .line 1067
    iget-object v1, v0, Lr00;->unknownFields:Lm61;

    .line 1068
    .line 1069
    sget-object v3, Lm61;->f:Lm61;

    .line 1070
    .line 1071
    if-ne v1, v3, :cond_437

    .line 1072
    .line 1073
    new-instance v1, Lm61;

    .line 1074
    .line 1075
    invoke-direct {v1}, Lm61;-><init>()V

    .line 1076
    .line 1077
    .line 1078
    iput-object v1, v0, Lr00;->unknownFields:Lm61;

    .line 1079
    .line 1080
    :cond_437
    move/from16 v3, p4

    .line 1081
    .line 1082
    move-object v4, v1

    .line 1083
    move v0, v2

    .line 1084
    move v2, v5

    .line 1085
    move-object/from16 v1, p2

    .line 1086
    .line 1087
    move-object/from16 v5, p6

    .line 1088
    .line 1089
    invoke-static/range {v0 .. v5}, Ln40;->q(I[BIILm61;Lz8;)I

    .line 1090
    .line 1091
    .line 1092
    move-result v2

    .line 1093
    move v5, v0

    .line 1094
    move-object/from16 v13, p6

    .line 1095
    .line 1096
    move v4, v3

    .line 1097
    move v12, v5

    .line 1098
    move-object v0, v8

    .line 1099
    move-object v1, v15

    .line 1100
    move/from16 v8, v23

    .line 1101
    .line 1102
    move-object/from16 v3, p2

    .line 1103
    .line 1104
    move v5, v2

    .line 1105
    goto/16 :goto_117

    .line 1106
    .line 1107
    :cond_452
    move-object v15, v1

    .line 1108
    move-object v10, v2

    .line 1109
    move/from16 v23, v8

    .line 1110
    .line 1111
    move/from16 v17, v9

    .line 1112
    .line 1113
    move-object v8, v0

    .line 1114
    goto :goto_421

    .line 1115
    :goto_45a
    if-eq v0, v6, :cond_460

    .line 1116
    .line 1117
    int-to-long v0, v0

    .line 1118
    invoke-virtual {v15, v10, v0, v1, v9}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 1119
    .line 1120
    .line 1121
    :cond_460
    iget v0, v8, Lde0;->i:I

    .line 1122
    .line 1123
    :goto_462
    iget v1, v8, Lde0;->j:I

    .line 1124
    .line 1125
    if-ge v0, v1, :cond_471

    .line 1126
    .line 1127
    iget-object v1, v8, Lde0;->h:[I

    .line 1128
    .line 1129
    aget v1, v1, v0

    .line 1130
    .line 1131
    const/4 v2, 0x0

    .line 1132
    invoke-virtual {v8, v10, v1, v2}, Lde0;->n(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1133
    .line 1134
    .line 1135
    add-int/lit8 v0, v0, 0x1

    .line 1136
    .line 1137
    goto :goto_462

    .line 1138
    :cond_471
    if-nez v14, :cond_47b

    .line 1139
    .line 1140
    if-ne v5, v4, :cond_476

    .line 1141
    .line 1142
    goto :goto_47f

    .line 1143
    :cond_476
    invoke-static {}, La50;->f()La50;

    .line 1144
    .line 1145
    .line 1146
    move-result-object v0

    .line 1147
    throw v0

    .line 1148
    :cond_47b
    if-gt v5, v4, :cond_480

    .line 1149
    .line 1150
    if-ne v12, v14, :cond_480

    .line 1151
    .line 1152
    :goto_47f
    return v5

    .line 1153
    :cond_480
    invoke-static {}, La50;->f()La50;

    .line 1154
    .line 1155
    .line 1156
    move-result-object v0

    .line 1157
    throw v0

    .line 1158
    nop

    .line 1159
    :pswitch_data_486
    .packed-switch 0x0
        :pswitch_2c6
        :pswitch_2a2
        :pswitch_27c
        :pswitch_27c
        :pswitch_262
        :pswitch_22c
        :pswitch_208
        :pswitch_1e4
        :pswitch_1c1
        :pswitch_185
        :pswitch_16d
        :pswitch_262
        :pswitch_153
        :pswitch_208
        :pswitch_22c
        :pswitch_122
        :pswitch_f1
        :pswitch_b1
    .end packed-switch
.end method

.method public final K(Ljava/lang/Object;[BIILz8;)V
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v7, p2

    .line 6
    .line 7
    move/from16 v8, p4

    .line 8
    .line 9
    move-object/from16 v13, p5

    .line 10
    .line 11
    invoke-static {v2}, Lde0;->l(Ljava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    sget-object v1, Lde0;->p:Lsun/misc/Unsafe;

    .line 15
    .line 16
    move/from16 v3, p3

    .line 17
    .line 18
    const/4 v4, -0x1

    .line 19
    const/4 v5, 0x0

    .line 20
    const v10, 0xfffff

    .line 21
    .line 22
    .line 23
    const/4 v11, 0x0

    .line 24
    :goto_17
    if-ge v3, v8, :cond_369

    .line 25
    .line 26
    add-int/lit8 v6, v3, 0x1

    .line 27
    .line 28
    aget-byte v3, v7, v3

    .line 29
    .line 30
    if-gez v3, :cond_25

    .line 31
    .line 32
    invoke-static {v3, v7, v6, v13}, Ln40;->s(I[BILz8;)I

    .line 33
    .line 34
    .line 35
    move-result v6

    .line 36
    iget v3, v13, Lz8;->a:I

    .line 37
    .line 38
    :cond_25
    ushr-int/lit8 v12, v3, 0x3

    .line 39
    .line 40
    const v16, 0xfffff

    .line 41
    .line 42
    .line 43
    and-int/lit8 v14, v3, 0x7

    .line 44
    .line 45
    iget v9, v0, Lde0;->d:I

    .line 46
    .line 47
    iget v15, v0, Lde0;->c:I

    .line 48
    .line 49
    if-le v12, v4, :cond_42

    .line 50
    .line 51
    div-int/lit8 v5, v5, 0x3

    .line 52
    .line 53
    if-lt v12, v15, :cond_3d

    .line 54
    .line 55
    if-gt v12, v9, :cond_3d

    .line 56
    .line 57
    invoke-virtual {v0, v12, v5}, Lde0;->S(II)I

    .line 58
    .line 59
    .line 60
    move-result v4

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    const/4 v4, -0x1

    .line 63
    :goto_3e
    const/4 v15, 0x0

    .line 64
    :goto_3f
    move v9, v4

    .line 65
    const/4 v4, -0x1

    .line 66
    goto :goto_4f

    .line 67
    :cond_42
    if-lt v12, v15, :cond_4c

    .line 68
    .line 69
    if-gt v12, v9, :cond_4c

    .line 70
    .line 71
    const/4 v15, 0x0

    .line 72
    invoke-virtual {v0, v12, v15}, Lde0;->S(II)I

    .line 73
    .line 74
    .line 75
    move-result v4

    .line 76
    goto :goto_3f

    .line 77
    :cond_4c
    const/4 v15, 0x0

    .line 78
    const/4 v4, -0x1

    .line 79
    goto :goto_3f

    .line 80
    :goto_4f
    if-ne v9, v4, :cond_5e

    .line 81
    .line 82
    move v5, v6

    .line 83
    move-object v6, v2

    .line 84
    move v2, v5

    .line 85
    move-object/from16 v22, v1

    .line 86
    .line 87
    move v5, v3

    .line 88
    move/from16 v18, v4

    .line 89
    .line 90
    move/from16 v17, v12

    .line 91
    .line 92
    move v12, v15

    .line 93
    goto/16 :goto_33d

    .line 94
    .line 95
    :cond_5e
    add-int/lit8 v5, v9, 0x1

    .line 96
    .line 97
    iget-object v4, v0, Lde0;->a:[I

    .line 98
    .line 99
    aget v5, v4, v5

    .line 100
    .line 101
    invoke-static {v5}, Lde0;->V(I)I

    .line 102
    .line 103
    .line 104
    move-result v15

    .line 105
    move/from16 p3, v3

    .line 106
    .line 107
    and-int v3, v5, v16

    .line 108
    .line 109
    move-object/from16 v18, v4

    .line 110
    .line 111
    int-to-long v3, v3

    .line 112
    move-wide/from16 v19, v3

    .line 113
    .line 114
    const/16 v3, 0x11

    .line 115
    .line 116
    if-gt v15, v3, :cond_23e

    .line 117
    .line 118
    add-int/lit8 v3, v9, 0x2

    .line 119
    .line 120
    aget v3, v18, v3

    .line 121
    .line 122
    ushr-int/lit8 v18, v3, 0x14

    .line 123
    .line 124
    const/4 v4, 0x1

    .line 125
    shl-int v18, v4, v18

    .line 126
    .line 127
    and-int v3, v3, v16

    .line 128
    .line 129
    if-eq v3, v10, :cond_98

    .line 130
    .line 131
    move/from16 v4, v16

    .line 132
    .line 133
    move/from16 v21, v5

    .line 134
    .line 135
    if-eq v10, v4, :cond_8f

    .line 136
    .line 137
    int-to-long v4, v10

    .line 138
    invoke-virtual {v1, v2, v4, v5, v11}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 139
    .line 140
    .line 141
    const v4, 0xfffff

    .line 142
    .line 143
    .line 144
    :cond_8f
    if-eq v3, v4, :cond_96

    .line 145
    .line 146
    int-to-long v4, v3

    .line 147
    invoke-virtual {v1, v2, v4, v5}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 148
    .line 149
    .line 150
    move-result v11

    .line 151
    :cond_96
    move v10, v3

    .line 152
    goto :goto_9a

    .line 153
    :cond_98
    move/from16 v21, v5

    .line 154
    .line 155
    :goto_9a
    const/4 v3, 0x5

    .line 156
    packed-switch v15, :pswitch_data_382

    .line 157
    .line 158
    .line 159
    move-object v15, v1

    .line 160
    move-object v1, v2

    .line 161
    move-object v8, v7

    .line 162
    const/16 v17, -0x1

    .line 163
    .line 164
    :goto_a3
    move v7, v6

    .line 165
    goto/16 :goto_231

    .line 166
    .line 167
    :pswitch_a6
    if-nez v14, :cond_c1

    .line 168
    .line 169
    invoke-static {v7, v6, v13}, Ln40;->v([BILz8;)I

    .line 170
    .line 171
    .line 172
    move-result v14

    .line 173
    iget-wide v3, v13, Lz8;->b:J

    .line 174
    .line 175
    invoke-static {v3, v4}, Lwd;->c(J)J

    .line 176
    .line 177
    .line 178
    move-result-wide v5

    .line 179
    move-wide/from16 v3, v19

    .line 180
    .line 181
    const/16 v17, -0x1

    .line 182
    .line 183
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    .line 184
    .line 185
    .line 186
    move-object v15, v2

    .line 187
    or-int v11, v11, v18

    .line 188
    .line 189
    move v5, v9

    .line 190
    move v4, v12

    .line 191
    move v3, v14

    .line 192
    goto/16 :goto_17

    .line 193
    .line 194
    :cond_c1
    const/16 v17, -0x1

    .line 195
    .line 196
    move-object v15, v1

    .line 197
    move-object v1, v2

    .line 198
    :goto_c5
    move-object v8, v7

    .line 199
    goto :goto_a3

    .line 200
    :pswitch_c7
    move-object v15, v2

    .line 201
    move-wide/from16 v4, v19

    .line 202
    .line 203
    const/16 v17, -0x1

    .line 204
    .line 205
    if-nez v14, :cond_e2

    .line 206
    .line 207
    invoke-static {v7, v6, v13}, Ln40;->t([BILz8;)I

    .line 208
    .line 209
    .line 210
    move-result v3

    .line 211
    iget v2, v13, Lz8;->a:I

    .line 212
    .line 213
    invoke-static {v2}, Lwd;->b(I)I

    .line 214
    .line 215
    .line 216
    move-result v2

    .line 217
    invoke-virtual {v1, v15, v4, v5, v2}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 218
    .line 219
    .line 220
    :goto_db
    or-int v11, v11, v18

    .line 221
    .line 222
    move v5, v9

    .line 223
    move v4, v12

    .line 224
    move-object v2, v15

    .line 225
    goto/16 :goto_17

    .line 226
    .line 227
    :cond_e2
    move-object v8, v15

    .line 228
    move-object v15, v1

    .line 229
    move-object v1, v8

    .line 230
    goto :goto_c5

    .line 231
    :pswitch_e6
    move-object v15, v2

    .line 232
    move-wide/from16 v4, v19

    .line 233
    .line 234
    const/16 v17, -0x1

    .line 235
    .line 236
    if-nez v14, :cond_e2

    .line 237
    .line 238
    invoke-static {v7, v6, v13}, Ln40;->t([BILz8;)I

    .line 239
    .line 240
    .line 241
    move-result v3

    .line 242
    iget v2, v13, Lz8;->a:I

    .line 243
    .line 244
    invoke-virtual {v1, v15, v4, v5, v2}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 245
    .line 246
    .line 247
    goto :goto_db

    .line 248
    :pswitch_f7
    move-object v15, v2

    .line 249
    move-wide/from16 v4, v19

    .line 250
    .line 251
    const/4 v2, 0x2

    .line 252
    const/16 v17, -0x1

    .line 253
    .line 254
    if-ne v14, v2, :cond_e2

    .line 255
    .line 256
    invoke-static {v7, v6, v13}, Ln40;->i([BILz8;)I

    .line 257
    .line 258
    .line 259
    move-result v3

    .line 260
    iget-object v2, v13, Lz8;->c:Ljava/lang/Object;

    .line 261
    .line 262
    invoke-virtual {v1, v15, v4, v5, v2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 263
    .line 264
    .line 265
    goto :goto_db

    .line 266
    :pswitch_109
    move-object v15, v2

    .line 267
    const/4 v2, 0x2

    .line 268
    const/16 v17, -0x1

    .line 269
    .line 270
    if-ne v14, v2, :cond_133

    .line 271
    .line 272
    move-object v2, v1

    .line 273
    invoke-virtual {v0, v9, v15}, Lde0;->A(ILjava/lang/Object;)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object v1

    .line 277
    move-object v3, v2

    .line 278
    invoke-virtual {v0, v9}, Lde0;->q(I)Les0;

    .line 279
    .line 280
    .line 281
    move-result-object v2

    .line 282
    move-object v4, v7

    .line 283
    move-object v7, v3

    .line 284
    move-object v3, v4

    .line 285
    move v4, v6

    .line 286
    move v5, v8

    .line 287
    move-object v6, v13

    .line 288
    invoke-static/range {v1 .. v6}, Ln40;->M(Ljava/lang/Object;Les0;[BIILz8;)I

    .line 289
    .line 290
    .line 291
    move-result v2

    .line 292
    move-object v8, v3

    .line 293
    invoke-virtual {v0, v15, v9, v1}, Lde0;->T(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    or-int v11, v11, v18

    .line 297
    .line 298
    move v3, v2

    .line 299
    :goto_12a
    move-object v1, v7

    .line 300
    move-object v7, v8

    .line 301
    move v5, v9

    .line 302
    move v4, v12

    .line 303
    move-object v2, v15

    .line 304
    :goto_12f
    move/from16 v8, p4

    .line 305
    .line 306
    goto/16 :goto_17

    .line 307
    .line 308
    :cond_133
    move-object v8, v7

    .line 309
    move-object v7, v1

    .line 310
    move-object v1, v15

    .line 311
    move-object v15, v7

    .line 312
    goto/16 :goto_a3

    .line 313
    .line 314
    :pswitch_139
    move-object v15, v2

    .line 315
    move-object v8, v7

    .line 316
    move-wide/from16 v4, v19

    .line 317
    .line 318
    const/4 v2, 0x2

    .line 319
    const/16 v17, -0x1

    .line 320
    .line 321
    move-object v7, v1

    .line 322
    move v1, v6

    .line 323
    if-ne v14, v2, :cond_15d

    .line 324
    .line 325
    const/high16 v2, 0x20000000

    .line 326
    .line 327
    and-int v2, v21, v2

    .line 328
    .line 329
    if-nez v2, :cond_150

    .line 330
    .line 331
    invoke-static {v8, v1, v13}, Ln40;->o([BILz8;)I

    .line 332
    .line 333
    .line 334
    move-result v1

    .line 335
    :goto_14e
    move v3, v1

    .line 336
    goto :goto_155

    .line 337
    :cond_150
    invoke-static {v8, v1, v13}, Ln40;->p([BILz8;)I

    .line 338
    .line 339
    .line 340
    move-result v1

    .line 341
    goto :goto_14e

    .line 342
    :goto_155
    iget-object v1, v13, Lz8;->c:Ljava/lang/Object;

    .line 343
    .line 344
    invoke-virtual {v7, v15, v4, v5, v1}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 345
    .line 346
    .line 347
    :goto_15a
    or-int v11, v11, v18

    .line 348
    .line 349
    goto :goto_12a

    .line 350
    :cond_15d
    move-object/from16 v23, v7

    .line 351
    .line 352
    move v7, v1

    .line 353
    move-object v1, v15

    .line 354
    move-object/from16 v15, v23

    .line 355
    .line 356
    goto/16 :goto_231

    .line 357
    .line 358
    :pswitch_165
    move-object v15, v2

    .line 359
    move-object v8, v7

    .line 360
    move-wide/from16 v4, v19

    .line 361
    .line 362
    const/16 v17, -0x1

    .line 363
    .line 364
    move-object v7, v1

    .line 365
    move v1, v6

    .line 366
    if-nez v14, :cond_15d

    .line 367
    .line 368
    invoke-static {v8, v1, v13}, Ln40;->v([BILz8;)I

    .line 369
    .line 370
    .line 371
    move-result v3

    .line 372
    iget-wide v1, v13, Lz8;->b:J

    .line 373
    .line 374
    const-wide/16 v19, 0x0

    .line 375
    .line 376
    cmp-long v1, v1, v19

    .line 377
    .line 378
    if-eqz v1, :cond_17d

    .line 379
    .line 380
    const/4 v1, 0x1

    .line 381
    goto :goto_17e

    .line 382
    :cond_17d
    const/4 v1, 0x0

    .line 383
    :goto_17e
    sget-object v2, Lk71;->c:Lh71;

    .line 384
    .line 385
    invoke-virtual {v2, v15, v4, v5, v1}, Lh71;->m(Ljava/lang/Object;JZ)V

    .line 386
    .line 387
    .line 388
    goto :goto_15a

    .line 389
    :pswitch_184
    move-object v15, v2

    .line 390
    move-object v8, v7

    .line 391
    move-wide/from16 v4, v19

    .line 392
    .line 393
    const/16 v17, -0x1

    .line 394
    .line 395
    move-object v7, v1

    .line 396
    move v1, v6

    .line 397
    if-ne v14, v3, :cond_15d

    .line 398
    .line 399
    invoke-static {v1, v8}, Ln40;->j(I[B)I

    .line 400
    .line 401
    .line 402
    move-result v2

    .line 403
    invoke-virtual {v7, v15, v4, v5, v2}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 404
    .line 405
    .line 406
    add-int/lit8 v3, v1, 0x4

    .line 407
    .line 408
    goto :goto_15a

    .line 409
    :pswitch_198
    move-object v15, v2

    .line 410
    move-object v8, v7

    .line 411
    move-wide/from16 v4, v19

    .line 412
    .line 413
    const/4 v2, 0x1

    .line 414
    const/16 v17, -0x1

    .line 415
    .line 416
    move-object v7, v1

    .line 417
    move v1, v6

    .line 418
    if-ne v14, v2, :cond_1b8

    .line 419
    .line 420
    move-wide v3, v4

    .line 421
    invoke-static {v1, v8}, Ln40;->k(I[B)J

    .line 422
    .line 423
    .line 424
    move-result-wide v5

    .line 425
    move-object v2, v7

    .line 426
    move v7, v1

    .line 427
    move-object v1, v2

    .line 428
    move-object v2, v15

    .line 429
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    .line 430
    .line 431
    .line 432
    add-int/lit8 v3, v7, 0x8

    .line 433
    .line 434
    or-int v11, v11, v18

    .line 435
    .line 436
    :goto_1b3
    move-object v7, v8

    .line 437
    :goto_1b4
    move v5, v9

    .line 438
    move v4, v12

    .line 439
    goto/16 :goto_12f

    .line 440
    .line 441
    :cond_1b8
    move-object/from16 v23, v7

    .line 442
    .line 443
    move v7, v1

    .line 444
    move-object/from16 v1, v23

    .line 445
    .line 446
    move-object/from16 v23, v15

    .line 447
    .line 448
    move-object v15, v1

    .line 449
    move-object/from16 v1, v23

    .line 450
    .line 451
    goto/16 :goto_231

    .line 452
    .line 453
    :pswitch_1c4
    move-object v8, v7

    .line 454
    move-wide/from16 v3, v19

    .line 455
    .line 456
    const/16 v17, -0x1

    .line 457
    .line 458
    move v7, v6

    .line 459
    if-nez v14, :cond_1d9

    .line 460
    .line 461
    invoke-static {v8, v7, v13}, Ln40;->t([BILz8;)I

    .line 462
    .line 463
    .line 464
    move-result v5

    .line 465
    iget v6, v13, Lz8;->a:I

    .line 466
    .line 467
    invoke-virtual {v1, v2, v3, v4, v6}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 468
    .line 469
    .line 470
    or-int v11, v11, v18

    .line 471
    .line 472
    move v3, v5

    .line 473
    goto :goto_1b3

    .line 474
    :cond_1d9
    move-object v15, v1

    .line 475
    :cond_1da
    move-object v1, v2

    .line 476
    goto/16 :goto_231

    .line 477
    .line 478
    :pswitch_1dd
    move-object v8, v7

    .line 479
    move-wide/from16 v3, v19

    .line 480
    .line 481
    const/16 v17, -0x1

    .line 482
    .line 483
    move v7, v6

    .line 484
    if-nez v14, :cond_1d9

    .line 485
    .line 486
    invoke-static {v8, v7, v13}, Ln40;->v([BILz8;)I

    .line 487
    .line 488
    .line 489
    move-result v7

    .line 490
    iget-wide v5, v13, Lz8;->b:J

    .line 491
    .line 492
    invoke-virtual/range {v1 .. v6}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    .line 493
    .line 494
    .line 495
    move-object v15, v1

    .line 496
    or-int v11, v11, v18

    .line 497
    .line 498
    move v3, v7

    .line 499
    goto :goto_1b3

    .line 500
    :pswitch_1f3
    move-object v15, v1

    .line 501
    move-object v8, v7

    .line 502
    move-wide/from16 v4, v19

    .line 503
    .line 504
    const/16 v17, -0x1

    .line 505
    .line 506
    move v7, v6

    .line 507
    if-ne v14, v3, :cond_1da

    .line 508
    .line 509
    invoke-static {v7, v8}, Ln40;->j(I[B)I

    .line 510
    .line 511
    .line 512
    move-result v1

    .line 513
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 514
    .line 515
    .line 516
    move-result v1

    .line 517
    sget-object v3, Lk71;->c:Lh71;

    .line 518
    .line 519
    invoke-virtual {v3, v2, v4, v5, v1}, Lh71;->p(Ljava/lang/Object;JF)V

    .line 520
    .line 521
    .line 522
    add-int/lit8 v3, v7, 0x4

    .line 523
    .line 524
    :goto_20b
    or-int v11, v11, v18

    .line 525
    .line 526
    move-object v7, v8

    .line 527
    move v5, v9

    .line 528
    move v4, v12

    .line 529
    move-object v1, v15

    .line 530
    goto/16 :goto_12f

    .line 531
    .line 532
    :pswitch_213
    move-object v15, v1

    .line 533
    move-object v8, v7

    .line 534
    move-wide/from16 v4, v19

    .line 535
    .line 536
    const/4 v1, 0x1

    .line 537
    const/16 v17, -0x1

    .line 538
    .line 539
    move v7, v6

    .line 540
    if-ne v14, v1, :cond_1da

    .line 541
    .line 542
    invoke-static {v7, v8}, Ln40;->k(I[B)J

    .line 543
    .line 544
    .line 545
    move-result-wide v19

    .line 546
    invoke-static/range {v19 .. v20}, Ljava/lang/Double;->longBitsToDouble(J)D

    .line 547
    .line 548
    .line 549
    move-result-wide v19

    .line 550
    sget-object v1, Lk71;->c:Lh71;

    .line 551
    .line 552
    move-wide v3, v4

    .line 553
    move-wide/from16 v5, v19

    .line 554
    .line 555
    invoke-virtual/range {v1 .. v6}, Lh71;->o(Ljava/lang/Object;JD)V

    .line 556
    .line 557
    .line 558
    move-object v1, v2

    .line 559
    add-int/lit8 v3, v7, 0x8

    .line 560
    .line 561
    goto :goto_20b

    .line 562
    :goto_231
    move/from16 v5, p3

    .line 563
    .line 564
    move-object v6, v1

    .line 565
    move v2, v7

    .line 566
    move-object/from16 v22, v15

    .line 567
    .line 568
    move/from16 v18, v17

    .line 569
    .line 570
    move/from16 v17, v12

    .line 571
    .line 572
    move v12, v9

    .line 573
    goto/16 :goto_33d

    .line 574
    .line 575
    :cond_23e
    move-object v3, v2

    .line 576
    move-object v2, v1

    .line 577
    move-object v1, v3

    .line 578
    move/from16 v21, v5

    .line 579
    .line 580
    move-object v8, v7

    .line 581
    move-wide/from16 v3, v19

    .line 582
    .line 583
    const/16 v17, -0x1

    .line 584
    .line 585
    move v7, v6

    .line 586
    const/16 v5, 0x1b

    .line 587
    .line 588
    if-ne v15, v5, :cond_298

    .line 589
    .line 590
    const/4 v5, 0x2

    .line 591
    if-ne v14, v5, :cond_28a

    .line 592
    .line 593
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 594
    .line 595
    .line 596
    move-result-object v5

    .line 597
    check-cast v5, Li40;

    .line 598
    .line 599
    move-object v6, v5

    .line 600
    check-cast v6, Lx;

    .line 601
    .line 602
    iget-boolean v6, v6, Lx;->f:Z

    .line 603
    .line 604
    if-nez v6, :cond_26f

    .line 605
    .line 606
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 607
    .line 608
    .line 609
    move-result v6

    .line 610
    if-nez v6, :cond_266

    .line 611
    .line 612
    const/16 v6, 0xa

    .line 613
    .line 614
    goto :goto_268

    .line 615
    :cond_266
    mul-int/lit8 v6, v6, 0x2

    .line 616
    .line 617
    :goto_268
    invoke-interface {v5, v6}, Li40;->a(I)Li40;

    .line 618
    .line 619
    .line 620
    move-result-object v5

    .line 621
    invoke-virtual {v2, v1, v3, v4, v5}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 622
    .line 623
    .line 624
    :cond_26f
    move-object v6, v5

    .line 625
    invoke-virtual {v0, v9}, Lde0;->q(I)Les0;

    .line 626
    .line 627
    .line 628
    move-result-object v1

    .line 629
    move/from16 v5, p4

    .line 630
    .line 631
    move v4, v7

    .line 632
    move-object v3, v8

    .line 633
    move-object v7, v13

    .line 634
    move-object v8, v2

    .line 635
    move/from16 v2, p3

    .line 636
    .line 637
    invoke-static/range {v1 .. v7}, Ln40;->n(Les0;I[BIILi40;Lz8;)I

    .line 638
    .line 639
    .line 640
    move-result v1

    .line 641
    move-object/from16 v2, p1

    .line 642
    .line 643
    move-object/from16 v7, p2

    .line 644
    .line 645
    move-object/from16 v13, p5

    .line 646
    .line 647
    move v3, v1

    .line 648
    move-object v1, v8

    .line 649
    goto/16 :goto_1b4

    .line 650
    .line 651
    :cond_28a
    move-object/from16 v22, v2

    .line 652
    .line 653
    move v3, v7

    .line 654
    move v14, v10

    .line 655
    move v15, v11

    .line 656
    move/from16 v18, v17

    .line 657
    .line 658
    move/from16 v17, v12

    .line 659
    .line 660
    move v12, v9

    .line 661
    move/from16 v9, p3

    .line 662
    .line 663
    goto/16 :goto_308

    .line 664
    .line 665
    :cond_298
    move/from16 v5, p3

    .line 666
    .line 667
    move-object v8, v2

    .line 668
    move v1, v7

    .line 669
    const/16 v2, 0x31

    .line 670
    .line 671
    if-gt v15, v2, :cond_2de

    .line 672
    .line 673
    move-object v7, v8

    .line 674
    move v6, v9

    .line 675
    move/from16 v2, v21

    .line 676
    .line 677
    int-to-long v8, v2

    .line 678
    move-object/from16 v2, p2

    .line 679
    .line 680
    move-object/from16 v13, p5

    .line 681
    .line 682
    move-object/from16 v22, v7

    .line 683
    .line 684
    move/from16 v18, v17

    .line 685
    .line 686
    move v7, v6

    .line 687
    move/from16 v17, v12

    .line 688
    .line 689
    move v6, v14

    .line 690
    move v14, v10

    .line 691
    move v10, v15

    .line 692
    move v15, v11

    .line 693
    move-wide v11, v3

    .line 694
    move/from16 v4, p4

    .line 695
    .line 696
    move v3, v1

    .line 697
    move-object/from16 v1, p1

    .line 698
    .line 699
    invoke-virtual/range {v0 .. v13}, Lde0;->L(Ljava/lang/Object;[BIIIIIJIJLz8;)I

    .line 700
    .line 701
    .line 702
    move-result v6

    .line 703
    move v9, v5

    .line 704
    move v12, v7

    .line 705
    if-eq v6, v3, :cond_2d6

    .line 706
    .line 707
    :goto_2c2
    move-object/from16 v0, p0

    .line 708
    .line 709
    move-object/from16 v2, p1

    .line 710
    .line 711
    move-object/from16 v7, p2

    .line 712
    .line 713
    move/from16 v8, p4

    .line 714
    .line 715
    move-object/from16 v13, p5

    .line 716
    .line 717
    move v3, v6

    .line 718
    move v5, v12

    .line 719
    move v10, v14

    .line 720
    move v11, v15

    .line 721
    move/from16 v4, v17

    .line 722
    .line 723
    move-object/from16 v1, v22

    .line 724
    .line 725
    goto/16 :goto_17

    .line 726
    .line 727
    :cond_2d6
    move v2, v6

    .line 728
    move v5, v9

    .line 729
    move v10, v14

    .line 730
    move v11, v15

    .line 731
    move-object/from16 v6, p1

    .line 732
    .line 733
    goto/16 :goto_33d

    .line 734
    .line 735
    :cond_2de
    move-object/from16 v22, v8

    .line 736
    .line 737
    move v6, v14

    .line 738
    move/from16 v18, v17

    .line 739
    .line 740
    move/from16 v2, v21

    .line 741
    .line 742
    move v14, v10

    .line 743
    move/from16 v17, v12

    .line 744
    .line 745
    move v10, v15

    .line 746
    move v12, v9

    .line 747
    move v15, v11

    .line 748
    move v9, v5

    .line 749
    move-wide v4, v3

    .line 750
    move v3, v1

    .line 751
    const/16 v0, 0x32

    .line 752
    .line 753
    if-ne v10, v0, :cond_30f

    .line 754
    .line 755
    const/4 v0, 0x2

    .line 756
    if-ne v6, v0, :cond_308

    .line 757
    .line 758
    move-object/from16 v0, p0

    .line 759
    .line 760
    move-object/from16 v1, p1

    .line 761
    .line 762
    move-object/from16 v2, p2

    .line 763
    .line 764
    move-object/from16 v8, p5

    .line 765
    .line 766
    move-wide v6, v4

    .line 767
    move v5, v12

    .line 768
    move/from16 v4, p4

    .line 769
    .line 770
    invoke-virtual/range {v0 .. v8}, Lde0;->H(Ljava/lang/Object;[BIIIJLz8;)I

    .line 771
    .line 772
    .line 773
    move-result v6

    .line 774
    if-eq v6, v3, :cond_2d6

    .line 775
    .line 776
    goto :goto_2c2

    .line 777
    :cond_308
    :goto_308
    move-object/from16 v6, p1

    .line 778
    .line 779
    move v2, v3

    .line 780
    move v5, v9

    .line 781
    :goto_30c
    move v10, v14

    .line 782
    move v11, v15

    .line 783
    goto :goto_33d

    .line 784
    :cond_30f
    move-wide v0, v4

    .line 785
    move v5, v9

    .line 786
    move v9, v10

    .line 787
    move-wide v10, v0

    .line 788
    move-object/from16 v0, p0

    .line 789
    .line 790
    move-object/from16 v1, p1

    .line 791
    .line 792
    move/from16 v4, p4

    .line 793
    .line 794
    move-object/from16 v13, p5

    .line 795
    .line 796
    move v8, v2

    .line 797
    move v7, v6

    .line 798
    move/from16 v6, v17

    .line 799
    .line 800
    move-object/from16 v2, p2

    .line 801
    .line 802
    invoke-virtual/range {v0 .. v13}, Lde0;->I(Ljava/lang/Object;[BIIIIIIIJILz8;)I

    .line 803
    .line 804
    .line 805
    move-result v7

    .line 806
    move-object v6, v1

    .line 807
    if-eq v7, v3, :cond_33b

    .line 808
    .line 809
    move-object/from16 v0, p0

    .line 810
    .line 811
    move/from16 v8, p4

    .line 812
    .line 813
    move-object/from16 v13, p5

    .line 814
    .line 815
    move-object v2, v6

    .line 816
    move v3, v7

    .line 817
    move v5, v12

    .line 818
    move v10, v14

    .line 819
    move v11, v15

    .line 820
    move/from16 v4, v17

    .line 821
    .line 822
    move-object/from16 v1, v22

    .line 823
    .line 824
    move-object/from16 v7, p2

    .line 825
    .line 826
    goto/16 :goto_17

    .line 827
    .line 828
    :cond_33b
    move v2, v7

    .line 829
    goto :goto_30c

    .line 830
    :goto_33d
    move-object v0, v6

    .line 831
    check-cast v0, Lr00;

    .line 832
    .line 833
    iget-object v1, v0, Lr00;->unknownFields:Lm61;

    .line 834
    .line 835
    sget-object v3, Lm61;->f:Lm61;

    .line 836
    .line 837
    if-ne v1, v3, :cond_34d

    .line 838
    .line 839
    new-instance v1, Lm61;

    .line 840
    .line 841
    invoke-direct {v1}, Lm61;-><init>()V

    .line 842
    .line 843
    .line 844
    iput-object v1, v0, Lr00;->unknownFields:Lm61;

    .line 845
    .line 846
    :cond_34d
    move/from16 v3, p4

    .line 847
    .line 848
    move-object v4, v1

    .line 849
    move v0, v5

    .line 850
    move-object/from16 v1, p2

    .line 851
    .line 852
    move-object/from16 v5, p5

    .line 853
    .line 854
    invoke-static/range {v0 .. v5}, Ln40;->q(I[BIILm61;Lz8;)I

    .line 855
    .line 856
    .line 857
    move-result v0

    .line 858
    move-object/from16 v7, p2

    .line 859
    .line 860
    move-object/from16 v13, p5

    .line 861
    .line 862
    move v8, v3

    .line 863
    move-object v2, v6

    .line 864
    move v5, v12

    .line 865
    move/from16 v4, v17

    .line 866
    .line 867
    move-object/from16 v1, v22

    .line 868
    .line 869
    move v3, v0

    .line 870
    move-object/from16 v0, p0

    .line 871
    .line 872
    goto/16 :goto_17

    .line 873
    .line 874
    :cond_369
    move-object/from16 v22, v1

    .line 875
    .line 876
    move-object v6, v2

    .line 877
    move v4, v8

    .line 878
    move v14, v10

    .line 879
    move v15, v11

    .line 880
    const v0, 0xfffff

    .line 881
    .line 882
    .line 883
    if-eq v14, v0, :cond_37a

    .line 884
    .line 885
    int-to-long v0, v14

    .line 886
    move-object/from16 v2, v22

    .line 887
    .line 888
    invoke-virtual {v2, v6, v0, v1, v15}, Lsun/misc/Unsafe;->putInt(Ljava/lang/Object;JI)V

    .line 889
    .line 890
    .line 891
    :cond_37a
    if-ne v3, v4, :cond_37d

    .line 892
    .line 893
    return-void

    .line 894
    :cond_37d
    invoke-static {}, La50;->f()La50;

    .line 895
    .line 896
    .line 897
    move-result-object v0

    .line 898
    throw v0

    :pswitch_data_382
    .packed-switch 0x0
        :pswitch_213
        :pswitch_1f3
        :pswitch_1dd
        :pswitch_1dd
        :pswitch_1c4
        :pswitch_198
        :pswitch_184
        :pswitch_165
        :pswitch_139
        :pswitch_109
        :pswitch_f7
        :pswitch_1c4
        :pswitch_e6
        :pswitch_184
        :pswitch_198
        :pswitch_c7
        :pswitch_a6
    .end packed-switch
.end method

.method public final L(Ljava/lang/Object;[BIIIIIJIJLz8;)I
    .registers 26

    move/from16 v0, p5

    move/from16 v1, p6

    move/from16 v6, p7

    move-wide/from16 v2, p11

    .line 1
    sget-object v4, Lde0;->p:Lsun/misc/Unsafe;

    invoke-virtual {v4, p1, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Li40;

    .line 2
    move-object v7, v5

    check-cast v7, Lx;

    .line 3
    iget-boolean v7, v7, Lx;->f:Z

    const/4 v8, 0x2

    if-nez v7, :cond_29

    .line 4
    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v7

    if-nez v7, :cond_21

    const/16 v7, 0xa

    goto :goto_22

    :cond_21
    mul-int/2addr v7, v8

    .line 5
    :goto_22
    invoke-interface {v5, v7}, Li40;->a(I)Li40;

    move-result-object v5

    .line 6
    invoke-virtual {v4, p1, v2, v3, v5}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    :cond_29
    move-object v4, v5

    const/4 p1, 0x5

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    packed-switch p10, :pswitch_data_4bc

    :cond_31
    move v2, p3

    goto/16 :goto_4ba

    :pswitch_34
    const/4 p1, 0x3

    if-ne v1, p1, :cond_31

    .line 7
    invoke-virtual {p0, v6}, Lde0;->q(I)Les0;

    move-result-object p0

    and-int/lit8 p1, v0, -0x8

    or-int/lit8 p1, p1, 0x4

    move-object/from16 p6, p0

    move/from16 p10, p1

    move-object/from16 p7, p2

    move/from16 p8, p3

    move/from16 p9, p4

    move-object/from16 p11, p13

    .line 8
    invoke-static/range {p6 .. p11}, Ln40;->l(Les0;[BIIILz8;)I

    move-result p0

    move-object/from16 p1, p6

    move/from16 v3, p9

    move/from16 p3, p10

    move-object/from16 v5, p11

    .line 9
    iget-object v2, v5, Lz8;->c:Ljava/lang/Object;

    invoke-interface {v4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_5c
    if-ge p0, v3, :cond_83

    .line 10
    invoke-static {p2, p0, v5}, Ln40;->t([BILz8;)I

    move-result v2

    .line 11
    iget v6, v5, Lz8;->a:I

    if-eq v0, v6, :cond_67

    goto :goto_83

    :cond_67
    move-object/from16 p6, p1

    move-object/from16 p7, p2

    move/from16 p10, p3

    move/from16 p8, v2

    move/from16 p9, v3

    move-object/from16 p11, v5

    .line 12
    invoke-static/range {p6 .. p11}, Ln40;->l(Les0;[BIIILz8;)I

    move-result p0

    move-object/from16 p3, p6

    move/from16 v1, p10

    .line 13
    iget-object v2, v5, Lz8;->c:Ljava/lang/Object;

    invoke-interface {v4, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-object p1, p3

    move p3, v1

    goto :goto_5c

    :cond_83
    :goto_83
    return p0

    :pswitch_84
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v5, p13

    if-ne v1, v8, :cond_ac

    .line 14
    check-cast v4, Lua0;

    .line 15
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 16
    iget p3, v5, Lz8;->a:I

    add-int/2addr p3, p0

    :goto_94
    if-ge p0, p3, :cond_a4

    .line 17
    invoke-static {p2, p0, v5}, Ln40;->v([BILz8;)I

    move-result p0

    .line 18
    iget-wide v0, v5, Lz8;->b:J

    invoke-static {v0, v1}, Lwd;->c(J)J

    move-result-wide v0

    invoke-virtual {v4, v0, v1}, Lua0;->g(J)V

    goto :goto_94

    :cond_a4
    if-ne p0, p3, :cond_a7

    return p0

    .line 19
    :cond_a7
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_ac
    if-nez v1, :cond_4ba

    .line 20
    check-cast v4, Lua0;

    .line 21
    invoke-static {p2, p3, v5}, Ln40;->v([BILz8;)I

    move-result p0

    .line 22
    iget-wide v1, v5, Lz8;->b:J

    invoke-static {v1, v2}, Lwd;->c(J)J

    move-result-wide v1

    invoke-virtual {v4, v1, v2}, Lua0;->g(J)V

    :goto_bd
    if-ge p0, v3, :cond_d6

    .line 23
    invoke-static {p2, p0, v5}, Ln40;->t([BILz8;)I

    move-result p3

    .line 24
    iget v1, v5, Lz8;->a:I

    if-eq v0, v1, :cond_c8

    goto :goto_d6

    .line 25
    :cond_c8
    invoke-static {p2, p3, v5}, Ln40;->v([BILz8;)I

    move-result p0

    .line 26
    iget-wide v1, v5, Lz8;->b:J

    invoke-static {v1, v2}, Lwd;->c(J)J

    move-result-wide v1

    invoke-virtual {v4, v1, v2}, Lua0;->g(J)V

    goto :goto_bd

    :cond_d6
    :goto_d6
    return p0

    :pswitch_d7
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v5, p13

    if-ne v1, v8, :cond_ff

    .line 27
    check-cast v4, Ls30;

    .line 28
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 29
    iget p3, v5, Lz8;->a:I

    add-int/2addr p3, p0

    :goto_e7
    if-ge p0, p3, :cond_f7

    .line 30
    invoke-static {p2, p0, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 31
    iget v0, v5, Lz8;->a:I

    invoke-static {v0}, Lwd;->b(I)I

    move-result v0

    invoke-virtual {v4, v0}, Ls30;->g(I)V

    goto :goto_e7

    :cond_f7
    if-ne p0, p3, :cond_fa

    return p0

    .line 32
    :cond_fa
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_ff
    if-nez v1, :cond_4ba

    .line 33
    check-cast v4, Ls30;

    .line 34
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 35
    iget p3, v5, Lz8;->a:I

    invoke-static {p3}, Lwd;->b(I)I

    move-result p3

    invoke-virtual {v4, p3}, Ls30;->g(I)V

    :goto_110
    if-ge p0, v3, :cond_129

    .line 36
    invoke-static {p2, p0, v5}, Ln40;->t([BILz8;)I

    move-result p3

    .line 37
    iget v1, v5, Lz8;->a:I

    if-eq v0, v1, :cond_11b

    goto :goto_129

    .line 38
    :cond_11b
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 39
    iget p3, v5, Lz8;->a:I

    invoke-static {p3}, Lwd;->b(I)I

    move-result p3

    invoke-virtual {v4, p3}, Ls30;->g(I)V

    goto :goto_110

    :cond_129
    :goto_129
    return p0

    :pswitch_12a
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v5, p13

    if-ne v1, v8, :cond_14e

    .line 40
    check-cast v4, Ls30;

    .line 41
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p3

    .line 42
    iget v0, v5, Lz8;->a:I

    add-int/2addr v0, p3

    :goto_13a
    if-ge p3, v0, :cond_146

    .line 43
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p3

    .line 44
    iget v1, v5, Lz8;->a:I

    invoke-virtual {v4, v1}, Ls30;->g(I)V

    goto :goto_13a

    :cond_146
    if-ne p3, v0, :cond_149

    goto :goto_155

    .line 45
    :cond_149
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_14e
    if-nez v1, :cond_4ba

    move-object v1, p2

    .line 46
    invoke-static/range {v0 .. v5}, Ln40;->u(I[BIILi40;Lz8;)I

    move-result p3

    .line 47
    :goto_155
    invoke-virtual {p0, v6}, Lde0;->o(I)V

    .line 48
    sget-object p0, Lis0;->a:Ljava/lang/Class;

    return p3

    :pswitch_15b
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v5, p13

    if-ne v1, v8, :cond_4ba

    .line 49
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 50
    iget p3, v5, Lz8;->a:I

    if-ltz p3, :cond_1b5

    .line 51
    array-length v1, p2

    sub-int/2addr v1, p0

    if-gt p3, v1, :cond_1b0

    if-nez p3, :cond_176

    .line 52
    sget-object p3, Lqb;->g:Lnb;

    invoke-interface {v4, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_17e

    .line 53
    :cond_176
    invoke-static {p2, p0, p3}, Lqb;->h([BII)Lnb;

    move-result-object v1

    invoke-interface {v4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_17d
    add-int/2addr p0, p3

    :goto_17e
    if-ge p0, v3, :cond_1af

    .line 54
    invoke-static {p2, p0, v5}, Ln40;->t([BILz8;)I

    move-result p3

    .line 55
    iget v1, v5, Lz8;->a:I

    if-eq v0, v1, :cond_189

    goto :goto_1af

    .line 56
    :cond_189
    invoke-static {p2, p3, v5}, Ln40;->t([BILz8;)I

    move-result p0

    .line 57
    iget p3, v5, Lz8;->a:I

    if-ltz p3, :cond_1aa

    .line 58
    array-length v1, p2

    sub-int/2addr v1, p0

    if-gt p3, v1, :cond_1a5

    if-nez p3, :cond_19d

    .line 59
    sget-object p3, Lqb;->g:Lnb;

    invoke-interface {v4, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_17e

    .line 60
    :cond_19d
    invoke-static {p2, p0, p3}, Lqb;->h([BII)Lnb;

    move-result-object v1

    invoke-interface {v4, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_17d

    .line 61
    :cond_1a5
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    .line 62
    :cond_1aa
    invoke-static {}, La50;->e()La50;

    move-result-object p0

    throw p0

    :cond_1af
    :goto_1af
    return p0

    .line 63
    :cond_1b0
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    .line 64
    :cond_1b5
    invoke-static {}, La50;->e()La50;

    move-result-object p0

    throw p0

    :pswitch_1ba
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v5, p13

    if-ne v1, v8, :cond_4ba

    .line 65
    invoke-virtual {p0, v6}, Lde0;->q(I)Les0;

    move-result-object p0

    move-object/from16 p6, p0

    move-object/from16 p8, p2

    move/from16 p7, v0

    move/from16 p9, v2

    move/from16 p10, v3

    move-object/from16 p11, v4

    move-object/from16 p12, v5

    .line 66
    invoke-static/range {p6 .. p12}, Ln40;->n(Les0;I[BIILi40;Lz8;)I

    move-result p0

    return p0

    :pswitch_1d8
    move p0, p3

    move-object/from16 v7, p13

    move v6, v0

    move-object v9, v4

    move/from16 v4, p4

    if-ne v1, v8, :cond_29a

    const-wide/32 v10, 0x20000000

    and-long v10, p8, v10

    cmp-long p1, v10, v2

    .line 67
    const-string v1, ""

    if-nez p1, :cond_234

    .line 68
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 69
    iget p1, v7, Lz8;->a:I

    if-ltz p1, :cond_22f

    if-nez p1, :cond_1fa

    .line 70
    invoke-interface {v9, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_205

    .line 71
    :cond_1fa
    new-instance p3, Ljava/lang/String;

    sget-object v2, Ll40;->a:Ljava/nio/charset/Charset;

    invoke-direct {p3, p2, p0, p1, v2}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 72
    invoke-interface {v9, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_204
    add-int/2addr p0, p1

    :goto_205
    if-ge p0, v4, :cond_22e

    .line 73
    invoke-static {p2, p0, v7}, Ln40;->t([BILz8;)I

    move-result p1

    .line 74
    iget p3, v7, Lz8;->a:I

    if-eq v6, p3, :cond_210

    goto :goto_22e

    .line 75
    :cond_210
    invoke-static {p2, p1, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 76
    iget p1, v7, Lz8;->a:I

    if-ltz p1, :cond_229

    if-nez p1, :cond_21e

    .line 77
    invoke-interface {v9, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_205

    .line 78
    :cond_21e
    new-instance p3, Ljava/lang/String;

    sget-object v2, Ll40;->a:Ljava/nio/charset/Charset;

    invoke-direct {p3, p2, p0, p1, v2}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 79
    invoke-interface {v9, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_204

    .line 80
    :cond_229
    invoke-static {}, La50;->e()La50;

    move-result-object p0

    throw p0

    :cond_22e
    :goto_22e
    return p0

    .line 81
    :cond_22f
    invoke-static {}, La50;->e()La50;

    move-result-object p0

    throw p0

    .line 82
    :cond_234
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 83
    iget p1, v7, Lz8;->a:I

    if-ltz p1, :cond_295

    if-nez p1, :cond_242

    .line 84
    invoke-interface {v9, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_257

    :cond_242
    add-int p3, p0, p1

    .line 85
    sget-object v2, La81;->a:Lfo0;

    invoke-virtual {v2, p2, p0, p3}, Lfo0;->B([BII)Z

    move-result v2

    if-eqz v2, :cond_290

    .line 86
    new-instance v2, Ljava/lang/String;

    sget-object v3, Ll40;->a:Ljava/nio/charset/Charset;

    invoke-direct {v2, p2, p0, p1, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 87
    invoke-interface {v9, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_256
    move p0, p3

    :goto_257
    if-ge p0, v4, :cond_28f

    .line 88
    invoke-static {p2, p0, v7}, Ln40;->t([BILz8;)I

    move-result p1

    .line 89
    iget p3, v7, Lz8;->a:I

    if-eq v6, p3, :cond_262

    goto :goto_28f

    .line 90
    :cond_262
    invoke-static {p2, p1, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 91
    iget p1, v7, Lz8;->a:I

    if-ltz p1, :cond_28a

    if-nez p1, :cond_270

    .line 92
    invoke-interface {v9, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_257

    :cond_270
    add-int p3, p0, p1

    .line 93
    sget-object v2, La81;->a:Lfo0;

    invoke-virtual {v2, p2, p0, p3}, Lfo0;->B([BII)Z

    move-result v2

    if-eqz v2, :cond_285

    .line 94
    new-instance v2, Ljava/lang/String;

    sget-object v3, Ll40;->a:Ljava/nio/charset/Charset;

    invoke-direct {v2, p2, p0, p1, v3}, Ljava/lang/String;-><init>([BIILjava/nio/charset/Charset;)V

    .line 95
    invoke-interface {v9, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_256

    .line 96
    :cond_285
    invoke-static {}, La50;->b()La50;

    move-result-object p0

    throw p0

    .line 97
    :cond_28a
    invoke-static {}, La50;->e()La50;

    move-result-object p0

    throw p0

    :cond_28f
    :goto_28f
    return p0

    .line 98
    :cond_290
    invoke-static {}, La50;->b()La50;

    move-result-object p0

    throw p0

    .line 99
    :cond_295
    invoke-static {}, La50;->e()La50;

    move-result-object p0

    throw p0

    :cond_29a
    move v2, p0

    goto/16 :goto_4ba

    :pswitch_29d
    move p0, p3

    move-object/from16 v7, p13

    move v6, v0

    move-object v9, v4

    move/from16 v4, p4

    const/4 p1, 0x0

    if-ne v1, v8, :cond_2cc

    .line 100
    move-object v4, v9

    check-cast v4, Loa;

    .line 101
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 102
    iget p3, v7, Lz8;->a:I

    add-int/2addr p3, p0

    :goto_2b1
    if-ge p0, p3, :cond_2c4

    .line 103
    invoke-static {p2, p0, v7}, Ln40;->v([BILz8;)I

    move-result p0

    .line 104
    iget-wide v8, v7, Lz8;->b:J

    cmp-long v1, v8, v2

    if-eqz v1, :cond_2bf

    move v1, v5

    goto :goto_2c0

    :cond_2bf
    move v1, p1

    :goto_2c0
    invoke-virtual {v4, v1}, Loa;->g(Z)V

    goto :goto_2b1

    :cond_2c4
    if-ne p0, p3, :cond_2c7

    return p0

    .line 105
    :cond_2c7
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_2cc
    if-nez v1, :cond_29a

    .line 106
    move-object v1, v9

    check-cast v1, Loa;

    .line 107
    invoke-static {p2, p3, v7}, Ln40;->v([BILz8;)I

    move-result p0

    .line 108
    iget-wide v8, v7, Lz8;->b:J

    cmp-long p3, v8, v2

    if-eqz p3, :cond_2dd

    move p3, v5

    goto :goto_2de

    :cond_2dd
    move p3, p1

    :goto_2de
    invoke-virtual {v1, p3}, Loa;->g(Z)V

    :goto_2e1
    if-ge p0, v4, :cond_2fd

    .line 109
    invoke-static {p2, p0, v7}, Ln40;->t([BILz8;)I

    move-result p3

    .line 110
    iget v8, v7, Lz8;->a:I

    if-eq v6, v8, :cond_2ec

    goto :goto_2fd

    .line 111
    :cond_2ec
    invoke-static {p2, p3, v7}, Ln40;->v([BILz8;)I

    move-result p0

    .line 112
    iget-wide v8, v7, Lz8;->b:J

    cmp-long p3, v8, v2

    if-eqz p3, :cond_2f8

    move p3, v5

    goto :goto_2f9

    :cond_2f8
    move p3, p1

    :goto_2f9
    invoke-virtual {v1, p3}, Loa;->g(Z)V

    goto :goto_2e1

    :cond_2fd
    :goto_2fd
    return p0

    :pswitch_2fe
    move p0, p3

    move-object/from16 v7, p13

    move v6, v0

    move-object v9, v4

    move/from16 v4, p4

    if-ne v1, v8, :cond_325

    .line 113
    move-object v4, v9

    check-cast v4, Ls30;

    .line 114
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 115
    iget p1, v7, Lz8;->a:I

    add-int/2addr p1, p0

    :goto_311
    if-ge p0, p1, :cond_31d

    .line 116
    invoke-static {p0, p2}, Ln40;->j(I[B)I

    move-result p3

    invoke-virtual {v4, p3}, Ls30;->g(I)V

    add-int/lit8 p0, p0, 0x4

    goto :goto_311

    :cond_31d
    if-ne p0, p1, :cond_320

    return p0

    .line 117
    :cond_320
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_325
    if-ne v1, p1, :cond_29a

    .line 118
    move-object p1, v9

    check-cast p1, Ls30;

    .line 119
    invoke-static {p3, p2}, Ln40;->j(I[B)I

    move-result v1

    invoke-virtual {p1, v1}, Ls30;->g(I)V

    :goto_331
    add-int/lit8 p3, p0, 0x4

    if-ge p3, v4, :cond_346

    .line 120
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 121
    iget v1, v7, Lz8;->a:I

    if-eq v6, v1, :cond_33e

    goto :goto_346

    .line 122
    :cond_33e
    invoke-static {p0, p2}, Ln40;->j(I[B)I

    move-result p3

    invoke-virtual {p1, p3}, Ls30;->g(I)V

    goto :goto_331

    :cond_346
    :goto_346
    return p3

    :pswitch_347
    move p0, p3

    move-object/from16 v7, p13

    move v6, v0

    move-object v9, v4

    move/from16 v4, p4

    if-ne v1, v8, :cond_36e

    .line 123
    move-object v4, v9

    check-cast v4, Lua0;

    .line 124
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 125
    iget p1, v7, Lz8;->a:I

    add-int/2addr p1, p0

    :goto_35a
    if-ge p0, p1, :cond_366

    .line 126
    invoke-static {p0, p2}, Ln40;->k(I[B)J

    move-result-wide v1

    invoke-virtual {v4, v1, v2}, Lua0;->g(J)V

    add-int/lit8 p0, p0, 0x8

    goto :goto_35a

    :cond_366
    if-ne p0, p1, :cond_369

    return p0

    .line 127
    :cond_369
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_36e
    if-ne v1, v5, :cond_29a

    .line 128
    move-object p1, v9

    check-cast p1, Lua0;

    .line 129
    invoke-static {p3, p2}, Ln40;->k(I[B)J

    move-result-wide v1

    invoke-virtual {p1, v1, v2}, Lua0;->g(J)V

    :goto_37a
    add-int/lit8 p3, p0, 0x8

    if-ge p3, v4, :cond_38f

    .line 130
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 131
    iget v1, v7, Lz8;->a:I

    if-eq v6, v1, :cond_387

    goto :goto_38f

    .line 132
    :cond_387
    invoke-static {p0, p2}, Ln40;->k(I[B)J

    move-result-wide v1

    invoke-virtual {p1, v1, v2}, Lua0;->g(J)V

    goto :goto_37a

    :cond_38f
    :goto_38f
    return p3

    :pswitch_390
    move p0, p3

    move-object/from16 v7, p13

    move v6, v0

    move-object v9, v4

    move/from16 v4, p4

    if-ne v1, v8, :cond_3b7

    .line 133
    move-object v4, v9

    check-cast v4, Ls30;

    .line 134
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 135
    iget p1, v7, Lz8;->a:I

    add-int/2addr p1, p0

    :goto_3a3
    if-ge p0, p1, :cond_3af

    .line 136
    invoke-static {p2, p0, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 137
    iget p3, v7, Lz8;->a:I

    invoke-virtual {v4, p3}, Ls30;->g(I)V

    goto :goto_3a3

    :cond_3af
    if-ne p0, p1, :cond_3b2

    return p0

    .line 138
    :cond_3b2
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_3b7
    if-nez v1, :cond_29a

    move/from16 p8, p0

    move-object/from16 p7, p2

    move/from16 p9, v4

    move/from16 p6, v6

    move-object/from16 p11, v7

    move-object/from16 p10, v9

    .line 139
    invoke-static/range {p6 .. p11}, Ln40;->u(I[BIILi40;Lz8;)I

    move-result p0

    return p0

    :pswitch_3ca
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v7, p13

    move v6, v0

    if-ne v1, v8, :cond_3ef

    .line 140
    check-cast v4, Lua0;

    .line 141
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 142
    iget p1, v7, Lz8;->a:I

    add-int/2addr p1, p0

    :goto_3db
    if-ge p0, p1, :cond_3e7

    .line 143
    invoke-static {p2, p0, v7}, Ln40;->v([BILz8;)I

    move-result p0

    .line 144
    iget-wide v1, v7, Lz8;->b:J

    invoke-virtual {v4, v1, v2}, Lua0;->g(J)V

    goto :goto_3db

    :cond_3e7
    if-ne p0, p1, :cond_3ea

    return p0

    .line 145
    :cond_3ea
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_3ef
    if-nez v1, :cond_4ba

    .line 146
    check-cast v4, Lua0;

    .line 147
    invoke-static {p2, p3, v7}, Ln40;->v([BILz8;)I

    move-result p0

    .line 148
    iget-wide v1, v7, Lz8;->b:J

    invoke-virtual {v4, v1, v2}, Lua0;->g(J)V

    :goto_3fc
    if-ge p0, v3, :cond_411

    .line 149
    invoke-static {p2, p0, v7}, Ln40;->t([BILz8;)I

    move-result p1

    .line 150
    iget p3, v7, Lz8;->a:I

    if-eq v6, p3, :cond_407

    goto :goto_411

    .line 151
    :cond_407
    invoke-static {p2, p1, v7}, Ln40;->v([BILz8;)I

    move-result p0

    .line 152
    iget-wide v1, v7, Lz8;->b:J

    invoke-virtual {v4, v1, v2}, Lua0;->g(J)V

    goto :goto_3fc

    :cond_411
    :goto_411
    return p0

    :pswitch_412
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v7, p13

    move v6, v0

    if-ne v1, v8, :cond_43b

    .line 153
    check-cast v4, Lcu;

    .line 154
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 155
    iget p1, v7, Lz8;->a:I

    add-int/2addr p1, p0

    :goto_423
    if-ge p0, p1, :cond_433

    .line 156
    invoke-static {p0, p2}, Ln40;->j(I[B)I

    move-result p3

    invoke-static {p3}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p3

    .line 157
    invoke-virtual {v4, p3}, Lcu;->g(F)V

    add-int/lit8 p0, p0, 0x4

    goto :goto_423

    :cond_433
    if-ne p0, p1, :cond_436

    return p0

    .line 158
    :cond_436
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_43b
    if-ne v1, p1, :cond_4ba

    .line 159
    check-cast v4, Lcu;

    .line 160
    invoke-static {p3, p2}, Ln40;->j(I[B)I

    move-result p0

    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p0

    .line 161
    invoke-virtual {v4, p0}, Lcu;->g(F)V

    add-int/lit8 p3, v2, 0x4

    :goto_44c
    if-ge p3, v3, :cond_465

    .line 162
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 163
    iget p1, v7, Lz8;->a:I

    if-eq v6, p1, :cond_457

    goto :goto_465

    .line 164
    :cond_457
    invoke-static {p0, p2}, Ln40;->j(I[B)I

    move-result p1

    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result p1

    .line 165
    invoke-virtual {v4, p1}, Lcu;->g(F)V

    add-int/lit8 p3, p0, 0x4

    goto :goto_44c

    :cond_465
    :goto_465
    return p3

    :pswitch_466
    move v2, p3

    move/from16 v3, p4

    move-object/from16 v7, p13

    move v6, v0

    if-ne v1, v8, :cond_48f

    .line 166
    check-cast v4, Lbo;

    .line 167
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 168
    iget p1, v7, Lz8;->a:I

    add-int/2addr p1, p0

    :goto_477
    if-ge p0, p1, :cond_487

    .line 169
    invoke-static {p0, p2}, Ln40;->k(I[B)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v1

    .line 170
    invoke-virtual {v4, v1, v2}, Lbo;->g(D)V

    add-int/lit8 p0, p0, 0x8

    goto :goto_477

    :cond_487
    if-ne p0, p1, :cond_48a

    return p0

    .line 171
    :cond_48a
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :cond_48f
    if-ne v1, v5, :cond_4ba

    .line 172
    check-cast v4, Lbo;

    .line 173
    invoke-static {p3, p2}, Ln40;->k(I[B)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide p0

    .line 174
    invoke-virtual {v4, p0, p1}, Lbo;->g(D)V

    add-int/lit8 p3, v2, 0x8

    :goto_4a0
    if-ge p3, v3, :cond_4b9

    .line 175
    invoke-static {p2, p3, v7}, Ln40;->t([BILz8;)I

    move-result p0

    .line 176
    iget p1, v7, Lz8;->a:I

    if-eq v6, p1, :cond_4ab

    goto :goto_4b9

    .line 177
    :cond_4ab
    invoke-static {p0, p2}, Ln40;->k(I[B)J

    move-result-wide v1

    invoke-static {v1, v2}, Ljava/lang/Double;->longBitsToDouble(J)D

    move-result-wide v1

    .line 178
    invoke-virtual {v4, v1, v2}, Lbo;->g(D)V

    add-int/lit8 p3, p0, 0x8

    goto :goto_4a0

    :cond_4b9
    :goto_4b9
    return p3

    :cond_4ba
    :goto_4ba
    return v2

    nop

    :pswitch_data_4bc
    .packed-switch 0x12
        :pswitch_466
        :pswitch_412
        :pswitch_3ca
        :pswitch_3ca
        :pswitch_390
        :pswitch_347
        :pswitch_2fe
        :pswitch_29d
        :pswitch_1d8
        :pswitch_1ba
        :pswitch_15b
        :pswitch_390
        :pswitch_12a
        :pswitch_2fe
        :pswitch_347
        :pswitch_d7
        :pswitch_84
        :pswitch_466
        :pswitch_412
        :pswitch_3ca
        :pswitch_3ca
        :pswitch_390
        :pswitch_347
        :pswitch_2fe
        :pswitch_29d
        :pswitch_390
        :pswitch_12a
        :pswitch_2fe
        :pswitch_347
        :pswitch_d7
        :pswitch_84
        :pswitch_34
    .end packed-switch
.end method

.method public final M(Ljava/lang/Object;JLcd;Les0;Lcs;)V
    .registers 8

    .line 1
    iget-object p0, p0, Lde0;->l:Le90;

    .line 2
    .line 3
    invoke-virtual {p0, p2, p3, p1}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    iget-object p1, p4, Lcd;->e:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast p1, Lwd;

    .line 10
    .line 11
    iget p2, p4, Lcd;->b:I

    .line 12
    .line 13
    and-int/lit8 p3, p2, 0x7

    .line 14
    .line 15
    const/4 v0, 0x3

    .line 16
    if-ne p3, v0, :cond_32

    .line 17
    .line 18
    :cond_11
    invoke-interface {p5}, Les0;->d()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p3

    .line 22
    invoke-virtual {p4, p3, p5, p6}, Lcd;->e(Ljava/lang/Object;Les0;Lcs;)V

    .line 23
    .line 24
    .line 25
    invoke-interface {p5, p3}, Les0;->b(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    invoke-interface {p0, p3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    invoke-virtual {p1}, Lwd;->e()Z

    .line 32
    .line 33
    .line 34
    move-result p3

    .line 35
    if-nez p3, :cond_31

    .line 36
    .line 37
    iget p3, p4, Lcd;->d:I

    .line 38
    .line 39
    if-eqz p3, :cond_29

    .line 40
    .line 41
    goto :goto_31

    .line 42
    :cond_29
    invoke-virtual {p1}, Lwd;->z()I

    .line 43
    .line 44
    .line 45
    move-result p3

    .line 46
    if-eq p3, p2, :cond_11

    .line 47
    .line 48
    iput p3, p4, Lcd;->d:I

    .line 49
    .line 50
    :cond_31
    :goto_31
    return-void

    .line 51
    :cond_32
    invoke-static {}, La50;->c()Lx40;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    throw p0
.end method

.method public final N(Ljava/lang/Object;ILcd;Les0;Lcs;)V
    .registers 8

    .line 1
    const v0, 0xfffff

    .line 2
    .line 3
    .line 4
    and-int/2addr p2, v0

    .line 5
    int-to-long v0, p2

    .line 6
    iget-object p0, p0, Lde0;->l:Le90;

    .line 7
    .line 8
    invoke-virtual {p0, v0, v1, p1}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    iget-object p1, p3, Lcd;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p1, Lwd;

    .line 15
    .line 16
    iget p2, p3, Lcd;->b:I

    .line 17
    .line 18
    and-int/lit8 v0, p2, 0x7

    .line 19
    .line 20
    const/4 v1, 0x2

    .line 21
    if-ne v0, v1, :cond_37

    .line 22
    .line 23
    :cond_16
    invoke-interface {p4}, Les0;->d()Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {p3, v0, p4, p5}, Lcd;->g(Ljava/lang/Object;Les0;Lcs;)V

    .line 28
    .line 29
    .line 30
    invoke-interface {p4, v0}, Les0;->b(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    invoke-virtual {p1}, Lwd;->e()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-nez v0, :cond_36

    .line 41
    .line 42
    iget v0, p3, Lcd;->d:I

    .line 43
    .line 44
    if-eqz v0, :cond_2e

    .line 45
    .line 46
    goto :goto_36

    .line 47
    :cond_2e
    invoke-virtual {p1}, Lwd;->z()I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    if-eq v0, p2, :cond_16

    .line 52
    .line 53
    iput v0, p3, Lcd;->d:I

    .line 54
    .line 55
    :cond_36
    :goto_36
    return-void

    .line 56
    :cond_37
    invoke-static {}, La50;->c()Lx40;

    .line 57
    .line 58
    .line 59
    move-result-object p0

    .line 60
    throw p0
.end method

.method public final O(ILcd;Ljava/lang/Object;)V
    .registers 7

    .line 1
    const/high16 v0, 0x20000000

    .line 2
    .line 3
    and-int/2addr v0, p1

    .line 4
    const/4 v1, 0x2

    .line 5
    const v2, 0xfffff

    .line 6
    .line 7
    .line 8
    if-eqz v0, :cond_1b

    .line 9
    .line 10
    and-int p0, p1, v2

    .line 11
    .line 12
    int-to-long p0, p0

    .line 13
    invoke-virtual {p2, v1}, Lcd;->T(I)V

    .line 14
    .line 15
    .line 16
    iget-object p2, p2, Lcd;->e:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p2, Lwd;

    .line 19
    .line 20
    invoke-virtual {p2}, Lwd;->y()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object p2

    .line 24
    invoke-static {p0, p1, p3, p2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    return-void

    .line 28
    :cond_1b
    iget-boolean p0, p0, Lde0;->f:Z

    .line 29
    .line 30
    if-eqz p0, :cond_31

    .line 31
    .line 32
    and-int p0, p1, v2

    .line 33
    .line 34
    int-to-long p0, p0

    .line 35
    invoke-virtual {p2, v1}, Lcd;->T(I)V

    .line 36
    .line 37
    .line 38
    iget-object p2, p2, Lcd;->e:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast p2, Lwd;

    .line 41
    .line 42
    invoke-virtual {p2}, Lwd;->x()Ljava/lang/String;

    .line 43
    .line 44
    .line 45
    move-result-object p2

    .line 46
    invoke-static {p0, p1, p3, p2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 47
    .line 48
    .line 49
    return-void

    .line 50
    :cond_31
    and-int p0, p1, v2

    .line 51
    .line 52
    int-to-long p0, p0

    .line 53
    invoke-virtual {p2}, Lcd;->l()Lqb;

    .line 54
    .line 55
    .line 56
    move-result-object p2

    .line 57
    invoke-static {p0, p1, p3, p2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    return-void
.end method

.method public final Q(ILjava/lang/Object;)V
    .registers 7

    .line 1
    add-int/lit8 p1, p1, 0x2

    .line 2
    .line 3
    iget-object p0, p0, Lde0;->a:[I

    .line 4
    .line 5
    aget p0, p0, p1

    .line 6
    .line 7
    const p1, 0xfffff

    .line 8
    .line 9
    .line 10
    and-int/2addr p1, p0

    .line 11
    int-to-long v0, p1

    .line 12
    const-wide/32 v2, 0xfffff

    .line 13
    .line 14
    .line 15
    cmp-long p1, v0, v2

    .line 16
    .line 17
    if-nez p1, :cond_13

    .line 18
    .line 19
    return-void

    .line 20
    :cond_13
    ushr-int/lit8 p0, p0, 0x14

    .line 21
    .line 22
    const/4 p1, 0x1

    .line 23
    shl-int p0, p1, p0

    .line 24
    .line 25
    sget-object p1, Lk71;->c:Lh71;

    .line 26
    .line 27
    invoke-virtual {p1, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 28
    .line 29
    .line 30
    move-result p1

    .line 31
    or-int/2addr p0, p1

    .line 32
    invoke-static {p0, v0, v1, p2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    return-void
.end method

.method public final R(IILjava/lang/Object;)V
    .registers 6

    .line 1
    add-int/lit8 p2, p2, 0x2

    .line 2
    .line 3
    iget-object p0, p0, Lde0;->a:[I

    .line 4
    .line 5
    aget p0, p0, p2

    .line 6
    .line 7
    const p2, 0xfffff

    .line 8
    .line 9
    .line 10
    and-int/2addr p0, p2

    .line 11
    int-to-long v0, p0

    .line 12
    invoke-static {p1, v0, v1, p3}, Lk71;->n(IJLjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public final S(II)I
    .registers 7

    .line 1
    iget-object p0, p0, Lde0;->a:[I

    .line 2
    .line 3
    array-length v0, p0

    .line 4
    div-int/lit8 v0, v0, 0x3

    .line 5
    .line 6
    add-int/lit8 v0, v0, -0x1

    .line 7
    .line 8
    :goto_7
    if-gt p2, v0, :cond_1e

    .line 9
    .line 10
    add-int v1, v0, p2

    .line 11
    .line 12
    ushr-int/lit8 v1, v1, 0x1

    .line 13
    .line 14
    mul-int/lit8 v2, v1, 0x3

    .line 15
    .line 16
    aget v3, p0, v2

    .line 17
    .line 18
    if-ne p1, v3, :cond_14

    .line 19
    .line 20
    return v2

    .line 21
    :cond_14
    if-ge p1, v3, :cond_1a

    .line 22
    .line 23
    add-int/lit8 v1, v1, -0x1

    .line 24
    .line 25
    move v0, v1

    .line 26
    goto :goto_7

    .line 27
    :cond_1a
    add-int/lit8 v1, v1, 0x1

    .line 28
    .line 29
    move p2, v1

    .line 30
    goto :goto_7

    .line 31
    :cond_1e
    const/4 p0, -0x1

    .line 32
    return p0
.end method

.method public final T(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 7

    .line 1
    sget-object v0, Lde0;->p:Lsun/misc/Unsafe;

    .line 2
    .line 3
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const v2, 0xfffff

    .line 8
    .line 9
    .line 10
    and-int/2addr v1, v2

    .line 11
    int-to-long v1, v1

    .line 12
    invoke-virtual {v0, p1, v1, v2, p3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p2, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final U(IILjava/lang/Object;Ljava/lang/Object;)V
    .registers 8

    .line 1
    sget-object v0, Lde0;->p:Lsun/misc/Unsafe;

    .line 2
    .line 3
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const v2, 0xfffff

    .line 8
    .line 9
    .line 10
    and-int/2addr v1, v2

    .line 11
    int-to-long v1, v1

    .line 12
    invoke-virtual {v0, p3, v1, v2, p4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    invoke-virtual {p0, p1, p2, p3}, Lde0;->R(IILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method

.method public final W(I)I
    .registers 2

    .line 1
    add-int/lit8 p1, p1, 0x1

    .line 2
    .line 3
    iget-object p0, p0, Lde0;->a:[I

    .line 4
    .line 5
    aget p0, p0, p1

    .line 6
    .line 7
    return p0
.end method

.method public final X(Ljava/lang/Object;Ldb0;)V
    .registers 22

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Lde0;->a:[I

    .line 8
    .line 9
    array-length v4, v3

    .line 10
    sget-object v5, Lde0;->p:Lsun/misc/Unsafe;

    .line 11
    .line 12
    const/4 v8, 0x0

    .line 13
    const v9, 0xfffff

    .line 14
    .line 15
    .line 16
    const/4 v10, 0x0

    .line 17
    :goto_10
    if-ge v8, v4, :cond_535

    .line 18
    .line 19
    invoke-virtual {v0, v8}, Lde0;->W(I)I

    .line 20
    .line 21
    .line 22
    move-result v11

    .line 23
    aget v12, v3, v8

    .line 24
    .line 25
    invoke-static {v11}, Lde0;->V(I)I

    .line 26
    .line 27
    .line 28
    move-result v13

    .line 29
    const/16 v14, 0x11

    .line 30
    .line 31
    const/4 v15, 0x1

    .line 32
    if-gt v13, v14, :cond_37

    .line 33
    .line 34
    add-int/lit8 v14, v8, 0x2

    .line 35
    .line 36
    aget v14, v3, v14

    .line 37
    .line 38
    const v16, 0xfffff

    .line 39
    .line 40
    .line 41
    and-int v6, v14, v16

    .line 42
    .line 43
    if-eq v6, v9, :cond_32

    .line 44
    .line 45
    int-to-long v9, v6

    .line 46
    invoke-virtual {v5, v1, v9, v10}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 47
    .line 48
    .line 49
    move-result v10

    .line 50
    move v9, v6

    .line 51
    :cond_32
    ushr-int/lit8 v6, v14, 0x14

    .line 52
    .line 53
    shl-int v6, v15, v6

    .line 54
    .line 55
    goto :goto_3b

    .line 56
    :cond_37
    const v16, 0xfffff

    .line 57
    .line 58
    .line 59
    const/4 v6, 0x0

    .line 60
    :goto_3b
    and-int v11, v11, v16

    .line 61
    .line 62
    move/from16 v17, v8

    .line 63
    .line 64
    int-to-long v7, v11

    .line 65
    const/16 v11, 0x3f

    .line 66
    .line 67
    packed-switch v13, :pswitch_data_544

    .line 68
    .line 69
    .line 70
    move/from16 v13, v17

    .line 71
    .line 72
    :cond_47
    :goto_47
    const/4 v14, 0x0

    .line 73
    goto/16 :goto_531

    .line 74
    .line 75
    :pswitch_4a
    move/from16 v13, v17

    .line 76
    .line 77
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 78
    .line 79
    .line 80
    move-result v6

    .line 81
    if-eqz v6, :cond_47

    .line 82
    .line 83
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v6

    .line 87
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 88
    .line 89
    .line 90
    move-result-object v7

    .line 91
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->B(ILjava/lang/Object;Les0;)V

    .line 92
    .line 93
    .line 94
    goto :goto_47

    .line 95
    :pswitch_5e
    move/from16 v13, v17

    .line 96
    .line 97
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 98
    .line 99
    .line 100
    move-result v6

    .line 101
    if-eqz v6, :cond_47

    .line 102
    .line 103
    invoke-static {v7, v8, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 104
    .line 105
    .line 106
    move-result-wide v6

    .line 107
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast v8, Lde;

    .line 110
    .line 111
    shl-long v17, v6, v15

    .line 112
    .line 113
    shr-long/2addr v6, v11

    .line 114
    xor-long v6, v17, v6

    .line 115
    .line 116
    invoke-virtual {v8, v12, v6, v7}, Lde;->F(IJ)V

    .line 117
    .line 118
    .line 119
    goto :goto_47

    .line 120
    :pswitch_77
    move/from16 v13, v17

    .line 121
    .line 122
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 123
    .line 124
    .line 125
    move-result v6

    .line 126
    if-eqz v6, :cond_47

    .line 127
    .line 128
    invoke-static {v7, v8, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 129
    .line 130
    .line 131
    move-result v6

    .line 132
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 133
    .line 134
    check-cast v7, Lde;

    .line 135
    .line 136
    shl-int/lit8 v8, v6, 0x1

    .line 137
    .line 138
    shr-int/lit8 v6, v6, 0x1f

    .line 139
    .line 140
    xor-int/2addr v6, v8

    .line 141
    invoke-virtual {v7, v12, v6}, Lde;->D(II)V

    .line 142
    .line 143
    .line 144
    goto :goto_47

    .line 145
    :pswitch_90
    move/from16 v13, v17

    .line 146
    .line 147
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v6

    .line 151
    if-eqz v6, :cond_47

    .line 152
    .line 153
    invoke-static {v7, v8, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 154
    .line 155
    .line 156
    move-result-wide v6

    .line 157
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 158
    .line 159
    check-cast v8, Lde;

    .line 160
    .line 161
    invoke-virtual {v8, v12, v6, v7}, Lde;->t(IJ)V

    .line 162
    .line 163
    .line 164
    goto :goto_47

    .line 165
    :pswitch_a4
    move/from16 v13, v17

    .line 166
    .line 167
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v6

    .line 171
    if-eqz v6, :cond_47

    .line 172
    .line 173
    invoke-static {v7, v8, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 174
    .line 175
    .line 176
    move-result v6

    .line 177
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 178
    .line 179
    check-cast v7, Lde;

    .line 180
    .line 181
    invoke-virtual {v7, v12, v6}, Lde;->r(II)V

    .line 182
    .line 183
    .line 184
    goto :goto_47

    .line 185
    :pswitch_b8
    move/from16 v13, v17

    .line 186
    .line 187
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result v6

    .line 191
    if-eqz v6, :cond_47

    .line 192
    .line 193
    invoke-static {v7, v8, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 194
    .line 195
    .line 196
    move-result v6

    .line 197
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 198
    .line 199
    check-cast v7, Lde;

    .line 200
    .line 201
    invoke-virtual {v7, v12, v6}, Lde;->v(II)V

    .line 202
    .line 203
    .line 204
    goto/16 :goto_47

    .line 205
    .line 206
    :pswitch_cd
    move/from16 v13, v17

    .line 207
    .line 208
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 209
    .line 210
    .line 211
    move-result v6

    .line 212
    if-eqz v6, :cond_47

    .line 213
    .line 214
    invoke-static {v7, v8, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 215
    .line 216
    .line 217
    move-result v6

    .line 218
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 219
    .line 220
    check-cast v7, Lde;

    .line 221
    .line 222
    invoke-virtual {v7, v12, v6}, Lde;->D(II)V

    .line 223
    .line 224
    .line 225
    goto/16 :goto_47

    .line 226
    .line 227
    :pswitch_e2
    move/from16 v13, v17

    .line 228
    .line 229
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 230
    .line 231
    .line 232
    move-result v6

    .line 233
    if-eqz v6, :cond_47

    .line 234
    .line 235
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v6

    .line 239
    check-cast v6, Lqb;

    .line 240
    .line 241
    invoke-virtual {v2, v12, v6}, Ldb0;->x(ILqb;)V

    .line 242
    .line 243
    .line 244
    goto/16 :goto_47

    .line 245
    .line 246
    :pswitch_f5
    move/from16 v13, v17

    .line 247
    .line 248
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 249
    .line 250
    .line 251
    move-result v6

    .line 252
    if-eqz v6, :cond_47

    .line 253
    .line 254
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v6

    .line 258
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 259
    .line 260
    .line 261
    move-result-object v7

    .line 262
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->G(ILjava/lang/Object;Les0;)V

    .line 263
    .line 264
    .line 265
    goto/16 :goto_47

    .line 266
    .line 267
    :pswitch_10a
    move/from16 v13, v17

    .line 268
    .line 269
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 270
    .line 271
    .line 272
    move-result v6

    .line 273
    if-eqz v6, :cond_47

    .line 274
    .line 275
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 276
    .line 277
    .line 278
    move-result-object v6

    .line 279
    invoke-static {v12, v6, v2}, Lde0;->Z(ILjava/lang/Object;Ldb0;)V

    .line 280
    .line 281
    .line 282
    goto/16 :goto_47

    .line 283
    .line 284
    :pswitch_11b
    move/from16 v13, v17

    .line 285
    .line 286
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    move-result v6

    .line 290
    if-eqz v6, :cond_47

    .line 291
    .line 292
    sget-object v6, Lk71;->c:Lh71;

    .line 293
    .line 294
    invoke-virtual {v6, v7, v8, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 295
    .line 296
    .line 297
    move-result-object v6

    .line 298
    check-cast v6, Ljava/lang/Boolean;

    .line 299
    .line 300
    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    .line 301
    .line 302
    .line 303
    move-result v6

    .line 304
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 305
    .line 306
    check-cast v7, Lde;

    .line 307
    .line 308
    invoke-virtual {v7, v12, v6}, Lde;->n(IZ)V

    .line 309
    .line 310
    .line 311
    goto/16 :goto_47

    .line 312
    .line 313
    :pswitch_138
    move/from16 v13, v17

    .line 314
    .line 315
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    move-result v6

    .line 319
    if-eqz v6, :cond_47

    .line 320
    .line 321
    invoke-static {v7, v8, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 322
    .line 323
    .line 324
    move-result v6

    .line 325
    invoke-virtual {v2, v12, v6}, Ldb0;->y(II)V

    .line 326
    .line 327
    .line 328
    goto/16 :goto_47

    .line 329
    .line 330
    :pswitch_149
    move/from16 v13, v17

    .line 331
    .line 332
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 333
    .line 334
    .line 335
    move-result v6

    .line 336
    if-eqz v6, :cond_47

    .line 337
    .line 338
    invoke-static {v7, v8, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 339
    .line 340
    .line 341
    move-result-wide v6

    .line 342
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->z(IJ)V

    .line 343
    .line 344
    .line 345
    goto/16 :goto_47

    .line 346
    .line 347
    :pswitch_15a
    move/from16 v13, v17

    .line 348
    .line 349
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 350
    .line 351
    .line 352
    move-result v6

    .line 353
    if-eqz v6, :cond_47

    .line 354
    .line 355
    invoke-static {v7, v8, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 356
    .line 357
    .line 358
    move-result v6

    .line 359
    invoke-virtual {v2, v12, v6}, Ldb0;->D(II)V

    .line 360
    .line 361
    .line 362
    goto/16 :goto_47

    .line 363
    .line 364
    :pswitch_16b
    move/from16 v13, v17

    .line 365
    .line 366
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 367
    .line 368
    .line 369
    move-result v6

    .line 370
    if-eqz v6, :cond_47

    .line 371
    .line 372
    invoke-static {v7, v8, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 373
    .line 374
    .line 375
    move-result-wide v6

    .line 376
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 377
    .line 378
    check-cast v8, Lde;

    .line 379
    .line 380
    invoke-virtual {v8, v12, v6, v7}, Lde;->F(IJ)V

    .line 381
    .line 382
    .line 383
    goto/16 :goto_47

    .line 384
    .line 385
    :pswitch_180
    move/from16 v13, v17

    .line 386
    .line 387
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 388
    .line 389
    .line 390
    move-result v6

    .line 391
    if-eqz v6, :cond_47

    .line 392
    .line 393
    invoke-static {v7, v8, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 394
    .line 395
    .line 396
    move-result-wide v6

    .line 397
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->E(IJ)V

    .line 398
    .line 399
    .line 400
    goto/16 :goto_47

    .line 401
    .line 402
    :pswitch_191
    move/from16 v13, v17

    .line 403
    .line 404
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 405
    .line 406
    .line 407
    move-result v6

    .line 408
    if-eqz v6, :cond_47

    .line 409
    .line 410
    sget-object v6, Lk71;->c:Lh71;

    .line 411
    .line 412
    invoke-virtual {v6, v7, v8, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    move-result-object v6

    .line 416
    check-cast v6, Ljava/lang/Float;

    .line 417
    .line 418
    invoke-virtual {v6}, Ljava/lang/Float;->floatValue()F

    .line 419
    .line 420
    .line 421
    move-result v6

    .line 422
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 423
    .line 424
    check-cast v7, Lde;

    .line 425
    .line 426
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 427
    .line 428
    .line 429
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 430
    .line 431
    .line 432
    move-result v6

    .line 433
    invoke-virtual {v7, v12, v6}, Lde;->r(II)V

    .line 434
    .line 435
    .line 436
    goto/16 :goto_47

    .line 437
    .line 438
    :pswitch_1b5
    move/from16 v13, v17

    .line 439
    .line 440
    invoke-virtual {v0, v12, v13, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 441
    .line 442
    .line 443
    move-result v6

    .line 444
    if-eqz v6, :cond_47

    .line 445
    .line 446
    sget-object v6, Lk71;->c:Lh71;

    .line 447
    .line 448
    invoke-virtual {v6, v7, v8, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 449
    .line 450
    .line 451
    move-result-object v6

    .line 452
    check-cast v6, Ljava/lang/Double;

    .line 453
    .line 454
    invoke-virtual {v6}, Ljava/lang/Double;->doubleValue()D

    .line 455
    .line 456
    .line 457
    move-result-wide v6

    .line 458
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 459
    .line 460
    check-cast v8, Lde;

    .line 461
    .line 462
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 463
    .line 464
    .line 465
    invoke-static {v6, v7}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 466
    .line 467
    .line 468
    move-result-wide v6

    .line 469
    invoke-virtual {v8, v12, v6, v7}, Lde;->t(IJ)V

    .line 470
    .line 471
    .line 472
    goto/16 :goto_47

    .line 473
    .line 474
    :pswitch_1d9
    move/from16 v13, v17

    .line 475
    .line 476
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 477
    .line 478
    .line 479
    move-result-object v6

    .line 480
    invoke-virtual {v0, v2, v12, v6, v13}, Lde0;->Y(Ldb0;ILjava/lang/Object;I)V

    .line 481
    .line 482
    .line 483
    goto/16 :goto_47

    .line 484
    .line 485
    :pswitch_1e4
    move/from16 v13, v17

    .line 486
    .line 487
    aget v6, v3, v13

    .line 488
    .line 489
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 490
    .line 491
    .line 492
    move-result-object v7

    .line 493
    check-cast v7, Ljava/util/List;

    .line 494
    .line 495
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 496
    .line 497
    .line 498
    move-result-object v8

    .line 499
    invoke-static {v6, v7, v2, v8}, Lis0;->F(ILjava/util/List;Ldb0;Les0;)V

    .line 500
    .line 501
    .line 502
    goto/16 :goto_47

    .line 503
    .line 504
    :pswitch_1f7
    move/from16 v13, v17

    .line 505
    .line 506
    aget v6, v3, v13

    .line 507
    .line 508
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 509
    .line 510
    .line 511
    move-result-object v7

    .line 512
    check-cast v7, Ljava/util/List;

    .line 513
    .line 514
    invoke-static {v6, v7, v2, v15}, Lis0;->M(ILjava/util/List;Ldb0;Z)V

    .line 515
    .line 516
    .line 517
    goto/16 :goto_47

    .line 518
    .line 519
    :pswitch_206
    move/from16 v13, v17

    .line 520
    .line 521
    aget v6, v3, v13

    .line 522
    .line 523
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 524
    .line 525
    .line 526
    move-result-object v7

    .line 527
    check-cast v7, Ljava/util/List;

    .line 528
    .line 529
    invoke-static {v6, v7, v2, v15}, Lis0;->L(ILjava/util/List;Ldb0;Z)V

    .line 530
    .line 531
    .line 532
    goto/16 :goto_47

    .line 533
    .line 534
    :pswitch_215
    move/from16 v13, v17

    .line 535
    .line 536
    aget v6, v3, v13

    .line 537
    .line 538
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 539
    .line 540
    .line 541
    move-result-object v7

    .line 542
    check-cast v7, Ljava/util/List;

    .line 543
    .line 544
    invoke-static {v6, v7, v2, v15}, Lis0;->K(ILjava/util/List;Ldb0;Z)V

    .line 545
    .line 546
    .line 547
    goto/16 :goto_47

    .line 548
    .line 549
    :pswitch_224
    move/from16 v13, v17

    .line 550
    .line 551
    aget v6, v3, v13

    .line 552
    .line 553
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 554
    .line 555
    .line 556
    move-result-object v7

    .line 557
    check-cast v7, Ljava/util/List;

    .line 558
    .line 559
    invoke-static {v6, v7, v2, v15}, Lis0;->J(ILjava/util/List;Ldb0;Z)V

    .line 560
    .line 561
    .line 562
    goto/16 :goto_47

    .line 563
    .line 564
    :pswitch_233
    move/from16 v13, v17

    .line 565
    .line 566
    aget v6, v3, v13

    .line 567
    .line 568
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    move-result-object v7

    .line 572
    check-cast v7, Ljava/util/List;

    .line 573
    .line 574
    invoke-static {v6, v7, v2, v15}, Lis0;->B(ILjava/util/List;Ldb0;Z)V

    .line 575
    .line 576
    .line 577
    goto/16 :goto_47

    .line 578
    .line 579
    :pswitch_242
    move/from16 v13, v17

    .line 580
    .line 581
    aget v6, v3, v13

    .line 582
    .line 583
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 584
    .line 585
    .line 586
    move-result-object v7

    .line 587
    check-cast v7, Ljava/util/List;

    .line 588
    .line 589
    invoke-static {v6, v7, v2, v15}, Lis0;->O(ILjava/util/List;Ldb0;Z)V

    .line 590
    .line 591
    .line 592
    goto/16 :goto_47

    .line 593
    .line 594
    :pswitch_251
    move/from16 v13, v17

    .line 595
    .line 596
    aget v6, v3, v13

    .line 597
    .line 598
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 599
    .line 600
    .line 601
    move-result-object v7

    .line 602
    check-cast v7, Ljava/util/List;

    .line 603
    .line 604
    invoke-static {v6, v7, v2, v15}, Lis0;->y(ILjava/util/List;Ldb0;Z)V

    .line 605
    .line 606
    .line 607
    goto/16 :goto_47

    .line 608
    .line 609
    :pswitch_260
    move/from16 v13, v17

    .line 610
    .line 611
    aget v6, v3, v13

    .line 612
    .line 613
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 614
    .line 615
    .line 616
    move-result-object v7

    .line 617
    check-cast v7, Ljava/util/List;

    .line 618
    .line 619
    invoke-static {v6, v7, v2, v15}, Lis0;->C(ILjava/util/List;Ldb0;Z)V

    .line 620
    .line 621
    .line 622
    goto/16 :goto_47

    .line 623
    .line 624
    :pswitch_26f
    move/from16 v13, v17

    .line 625
    .line 626
    aget v6, v3, v13

    .line 627
    .line 628
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 629
    .line 630
    .line 631
    move-result-object v7

    .line 632
    check-cast v7, Ljava/util/List;

    .line 633
    .line 634
    invoke-static {v6, v7, v2, v15}, Lis0;->D(ILjava/util/List;Ldb0;Z)V

    .line 635
    .line 636
    .line 637
    goto/16 :goto_47

    .line 638
    .line 639
    :pswitch_27e
    move/from16 v13, v17

    .line 640
    .line 641
    aget v6, v3, v13

    .line 642
    .line 643
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 644
    .line 645
    .line 646
    move-result-object v7

    .line 647
    check-cast v7, Ljava/util/List;

    .line 648
    .line 649
    invoke-static {v6, v7, v2, v15}, Lis0;->G(ILjava/util/List;Ldb0;Z)V

    .line 650
    .line 651
    .line 652
    goto/16 :goto_47

    .line 653
    .line 654
    :pswitch_28d
    move/from16 v13, v17

    .line 655
    .line 656
    aget v6, v3, v13

    .line 657
    .line 658
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 659
    .line 660
    .line 661
    move-result-object v7

    .line 662
    check-cast v7, Ljava/util/List;

    .line 663
    .line 664
    invoke-static {v6, v7, v2, v15}, Lis0;->P(ILjava/util/List;Ldb0;Z)V

    .line 665
    .line 666
    .line 667
    goto/16 :goto_47

    .line 668
    .line 669
    :pswitch_29c
    move/from16 v13, v17

    .line 670
    .line 671
    aget v6, v3, v13

    .line 672
    .line 673
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 674
    .line 675
    .line 676
    move-result-object v7

    .line 677
    check-cast v7, Ljava/util/List;

    .line 678
    .line 679
    invoke-static {v6, v7, v2, v15}, Lis0;->H(ILjava/util/List;Ldb0;Z)V

    .line 680
    .line 681
    .line 682
    goto/16 :goto_47

    .line 683
    .line 684
    :pswitch_2ab
    move/from16 v13, v17

    .line 685
    .line 686
    aget v6, v3, v13

    .line 687
    .line 688
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 689
    .line 690
    .line 691
    move-result-object v7

    .line 692
    check-cast v7, Ljava/util/List;

    .line 693
    .line 694
    invoke-static {v6, v7, v2, v15}, Lis0;->E(ILjava/util/List;Ldb0;Z)V

    .line 695
    .line 696
    .line 697
    goto/16 :goto_47

    .line 698
    .line 699
    :pswitch_2ba
    move/from16 v13, v17

    .line 700
    .line 701
    aget v6, v3, v13

    .line 702
    .line 703
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 704
    .line 705
    .line 706
    move-result-object v7

    .line 707
    check-cast v7, Ljava/util/List;

    .line 708
    .line 709
    invoke-static {v6, v7, v2, v15}, Lis0;->A(ILjava/util/List;Ldb0;Z)V

    .line 710
    .line 711
    .line 712
    goto/16 :goto_47

    .line 713
    .line 714
    :pswitch_2c9
    move/from16 v13, v17

    .line 715
    .line 716
    aget v6, v3, v13

    .line 717
    .line 718
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 719
    .line 720
    .line 721
    move-result-object v7

    .line 722
    check-cast v7, Ljava/util/List;

    .line 723
    .line 724
    const/4 v14, 0x0

    .line 725
    invoke-static {v6, v7, v2, v14}, Lis0;->M(ILjava/util/List;Ldb0;Z)V

    .line 726
    .line 727
    .line 728
    goto/16 :goto_531

    .line 729
    .line 730
    :pswitch_2d9
    move/from16 v13, v17

    .line 731
    .line 732
    const/4 v14, 0x0

    .line 733
    aget v6, v3, v13

    .line 734
    .line 735
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 736
    .line 737
    .line 738
    move-result-object v7

    .line 739
    check-cast v7, Ljava/util/List;

    .line 740
    .line 741
    invoke-static {v6, v7, v2, v14}, Lis0;->L(ILjava/util/List;Ldb0;Z)V

    .line 742
    .line 743
    .line 744
    goto/16 :goto_531

    .line 745
    .line 746
    :pswitch_2e9
    move/from16 v13, v17

    .line 747
    .line 748
    const/4 v14, 0x0

    .line 749
    aget v6, v3, v13

    .line 750
    .line 751
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 752
    .line 753
    .line 754
    move-result-object v7

    .line 755
    check-cast v7, Ljava/util/List;

    .line 756
    .line 757
    invoke-static {v6, v7, v2, v14}, Lis0;->K(ILjava/util/List;Ldb0;Z)V

    .line 758
    .line 759
    .line 760
    goto/16 :goto_531

    .line 761
    .line 762
    :pswitch_2f9
    move/from16 v13, v17

    .line 763
    .line 764
    const/4 v14, 0x0

    .line 765
    aget v6, v3, v13

    .line 766
    .line 767
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 768
    .line 769
    .line 770
    move-result-object v7

    .line 771
    check-cast v7, Ljava/util/List;

    .line 772
    .line 773
    invoke-static {v6, v7, v2, v14}, Lis0;->J(ILjava/util/List;Ldb0;Z)V

    .line 774
    .line 775
    .line 776
    goto/16 :goto_531

    .line 777
    .line 778
    :pswitch_309
    move/from16 v13, v17

    .line 779
    .line 780
    const/4 v14, 0x0

    .line 781
    aget v6, v3, v13

    .line 782
    .line 783
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 784
    .line 785
    .line 786
    move-result-object v7

    .line 787
    check-cast v7, Ljava/util/List;

    .line 788
    .line 789
    invoke-static {v6, v7, v2, v14}, Lis0;->B(ILjava/util/List;Ldb0;Z)V

    .line 790
    .line 791
    .line 792
    goto/16 :goto_531

    .line 793
    .line 794
    :pswitch_319
    move/from16 v13, v17

    .line 795
    .line 796
    const/4 v14, 0x0

    .line 797
    aget v6, v3, v13

    .line 798
    .line 799
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 800
    .line 801
    .line 802
    move-result-object v7

    .line 803
    check-cast v7, Ljava/util/List;

    .line 804
    .line 805
    invoke-static {v6, v7, v2, v14}, Lis0;->O(ILjava/util/List;Ldb0;Z)V

    .line 806
    .line 807
    .line 808
    goto/16 :goto_47

    .line 809
    .line 810
    :pswitch_329
    move/from16 v13, v17

    .line 811
    .line 812
    aget v6, v3, v13

    .line 813
    .line 814
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 815
    .line 816
    .line 817
    move-result-object v7

    .line 818
    check-cast v7, Ljava/util/List;

    .line 819
    .line 820
    invoke-static {v6, v7, v2}, Lis0;->z(ILjava/util/List;Ldb0;)V

    .line 821
    .line 822
    .line 823
    goto/16 :goto_47

    .line 824
    .line 825
    :pswitch_338
    move/from16 v13, v17

    .line 826
    .line 827
    aget v6, v3, v13

    .line 828
    .line 829
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 830
    .line 831
    .line 832
    move-result-object v7

    .line 833
    check-cast v7, Ljava/util/List;

    .line 834
    .line 835
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 836
    .line 837
    .line 838
    move-result-object v8

    .line 839
    invoke-static {v6, v7, v2, v8}, Lis0;->I(ILjava/util/List;Ldb0;Les0;)V

    .line 840
    .line 841
    .line 842
    goto/16 :goto_47

    .line 843
    .line 844
    :pswitch_34b
    move/from16 v13, v17

    .line 845
    .line 846
    aget v6, v3, v13

    .line 847
    .line 848
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 849
    .line 850
    .line 851
    move-result-object v7

    .line 852
    check-cast v7, Ljava/util/List;

    .line 853
    .line 854
    invoke-static {v6, v7, v2}, Lis0;->N(ILjava/util/List;Ldb0;)V

    .line 855
    .line 856
    .line 857
    goto/16 :goto_47

    .line 858
    .line 859
    :pswitch_35a
    move/from16 v13, v17

    .line 860
    .line 861
    aget v6, v3, v13

    .line 862
    .line 863
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 864
    .line 865
    .line 866
    move-result-object v7

    .line 867
    check-cast v7, Ljava/util/List;

    .line 868
    .line 869
    const/4 v14, 0x0

    .line 870
    invoke-static {v6, v7, v2, v14}, Lis0;->y(ILjava/util/List;Ldb0;Z)V

    .line 871
    .line 872
    .line 873
    goto/16 :goto_531

    .line 874
    .line 875
    :pswitch_36a
    move/from16 v13, v17

    .line 876
    .line 877
    const/4 v14, 0x0

    .line 878
    aget v6, v3, v13

    .line 879
    .line 880
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 881
    .line 882
    .line 883
    move-result-object v7

    .line 884
    check-cast v7, Ljava/util/List;

    .line 885
    .line 886
    invoke-static {v6, v7, v2, v14}, Lis0;->C(ILjava/util/List;Ldb0;Z)V

    .line 887
    .line 888
    .line 889
    goto/16 :goto_531

    .line 890
    .line 891
    :pswitch_37a
    move/from16 v13, v17

    .line 892
    .line 893
    const/4 v14, 0x0

    .line 894
    aget v6, v3, v13

    .line 895
    .line 896
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 897
    .line 898
    .line 899
    move-result-object v7

    .line 900
    check-cast v7, Ljava/util/List;

    .line 901
    .line 902
    invoke-static {v6, v7, v2, v14}, Lis0;->D(ILjava/util/List;Ldb0;Z)V

    .line 903
    .line 904
    .line 905
    goto/16 :goto_531

    .line 906
    .line 907
    :pswitch_38a
    move/from16 v13, v17

    .line 908
    .line 909
    const/4 v14, 0x0

    .line 910
    aget v6, v3, v13

    .line 911
    .line 912
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 913
    .line 914
    .line 915
    move-result-object v7

    .line 916
    check-cast v7, Ljava/util/List;

    .line 917
    .line 918
    invoke-static {v6, v7, v2, v14}, Lis0;->G(ILjava/util/List;Ldb0;Z)V

    .line 919
    .line 920
    .line 921
    goto/16 :goto_531

    .line 922
    .line 923
    :pswitch_39a
    move/from16 v13, v17

    .line 924
    .line 925
    const/4 v14, 0x0

    .line 926
    aget v6, v3, v13

    .line 927
    .line 928
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 929
    .line 930
    .line 931
    move-result-object v7

    .line 932
    check-cast v7, Ljava/util/List;

    .line 933
    .line 934
    invoke-static {v6, v7, v2, v14}, Lis0;->P(ILjava/util/List;Ldb0;Z)V

    .line 935
    .line 936
    .line 937
    goto/16 :goto_531

    .line 938
    .line 939
    :pswitch_3aa
    move/from16 v13, v17

    .line 940
    .line 941
    const/4 v14, 0x0

    .line 942
    aget v6, v3, v13

    .line 943
    .line 944
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 945
    .line 946
    .line 947
    move-result-object v7

    .line 948
    check-cast v7, Ljava/util/List;

    .line 949
    .line 950
    invoke-static {v6, v7, v2, v14}, Lis0;->H(ILjava/util/List;Ldb0;Z)V

    .line 951
    .line 952
    .line 953
    goto/16 :goto_531

    .line 954
    .line 955
    :pswitch_3ba
    move/from16 v13, v17

    .line 956
    .line 957
    const/4 v14, 0x0

    .line 958
    aget v6, v3, v13

    .line 959
    .line 960
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 961
    .line 962
    .line 963
    move-result-object v7

    .line 964
    check-cast v7, Ljava/util/List;

    .line 965
    .line 966
    invoke-static {v6, v7, v2, v14}, Lis0;->E(ILjava/util/List;Ldb0;Z)V

    .line 967
    .line 968
    .line 969
    goto/16 :goto_531

    .line 970
    .line 971
    :pswitch_3ca
    move/from16 v13, v17

    .line 972
    .line 973
    const/4 v14, 0x0

    .line 974
    aget v6, v3, v13

    .line 975
    .line 976
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 977
    .line 978
    .line 979
    move-result-object v7

    .line 980
    check-cast v7, Ljava/util/List;

    .line 981
    .line 982
    invoke-static {v6, v7, v2, v14}, Lis0;->A(ILjava/util/List;Ldb0;Z)V

    .line 983
    .line 984
    .line 985
    goto/16 :goto_531

    .line 986
    .line 987
    :pswitch_3da
    move/from16 v13, v17

    .line 988
    .line 989
    const/4 v14, 0x0

    .line 990
    and-int/2addr v6, v10

    .line 991
    if-eqz v6, :cond_531

    .line 992
    .line 993
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 994
    .line 995
    .line 996
    move-result-object v6

    .line 997
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 998
    .line 999
    .line 1000
    move-result-object v7

    .line 1001
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->B(ILjava/lang/Object;Les0;)V

    .line 1002
    .line 1003
    .line 1004
    goto/16 :goto_531

    .line 1005
    .line 1006
    :pswitch_3ed
    move/from16 v13, v17

    .line 1007
    .line 1008
    const/4 v14, 0x0

    .line 1009
    and-int/2addr v6, v10

    .line 1010
    if-eqz v6, :cond_531

    .line 1011
    .line 1012
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1013
    .line 1014
    .line 1015
    move-result-wide v6

    .line 1016
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1017
    .line 1018
    check-cast v8, Lde;

    .line 1019
    .line 1020
    shl-long v17, v6, v15

    .line 1021
    .line 1022
    shr-long/2addr v6, v11

    .line 1023
    xor-long v6, v17, v6

    .line 1024
    .line 1025
    invoke-virtual {v8, v12, v6, v7}, Lde;->F(IJ)V

    .line 1026
    .line 1027
    .line 1028
    goto/16 :goto_531

    .line 1029
    .line 1030
    :pswitch_405
    move/from16 v13, v17

    .line 1031
    .line 1032
    const/4 v14, 0x0

    .line 1033
    and-int/2addr v6, v10

    .line 1034
    if-eqz v6, :cond_531

    .line 1035
    .line 1036
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1037
    .line 1038
    .line 1039
    move-result v6

    .line 1040
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1041
    .line 1042
    check-cast v7, Lde;

    .line 1043
    .line 1044
    shl-int/lit8 v8, v6, 0x1

    .line 1045
    .line 1046
    shr-int/lit8 v6, v6, 0x1f

    .line 1047
    .line 1048
    xor-int/2addr v6, v8

    .line 1049
    invoke-virtual {v7, v12, v6}, Lde;->D(II)V

    .line 1050
    .line 1051
    .line 1052
    goto/16 :goto_531

    .line 1053
    .line 1054
    :pswitch_41d
    move/from16 v13, v17

    .line 1055
    .line 1056
    const/4 v14, 0x0

    .line 1057
    and-int/2addr v6, v10

    .line 1058
    if-eqz v6, :cond_531

    .line 1059
    .line 1060
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1061
    .line 1062
    .line 1063
    move-result-wide v6

    .line 1064
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1065
    .line 1066
    check-cast v8, Lde;

    .line 1067
    .line 1068
    invoke-virtual {v8, v12, v6, v7}, Lde;->t(IJ)V

    .line 1069
    .line 1070
    .line 1071
    goto/16 :goto_531

    .line 1072
    .line 1073
    :pswitch_430
    move/from16 v13, v17

    .line 1074
    .line 1075
    const/4 v14, 0x0

    .line 1076
    and-int/2addr v6, v10

    .line 1077
    if-eqz v6, :cond_531

    .line 1078
    .line 1079
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1080
    .line 1081
    .line 1082
    move-result v6

    .line 1083
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1084
    .line 1085
    check-cast v7, Lde;

    .line 1086
    .line 1087
    invoke-virtual {v7, v12, v6}, Lde;->r(II)V

    .line 1088
    .line 1089
    .line 1090
    goto/16 :goto_531

    .line 1091
    .line 1092
    :pswitch_443
    move/from16 v13, v17

    .line 1093
    .line 1094
    const/4 v14, 0x0

    .line 1095
    and-int/2addr v6, v10

    .line 1096
    if-eqz v6, :cond_531

    .line 1097
    .line 1098
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1099
    .line 1100
    .line 1101
    move-result v6

    .line 1102
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1103
    .line 1104
    check-cast v7, Lde;

    .line 1105
    .line 1106
    invoke-virtual {v7, v12, v6}, Lde;->v(II)V

    .line 1107
    .line 1108
    .line 1109
    goto/16 :goto_531

    .line 1110
    .line 1111
    :pswitch_456
    move/from16 v13, v17

    .line 1112
    .line 1113
    const/4 v14, 0x0

    .line 1114
    and-int/2addr v6, v10

    .line 1115
    if-eqz v6, :cond_531

    .line 1116
    .line 1117
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1118
    .line 1119
    .line 1120
    move-result v6

    .line 1121
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1122
    .line 1123
    check-cast v7, Lde;

    .line 1124
    .line 1125
    invoke-virtual {v7, v12, v6}, Lde;->D(II)V

    .line 1126
    .line 1127
    .line 1128
    goto/16 :goto_531

    .line 1129
    .line 1130
    :pswitch_469
    move/from16 v13, v17

    .line 1131
    .line 1132
    const/4 v14, 0x0

    .line 1133
    and-int/2addr v6, v10

    .line 1134
    if-eqz v6, :cond_531

    .line 1135
    .line 1136
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 1137
    .line 1138
    .line 1139
    move-result-object v6

    .line 1140
    check-cast v6, Lqb;

    .line 1141
    .line 1142
    invoke-virtual {v2, v12, v6}, Ldb0;->x(ILqb;)V

    .line 1143
    .line 1144
    .line 1145
    goto/16 :goto_531

    .line 1146
    .line 1147
    :pswitch_47a
    move/from16 v13, v17

    .line 1148
    .line 1149
    const/4 v14, 0x0

    .line 1150
    and-int/2addr v6, v10

    .line 1151
    if-eqz v6, :cond_531

    .line 1152
    .line 1153
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 1154
    .line 1155
    .line 1156
    move-result-object v6

    .line 1157
    invoke-virtual {v0, v13}, Lde0;->q(I)Les0;

    .line 1158
    .line 1159
    .line 1160
    move-result-object v7

    .line 1161
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->G(ILjava/lang/Object;Les0;)V

    .line 1162
    .line 1163
    .line 1164
    goto/16 :goto_531

    .line 1165
    .line 1166
    :pswitch_48d
    move/from16 v13, v17

    .line 1167
    .line 1168
    const/4 v14, 0x0

    .line 1169
    and-int/2addr v6, v10

    .line 1170
    if-eqz v6, :cond_531

    .line 1171
    .line 1172
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 1173
    .line 1174
    .line 1175
    move-result-object v6

    .line 1176
    invoke-static {v12, v6, v2}, Lde0;->Z(ILjava/lang/Object;Ldb0;)V

    .line 1177
    .line 1178
    .line 1179
    goto/16 :goto_531

    .line 1180
    .line 1181
    :pswitch_49c
    move/from16 v13, v17

    .line 1182
    .line 1183
    const/4 v14, 0x0

    .line 1184
    and-int/2addr v6, v10

    .line 1185
    if-eqz v6, :cond_531

    .line 1186
    .line 1187
    sget-object v6, Lk71;->c:Lh71;

    .line 1188
    .line 1189
    invoke-virtual {v6, v7, v8, v1}, Lh71;->d(JLjava/lang/Object;)Z

    .line 1190
    .line 1191
    .line 1192
    move-result v6

    .line 1193
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1194
    .line 1195
    check-cast v7, Lde;

    .line 1196
    .line 1197
    invoke-virtual {v7, v12, v6}, Lde;->n(IZ)V

    .line 1198
    .line 1199
    .line 1200
    goto/16 :goto_531

    .line 1201
    .line 1202
    :pswitch_4b1
    move/from16 v13, v17

    .line 1203
    .line 1204
    const/4 v14, 0x0

    .line 1205
    and-int/2addr v6, v10

    .line 1206
    if-eqz v6, :cond_531

    .line 1207
    .line 1208
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1209
    .line 1210
    .line 1211
    move-result v6

    .line 1212
    invoke-virtual {v2, v12, v6}, Ldb0;->y(II)V

    .line 1213
    .line 1214
    .line 1215
    goto/16 :goto_531

    .line 1216
    .line 1217
    :pswitch_4c0
    move/from16 v13, v17

    .line 1218
    .line 1219
    const/4 v14, 0x0

    .line 1220
    and-int/2addr v6, v10

    .line 1221
    if-eqz v6, :cond_531

    .line 1222
    .line 1223
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1224
    .line 1225
    .line 1226
    move-result-wide v6

    .line 1227
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->z(IJ)V

    .line 1228
    .line 1229
    .line 1230
    goto :goto_531

    .line 1231
    :pswitch_4ce
    move/from16 v13, v17

    .line 1232
    .line 1233
    const/4 v14, 0x0

    .line 1234
    and-int/2addr v6, v10

    .line 1235
    if-eqz v6, :cond_531

    .line 1236
    .line 1237
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1238
    .line 1239
    .line 1240
    move-result v6

    .line 1241
    invoke-virtual {v2, v12, v6}, Ldb0;->D(II)V

    .line 1242
    .line 1243
    .line 1244
    goto :goto_531

    .line 1245
    :pswitch_4dc
    move/from16 v13, v17

    .line 1246
    .line 1247
    const/4 v14, 0x0

    .line 1248
    and-int/2addr v6, v10

    .line 1249
    if-eqz v6, :cond_531

    .line 1250
    .line 1251
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1252
    .line 1253
    .line 1254
    move-result-wide v6

    .line 1255
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1256
    .line 1257
    check-cast v8, Lde;

    .line 1258
    .line 1259
    invoke-virtual {v8, v12, v6, v7}, Lde;->F(IJ)V

    .line 1260
    .line 1261
    .line 1262
    goto :goto_531

    .line 1263
    :pswitch_4ee
    move/from16 v13, v17

    .line 1264
    .line 1265
    const/4 v14, 0x0

    .line 1266
    and-int/2addr v6, v10

    .line 1267
    if-eqz v6, :cond_531

    .line 1268
    .line 1269
    invoke-virtual {v5, v1, v7, v8}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1270
    .line 1271
    .line 1272
    move-result-wide v6

    .line 1273
    invoke-virtual {v2, v12, v6, v7}, Ldb0;->E(IJ)V

    .line 1274
    .line 1275
    .line 1276
    goto :goto_531

    .line 1277
    :pswitch_4fc
    move/from16 v13, v17

    .line 1278
    .line 1279
    const/4 v14, 0x0

    .line 1280
    and-int/2addr v6, v10

    .line 1281
    if-eqz v6, :cond_531

    .line 1282
    .line 1283
    sget-object v6, Lk71;->c:Lh71;

    .line 1284
    .line 1285
    invoke-virtual {v6, v7, v8, v1}, Lh71;->h(JLjava/lang/Object;)F

    .line 1286
    .line 1287
    .line 1288
    move-result v6

    .line 1289
    iget-object v7, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1290
    .line 1291
    check-cast v7, Lde;

    .line 1292
    .line 1293
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1294
    .line 1295
    .line 1296
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1297
    .line 1298
    .line 1299
    move-result v6

    .line 1300
    invoke-virtual {v7, v12, v6}, Lde;->r(II)V

    .line 1301
    .line 1302
    .line 1303
    goto :goto_531

    .line 1304
    :pswitch_517
    move/from16 v13, v17

    .line 1305
    .line 1306
    const/4 v14, 0x0

    .line 1307
    and-int/2addr v6, v10

    .line 1308
    if-eqz v6, :cond_531

    .line 1309
    .line 1310
    sget-object v6, Lk71;->c:Lh71;

    .line 1311
    .line 1312
    invoke-virtual {v6, v7, v8, v1}, Lh71;->g(JLjava/lang/Object;)D

    .line 1313
    .line 1314
    .line 1315
    move-result-wide v6

    .line 1316
    iget-object v8, v2, Ldb0;->g:Ljava/lang/Object;

    .line 1317
    .line 1318
    check-cast v8, Lde;

    .line 1319
    .line 1320
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1321
    .line 1322
    .line 1323
    invoke-static {v6, v7}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 1324
    .line 1325
    .line 1326
    move-result-wide v6

    .line 1327
    invoke-virtual {v8, v12, v6, v7}, Lde;->t(IJ)V

    .line 1328
    .line 1329
    .line 1330
    :cond_531
    :goto_531
    add-int/lit8 v8, v13, 0x3

    .line 1331
    .line 1332
    goto/16 :goto_10

    .line 1333
    .line 1334
    :cond_535
    iget-object v0, v0, Lde0;->m:Lp61;

    .line 1335
    .line 1336
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1337
    .line 1338
    .line 1339
    move-object v0, v1

    .line 1340
    check-cast v0, Lr00;

    .line 1341
    .line 1342
    iget-object v0, v0, Lr00;->unknownFields:Lm61;

    .line 1343
    .line 1344
    invoke-virtual {v0, v2}, Lm61;->g(Ldb0;)V

    .line 1345
    .line 1346
    .line 1347
    return-void

    .line 1348
    nop

    .line 1349
    :pswitch_data_544
    .packed-switch 0x0
        :pswitch_517
        :pswitch_4fc
        :pswitch_4ee
        :pswitch_4dc
        :pswitch_4ce
        :pswitch_4c0
        :pswitch_4b1
        :pswitch_49c
        :pswitch_48d
        :pswitch_47a
        :pswitch_469
        :pswitch_456
        :pswitch_443
        :pswitch_430
        :pswitch_41d
        :pswitch_405
        :pswitch_3ed
        :pswitch_3da
        :pswitch_3ca
        :pswitch_3ba
        :pswitch_3aa
        :pswitch_39a
        :pswitch_38a
        :pswitch_37a
        :pswitch_36a
        :pswitch_35a
        :pswitch_34b
        :pswitch_338
        :pswitch_329
        :pswitch_319
        :pswitch_309
        :pswitch_2f9
        :pswitch_2e9
        :pswitch_2d9
        :pswitch_2c9
        :pswitch_2ba
        :pswitch_2ab
        :pswitch_29c
        :pswitch_28d
        :pswitch_27e
        :pswitch_26f
        :pswitch_260
        :pswitch_251
        :pswitch_242
        :pswitch_233
        :pswitch_224
        :pswitch_215
        :pswitch_206
        :pswitch_1f7
        :pswitch_1e4
        :pswitch_1d9
        :pswitch_1b5
        :pswitch_191
        :pswitch_180
        :pswitch_16b
        :pswitch_15a
        :pswitch_149
        :pswitch_138
        :pswitch_11b
        :pswitch_10a
        :pswitch_f5
        :pswitch_e2
        :pswitch_cd
        :pswitch_b8
        :pswitch_a4
        :pswitch_90
        :pswitch_77
        :pswitch_5e
        :pswitch_4a
    .end packed-switch
.end method

.method public final Y(Ldb0;ILjava/lang/Object;I)V
    .registers 10

    .line 1
    if-eqz p3, :cond_5c

    .line 2
    .line 3
    invoke-virtual {p0, p4}, Lde0;->p(I)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p4

    .line 7
    iget-object p0, p0, Lde0;->n:Lrb0;

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    check-cast p4, Llb0;

    .line 13
    .line 14
    iget-object p0, p4, Llb0;->a:Ld8;

    .line 15
    .line 16
    iget-object p4, p0, Ld8;->g:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p4, Lnd1;

    .line 19
    .line 20
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast p0, Lnd1;

    .line 23
    .line 24
    check-cast p3, Lob0;

    .line 25
    .line 26
    iget-object p1, p1, Ldb0;->g:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p1, Lde;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    invoke-virtual {p3}, Lob0;->entrySet()Ljava/util/Set;

    .line 34
    .line 35
    .line 36
    move-result-object p3

    .line 37
    invoke-interface {p3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 38
    .line 39
    .line 40
    move-result-object p3

    .line 41
    :goto_28
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-eqz v0, :cond_5c

    .line 46
    .line 47
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v0

    .line 51
    check-cast v0, Ljava/util/Map$Entry;

    .line 52
    .line 53
    const/4 v1, 0x2

    .line 54
    invoke-virtual {p1, p2, v1}, Lde;->C(II)V

    .line 55
    .line 56
    .line 57
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    const/4 v4, 0x1

    .line 66
    invoke-static {p0, v4, v2}, Lxs;->a(Lnd1;ILjava/lang/Object;)I

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    invoke-static {p4, v1, v3}, Lxs;->a(Lnd1;ILjava/lang/Object;)I

    .line 71
    .line 72
    .line 73
    move-result v3

    .line 74
    add-int/2addr v3, v2

    .line 75
    invoke-virtual {p1, v3}, Lde;->E(I)V

    .line 76
    .line 77
    .line 78
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v2

    .line 82
    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-static {p1, p0, v4, v2}, Lxs;->e(Lde;Lnd1;ILjava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    invoke-static {p1, p4, v1, v0}, Lxs;->e(Lde;Lnd1;ILjava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    goto :goto_28

    .line 93
    :cond_5c
    return-void
.end method

.method public final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 13

    .line 1
    invoke-static {p1}, Lde0;->l(Ljava/lang/Object;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x0

    .line 8
    :goto_7
    iget-object v1, p0, Lde0;->a:[I

    .line 9
    .line 10
    array-length v2, v1

    .line 11
    if-ge v0, v2, :cond_1b9

    .line 12
    .line 13
    invoke-virtual {p0, v0}, Lde0;->W(I)I

    .line 14
    .line 15
    .line 16
    move-result v2

    .line 17
    const v3, 0xfffff

    .line 18
    .line 19
    .line 20
    and-int/2addr v3, v2

    .line 21
    int-to-long v6, v3

    .line 22
    aget v1, v1, v0

    .line 23
    .line 24
    invoke-static {v2}, Lde0;->V(I)I

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    packed-switch v2, :pswitch_data_1c0

    .line 29
    .line 30
    .line 31
    goto :goto_22

    .line 32
    :pswitch_1f
    invoke-virtual {p0, p1, v0, p2}, Lde0;->z(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    :cond_22
    :goto_22
    move-object v5, p1

    .line 36
    goto/16 :goto_1b4

    .line 37
    .line 38
    :pswitch_25
    invoke-virtual {p0, v1, v0, p2}, Lde0;->v(IILjava/lang/Object;)Z

    .line 39
    .line 40
    .line 41
    move-result v2

    .line 42
    if-eqz v2, :cond_22

    .line 43
    .line 44
    sget-object v2, Lk71;->c:Lh71;

    .line 45
    .line 46
    invoke-virtual {v2, v6, v7, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v2

    .line 50
    invoke-static {v6, v7, p1, v2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {p0, v1, v0, p1}, Lde0;->R(IILjava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    goto :goto_22

    .line 57
    :pswitch_38
    invoke-virtual {p0, p1, v0, p2}, Lde0;->z(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 58
    .line 59
    .line 60
    goto :goto_22

    .line 61
    :pswitch_3c
    invoke-virtual {p0, v1, v0, p2}, Lde0;->v(IILjava/lang/Object;)Z

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    if-eqz v2, :cond_22

    .line 66
    .line 67
    sget-object v2, Lk71;->c:Lh71;

    .line 68
    .line 69
    invoke-virtual {v2, v6, v7, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    invoke-static {v6, v7, p1, v2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {p0, v1, v0, p1}, Lde0;->R(IILjava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    goto :goto_22

    .line 80
    :pswitch_4f
    sget-object v1, Lis0;->a:Ljava/lang/Class;

    .line 81
    .line 82
    sget-object v1, Lk71;->c:Lh71;

    .line 83
    .line 84
    invoke-virtual {v1, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    invoke-virtual {v1, v6, v7, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v1

    .line 92
    iget-object v3, p0, Lde0;->n:Lrb0;

    .line 93
    .line 94
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    .line 96
    .line 97
    invoke-static {v2, v1}, Lrb0;->b(Ljava/lang/Object;Ljava/lang/Object;)Lob0;

    .line 98
    .line 99
    .line 100
    move-result-object v1

    .line 101
    invoke-static {v6, v7, p1, v1}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    goto :goto_22

    .line 105
    :pswitch_68
    iget-object v1, p0, Lde0;->l:Le90;

    .line 106
    .line 107
    invoke-virtual {v1, v6, v7, p1, p2}, Le90;->b(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 108
    .line 109
    .line 110
    goto :goto_22

    .line 111
    :pswitch_6e
    invoke-virtual {p0, p1, v0, p2}, Lde0;->y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    goto :goto_22

    .line 115
    :pswitch_72
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v1

    .line 119
    if-eqz v1, :cond_22

    .line 120
    .line 121
    sget-object v1, Lk71;->c:Lh71;

    .line 122
    .line 123
    invoke-virtual {v1, v6, v7, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 124
    .line 125
    .line 126
    move-result-wide v1

    .line 127
    invoke-static {p1, v6, v7, v1, v2}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 128
    .line 129
    .line 130
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    goto :goto_22

    .line 134
    :pswitch_85
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v1

    .line 138
    if-eqz v1, :cond_22

    .line 139
    .line 140
    sget-object v1, Lk71;->c:Lh71;

    .line 141
    .line 142
    invoke-virtual {v1, v6, v7, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    invoke-static {v1, v6, v7, p1}, Lk71;->n(IJLjava/lang/Object;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    goto :goto_22

    .line 153
    :pswitch_98
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v1

    .line 157
    if-eqz v1, :cond_22

    .line 158
    .line 159
    sget-object v1, Lk71;->c:Lh71;

    .line 160
    .line 161
    invoke-virtual {v1, v6, v7, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 162
    .line 163
    .line 164
    move-result-wide v1

    .line 165
    invoke-static {p1, v6, v7, v1, v2}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 169
    .line 170
    .line 171
    goto/16 :goto_22

    .line 172
    .line 173
    :pswitch_ac
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 174
    .line 175
    .line 176
    move-result v1

    .line 177
    if-eqz v1, :cond_22

    .line 178
    .line 179
    sget-object v1, Lk71;->c:Lh71;

    .line 180
    .line 181
    invoke-virtual {v1, v6, v7, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 182
    .line 183
    .line 184
    move-result v1

    .line 185
    invoke-static {v1, v6, v7, p1}, Lk71;->n(IJLjava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 189
    .line 190
    .line 191
    goto/16 :goto_22

    .line 192
    .line 193
    :pswitch_c0
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    if-eqz v1, :cond_22

    .line 198
    .line 199
    sget-object v1, Lk71;->c:Lh71;

    .line 200
    .line 201
    invoke-virtual {v1, v6, v7, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 202
    .line 203
    .line 204
    move-result v1

    .line 205
    invoke-static {v1, v6, v7, p1}, Lk71;->n(IJLjava/lang/Object;)V

    .line 206
    .line 207
    .line 208
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 209
    .line 210
    .line 211
    goto/16 :goto_22

    .line 212
    .line 213
    :pswitch_d4
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result v1

    .line 217
    if-eqz v1, :cond_22

    .line 218
    .line 219
    sget-object v1, Lk71;->c:Lh71;

    .line 220
    .line 221
    invoke-virtual {v1, v6, v7, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 222
    .line 223
    .line 224
    move-result v1

    .line 225
    invoke-static {v1, v6, v7, p1}, Lk71;->n(IJLjava/lang/Object;)V

    .line 226
    .line 227
    .line 228
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    goto/16 :goto_22

    .line 232
    .line 233
    :pswitch_e8
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 234
    .line 235
    .line 236
    move-result v1

    .line 237
    if-eqz v1, :cond_22

    .line 238
    .line 239
    sget-object v1, Lk71;->c:Lh71;

    .line 240
    .line 241
    invoke-virtual {v1, v6, v7, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v1

    .line 245
    invoke-static {v6, v7, p1, v1}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 249
    .line 250
    .line 251
    goto/16 :goto_22

    .line 252
    .line 253
    :pswitch_fc
    invoke-virtual {p0, p1, v0, p2}, Lde0;->y(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 254
    .line 255
    .line 256
    goto/16 :goto_22

    .line 257
    .line 258
    :pswitch_101
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v1

    .line 262
    if-eqz v1, :cond_22

    .line 263
    .line 264
    sget-object v1, Lk71;->c:Lh71;

    .line 265
    .line 266
    invoke-virtual {v1, v6, v7, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 267
    .line 268
    .line 269
    move-result-object v1

    .line 270
    invoke-static {v6, v7, p1, v1}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 271
    .line 272
    .line 273
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 274
    .line 275
    .line 276
    goto/16 :goto_22

    .line 277
    .line 278
    :pswitch_115
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 279
    .line 280
    .line 281
    move-result v1

    .line 282
    if-eqz v1, :cond_22

    .line 283
    .line 284
    sget-object v1, Lk71;->c:Lh71;

    .line 285
    .line 286
    invoke-virtual {v1, v6, v7, p2}, Lh71;->d(JLjava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    move-result v2

    .line 290
    invoke-virtual {v1, p1, v6, v7, v2}, Lh71;->m(Ljava/lang/Object;JZ)V

    .line 291
    .line 292
    .line 293
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 294
    .line 295
    .line 296
    goto/16 :goto_22

    .line 297
    .line 298
    :pswitch_129
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 299
    .line 300
    .line 301
    move-result v1

    .line 302
    if-eqz v1, :cond_22

    .line 303
    .line 304
    sget-object v1, Lk71;->c:Lh71;

    .line 305
    .line 306
    invoke-virtual {v1, v6, v7, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 307
    .line 308
    .line 309
    move-result v1

    .line 310
    invoke-static {v1, v6, v7, p1}, Lk71;->n(IJLjava/lang/Object;)V

    .line 311
    .line 312
    .line 313
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 314
    .line 315
    .line 316
    goto/16 :goto_22

    .line 317
    .line 318
    :pswitch_13d
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 319
    .line 320
    .line 321
    move-result v1

    .line 322
    if-eqz v1, :cond_22

    .line 323
    .line 324
    sget-object v1, Lk71;->c:Lh71;

    .line 325
    .line 326
    invoke-virtual {v1, v6, v7, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 327
    .line 328
    .line 329
    move-result-wide v1

    .line 330
    invoke-static {p1, v6, v7, v1, v2}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 331
    .line 332
    .line 333
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 334
    .line 335
    .line 336
    goto/16 :goto_22

    .line 337
    .line 338
    :pswitch_151
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 339
    .line 340
    .line 341
    move-result v1

    .line 342
    if-eqz v1, :cond_22

    .line 343
    .line 344
    sget-object v1, Lk71;->c:Lh71;

    .line 345
    .line 346
    invoke-virtual {v1, v6, v7, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 347
    .line 348
    .line 349
    move-result v1

    .line 350
    invoke-static {v1, v6, v7, p1}, Lk71;->n(IJLjava/lang/Object;)V

    .line 351
    .line 352
    .line 353
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 354
    .line 355
    .line 356
    goto/16 :goto_22

    .line 357
    .line 358
    :pswitch_165
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 359
    .line 360
    .line 361
    move-result v1

    .line 362
    if-eqz v1, :cond_22

    .line 363
    .line 364
    sget-object v1, Lk71;->c:Lh71;

    .line 365
    .line 366
    invoke-virtual {v1, v6, v7, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 367
    .line 368
    .line 369
    move-result-wide v1

    .line 370
    invoke-static {p1, v6, v7, v1, v2}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 371
    .line 372
    .line 373
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 374
    .line 375
    .line 376
    goto/16 :goto_22

    .line 377
    .line 378
    :pswitch_179
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 379
    .line 380
    .line 381
    move-result v1

    .line 382
    if-eqz v1, :cond_22

    .line 383
    .line 384
    sget-object v1, Lk71;->c:Lh71;

    .line 385
    .line 386
    invoke-virtual {v1, v6, v7, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 387
    .line 388
    .line 389
    move-result-wide v1

    .line 390
    invoke-static {p1, v6, v7, v1, v2}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 391
    .line 392
    .line 393
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 394
    .line 395
    .line 396
    goto/16 :goto_22

    .line 397
    .line 398
    :pswitch_18d
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 399
    .line 400
    .line 401
    move-result v1

    .line 402
    if-eqz v1, :cond_22

    .line 403
    .line 404
    sget-object v1, Lk71;->c:Lh71;

    .line 405
    .line 406
    invoke-virtual {v1, v6, v7, p2}, Lh71;->h(JLjava/lang/Object;)F

    .line 407
    .line 408
    .line 409
    move-result v2

    .line 410
    invoke-virtual {v1, p1, v6, v7, v2}, Lh71;->p(Ljava/lang/Object;JF)V

    .line 411
    .line 412
    .line 413
    invoke-virtual {p0, v0, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 414
    .line 415
    .line 416
    goto/16 :goto_22

    .line 417
    .line 418
    :pswitch_1a1
    invoke-virtual {p0, v0, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 419
    .line 420
    .line 421
    move-result v1

    .line 422
    if-eqz v1, :cond_22

    .line 423
    .line 424
    sget-object v4, Lk71;->c:Lh71;

    .line 425
    .line 426
    invoke-virtual {v4, v6, v7, p2}, Lh71;->g(JLjava/lang/Object;)D

    .line 427
    .line 428
    .line 429
    move-result-wide v8

    .line 430
    move-object v5, p1

    .line 431
    invoke-virtual/range {v4 .. v9}, Lh71;->o(Ljava/lang/Object;JD)V

    .line 432
    .line 433
    .line 434
    invoke-virtual {p0, v0, v5}, Lde0;->Q(ILjava/lang/Object;)V

    .line 435
    .line 436
    .line 437
    :goto_1b4
    add-int/lit8 v0, v0, 0x3

    .line 438
    .line 439
    move-object p1, v5

    .line 440
    goto/16 :goto_7

    .line 441
    .line 442
    :cond_1b9
    move-object v5, p1

    .line 443
    iget-object p0, p0, Lde0;->m:Lp61;

    .line 444
    .line 445
    invoke-static {p0, v5, p2}, Lis0;->w(Lp61;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 446
    .line 447
    .line 448
    return-void

    .line 449
    :pswitch_data_1c0
    .packed-switch 0x0
        :pswitch_1a1
        :pswitch_18d
        :pswitch_179
        :pswitch_165
        :pswitch_151
        :pswitch_13d
        :pswitch_129
        :pswitch_115
        :pswitch_101
        :pswitch_fc
        :pswitch_e8
        :pswitch_d4
        :pswitch_c0
        :pswitch_ac
        :pswitch_98
        :pswitch_85
        :pswitch_72
        :pswitch_6e
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_68
        :pswitch_4f
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_3c
        :pswitch_38
        :pswitch_25
        :pswitch_25
        :pswitch_25
        :pswitch_25
        :pswitch_25
        :pswitch_25
        :pswitch_25
        :pswitch_1f
    .end packed-switch
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 11

    .line 1
    invoke-static {p1}, Lde0;->u(Ljava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    instance-of v0, p1, Lr00;

    .line 9
    .line 10
    if-eqz v0, :cond_17

    .line 11
    .line 12
    move-object v0, p1

    .line 13
    check-cast v0, Lr00;

    .line 14
    .line 15
    invoke-virtual {v0}, Lr00;->clearMemoizedSerializedSize()V

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0}, Lr00;->clearMemoizedHashCode()V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v0}, Lr00;->markImmutable()V

    .line 22
    .line 23
    .line 24
    :cond_17
    iget-object v0, p0, Lde0;->a:[I

    .line 25
    .line 26
    array-length v1, v0

    .line 27
    const/4 v2, 0x0

    .line 28
    move v3, v2

    .line 29
    :goto_1c
    if-ge v3, v1, :cond_83

    .line 30
    .line 31
    invoke-virtual {p0, v3}, Lde0;->W(I)I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    const v5, 0xfffff

    .line 36
    .line 37
    .line 38
    and-int/2addr v5, v4

    .line 39
    int-to-long v5, v5

    .line 40
    invoke-static {v4}, Lde0;->V(I)I

    .line 41
    .line 42
    .line 43
    move-result v4

    .line 44
    const/16 v7, 0x9

    .line 45
    .line 46
    if-eq v4, v7, :cond_6d

    .line 47
    .line 48
    const/16 v7, 0x3c

    .line 49
    .line 50
    if-eq v4, v7, :cond_57

    .line 51
    .line 52
    const/16 v7, 0x44

    .line 53
    .line 54
    if-eq v4, v7, :cond_57

    .line 55
    .line 56
    packed-switch v4, :pswitch_data_90

    .line 57
    .line 58
    .line 59
    goto :goto_80

    .line 60
    :pswitch_3b
    sget-object v4, Lde0;->p:Lsun/misc/Unsafe;

    .line 61
    .line 62
    invoke-virtual {v4, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    if-eqz v7, :cond_80

    .line 67
    .line 68
    iget-object v8, p0, Lde0;->n:Lrb0;

    .line 69
    .line 70
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    move-object v8, v7

    .line 74
    check-cast v8, Lob0;

    .line 75
    .line 76
    iput-boolean v2, v8, Lob0;->f:Z

    .line 77
    .line 78
    invoke-virtual {v4, p1, v5, v6, v7}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    goto :goto_80

    .line 82
    :pswitch_51
    iget-object v4, p0, Lde0;->l:Le90;

    .line 83
    .line 84
    invoke-virtual {v4, v5, v6, p1}, Le90;->a(JLjava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    goto :goto_80

    .line 88
    :cond_57
    aget v4, v0, v3

    .line 89
    .line 90
    invoke-virtual {p0, v4, v3, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    if-eqz v4, :cond_80

    .line 95
    .line 96
    invoke-virtual {p0, v3}, Lde0;->q(I)Les0;

    .line 97
    .line 98
    .line 99
    move-result-object v4

    .line 100
    sget-object v7, Lde0;->p:Lsun/misc/Unsafe;

    .line 101
    .line 102
    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v5

    .line 106
    invoke-interface {v4, v5}, Les0;->b(Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    goto :goto_80

    .line 110
    :cond_6d
    :pswitch_6d
    invoke-virtual {p0, v3, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 111
    .line 112
    .line 113
    move-result v4

    .line 114
    if-eqz v4, :cond_80

    .line 115
    .line 116
    invoke-virtual {p0, v3}, Lde0;->q(I)Les0;

    .line 117
    .line 118
    .line 119
    move-result-object v4

    .line 120
    sget-object v7, Lde0;->p:Lsun/misc/Unsafe;

    .line 121
    .line 122
    invoke-virtual {v7, p1, v5, v6}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object v5

    .line 126
    invoke-interface {v4, v5}, Les0;->b(Ljava/lang/Object;)V

    .line 127
    .line 128
    .line 129
    :cond_80
    :goto_80
    add-int/lit8 v3, v3, 0x3

    .line 130
    .line 131
    goto :goto_1c

    .line 132
    :cond_83
    iget-object p0, p0, Lde0;->m:Lp61;

    .line 133
    .line 134
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    .line 136
    .line 137
    check-cast p1, Lr00;

    .line 138
    .line 139
    iget-object p0, p1, Lr00;->unknownFields:Lm61;

    .line 140
    .line 141
    iput-boolean v2, p0, Lm61;->e:Z

    .line 142
    .line 143
    return-void

    .line 144
    nop

    .line 145
    :pswitch_data_90
    .packed-switch 0x11
        :pswitch_6d
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_51
        :pswitch_3b
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 15

    .line 1
    const v0, 0xfffff

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    move v3, v0

    .line 6
    move v2, v1

    .line 7
    move v4, v2

    .line 8
    :goto_7
    iget v5, p0, Lde0;->i:I

    .line 9
    .line 10
    const/4 v6, 0x1

    .line 11
    if-ge v2, v5, :cond_125

    .line 12
    .line 13
    iget-object v5, p0, Lde0;->h:[I

    .line 14
    .line 15
    aget v5, v5, v2

    .line 16
    .line 17
    iget-object v7, p0, Lde0;->a:[I

    .line 18
    .line 19
    aget v8, v7, v5

    .line 20
    .line 21
    invoke-virtual {p0, v5}, Lde0;->W(I)I

    .line 22
    .line 23
    .line 24
    move-result v9

    .line 25
    add-int/lit8 v10, v5, 0x2

    .line 26
    .line 27
    aget v7, v7, v10

    .line 28
    .line 29
    and-int v10, v7, v0

    .line 30
    .line 31
    ushr-int/lit8 v7, v7, 0x14

    .line 32
    .line 33
    shl-int v7, v6, v7

    .line 34
    .line 35
    if-eq v10, v3, :cond_2e

    .line 36
    .line 37
    if-eq v10, v0, :cond_2d

    .line 38
    .line 39
    sget-object v3, Lde0;->p:Lsun/misc/Unsafe;

    .line 40
    .line 41
    int-to-long v11, v10

    .line 42
    invoke-virtual {v3, p1, v11, v12}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    :cond_2d
    move v3, v10

    .line 47
    :cond_2e
    const/high16 v10, 0x10000000

    .line 48
    .line 49
    and-int/2addr v10, v9

    .line 50
    if-eqz v10, :cond_45

    .line 51
    .line 52
    if-ne v3, v0, :cond_3a

    .line 53
    .line 54
    invoke-virtual {p0, v5, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v10

    .line 58
    goto :goto_41

    .line 59
    :cond_3a
    and-int v10, v4, v7

    .line 60
    .line 61
    if-eqz v10, :cond_40

    .line 62
    .line 63
    move v10, v6

    .line 64
    goto :goto_41

    .line 65
    :cond_40
    move v10, v1

    .line 66
    :goto_41
    if-nez v10, :cond_45

    .line 67
    .line 68
    goto/16 :goto_120

    .line 69
    .line 70
    :cond_45
    invoke-static {v9}, Lde0;->V(I)I

    .line 71
    .line 72
    .line 73
    move-result v10

    .line 74
    const/16 v11, 0x9

    .line 75
    .line 76
    if-eq v10, v11, :cond_ff

    .line 77
    .line 78
    const/16 v11, 0x11

    .line 79
    .line 80
    if-eq v10, v11, :cond_ff

    .line 81
    .line 82
    const/16 v6, 0x1b

    .line 83
    .line 84
    if-eq v10, v6, :cond_d4

    .line 85
    .line 86
    const/16 v6, 0x3c

    .line 87
    .line 88
    if-eq v10, v6, :cond_ba

    .line 89
    .line 90
    const/16 v6, 0x44

    .line 91
    .line 92
    if-eq v10, v6, :cond_ba

    .line 93
    .line 94
    const/16 v6, 0x31

    .line 95
    .line 96
    if-eq v10, v6, :cond_d4

    .line 97
    .line 98
    const/16 v6, 0x32

    .line 99
    .line 100
    if-eq v10, v6, :cond_67

    .line 101
    .line 102
    goto/16 :goto_121

    .line 103
    .line 104
    :cond_67
    and-int v6, v9, v0

    .line 105
    .line 106
    int-to-long v6, v6

    .line 107
    sget-object v8, Lk71;->c:Lh71;

    .line 108
    .line 109
    invoke-virtual {v8, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v6

    .line 113
    iget-object v7, p0, Lde0;->n:Lrb0;

    .line 114
    .line 115
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    .line 117
    .line 118
    check-cast v6, Lob0;

    .line 119
    .line 120
    invoke-virtual {v6}, Ljava/util/HashMap;->isEmpty()Z

    .line 121
    .line 122
    .line 123
    move-result v7

    .line 124
    if-eqz v7, :cond_7f

    .line 125
    .line 126
    goto/16 :goto_121

    .line 127
    .line 128
    :cond_7f
    invoke-virtual {p0, v5}, Lde0;->p(I)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    move-result-object v5

    .line 132
    check-cast v5, Llb0;

    .line 133
    .line 134
    iget-object v5, v5, Llb0;->a:Ld8;

    .line 135
    .line 136
    iget-object v5, v5, Ld8;->g:Ljava/lang/Object;

    .line 137
    .line 138
    check-cast v5, Lnd1;

    .line 139
    .line 140
    iget-object v5, v5, Lnd1;->f:Lpd1;

    .line 141
    .line 142
    sget-object v7, Lpd1;->n:Lpd1;

    .line 143
    .line 144
    if-eq v5, v7, :cond_93

    .line 145
    .line 146
    goto/16 :goto_121

    .line 147
    .line 148
    :cond_93
    invoke-virtual {v6}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 149
    .line 150
    .line 151
    move-result-object v5

    .line 152
    invoke-interface {v5}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    .line 153
    .line 154
    .line 155
    move-result-object v5

    .line 156
    const/4 v6, 0x0

    .line 157
    :cond_9c
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 158
    .line 159
    .line 160
    move-result v7

    .line 161
    if-eqz v7, :cond_121

    .line 162
    .line 163
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 164
    .line 165
    .line 166
    move-result-object v7

    .line 167
    if-nez v6, :cond_b2

    .line 168
    .line 169
    sget-object v6, Lhn0;->c:Lhn0;

    .line 170
    .line 171
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 172
    .line 173
    .line 174
    move-result-object v8

    .line 175
    invoke-virtual {v6, v8}, Lhn0;->a(Ljava/lang/Class;)Les0;

    .line 176
    .line 177
    .line 178
    move-result-object v6

    .line 179
    :cond_b2
    invoke-interface {v6, v7}, Les0;->c(Ljava/lang/Object;)Z

    .line 180
    .line 181
    .line 182
    move-result v7

    .line 183
    if-nez v7, :cond_9c

    .line 184
    .line 185
    goto/16 :goto_120

    .line 186
    .line 187
    :cond_ba
    invoke-virtual {p0, v8, v5, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 188
    .line 189
    .line 190
    move-result v6

    .line 191
    if-eqz v6, :cond_121

    .line 192
    .line 193
    invoke-virtual {p0, v5}, Lde0;->q(I)Les0;

    .line 194
    .line 195
    .line 196
    move-result-object v5

    .line 197
    and-int v6, v9, v0

    .line 198
    .line 199
    int-to-long v6, v6

    .line 200
    sget-object v8, Lk71;->c:Lh71;

    .line 201
    .line 202
    invoke-virtual {v8, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v6

    .line 206
    invoke-interface {v5, v6}, Les0;->c(Ljava/lang/Object;)Z

    .line 207
    .line 208
    .line 209
    move-result v5

    .line 210
    if-nez v5, :cond_121

    .line 211
    .line 212
    goto :goto_120

    .line 213
    :cond_d4
    and-int v6, v9, v0

    .line 214
    .line 215
    int-to-long v6, v6

    .line 216
    sget-object v8, Lk71;->c:Lh71;

    .line 217
    .line 218
    invoke-virtual {v8, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v6

    .line 222
    check-cast v6, Ljava/util/List;

    .line 223
    .line 224
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 225
    .line 226
    .line 227
    move-result v7

    .line 228
    if-eqz v7, :cond_e6

    .line 229
    .line 230
    goto :goto_121

    .line 231
    :cond_e6
    invoke-virtual {p0, v5}, Lde0;->q(I)Les0;

    .line 232
    .line 233
    .line 234
    move-result-object v5

    .line 235
    move v7, v1

    .line 236
    :goto_eb
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 237
    .line 238
    .line 239
    move-result v8

    .line 240
    if-ge v7, v8, :cond_121

    .line 241
    .line 242
    invoke-interface {v6, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v8

    .line 246
    invoke-interface {v5, v8}, Les0;->c(Ljava/lang/Object;)Z

    .line 247
    .line 248
    .line 249
    move-result v8

    .line 250
    if-nez v8, :cond_fc

    .line 251
    .line 252
    goto :goto_120

    .line 253
    :cond_fc
    add-int/lit8 v7, v7, 0x1

    .line 254
    .line 255
    goto :goto_eb

    .line 256
    :cond_ff
    if-ne v3, v0, :cond_106

    .line 257
    .line 258
    invoke-virtual {p0, v5, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 259
    .line 260
    .line 261
    move-result v6

    .line 262
    goto :goto_10b

    .line 263
    :cond_106
    and-int/2addr v7, v4

    .line 264
    if-eqz v7, :cond_10a

    .line 265
    .line 266
    goto :goto_10b

    .line 267
    :cond_10a
    move v6, v1

    .line 268
    :goto_10b
    if-eqz v6, :cond_121

    .line 269
    .line 270
    invoke-virtual {p0, v5}, Lde0;->q(I)Les0;

    .line 271
    .line 272
    .line 273
    move-result-object v5

    .line 274
    and-int v6, v9, v0

    .line 275
    .line 276
    int-to-long v6, v6

    .line 277
    sget-object v8, Lk71;->c:Lh71;

    .line 278
    .line 279
    invoke-virtual {v8, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v6

    .line 283
    invoke-interface {v5, v6}, Les0;->c(Ljava/lang/Object;)Z

    .line 284
    .line 285
    .line 286
    move-result v5

    .line 287
    if-nez v5, :cond_121

    .line 288
    .line 289
    :goto_120
    return v1

    .line 290
    :cond_121
    :goto_121
    add-int/lit8 v2, v2, 0x1

    .line 291
    .line 292
    goto/16 :goto_7

    .line 293
    .line 294
    :cond_125
    return v6
.end method

.method public final d()Ljava/lang/Object;
    .registers 2

    .line 1
    iget-object v0, p0, Lde0;->k:Lng0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lde0;->e:Lxd0;

    .line 7
    .line 8
    check-cast p0, Lr00;

    .line 9
    .line 10
    invoke-virtual {p0}, Lr00;->newMutableInstance()Lr00;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0
.end method

.method public final e(Ljava/lang/Object;Lcd;Lcs;)V
    .registers 21

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v2, p1

    .line 4
    .line 5
    move-object/from16 v4, p2

    .line 6
    .line 7
    move-object/from16 v5, p3

    .line 8
    .line 9
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    invoke-static {v2}, Lde0;->l(Ljava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iget-object v8, v1, Lde0;->m:Lp61;

    .line 16
    .line 17
    iget-object v9, v1, Lde0;->h:[I

    .line 18
    .line 19
    iget v10, v1, Lde0;->j:I

    .line 20
    .line 21
    iget v11, v1, Lde0;->i:I

    .line 22
    .line 23
    const/4 v0, 0x0

    .line 24
    move-object v12, v0

    .line 25
    :goto_18
    :try_start_18
    invoke-virtual {v4}, Lcd;->b()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    iget v3, v1, Lde0;->c:I

    .line 30
    .line 31
    const/4 v6, 0x0

    .line 32
    if-lt v0, v3, :cond_2d

    .line 33
    .line 34
    iget v3, v1, Lde0;->d:I

    .line 35
    .line 36
    if-gt v0, v3, :cond_2d

    .line 37
    .line 38
    invoke-virtual {v1, v0, v6}, Lde0;->S(II)I

    .line 39
    .line 40
    .line 41
    move-result v3
    :try_end_29
    .catchall {:try_start_18 .. :try_end_29} :catchall_66b

    .line 42
    goto :goto_2e

    .line 43
    :goto_2a
    move-object v7, v1

    .line 44
    goto/16 :goto_66e

    .line 45
    .line 46
    :cond_2d
    const/4 v3, -0x1

    .line 47
    :goto_2e
    if-gez v3, :cond_69

    .line 48
    .line 49
    const v3, 0x7fffffff

    .line 50
    .line 51
    .line 52
    if-ne v0, v3, :cond_4b

    .line 53
    .line 54
    :goto_35
    if-ge v11, v10, :cond_3f

    .line 55
    .line 56
    aget v0, v9, v11

    .line 57
    .line 58
    invoke-virtual {v1, v2, v0, v12}, Lde0;->n(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    add-int/lit8 v11, v11, 0x1

    .line 62
    .line 63
    goto :goto_35

    .line 64
    :cond_3f
    if-eqz v12, :cond_664

    .line 65
    .line 66
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    .line 68
    .line 69
    :goto_44
    move-object v0, v2

    .line 70
    check-cast v0, Lr00;

    .line 71
    .line 72
    iput-object v12, v0, Lr00;->unknownFields:Lm61;

    .line 73
    .line 74
    goto/16 :goto_664

    .line 75
    .line 76
    :cond_4b
    :try_start_4b
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    .line 78
    .line 79
    if-nez v12, :cond_55

    .line 80
    .line 81
    invoke-static {v2}, Lp61;->a(Ljava/lang/Object;)Lm61;

    .line 82
    .line 83
    .line 84
    move-result-object v0

    .line 85
    move-object v12, v0

    .line 86
    :cond_55
    invoke-static {v12, v4}, Lp61;->b(Ljava/lang/Object;Lcd;)Z

    .line 87
    .line 88
    .line 89
    move-result v0
    :try_end_59
    .catchall {:try_start_4b .. :try_end_59} :catchall_66b

    .line 90
    if-eqz v0, :cond_5c

    .line 91
    .line 92
    goto :goto_18

    .line 93
    :cond_5c
    :goto_5c
    if-ge v11, v10, :cond_66

    .line 94
    .line 95
    aget v0, v9, v11

    .line 96
    .line 97
    invoke-virtual {v1, v2, v0, v12}, Lde0;->n(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    add-int/lit8 v11, v11, 0x1

    .line 101
    .line 102
    goto :goto_5c

    .line 103
    :cond_66
    if-eqz v12, :cond_664

    .line 104
    .line 105
    :goto_68
    goto :goto_44

    .line 106
    :cond_69
    :try_start_69
    invoke-virtual {v1, v3}, Lde0;->W(I)I

    .line 107
    .line 108
    .line 109
    move-result v7
    :try_end_6d
    .catchall {:try_start_69 .. :try_end_6d} :catchall_66b

    .line 110
    :try_start_6d
    invoke-static {v7}, Lde0;->V(I)I

    .line 111
    .line 112
    .line 113
    move-result v13
    :try_end_71
    .catch Lx40; {:try_start_6d .. :try_end_71} :catch_85
    .catchall {:try_start_6d .. :try_end_71} :catchall_66b

    .line 114
    const/4 v15, 0x3

    .line 115
    const v16, 0xfffff

    .line 116
    .line 117
    .line 118
    iget-object v14, v1, Lde0;->l:Le90;

    .line 119
    .line 120
    packed-switch v13, :pswitch_data_684

    .line 121
    .line 122
    .line 123
    if-nez v12, :cond_89

    .line 124
    .line 125
    :try_start_7c
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 126
    .line 127
    .line 128
    invoke-static {v2}, Lp61;->a(Ljava/lang/Object;)Lm61;

    .line 129
    .line 130
    .line 131
    move-result-object v0

    .line 132
    move-object v12, v0

    .line 133
    goto :goto_89

    .line 134
    :catch_85
    move-object v7, v1

    .line 135
    :goto_86
    move-object v6, v4

    .line 136
    goto/16 :goto_646

    .line 137
    .line 138
    :cond_89
    :goto_89
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 139
    .line 140
    .line 141
    invoke-static {v12, v4}, Lp61;->b(Ljava/lang/Object;Lcd;)Z

    .line 142
    .line 143
    .line 144
    move-result v0
    :try_end_90
    .catch Lx40; {:try_start_7c .. :try_end_90} :catch_85
    .catchall {:try_start_7c .. :try_end_90} :catchall_66b

    .line 145
    if-nez v0, :cond_b2

    .line 146
    .line 147
    :goto_92
    if-ge v11, v10, :cond_9c

    .line 148
    .line 149
    aget v0, v9, v11

    .line 150
    .line 151
    invoke-virtual {v1, v2, v0, v12}, Lde0;->n(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 152
    .line 153
    .line 154
    add-int/lit8 v11, v11, 0x1

    .line 155
    .line 156
    goto :goto_92

    .line 157
    :cond_9c
    if-eqz v12, :cond_664

    .line 158
    .line 159
    goto :goto_68

    .line 160
    :pswitch_9f
    :try_start_9f
    invoke-virtual {v1, v0, v3, v2}, Lde0;->B(IILjava/lang/Object;)Ljava/lang/Object;

    .line 161
    .line 162
    .line 163
    move-result-object v6

    .line 164
    check-cast v6, Lxd0;

    .line 165
    .line 166
    invoke-virtual {v1, v3}, Lde0;->q(I)Les0;

    .line 167
    .line 168
    .line 169
    move-result-object v7

    .line 170
    invoke-virtual {v4, v15}, Lcd;->T(I)V

    .line 171
    .line 172
    .line 173
    invoke-virtual {v4, v6, v7, v5}, Lcd;->e(Ljava/lang/Object;Les0;Lcs;)V

    .line 174
    .line 175
    .line 176
    invoke-virtual {v1, v0, v3, v2, v6}, Lde0;->U(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 177
    .line 178
    .line 179
    :cond_b2
    :goto_b2
    move-object v7, v1

    .line 180
    move-object v6, v4

    .line 181
    goto/16 :goto_665

    .line 182
    .line 183
    :pswitch_b6
    and-int v7, v7, v16

    .line 184
    .line 185
    int-to-long v13, v7

    .line 186
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 187
    .line 188
    .line 189
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 190
    .line 191
    check-cast v6, Lwd;

    .line 192
    .line 193
    invoke-virtual {v6}, Lwd;->w()J

    .line 194
    .line 195
    .line 196
    move-result-wide v6

    .line 197
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 198
    .line 199
    .line 200
    move-result-object v6

    .line 201
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 202
    .line 203
    .line 204
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 205
    .line 206
    .line 207
    goto :goto_b2

    .line 208
    :pswitch_cf
    and-int v7, v7, v16

    .line 209
    .line 210
    int-to-long v13, v7

    .line 211
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 212
    .line 213
    .line 214
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 215
    .line 216
    check-cast v6, Lwd;

    .line 217
    .line 218
    invoke-virtual {v6}, Lwd;->v()I

    .line 219
    .line 220
    .line 221
    move-result v6

    .line 222
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 223
    .line 224
    .line 225
    move-result-object v6

    .line 226
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 230
    .line 231
    .line 232
    goto :goto_b2

    .line 233
    :pswitch_e8
    and-int v6, v7, v16

    .line 234
    .line 235
    int-to-long v6, v6

    .line 236
    const/4 v13, 0x1

    .line 237
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 238
    .line 239
    .line 240
    iget-object v13, v4, Lcd;->e:Ljava/lang/Object;

    .line 241
    .line 242
    check-cast v13, Lwd;

    .line 243
    .line 244
    invoke-virtual {v13}, Lwd;->u()J

    .line 245
    .line 246
    .line 247
    move-result-wide v13

    .line 248
    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 249
    .line 250
    .line 251
    move-result-object v13

    .line 252
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 253
    .line 254
    .line 255
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 256
    .line 257
    .line 258
    goto :goto_b2

    .line 259
    :pswitch_102
    and-int v6, v7, v16

    .line 260
    .line 261
    int-to-long v6, v6

    .line 262
    const/4 v13, 0x5

    .line 263
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 264
    .line 265
    .line 266
    iget-object v13, v4, Lcd;->e:Ljava/lang/Object;

    .line 267
    .line 268
    check-cast v13, Lwd;

    .line 269
    .line 270
    invoke-virtual {v13}, Lwd;->t()I

    .line 271
    .line 272
    .line 273
    move-result v13

    .line 274
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 275
    .line 276
    .line 277
    move-result-object v13

    .line 278
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 279
    .line 280
    .line 281
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 282
    .line 283
    .line 284
    goto :goto_b2

    .line 285
    :pswitch_11c
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 286
    .line 287
    .line 288
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 289
    .line 290
    check-cast v6, Lwd;

    .line 291
    .line 292
    invoke-virtual {v6}, Lwd;->m()I

    .line 293
    .line 294
    .line 295
    move-result v6

    .line 296
    invoke-virtual {v1, v3}, Lde0;->o(I)V

    .line 297
    .line 298
    .line 299
    and-int v7, v7, v16

    .line 300
    .line 301
    int-to-long v13, v7

    .line 302
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 303
    .line 304
    .line 305
    move-result-object v6

    .line 306
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 307
    .line 308
    .line 309
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 310
    .line 311
    .line 312
    goto/16 :goto_b2

    .line 313
    .line 314
    :pswitch_139
    and-int v7, v7, v16

    .line 315
    .line 316
    int-to-long v13, v7

    .line 317
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 318
    .line 319
    .line 320
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 321
    .line 322
    check-cast v6, Lwd;

    .line 323
    .line 324
    invoke-virtual {v6}, Lwd;->A()I

    .line 325
    .line 326
    .line 327
    move-result v6

    .line 328
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 329
    .line 330
    .line 331
    move-result-object v6

    .line 332
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 336
    .line 337
    .line 338
    goto/16 :goto_b2

    .line 339
    .line 340
    :pswitch_153
    and-int v6, v7, v16

    .line 341
    .line 342
    int-to-long v6, v6

    .line 343
    invoke-virtual {v4}, Lcd;->l()Lqb;

    .line 344
    .line 345
    .line 346
    move-result-object v13

    .line 347
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 348
    .line 349
    .line 350
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 351
    .line 352
    .line 353
    goto/16 :goto_b2

    .line 354
    .line 355
    :pswitch_162
    invoke-virtual {v1, v0, v3, v2}, Lde0;->B(IILjava/lang/Object;)Ljava/lang/Object;

    .line 356
    .line 357
    .line 358
    move-result-object v6

    .line 359
    check-cast v6, Lxd0;

    .line 360
    .line 361
    invoke-virtual {v1, v3}, Lde0;->q(I)Les0;

    .line 362
    .line 363
    .line 364
    move-result-object v7

    .line 365
    const/4 v13, 0x2

    .line 366
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 367
    .line 368
    .line 369
    invoke-virtual {v4, v6, v7, v5}, Lcd;->g(Ljava/lang/Object;Les0;Lcs;)V

    .line 370
    .line 371
    .line 372
    invoke-virtual {v1, v0, v3, v2, v6}, Lde0;->U(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 373
    .line 374
    .line 375
    goto/16 :goto_b2

    .line 376
    .line 377
    :pswitch_178
    invoke-virtual {v1, v7, v4, v2}, Lde0;->O(ILcd;Ljava/lang/Object;)V

    .line 378
    .line 379
    .line 380
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 381
    .line 382
    .line 383
    goto/16 :goto_b2

    .line 384
    .line 385
    :pswitch_180
    and-int v7, v7, v16

    .line 386
    .line 387
    int-to-long v13, v7

    .line 388
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 389
    .line 390
    .line 391
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 392
    .line 393
    check-cast v6, Lwd;

    .line 394
    .line 395
    invoke-virtual {v6}, Lwd;->j()Z

    .line 396
    .line 397
    .line 398
    move-result v6

    .line 399
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 400
    .line 401
    .line 402
    move-result-object v6

    .line 403
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 404
    .line 405
    .line 406
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 407
    .line 408
    .line 409
    goto/16 :goto_b2

    .line 410
    .line 411
    :pswitch_19a
    and-int v6, v7, v16

    .line 412
    .line 413
    int-to-long v6, v6

    .line 414
    const/4 v13, 0x5

    .line 415
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 416
    .line 417
    .line 418
    iget-object v13, v4, Lcd;->e:Ljava/lang/Object;

    .line 419
    .line 420
    check-cast v13, Lwd;

    .line 421
    .line 422
    invoke-virtual {v13}, Lwd;->n()I

    .line 423
    .line 424
    .line 425
    move-result v13

    .line 426
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 427
    .line 428
    .line 429
    move-result-object v13

    .line 430
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 431
    .line 432
    .line 433
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 434
    .line 435
    .line 436
    goto/16 :goto_b2

    .line 437
    .line 438
    :pswitch_1b5
    and-int v6, v7, v16

    .line 439
    .line 440
    int-to-long v6, v6

    .line 441
    const/4 v13, 0x1

    .line 442
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 443
    .line 444
    .line 445
    iget-object v13, v4, Lcd;->e:Ljava/lang/Object;

    .line 446
    .line 447
    check-cast v13, Lwd;

    .line 448
    .line 449
    invoke-virtual {v13}, Lwd;->o()J

    .line 450
    .line 451
    .line 452
    move-result-wide v13

    .line 453
    invoke-static {v13, v14}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 454
    .line 455
    .line 456
    move-result-object v13

    .line 457
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 458
    .line 459
    .line 460
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 461
    .line 462
    .line 463
    goto/16 :goto_b2

    .line 464
    .line 465
    :pswitch_1d0
    and-int v7, v7, v16

    .line 466
    .line 467
    int-to-long v13, v7

    .line 468
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 469
    .line 470
    .line 471
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 472
    .line 473
    check-cast v6, Lwd;

    .line 474
    .line 475
    invoke-virtual {v6}, Lwd;->q()I

    .line 476
    .line 477
    .line 478
    move-result v6

    .line 479
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 480
    .line 481
    .line 482
    move-result-object v6

    .line 483
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 484
    .line 485
    .line 486
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 487
    .line 488
    .line 489
    goto/16 :goto_b2

    .line 490
    .line 491
    :pswitch_1ea
    and-int v7, v7, v16

    .line 492
    .line 493
    int-to-long v13, v7

    .line 494
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 495
    .line 496
    .line 497
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 498
    .line 499
    check-cast v6, Lwd;

    .line 500
    .line 501
    invoke-virtual {v6}, Lwd;->B()J

    .line 502
    .line 503
    .line 504
    move-result-wide v6

    .line 505
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 506
    .line 507
    .line 508
    move-result-object v6

    .line 509
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 510
    .line 511
    .line 512
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 513
    .line 514
    .line 515
    goto/16 :goto_b2

    .line 516
    .line 517
    :pswitch_204
    and-int v7, v7, v16

    .line 518
    .line 519
    int-to-long v13, v7

    .line 520
    invoke-virtual {v4, v6}, Lcd;->T(I)V

    .line 521
    .line 522
    .line 523
    iget-object v6, v4, Lcd;->e:Ljava/lang/Object;

    .line 524
    .line 525
    check-cast v6, Lwd;

    .line 526
    .line 527
    invoke-virtual {v6}, Lwd;->r()J

    .line 528
    .line 529
    .line 530
    move-result-wide v6

    .line 531
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 532
    .line 533
    .line 534
    move-result-object v6

    .line 535
    invoke-static {v13, v14, v2, v6}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 536
    .line 537
    .line 538
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 539
    .line 540
    .line 541
    goto/16 :goto_b2

    .line 542
    .line 543
    :pswitch_21e
    and-int v6, v7, v16

    .line 544
    .line 545
    int-to-long v6, v6

    .line 546
    const/4 v13, 0x5

    .line 547
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 548
    .line 549
    .line 550
    iget-object v13, v4, Lcd;->e:Ljava/lang/Object;

    .line 551
    .line 552
    check-cast v13, Lwd;

    .line 553
    .line 554
    invoke-virtual {v13}, Lwd;->p()F

    .line 555
    .line 556
    .line 557
    move-result v13

    .line 558
    invoke-static {v13}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 559
    .line 560
    .line 561
    move-result-object v13

    .line 562
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 563
    .line 564
    .line 565
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V

    .line 566
    .line 567
    .line 568
    goto/16 :goto_b2

    .line 569
    .line 570
    :pswitch_239
    and-int v6, v7, v16

    .line 571
    .line 572
    int-to-long v6, v6

    .line 573
    const/4 v13, 0x1

    .line 574
    invoke-virtual {v4, v13}, Lcd;->T(I)V

    .line 575
    .line 576
    .line 577
    iget-object v13, v4, Lcd;->e:Ljava/lang/Object;

    .line 578
    .line 579
    check-cast v13, Lwd;

    .line 580
    .line 581
    invoke-virtual {v13}, Lwd;->l()D

    .line 582
    .line 583
    .line 584
    move-result-wide v13

    .line 585
    invoke-static {v13, v14}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 586
    .line 587
    .line 588
    move-result-object v13

    .line 589
    invoke-static {v6, v7, v2, v13}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 590
    .line 591
    .line 592
    invoke-virtual {v1, v0, v3, v2}, Lde0;->R(IILjava/lang/Object;)V
    :try_end_252
    .catch Lx40; {:try_start_9f .. :try_end_252} :catch_85
    .catchall {:try_start_9f .. :try_end_252} :catchall_66b

    .line 593
    .line 594
    .line 595
    goto/16 :goto_b2

    .line 596
    .line 597
    :pswitch_254
    :try_start_254
    invoke-virtual {v1, v3}, Lde0;->p(I)Ljava/lang/Object;

    .line 598
    .line 599
    .line 600
    move-result-object v4

    .line 601
    move-object/from16 v6, p2

    .line 602
    .line 603
    invoke-virtual/range {v1 .. v6}, Lde0;->x(Ljava/lang/Object;ILjava/lang/Object;Lcs;Lcd;)V

    .line 604
    .line 605
    .line 606
    move-object/from16 v2, p1

    .line 607
    .line 608
    move-object/from16 v6, p2

    .line 609
    .line 610
    move-object v7, v1

    .line 611
    goto/16 :goto_665

    .line 612
    .line 613
    :catchall_264
    move-exception v0

    .line 614
    move-object/from16 v2, p1

    .line 615
    .line 616
    goto/16 :goto_2a

    .line 617
    .line 618
    :catch_269
    move-object/from16 v2, p1

    .line 619
    .line 620
    move-object/from16 v6, p2

    .line 621
    .line 622
    move-object v7, v1

    .line 623
    goto/16 :goto_646

    .line 624
    .line 625
    :pswitch_270
    move v13, v3

    .line 626
    and-int v0, v7, v16

    .line 627
    .line 628
    int-to-long v3, v0

    .line 629
    invoke-virtual {v1, v13}, Lde0;->q(I)Les0;

    .line 630
    .line 631
    .line 632
    move-result-object v6
    :try_end_278
    .catch Lx40; {:try_start_254 .. :try_end_278} :catch_269
    .catchall {:try_start_254 .. :try_end_278} :catchall_264

    .line 633
    move-object/from16 v2, p1

    .line 634
    .line 635
    move-object/from16 v5, p2

    .line 636
    .line 637
    move-object/from16 v7, p3

    .line 638
    .line 639
    :try_start_27e
    invoke-virtual/range {v1 .. v7}, Lde0;->M(Ljava/lang/Object;JLcd;Les0;Lcs;)V
    :try_end_281
    .catch Lx40; {:try_start_27e .. :try_end_281} :catch_284
    .catchall {:try_start_27e .. :try_end_281} :catchall_66b

    .line 640
    .line 641
    .line 642
    move-object v4, v5

    .line 643
    goto/16 :goto_b2

    .line 644
    .line 645
    :catch_284
    move-object v7, v1

    .line 646
    move-object v6, v5

    .line 647
    goto/16 :goto_646

    .line 648
    .line 649
    :pswitch_288
    and-int v0, v7, v16

    .line 650
    .line 651
    int-to-long v5, v0

    .line 652
    :try_start_28b
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 653
    .line 654
    .line 655
    move-result-object v0

    .line 656
    invoke-virtual {v4, v0}, Lcd;->L(Ljava/util/List;)V

    .line 657
    .line 658
    .line 659
    goto/16 :goto_b2

    .line 660
    .line 661
    :pswitch_294
    and-int v0, v7, v16

    .line 662
    .line 663
    int-to-long v5, v0

    .line 664
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 665
    .line 666
    .line 667
    move-result-object v0

    .line 668
    invoke-virtual {v4, v0}, Lcd;->J(Ljava/util/List;)V

    .line 669
    .line 670
    .line 671
    goto/16 :goto_b2

    .line 672
    .line 673
    :pswitch_2a0
    and-int v0, v7, v16

    .line 674
    .line 675
    int-to-long v5, v0

    .line 676
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 677
    .line 678
    .line 679
    move-result-object v0

    .line 680
    invoke-virtual {v4, v0}, Lcd;->H(Ljava/util/List;)V

    .line 681
    .line 682
    .line 683
    goto/16 :goto_b2

    .line 684
    .line 685
    :pswitch_2ac
    and-int v0, v7, v16

    .line 686
    .line 687
    int-to-long v5, v0

    .line 688
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 689
    .line 690
    .line 691
    move-result-object v0

    .line 692
    invoke-virtual {v4, v0}, Lcd;->F(Ljava/util/List;)V

    .line 693
    .line 694
    .line 695
    goto/16 :goto_b2

    .line 696
    .line 697
    :pswitch_2b8
    move v13, v3

    .line 698
    and-int v0, v7, v16

    .line 699
    .line 700
    int-to-long v5, v0

    .line 701
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 702
    .line 703
    .line 704
    move-result-object v0

    .line 705
    invoke-virtual {v4, v0}, Lcd;->r(Ljava/util/List;)V

    .line 706
    .line 707
    .line 708
    invoke-virtual {v1, v13}, Lde0;->o(I)V

    .line 709
    .line 710
    .line 711
    sget-object v0, Lis0;->a:Ljava/lang/Class;

    .line 712
    .line 713
    goto/16 :goto_b2

    .line 714
    .line 715
    :pswitch_2ca
    and-int v0, v7, v16

    .line 716
    .line 717
    int-to-long v5, v0

    .line 718
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 719
    .line 720
    .line 721
    move-result-object v0

    .line 722
    invoke-virtual {v4, v0}, Lcd;->P(Ljava/util/List;)V

    .line 723
    .line 724
    .line 725
    goto/16 :goto_b2

    .line 726
    .line 727
    :pswitch_2d6
    and-int v0, v7, v16

    .line 728
    .line 729
    int-to-long v5, v0

    .line 730
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 731
    .line 732
    .line 733
    move-result-object v0

    .line 734
    invoke-virtual {v4, v0}, Lcd;->j(Ljava/util/List;)V

    .line 735
    .line 736
    .line 737
    goto/16 :goto_b2

    .line 738
    .line 739
    :pswitch_2e2
    and-int v0, v7, v16

    .line 740
    .line 741
    int-to-long v5, v0

    .line 742
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 743
    .line 744
    .line 745
    move-result-object v0

    .line 746
    invoke-virtual {v4, v0}, Lcd;->v(Ljava/util/List;)V

    .line 747
    .line 748
    .line 749
    goto/16 :goto_b2

    .line 750
    .line 751
    :pswitch_2ee
    and-int v0, v7, v16

    .line 752
    .line 753
    int-to-long v5, v0

    .line 754
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 755
    .line 756
    .line 757
    move-result-object v0

    .line 758
    invoke-virtual {v4, v0}, Lcd;->x(Ljava/util/List;)V

    .line 759
    .line 760
    .line 761
    goto/16 :goto_b2

    .line 762
    .line 763
    :pswitch_2fa
    and-int v0, v7, v16

    .line 764
    .line 765
    int-to-long v5, v0

    .line 766
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 767
    .line 768
    .line 769
    move-result-object v0

    .line 770
    invoke-virtual {v4, v0}, Lcd;->B(Ljava/util/List;)V

    .line 771
    .line 772
    .line 773
    goto/16 :goto_b2

    .line 774
    .line 775
    :pswitch_306
    and-int v0, v7, v16

    .line 776
    .line 777
    int-to-long v5, v0

    .line 778
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 779
    .line 780
    .line 781
    move-result-object v0

    .line 782
    invoke-virtual {v4, v0}, Lcd;->R(Ljava/util/List;)V

    .line 783
    .line 784
    .line 785
    goto/16 :goto_b2

    .line 786
    .line 787
    :pswitch_312
    and-int v0, v7, v16

    .line 788
    .line 789
    int-to-long v5, v0

    .line 790
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 791
    .line 792
    .line 793
    move-result-object v0

    .line 794
    invoke-virtual {v4, v0}, Lcd;->D(Ljava/util/List;)V

    .line 795
    .line 796
    .line 797
    goto/16 :goto_b2

    .line 798
    .line 799
    :pswitch_31e
    and-int v0, v7, v16

    .line 800
    .line 801
    int-to-long v5, v0

    .line 802
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 803
    .line 804
    .line 805
    move-result-object v0

    .line 806
    invoke-virtual {v4, v0}, Lcd;->z(Ljava/util/List;)V

    .line 807
    .line 808
    .line 809
    goto/16 :goto_b2

    .line 810
    .line 811
    :pswitch_32a
    and-int v0, v7, v16

    .line 812
    .line 813
    int-to-long v5, v0

    .line 814
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 815
    .line 816
    .line 817
    move-result-object v0

    .line 818
    invoke-virtual {v4, v0}, Lcd;->p(Ljava/util/List;)V

    .line 819
    .line 820
    .line 821
    goto/16 :goto_b2

    .line 822
    .line 823
    :pswitch_336
    and-int v0, v7, v16

    .line 824
    .line 825
    int-to-long v5, v0

    .line 826
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 827
    .line 828
    .line 829
    move-result-object v0

    .line 830
    invoke-virtual {v4, v0}, Lcd;->L(Ljava/util/List;)V

    .line 831
    .line 832
    .line 833
    goto/16 :goto_b2

    .line 834
    .line 835
    :pswitch_342
    and-int v0, v7, v16

    .line 836
    .line 837
    int-to-long v5, v0

    .line 838
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 839
    .line 840
    .line 841
    move-result-object v0

    .line 842
    invoke-virtual {v4, v0}, Lcd;->J(Ljava/util/List;)V

    .line 843
    .line 844
    .line 845
    goto/16 :goto_b2

    .line 846
    .line 847
    :pswitch_34e
    and-int v0, v7, v16

    .line 848
    .line 849
    int-to-long v5, v0

    .line 850
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 851
    .line 852
    .line 853
    move-result-object v0

    .line 854
    invoke-virtual {v4, v0}, Lcd;->H(Ljava/util/List;)V

    .line 855
    .line 856
    .line 857
    goto/16 :goto_b2

    .line 858
    .line 859
    :pswitch_35a
    and-int v0, v7, v16

    .line 860
    .line 861
    int-to-long v5, v0

    .line 862
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 863
    .line 864
    .line 865
    move-result-object v0

    .line 866
    invoke-virtual {v4, v0}, Lcd;->F(Ljava/util/List;)V

    .line 867
    .line 868
    .line 869
    goto/16 :goto_b2

    .line 870
    .line 871
    :pswitch_366
    move v13, v3

    .line 872
    and-int v0, v7, v16

    .line 873
    .line 874
    int-to-long v5, v0

    .line 875
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 876
    .line 877
    .line 878
    move-result-object v0

    .line 879
    invoke-virtual {v4, v0}, Lcd;->r(Ljava/util/List;)V

    .line 880
    .line 881
    .line 882
    invoke-virtual {v1, v13}, Lde0;->o(I)V

    .line 883
    .line 884
    .line 885
    sget-object v0, Lis0;->a:Ljava/lang/Class;

    .line 886
    .line 887
    goto/16 :goto_b2

    .line 888
    .line 889
    :pswitch_378
    and-int v0, v7, v16

    .line 890
    .line 891
    int-to-long v5, v0

    .line 892
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 893
    .line 894
    .line 895
    move-result-object v0

    .line 896
    invoke-virtual {v4, v0}, Lcd;->P(Ljava/util/List;)V

    .line 897
    .line 898
    .line 899
    goto/16 :goto_b2

    .line 900
    .line 901
    :pswitch_384
    and-int v0, v7, v16

    .line 902
    .line 903
    int-to-long v5, v0

    .line 904
    invoke-virtual {v14, v5, v6, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 905
    .line 906
    .line 907
    move-result-object v0

    .line 908
    invoke-virtual {v4, v0}, Lcd;->n(Ljava/util/List;)V
    :try_end_38e
    .catch Lx40; {:try_start_28b .. :try_end_38e} :catch_85
    .catchall {:try_start_28b .. :try_end_38e} :catchall_66b

    .line 909
    .line 910
    .line 911
    goto/16 :goto_b2

    .line 912
    .line 913
    :pswitch_390
    move v13, v3

    .line 914
    :try_start_391
    invoke-virtual {v1, v13}, Lde0;->q(I)Les0;

    .line 915
    .line 916
    .line 917
    move-result-object v5
    :try_end_395
    .catch Lx40; {:try_start_391 .. :try_end_395} :catch_3a5
    .catchall {:try_start_391 .. :try_end_395} :catchall_66b

    .line 918
    move-object/from16 v6, p3

    .line 919
    .line 920
    move v3, v7

    .line 921
    :try_start_398
    invoke-virtual/range {v1 .. v6}, Lde0;->N(Ljava/lang/Object;ILcd;Les0;Lcs;)V
    :try_end_39b
    .catch Lx40; {:try_start_398 .. :try_end_39b} :catch_3a1
    .catchall {:try_start_398 .. :try_end_39b} :catchall_66b

    .line 922
    .line 923
    .line 924
    move-object v7, v1

    .line 925
    move-object v0, v4

    .line 926
    move-object v1, v6

    .line 927
    :goto_39e
    move-object v6, v0

    .line 928
    goto/16 :goto_665

    .line 929
    .line 930
    :catch_3a1
    move-object v7, v1

    .line 931
    move-object v1, v6

    .line 932
    goto/16 :goto_86

    .line 933
    .line 934
    :catch_3a5
    move-object v7, v1

    .line 935
    move-object/from16 v1, p3

    .line 936
    .line 937
    goto/16 :goto_86

    .line 938
    .line 939
    :pswitch_3aa
    move-object v0, v4

    .line 940
    move v3, v7

    .line 941
    move-object v7, v1

    .line 942
    move-object v1, v5

    .line 943
    const/high16 v4, 0x20000000

    .line 944
    .line 945
    and-int/2addr v4, v3

    .line 946
    if-eqz v4, :cond_3b5

    .line 947
    .line 948
    const/4 v4, 0x1

    .line 949
    goto :goto_3b6

    .line 950
    :cond_3b5
    move v4, v6

    .line 951
    :goto_3b6
    if-eqz v4, :cond_3c4

    .line 952
    .line 953
    and-int v3, v3, v16

    .line 954
    .line 955
    int-to-long v3, v3

    .line 956
    :try_start_3bb
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 957
    .line 958
    .line 959
    move-result-object v3

    .line 960
    const/4 v13, 0x1

    .line 961
    invoke-virtual {v0, v3, v13}, Lcd;->N(Ljava/util/List;Z)V

    .line 962
    .line 963
    .line 964
    goto :goto_39e

    .line 965
    :cond_3c4
    and-int v3, v3, v16

    .line 966
    .line 967
    int-to-long v3, v3

    .line 968
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 969
    .line 970
    .line 971
    move-result-object v3

    .line 972
    invoke-virtual {v0, v3, v6}, Lcd;->N(Ljava/util/List;Z)V

    .line 973
    .line 974
    .line 975
    goto :goto_39e

    .line 976
    :catchall_3cf
    move-exception v0

    .line 977
    goto/16 :goto_66e

    .line 978
    .line 979
    :catch_3d2
    move-object v6, v0

    .line 980
    goto/16 :goto_646

    .line 981
    .line 982
    :pswitch_3d5
    move-object v0, v4

    .line 983
    move v3, v7

    .line 984
    move-object v7, v1

    .line 985
    move-object v1, v5

    .line 986
    and-int v3, v3, v16

    .line 987
    .line 988
    int-to-long v3, v3

    .line 989
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 990
    .line 991
    .line 992
    move-result-object v3

    .line 993
    invoke-virtual {v0, v3}, Lcd;->j(Ljava/util/List;)V

    .line 994
    .line 995
    .line 996
    goto :goto_39e

    .line 997
    :pswitch_3e4
    move-object v0, v4

    .line 998
    move v3, v7

    .line 999
    move-object v7, v1

    .line 1000
    move-object v1, v5

    .line 1001
    and-int v3, v3, v16

    .line 1002
    .line 1003
    int-to-long v3, v3

    .line 1004
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1005
    .line 1006
    .line 1007
    move-result-object v3

    .line 1008
    invoke-virtual {v0, v3}, Lcd;->v(Ljava/util/List;)V

    .line 1009
    .line 1010
    .line 1011
    goto :goto_39e

    .line 1012
    :pswitch_3f3
    move-object v0, v4

    .line 1013
    move v3, v7

    .line 1014
    move-object v7, v1

    .line 1015
    move-object v1, v5

    .line 1016
    and-int v3, v3, v16

    .line 1017
    .line 1018
    int-to-long v3, v3

    .line 1019
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1020
    .line 1021
    .line 1022
    move-result-object v3

    .line 1023
    invoke-virtual {v0, v3}, Lcd;->x(Ljava/util/List;)V

    .line 1024
    .line 1025
    .line 1026
    goto :goto_39e

    .line 1027
    :pswitch_402
    move-object v0, v4

    .line 1028
    move v3, v7

    .line 1029
    move-object v7, v1

    .line 1030
    move-object v1, v5

    .line 1031
    and-int v3, v3, v16

    .line 1032
    .line 1033
    int-to-long v3, v3

    .line 1034
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v3

    .line 1038
    invoke-virtual {v0, v3}, Lcd;->B(Ljava/util/List;)V

    .line 1039
    .line 1040
    .line 1041
    goto :goto_39e

    .line 1042
    :pswitch_411
    move-object v0, v4

    .line 1043
    move v3, v7

    .line 1044
    move-object v7, v1

    .line 1045
    move-object v1, v5

    .line 1046
    and-int v3, v3, v16

    .line 1047
    .line 1048
    int-to-long v3, v3

    .line 1049
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1050
    .line 1051
    .line 1052
    move-result-object v3

    .line 1053
    invoke-virtual {v0, v3}, Lcd;->R(Ljava/util/List;)V

    .line 1054
    .line 1055
    .line 1056
    goto/16 :goto_39e

    .line 1057
    .line 1058
    :pswitch_421
    move-object v0, v4

    .line 1059
    move v3, v7

    .line 1060
    move-object v7, v1

    .line 1061
    move-object v1, v5

    .line 1062
    and-int v3, v3, v16

    .line 1063
    .line 1064
    int-to-long v3, v3

    .line 1065
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1066
    .line 1067
    .line 1068
    move-result-object v3

    .line 1069
    invoke-virtual {v0, v3}, Lcd;->D(Ljava/util/List;)V

    .line 1070
    .line 1071
    .line 1072
    goto/16 :goto_39e

    .line 1073
    .line 1074
    :pswitch_431
    move-object v0, v4

    .line 1075
    move v3, v7

    .line 1076
    move-object v7, v1

    .line 1077
    move-object v1, v5

    .line 1078
    and-int v3, v3, v16

    .line 1079
    .line 1080
    int-to-long v3, v3

    .line 1081
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1082
    .line 1083
    .line 1084
    move-result-object v3

    .line 1085
    invoke-virtual {v0, v3}, Lcd;->z(Ljava/util/List;)V

    .line 1086
    .line 1087
    .line 1088
    goto/16 :goto_39e

    .line 1089
    .line 1090
    :pswitch_441
    move-object v0, v4

    .line 1091
    move v3, v7

    .line 1092
    move-object v7, v1

    .line 1093
    move-object v1, v5

    .line 1094
    and-int v3, v3, v16

    .line 1095
    .line 1096
    int-to-long v3, v3

    .line 1097
    invoke-virtual {v14, v3, v4, v2}, Le90;->c(JLjava/lang/Object;)Ljava/util/List;

    .line 1098
    .line 1099
    .line 1100
    move-result-object v3

    .line 1101
    invoke-virtual {v0, v3}, Lcd;->p(Ljava/util/List;)V

    .line 1102
    .line 1103
    .line 1104
    goto/16 :goto_39e

    .line 1105
    .line 1106
    :pswitch_451
    move-object v7, v1

    .line 1107
    move v13, v3

    .line 1108
    move-object v0, v4

    .line 1109
    move-object v1, v5

    .line 1110
    invoke-virtual {v7, v13, v2}, Lde0;->A(ILjava/lang/Object;)Ljava/lang/Object;

    .line 1111
    .line 1112
    .line 1113
    move-result-object v3

    .line 1114
    check-cast v3, Lxd0;

    .line 1115
    .line 1116
    invoke-virtual {v7, v13}, Lde0;->q(I)Les0;

    .line 1117
    .line 1118
    .line 1119
    move-result-object v4

    .line 1120
    invoke-virtual {v0, v15}, Lcd;->T(I)V

    .line 1121
    .line 1122
    .line 1123
    invoke-virtual {v0, v3, v4, v1}, Lcd;->e(Ljava/lang/Object;Les0;Lcs;)V

    .line 1124
    .line 1125
    .line 1126
    invoke-virtual {v7, v2, v13, v3}, Lde0;->T(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1127
    .line 1128
    .line 1129
    goto/16 :goto_39e

    .line 1130
    .line 1131
    :pswitch_46a
    move v13, v3

    .line 1132
    move-object v0, v4

    .line 1133
    move v3, v7

    .line 1134
    move-object v7, v1

    .line 1135
    move-object v1, v5

    .line 1136
    and-int v3, v3, v16

    .line 1137
    .line 1138
    int-to-long v3, v3

    .line 1139
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1140
    .line 1141
    .line 1142
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1143
    .line 1144
    check-cast v5, Lwd;

    .line 1145
    .line 1146
    invoke-virtual {v5}, Lwd;->w()J

    .line 1147
    .line 1148
    .line 1149
    move-result-wide v5

    .line 1150
    invoke-static {v2, v3, v4, v5, v6}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 1151
    .line 1152
    .line 1153
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1154
    .line 1155
    .line 1156
    goto/16 :goto_39e

    .line 1157
    .line 1158
    :pswitch_485
    move v13, v3

    .line 1159
    move-object v0, v4

    .line 1160
    move v3, v7

    .line 1161
    move-object v7, v1

    .line 1162
    move-object v1, v5

    .line 1163
    and-int v3, v3, v16

    .line 1164
    .line 1165
    int-to-long v3, v3

    .line 1166
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1167
    .line 1168
    .line 1169
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1170
    .line 1171
    check-cast v5, Lwd;

    .line 1172
    .line 1173
    invoke-virtual {v5}, Lwd;->v()I

    .line 1174
    .line 1175
    .line 1176
    move-result v5

    .line 1177
    invoke-static {v5, v3, v4, v2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 1178
    .line 1179
    .line 1180
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1181
    .line 1182
    .line 1183
    goto/16 :goto_39e

    .line 1184
    .line 1185
    :pswitch_4a0
    move v13, v3

    .line 1186
    move-object v0, v4

    .line 1187
    move v3, v7

    .line 1188
    move-object v7, v1

    .line 1189
    move-object v1, v5

    .line 1190
    and-int v3, v3, v16

    .line 1191
    .line 1192
    int-to-long v3, v3

    .line 1193
    const/4 v5, 0x1

    .line 1194
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1195
    .line 1196
    .line 1197
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1198
    .line 1199
    check-cast v5, Lwd;

    .line 1200
    .line 1201
    invoke-virtual {v5}, Lwd;->u()J

    .line 1202
    .line 1203
    .line 1204
    move-result-wide v5

    .line 1205
    invoke-static {v2, v3, v4, v5, v6}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 1206
    .line 1207
    .line 1208
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1209
    .line 1210
    .line 1211
    goto/16 :goto_39e

    .line 1212
    .line 1213
    :pswitch_4bc
    move v13, v3

    .line 1214
    move-object v0, v4

    .line 1215
    move v3, v7

    .line 1216
    move-object v7, v1

    .line 1217
    move-object v1, v5

    .line 1218
    invoke-static {v3}, Lde0;->E(I)J

    .line 1219
    .line 1220
    .line 1221
    move-result-wide v3

    .line 1222
    const/4 v5, 0x5

    .line 1223
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1224
    .line 1225
    .line 1226
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1227
    .line 1228
    check-cast v5, Lwd;

    .line 1229
    .line 1230
    invoke-virtual {v5}, Lwd;->t()I

    .line 1231
    .line 1232
    .line 1233
    move-result v5

    .line 1234
    invoke-static {v5, v3, v4, v2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 1235
    .line 1236
    .line 1237
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1238
    .line 1239
    .line 1240
    goto/16 :goto_39e

    .line 1241
    .line 1242
    :pswitch_4d9
    move v13, v3

    .line 1243
    move-object v0, v4

    .line 1244
    move v3, v7

    .line 1245
    move-object v7, v1

    .line 1246
    move-object v1, v5

    .line 1247
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1248
    .line 1249
    .line 1250
    iget-object v4, v0, Lcd;->e:Ljava/lang/Object;

    .line 1251
    .line 1252
    check-cast v4, Lwd;

    .line 1253
    .line 1254
    invoke-virtual {v4}, Lwd;->m()I

    .line 1255
    .line 1256
    .line 1257
    move-result v4

    .line 1258
    invoke-virtual {v7, v13}, Lde0;->o(I)V

    .line 1259
    .line 1260
    .line 1261
    invoke-static {v3}, Lde0;->E(I)J

    .line 1262
    .line 1263
    .line 1264
    move-result-wide v5

    .line 1265
    invoke-static {v4, v5, v6, v2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 1266
    .line 1267
    .line 1268
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1269
    .line 1270
    .line 1271
    goto/16 :goto_39e

    .line 1272
    .line 1273
    :pswitch_4f8
    move v13, v3

    .line 1274
    move-object v0, v4

    .line 1275
    move v3, v7

    .line 1276
    move-object v7, v1

    .line 1277
    move-object v1, v5

    .line 1278
    invoke-static {v3}, Lde0;->E(I)J

    .line 1279
    .line 1280
    .line 1281
    move-result-wide v3

    .line 1282
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1283
    .line 1284
    .line 1285
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1286
    .line 1287
    check-cast v5, Lwd;

    .line 1288
    .line 1289
    invoke-virtual {v5}, Lwd;->A()I

    .line 1290
    .line 1291
    .line 1292
    move-result v5

    .line 1293
    invoke-static {v5, v3, v4, v2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 1294
    .line 1295
    .line 1296
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1297
    .line 1298
    .line 1299
    goto/16 :goto_39e

    .line 1300
    .line 1301
    :pswitch_514
    move v13, v3

    .line 1302
    move-object v0, v4

    .line 1303
    move v3, v7

    .line 1304
    move-object v7, v1

    .line 1305
    move-object v1, v5

    .line 1306
    invoke-static {v3}, Lde0;->E(I)J

    .line 1307
    .line 1308
    .line 1309
    move-result-wide v3

    .line 1310
    invoke-virtual {v0}, Lcd;->l()Lqb;

    .line 1311
    .line 1312
    .line 1313
    move-result-object v5

    .line 1314
    invoke-static {v3, v4, v2, v5}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 1315
    .line 1316
    .line 1317
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1318
    .line 1319
    .line 1320
    goto/16 :goto_39e

    .line 1321
    .line 1322
    :pswitch_529
    move-object v7, v1

    .line 1323
    move v13, v3

    .line 1324
    move-object v0, v4

    .line 1325
    move-object v1, v5

    .line 1326
    invoke-virtual {v7, v13, v2}, Lde0;->A(ILjava/lang/Object;)Ljava/lang/Object;

    .line 1327
    .line 1328
    .line 1329
    move-result-object v3

    .line 1330
    check-cast v3, Lxd0;

    .line 1331
    .line 1332
    invoke-virtual {v7, v13}, Lde0;->q(I)Les0;

    .line 1333
    .line 1334
    .line 1335
    move-result-object v4

    .line 1336
    const/4 v5, 0x2

    .line 1337
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1338
    .line 1339
    .line 1340
    invoke-virtual {v0, v3, v4, v1}, Lcd;->g(Ljava/lang/Object;Les0;Lcs;)V

    .line 1341
    .line 1342
    .line 1343
    invoke-virtual {v7, v2, v13, v3}, Lde0;->T(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1344
    .line 1345
    .line 1346
    goto/16 :goto_39e

    .line 1347
    .line 1348
    :pswitch_543
    move v13, v3

    .line 1349
    move-object v0, v4

    .line 1350
    move v3, v7

    .line 1351
    move-object v7, v1

    .line 1352
    move-object v1, v5

    .line 1353
    invoke-virtual {v7, v3, v0, v2}, Lde0;->O(ILcd;Ljava/lang/Object;)V

    .line 1354
    .line 1355
    .line 1356
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1357
    .line 1358
    .line 1359
    goto/16 :goto_39e

    .line 1360
    .line 1361
    :pswitch_550
    move v13, v3

    .line 1362
    move-object v0, v4

    .line 1363
    move v3, v7

    .line 1364
    move-object v7, v1

    .line 1365
    move-object v1, v5

    .line 1366
    invoke-static {v3}, Lde0;->E(I)J

    .line 1367
    .line 1368
    .line 1369
    move-result-wide v3

    .line 1370
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1371
    .line 1372
    .line 1373
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1374
    .line 1375
    check-cast v5, Lwd;

    .line 1376
    .line 1377
    invoke-virtual {v5}, Lwd;->j()Z

    .line 1378
    .line 1379
    .line 1380
    move-result v5

    .line 1381
    sget-object v6, Lk71;->c:Lh71;

    .line 1382
    .line 1383
    invoke-virtual {v6, v2, v3, v4, v5}, Lh71;->m(Ljava/lang/Object;JZ)V

    .line 1384
    .line 1385
    .line 1386
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1387
    .line 1388
    .line 1389
    goto/16 :goto_39e

    .line 1390
    .line 1391
    :pswitch_56e
    move v13, v3

    .line 1392
    move-object v0, v4

    .line 1393
    move v3, v7

    .line 1394
    move-object v7, v1

    .line 1395
    move-object v1, v5

    .line 1396
    invoke-static {v3}, Lde0;->E(I)J

    .line 1397
    .line 1398
    .line 1399
    move-result-wide v3

    .line 1400
    const/4 v5, 0x5

    .line 1401
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1402
    .line 1403
    .line 1404
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1405
    .line 1406
    check-cast v5, Lwd;

    .line 1407
    .line 1408
    invoke-virtual {v5}, Lwd;->n()I

    .line 1409
    .line 1410
    .line 1411
    move-result v5

    .line 1412
    invoke-static {v5, v3, v4, v2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 1413
    .line 1414
    .line 1415
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1416
    .line 1417
    .line 1418
    goto/16 :goto_39e

    .line 1419
    .line 1420
    :pswitch_58b
    move v13, v3

    .line 1421
    move-object v0, v4

    .line 1422
    move v3, v7

    .line 1423
    move-object v7, v1

    .line 1424
    move-object v1, v5

    .line 1425
    invoke-static {v3}, Lde0;->E(I)J

    .line 1426
    .line 1427
    .line 1428
    move-result-wide v3

    .line 1429
    const/4 v5, 0x1

    .line 1430
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1431
    .line 1432
    .line 1433
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1434
    .line 1435
    check-cast v5, Lwd;

    .line 1436
    .line 1437
    invoke-virtual {v5}, Lwd;->o()J

    .line 1438
    .line 1439
    .line 1440
    move-result-wide v5

    .line 1441
    invoke-static {v2, v3, v4, v5, v6}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 1442
    .line 1443
    .line 1444
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1445
    .line 1446
    .line 1447
    goto/16 :goto_39e

    .line 1448
    .line 1449
    :pswitch_5a8
    move v13, v3

    .line 1450
    move-object v0, v4

    .line 1451
    move v3, v7

    .line 1452
    move-object v7, v1

    .line 1453
    move-object v1, v5

    .line 1454
    invoke-static {v3}, Lde0;->E(I)J

    .line 1455
    .line 1456
    .line 1457
    move-result-wide v3

    .line 1458
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1459
    .line 1460
    .line 1461
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1462
    .line 1463
    check-cast v5, Lwd;

    .line 1464
    .line 1465
    invoke-virtual {v5}, Lwd;->q()I

    .line 1466
    .line 1467
    .line 1468
    move-result v5

    .line 1469
    invoke-static {v5, v3, v4, v2}, Lk71;->n(IJLjava/lang/Object;)V

    .line 1470
    .line 1471
    .line 1472
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1473
    .line 1474
    .line 1475
    goto/16 :goto_39e

    .line 1476
    .line 1477
    :pswitch_5c4
    move v13, v3

    .line 1478
    move-object v0, v4

    .line 1479
    move v3, v7

    .line 1480
    move-object v7, v1

    .line 1481
    move-object v1, v5

    .line 1482
    invoke-static {v3}, Lde0;->E(I)J

    .line 1483
    .line 1484
    .line 1485
    move-result-wide v3

    .line 1486
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1487
    .line 1488
    .line 1489
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1490
    .line 1491
    check-cast v5, Lwd;

    .line 1492
    .line 1493
    invoke-virtual {v5}, Lwd;->B()J

    .line 1494
    .line 1495
    .line 1496
    move-result-wide v5

    .line 1497
    invoke-static {v2, v3, v4, v5, v6}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 1498
    .line 1499
    .line 1500
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1501
    .line 1502
    .line 1503
    goto/16 :goto_39e

    .line 1504
    .line 1505
    :pswitch_5e0
    move v13, v3

    .line 1506
    move-object v0, v4

    .line 1507
    move v3, v7

    .line 1508
    move-object v7, v1

    .line 1509
    move-object v1, v5

    .line 1510
    invoke-static {v3}, Lde0;->E(I)J

    .line 1511
    .line 1512
    .line 1513
    move-result-wide v3

    .line 1514
    invoke-virtual {v0, v6}, Lcd;->T(I)V

    .line 1515
    .line 1516
    .line 1517
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1518
    .line 1519
    check-cast v5, Lwd;

    .line 1520
    .line 1521
    invoke-virtual {v5}, Lwd;->r()J

    .line 1522
    .line 1523
    .line 1524
    move-result-wide v5

    .line 1525
    invoke-static {v2, v3, v4, v5, v6}, Lk71;->o(Ljava/lang/Object;JJ)V

    .line 1526
    .line 1527
    .line 1528
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1529
    .line 1530
    .line 1531
    goto/16 :goto_39e

    .line 1532
    .line 1533
    :pswitch_5fc
    move v13, v3

    .line 1534
    move-object v0, v4

    .line 1535
    move v3, v7

    .line 1536
    move-object v7, v1

    .line 1537
    move-object v1, v5

    .line 1538
    invoke-static {v3}, Lde0;->E(I)J

    .line 1539
    .line 1540
    .line 1541
    move-result-wide v3

    .line 1542
    const/4 v5, 0x5

    .line 1543
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1544
    .line 1545
    .line 1546
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1547
    .line 1548
    check-cast v5, Lwd;

    .line 1549
    .line 1550
    invoke-virtual {v5}, Lwd;->p()F

    .line 1551
    .line 1552
    .line 1553
    move-result v5

    .line 1554
    sget-object v6, Lk71;->c:Lh71;

    .line 1555
    .line 1556
    invoke-virtual {v6, v2, v3, v4, v5}, Lh71;->p(Ljava/lang/Object;JF)V

    .line 1557
    .line 1558
    .line 1559
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V

    .line 1560
    .line 1561
    .line 1562
    goto/16 :goto_39e

    .line 1563
    .line 1564
    :pswitch_61b
    move v13, v3

    .line 1565
    move-object v0, v4

    .line 1566
    move v3, v7

    .line 1567
    move-object v7, v1

    .line 1568
    move-object v1, v5

    .line 1569
    invoke-static {v3}, Lde0;->E(I)J

    .line 1570
    .line 1571
    .line 1572
    move-result-wide v3

    .line 1573
    const/4 v5, 0x1

    .line 1574
    invoke-virtual {v0, v5}, Lcd;->T(I)V

    .line 1575
    .line 1576
    .line 1577
    iget-object v5, v0, Lcd;->e:Ljava/lang/Object;

    .line 1578
    .line 1579
    check-cast v5, Lwd;

    .line 1580
    .line 1581
    invoke-virtual {v5}, Lwd;->l()D

    .line 1582
    .line 1583
    .line 1584
    move-result-wide v5
    :try_end_630
    .catch Lx40; {:try_start_3bb .. :try_end_630} :catch_3d2
    .catchall {:try_start_3bb .. :try_end_630} :catchall_3cf

    .line 1585
    :try_start_630
    sget-object v0, Lk71;->c:Lh71;
    :try_end_632
    .catch Lx40; {:try_start_630 .. :try_end_632} :catch_644
    .catchall {:try_start_630 .. :try_end_632} :catchall_3cf

    .line 1586
    .line 1587
    move-object v1, v2

    .line 1588
    move-wide v2, v3

    .line 1589
    move-wide v4, v5

    .line 1590
    move-object/from16 v6, p2

    .line 1591
    .line 1592
    :try_start_637
    invoke-virtual/range {v0 .. v5}, Lh71;->o(Ljava/lang/Object;JD)V
    :try_end_63a
    .catch Lx40; {:try_start_637 .. :try_end_63a} :catch_642
    .catchall {:try_start_637 .. :try_end_63a} :catchall_63f

    .line 1593
    .line 1594
    .line 1595
    move-object v2, v1

    .line 1596
    :try_start_63b
    invoke-virtual {v7, v13, v2}, Lde0;->Q(ILjava/lang/Object;)V
    :try_end_63e
    .catch Lx40; {:try_start_63b .. :try_end_63e} :catch_646
    .catchall {:try_start_63b .. :try_end_63e} :catchall_3cf

    .line 1597
    .line 1598
    .line 1599
    goto :goto_665

    .line 1600
    :catchall_63f
    move-exception v0

    .line 1601
    move-object v2, v1

    .line 1602
    goto :goto_66e

    .line 1603
    :catch_642
    move-object v2, v1

    .line 1604
    goto :goto_646

    .line 1605
    :catch_644
    move-object/from16 v6, p2

    .line 1606
    .line 1607
    :catch_646
    :goto_646
    :try_start_646
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1608
    .line 1609
    .line 1610
    if-nez v12, :cond_650

    .line 1611
    .line 1612
    invoke-static {v2}, Lp61;->a(Ljava/lang/Object;)Lm61;

    .line 1613
    .line 1614
    .line 1615
    move-result-object v0

    .line 1616
    move-object v12, v0

    .line 1617
    :cond_650
    invoke-static {v12, v6}, Lp61;->b(Ljava/lang/Object;Lcd;)Z

    .line 1618
    .line 1619
    .line 1620
    move-result v0
    :try_end_654
    .catchall {:try_start_646 .. :try_end_654} :catchall_3cf

    .line 1621
    if-nez v0, :cond_665

    .line 1622
    .line 1623
    :goto_656
    if-ge v11, v10, :cond_660

    .line 1624
    .line 1625
    aget v0, v9, v11

    .line 1626
    .line 1627
    invoke-virtual {v7, v2, v0, v12}, Lde0;->n(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1628
    .line 1629
    .line 1630
    add-int/lit8 v11, v11, 0x1

    .line 1631
    .line 1632
    goto :goto_656

    .line 1633
    :cond_660
    if-eqz v12, :cond_664

    .line 1634
    .line 1635
    goto/16 :goto_68

    .line 1636
    .line 1637
    :cond_664
    :goto_664
    return-void

    .line 1638
    :cond_665
    :goto_665
    move-object/from16 v5, p3

    .line 1639
    .line 1640
    move-object v4, v6

    .line 1641
    move-object v1, v7

    .line 1642
    goto/16 :goto_18

    .line 1643
    .line 1644
    :catchall_66b
    move-exception v0

    .line 1645
    goto/16 :goto_2a

    .line 1646
    .line 1647
    :goto_66e
    if-ge v11, v10, :cond_678

    .line 1648
    .line 1649
    aget v1, v9, v11

    .line 1650
    .line 1651
    invoke-virtual {v7, v2, v1, v12}, Lde0;->n(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1652
    .line 1653
    .line 1654
    add-int/lit8 v11, v11, 0x1

    .line 1655
    .line 1656
    goto :goto_66e

    .line 1657
    :cond_678
    if-eqz v12, :cond_682

    .line 1658
    .line 1659
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1660
    .line 1661
    .line 1662
    move-object v1, v2

    .line 1663
    check-cast v1, Lr00;

    .line 1664
    .line 1665
    iput-object v12, v1, Lr00;->unknownFields:Lm61;

    .line 1666
    .line 1667
    :cond_682
    throw v0

    .line 1668
    nop

    .line 1669
    :pswitch_data_684
    .packed-switch 0x0
        :pswitch_61b
        :pswitch_5fc
        :pswitch_5e0
        :pswitch_5c4
        :pswitch_5a8
        :pswitch_58b
        :pswitch_56e
        :pswitch_550
        :pswitch_543
        :pswitch_529
        :pswitch_514
        :pswitch_4f8
        :pswitch_4d9
        :pswitch_4bc
        :pswitch_4a0
        :pswitch_485
        :pswitch_46a
        :pswitch_451
        :pswitch_441
        :pswitch_431
        :pswitch_421
        :pswitch_411
        :pswitch_402
        :pswitch_3f3
        :pswitch_3e4
        :pswitch_3d5
        :pswitch_3aa
        :pswitch_390
        :pswitch_384
        :pswitch_378
        :pswitch_366
        :pswitch_35a
        :pswitch_34e
        :pswitch_342
        :pswitch_336
        :pswitch_32a
        :pswitch_31e
        :pswitch_312
        :pswitch_306
        :pswitch_2fa
        :pswitch_2ee
        :pswitch_2e2
        :pswitch_2d6
        :pswitch_2ca
        :pswitch_2b8
        :pswitch_2ac
        :pswitch_2a0
        :pswitch_294
        :pswitch_288
        :pswitch_270
        :pswitch_254
        :pswitch_239
        :pswitch_21e
        :pswitch_204
        :pswitch_1ea
        :pswitch_1d0
        :pswitch_1b5
        :pswitch_19a
        :pswitch_180
        :pswitch_178
        :pswitch_162
        :pswitch_153
        :pswitch_139
        :pswitch_11c
        :pswitch_102
        :pswitch_e8
        :pswitch_cf
        :pswitch_b6
        :pswitch_9f
    .end packed-switch
.end method

.method public final f(Ljava/lang/Object;[BIILz8;)V
    .registers 14

    .line 1
    iget-boolean v0, p0, Lde0;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual/range {p0 .. p5}, Lde0;->K(Ljava/lang/Object;[BIILz8;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    const/4 v6, 0x0

    .line 10
    move-object v1, p0

    .line 11
    move-object v2, p1

    .line 12
    move-object v3, p2

    .line 13
    move v4, p3

    .line 14
    move v5, p4

    .line 15
    move-object v7, p5

    .line 16
    invoke-virtual/range {v1 .. v7}, Lde0;->J(Ljava/lang/Object;[BIIILz8;)I

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final g(Lr00;)I
    .registers 3

    .line 1
    iget-boolean v0, p0, Lde0;->g:Z

    .line 2
    .line 3
    if-eqz v0, :cond_9

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lde0;->s(Lr00;)I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    invoke-virtual {p0, p1}, Lde0;->r(Lr00;)I

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    return p0
.end method

.method public final h(Ljava/lang/Object;Ldb0;)V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    iget-object v3, v2, Ldb0;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v3, Lde;

    .line 13
    .line 14
    iget-boolean v4, v0, Lde0;->g:Z

    .line 15
    .line 16
    if-eqz v4, :cond_559

    .line 17
    .line 18
    iget-object v4, v0, Lde0;->a:[I

    .line 19
    .line 20
    array-length v5, v4

    .line 21
    const/4 v6, 0x0

    .line 22
    move v7, v6

    .line 23
    :goto_16
    if-ge v7, v5, :cond_54b

    .line 24
    .line 25
    invoke-virtual {v0, v7}, Lde0;->W(I)I

    .line 26
    .line 27
    .line 28
    move-result v8

    .line 29
    aget v9, v4, v7

    .line 30
    .line 31
    invoke-static {v8}, Lde0;->V(I)I

    .line 32
    .line 33
    .line 34
    move-result v10

    .line 35
    const/16 v11, 0x3f

    .line 36
    .line 37
    const/4 v12, 0x1

    .line 38
    const v13, 0xfffff

    .line 39
    .line 40
    .line 41
    packed-switch v10, :pswitch_data_55e

    .line 42
    .line 43
    .line 44
    goto/16 :goto_547

    .line 45
    .line 46
    :pswitch_2d
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-result v10

    .line 50
    if-eqz v10, :cond_547

    .line 51
    .line 52
    and-int/2addr v8, v13

    .line 53
    int-to-long v10, v8

    .line 54
    sget-object v8, Lk71;->c:Lh71;

    .line 55
    .line 56
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v8

    .line 60
    invoke-virtual {v0, v7}, Lde0;->q(I)Les0;

    .line 61
    .line 62
    .line 63
    move-result-object v10

    .line 64
    invoke-virtual {v2, v9, v8, v10}, Ldb0;->B(ILjava/lang/Object;Les0;)V

    .line 65
    .line 66
    .line 67
    goto/16 :goto_547

    .line 68
    .line 69
    :pswitch_44
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 70
    .line 71
    .line 72
    move-result v10

    .line 73
    if-eqz v10, :cond_547

    .line 74
    .line 75
    and-int/2addr v8, v13

    .line 76
    int-to-long v13, v8

    .line 77
    invoke-static {v13, v14, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 78
    .line 79
    .line 80
    move-result-wide v13

    .line 81
    shl-long v15, v13, v12

    .line 82
    .line 83
    shr-long v10, v13, v11

    .line 84
    .line 85
    xor-long/2addr v10, v15

    .line 86
    invoke-virtual {v3, v9, v10, v11}, Lde;->F(IJ)V

    .line 87
    .line 88
    .line 89
    goto/16 :goto_547

    .line 90
    .line 91
    :pswitch_5a
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v10

    .line 95
    if-eqz v10, :cond_547

    .line 96
    .line 97
    and-int/2addr v8, v13

    .line 98
    int-to-long v10, v8

    .line 99
    invoke-static {v10, v11, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 100
    .line 101
    .line 102
    move-result v8

    .line 103
    shl-int/lit8 v10, v8, 0x1

    .line 104
    .line 105
    shr-int/lit8 v8, v8, 0x1f

    .line 106
    .line 107
    xor-int/2addr v8, v10

    .line 108
    invoke-virtual {v3, v9, v8}, Lde;->D(II)V

    .line 109
    .line 110
    .line 111
    goto/16 :goto_547

    .line 112
    .line 113
    :pswitch_70
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move-result v10

    .line 117
    if-eqz v10, :cond_547

    .line 118
    .line 119
    and-int/2addr v8, v13

    .line 120
    int-to-long v10, v8

    .line 121
    invoke-static {v10, v11, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 122
    .line 123
    .line 124
    move-result-wide v10

    .line 125
    invoke-virtual {v3, v9, v10, v11}, Lde;->t(IJ)V

    .line 126
    .line 127
    .line 128
    goto/16 :goto_547

    .line 129
    .line 130
    :pswitch_81
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result v10

    .line 134
    if-eqz v10, :cond_547

    .line 135
    .line 136
    and-int/2addr v8, v13

    .line 137
    int-to-long v10, v8

    .line 138
    invoke-static {v10, v11, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 139
    .line 140
    .line 141
    move-result v8

    .line 142
    invoke-virtual {v3, v9, v8}, Lde;->r(II)V

    .line 143
    .line 144
    .line 145
    goto/16 :goto_547

    .line 146
    .line 147
    :pswitch_92
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v10

    .line 151
    if-eqz v10, :cond_547

    .line 152
    .line 153
    and-int/2addr v8, v13

    .line 154
    int-to-long v10, v8

    .line 155
    invoke-static {v10, v11, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 156
    .line 157
    .line 158
    move-result v8

    .line 159
    invoke-virtual {v3, v9, v8}, Lde;->v(II)V

    .line 160
    .line 161
    .line 162
    goto/16 :goto_547

    .line 163
    .line 164
    :pswitch_a3
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result v10

    .line 168
    if-eqz v10, :cond_547

    .line 169
    .line 170
    and-int/2addr v8, v13

    .line 171
    int-to-long v10, v8

    .line 172
    invoke-static {v10, v11, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 173
    .line 174
    .line 175
    move-result v8

    .line 176
    invoke-virtual {v3, v9, v8}, Lde;->D(II)V

    .line 177
    .line 178
    .line 179
    goto/16 :goto_547

    .line 180
    .line 181
    :pswitch_b4
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    move-result v10

    .line 185
    if-eqz v10, :cond_547

    .line 186
    .line 187
    and-int/2addr v8, v13

    .line 188
    int-to-long v10, v8

    .line 189
    sget-object v8, Lk71;->c:Lh71;

    .line 190
    .line 191
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object v8

    .line 195
    check-cast v8, Lqb;

    .line 196
    .line 197
    invoke-virtual {v2, v9, v8}, Ldb0;->x(ILqb;)V

    .line 198
    .line 199
    .line 200
    goto/16 :goto_547

    .line 201
    .line 202
    :pswitch_c9
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v10

    .line 206
    if-eqz v10, :cond_547

    .line 207
    .line 208
    and-int/2addr v8, v13

    .line 209
    int-to-long v10, v8

    .line 210
    sget-object v8, Lk71;->c:Lh71;

    .line 211
    .line 212
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v8

    .line 216
    invoke-virtual {v0, v7}, Lde0;->q(I)Les0;

    .line 217
    .line 218
    .line 219
    move-result-object v10

    .line 220
    invoke-virtual {v2, v9, v8, v10}, Ldb0;->G(ILjava/lang/Object;Les0;)V

    .line 221
    .line 222
    .line 223
    goto/16 :goto_547

    .line 224
    .line 225
    :pswitch_e0
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 226
    .line 227
    .line 228
    move-result v10

    .line 229
    if-eqz v10, :cond_547

    .line 230
    .line 231
    and-int/2addr v8, v13

    .line 232
    int-to-long v10, v8

    .line 233
    sget-object v8, Lk71;->c:Lh71;

    .line 234
    .line 235
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 236
    .line 237
    .line 238
    move-result-object v8

    .line 239
    invoke-static {v9, v8, v2}, Lde0;->Z(ILjava/lang/Object;Ldb0;)V

    .line 240
    .line 241
    .line 242
    goto/16 :goto_547

    .line 243
    .line 244
    :pswitch_f3
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 245
    .line 246
    .line 247
    move-result v10

    .line 248
    if-eqz v10, :cond_547

    .line 249
    .line 250
    and-int/2addr v8, v13

    .line 251
    int-to-long v10, v8

    .line 252
    sget-object v8, Lk71;->c:Lh71;

    .line 253
    .line 254
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 255
    .line 256
    .line 257
    move-result-object v8

    .line 258
    check-cast v8, Ljava/lang/Boolean;

    .line 259
    .line 260
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 261
    .line 262
    .line 263
    move-result v8

    .line 264
    invoke-virtual {v3, v9, v8}, Lde;->n(IZ)V

    .line 265
    .line 266
    .line 267
    goto/16 :goto_547

    .line 268
    .line 269
    :pswitch_10c
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 270
    .line 271
    .line 272
    move-result v10

    .line 273
    if-eqz v10, :cond_547

    .line 274
    .line 275
    and-int/2addr v8, v13

    .line 276
    int-to-long v10, v8

    .line 277
    invoke-static {v10, v11, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 278
    .line 279
    .line 280
    move-result v8

    .line 281
    invoke-virtual {v2, v9, v8}, Ldb0;->y(II)V

    .line 282
    .line 283
    .line 284
    goto/16 :goto_547

    .line 285
    .line 286
    :pswitch_11d
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 287
    .line 288
    .line 289
    move-result v10

    .line 290
    if-eqz v10, :cond_547

    .line 291
    .line 292
    and-int/2addr v8, v13

    .line 293
    int-to-long v10, v8

    .line 294
    invoke-static {v10, v11, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 295
    .line 296
    .line 297
    move-result-wide v10

    .line 298
    invoke-virtual {v2, v9, v10, v11}, Ldb0;->z(IJ)V

    .line 299
    .line 300
    .line 301
    goto/16 :goto_547

    .line 302
    .line 303
    :pswitch_12e
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 304
    .line 305
    .line 306
    move-result v10

    .line 307
    if-eqz v10, :cond_547

    .line 308
    .line 309
    and-int/2addr v8, v13

    .line 310
    int-to-long v10, v8

    .line 311
    invoke-static {v10, v11, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 312
    .line 313
    .line 314
    move-result v8

    .line 315
    invoke-virtual {v2, v9, v8}, Ldb0;->D(II)V

    .line 316
    .line 317
    .line 318
    goto/16 :goto_547

    .line 319
    .line 320
    :pswitch_13f
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 321
    .line 322
    .line 323
    move-result v10

    .line 324
    if-eqz v10, :cond_547

    .line 325
    .line 326
    and-int/2addr v8, v13

    .line 327
    int-to-long v10, v8

    .line 328
    invoke-static {v10, v11, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 329
    .line 330
    .line 331
    move-result-wide v10

    .line 332
    invoke-virtual {v3, v9, v10, v11}, Lde;->F(IJ)V

    .line 333
    .line 334
    .line 335
    goto/16 :goto_547

    .line 336
    .line 337
    :pswitch_150
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 338
    .line 339
    .line 340
    move-result v10

    .line 341
    if-eqz v10, :cond_547

    .line 342
    .line 343
    and-int/2addr v8, v13

    .line 344
    int-to-long v10, v8

    .line 345
    invoke-static {v10, v11, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 346
    .line 347
    .line 348
    move-result-wide v10

    .line 349
    invoke-virtual {v2, v9, v10, v11}, Ldb0;->E(IJ)V

    .line 350
    .line 351
    .line 352
    goto/16 :goto_547

    .line 353
    .line 354
    :pswitch_161
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 355
    .line 356
    .line 357
    move-result v10

    .line 358
    if-eqz v10, :cond_547

    .line 359
    .line 360
    and-int/2addr v8, v13

    .line 361
    int-to-long v10, v8

    .line 362
    sget-object v8, Lk71;->c:Lh71;

    .line 363
    .line 364
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object v8

    .line 368
    check-cast v8, Ljava/lang/Float;

    .line 369
    .line 370
    invoke-virtual {v8}, Ljava/lang/Float;->floatValue()F

    .line 371
    .line 372
    .line 373
    move-result v8

    .line 374
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 375
    .line 376
    .line 377
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 378
    .line 379
    .line 380
    move-result v8

    .line 381
    invoke-virtual {v3, v9, v8}, Lde;->r(II)V

    .line 382
    .line 383
    .line 384
    goto/16 :goto_547

    .line 385
    .line 386
    :pswitch_181
    invoke-virtual {v0, v9, v7, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 387
    .line 388
    .line 389
    move-result v10

    .line 390
    if-eqz v10, :cond_547

    .line 391
    .line 392
    and-int/2addr v8, v13

    .line 393
    int-to-long v10, v8

    .line 394
    sget-object v8, Lk71;->c:Lh71;

    .line 395
    .line 396
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 397
    .line 398
    .line 399
    move-result-object v8

    .line 400
    check-cast v8, Ljava/lang/Double;

    .line 401
    .line 402
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 403
    .line 404
    .line 405
    move-result-wide v10

    .line 406
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 407
    .line 408
    .line 409
    invoke-static {v10, v11}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 410
    .line 411
    .line 412
    move-result-wide v10

    .line 413
    invoke-virtual {v3, v9, v10, v11}, Lde;->t(IJ)V

    .line 414
    .line 415
    .line 416
    goto/16 :goto_547

    .line 417
    .line 418
    :pswitch_1a1
    and-int/2addr v8, v13

    .line 419
    int-to-long v10, v8

    .line 420
    sget-object v8, Lk71;->c:Lh71;

    .line 421
    .line 422
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v8

    .line 426
    invoke-virtual {v0, v2, v9, v8, v7}, Lde0;->Y(Ldb0;ILjava/lang/Object;I)V

    .line 427
    .line 428
    .line 429
    goto/16 :goto_547

    .line 430
    .line 431
    :pswitch_1ae
    aget v9, v4, v7

    .line 432
    .line 433
    and-int/2addr v8, v13

    .line 434
    int-to-long v10, v8

    .line 435
    sget-object v8, Lk71;->c:Lh71;

    .line 436
    .line 437
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v8

    .line 441
    check-cast v8, Ljava/util/List;

    .line 442
    .line 443
    invoke-virtual {v0, v7}, Lde0;->q(I)Les0;

    .line 444
    .line 445
    .line 446
    move-result-object v10

    .line 447
    invoke-static {v9, v8, v2, v10}, Lis0;->F(ILjava/util/List;Ldb0;Les0;)V

    .line 448
    .line 449
    .line 450
    goto/16 :goto_547

    .line 451
    .line 452
    :pswitch_1c3
    aget v9, v4, v7

    .line 453
    .line 454
    and-int/2addr v8, v13

    .line 455
    int-to-long v10, v8

    .line 456
    sget-object v8, Lk71;->c:Lh71;

    .line 457
    .line 458
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 459
    .line 460
    .line 461
    move-result-object v8

    .line 462
    check-cast v8, Ljava/util/List;

    .line 463
    .line 464
    invoke-static {v9, v8, v2, v12}, Lis0;->M(ILjava/util/List;Ldb0;Z)V

    .line 465
    .line 466
    .line 467
    goto/16 :goto_547

    .line 468
    .line 469
    :pswitch_1d4
    aget v9, v4, v7

    .line 470
    .line 471
    and-int/2addr v8, v13

    .line 472
    int-to-long v10, v8

    .line 473
    sget-object v8, Lk71;->c:Lh71;

    .line 474
    .line 475
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 476
    .line 477
    .line 478
    move-result-object v8

    .line 479
    check-cast v8, Ljava/util/List;

    .line 480
    .line 481
    invoke-static {v9, v8, v2, v12}, Lis0;->L(ILjava/util/List;Ldb0;Z)V

    .line 482
    .line 483
    .line 484
    goto/16 :goto_547

    .line 485
    .line 486
    :pswitch_1e5
    aget v9, v4, v7

    .line 487
    .line 488
    and-int/2addr v8, v13

    .line 489
    int-to-long v10, v8

    .line 490
    sget-object v8, Lk71;->c:Lh71;

    .line 491
    .line 492
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 493
    .line 494
    .line 495
    move-result-object v8

    .line 496
    check-cast v8, Ljava/util/List;

    .line 497
    .line 498
    invoke-static {v9, v8, v2, v12}, Lis0;->K(ILjava/util/List;Ldb0;Z)V

    .line 499
    .line 500
    .line 501
    goto/16 :goto_547

    .line 502
    .line 503
    :pswitch_1f6
    aget v9, v4, v7

    .line 504
    .line 505
    and-int/2addr v8, v13

    .line 506
    int-to-long v10, v8

    .line 507
    sget-object v8, Lk71;->c:Lh71;

    .line 508
    .line 509
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 510
    .line 511
    .line 512
    move-result-object v8

    .line 513
    check-cast v8, Ljava/util/List;

    .line 514
    .line 515
    invoke-static {v9, v8, v2, v12}, Lis0;->J(ILjava/util/List;Ldb0;Z)V

    .line 516
    .line 517
    .line 518
    goto/16 :goto_547

    .line 519
    .line 520
    :pswitch_207
    aget v9, v4, v7

    .line 521
    .line 522
    and-int/2addr v8, v13

    .line 523
    int-to-long v10, v8

    .line 524
    sget-object v8, Lk71;->c:Lh71;

    .line 525
    .line 526
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 527
    .line 528
    .line 529
    move-result-object v8

    .line 530
    check-cast v8, Ljava/util/List;

    .line 531
    .line 532
    invoke-static {v9, v8, v2, v12}, Lis0;->B(ILjava/util/List;Ldb0;Z)V

    .line 533
    .line 534
    .line 535
    goto/16 :goto_547

    .line 536
    .line 537
    :pswitch_218
    aget v9, v4, v7

    .line 538
    .line 539
    and-int/2addr v8, v13

    .line 540
    int-to-long v10, v8

    .line 541
    sget-object v8, Lk71;->c:Lh71;

    .line 542
    .line 543
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 544
    .line 545
    .line 546
    move-result-object v8

    .line 547
    check-cast v8, Ljava/util/List;

    .line 548
    .line 549
    invoke-static {v9, v8, v2, v12}, Lis0;->O(ILjava/util/List;Ldb0;Z)V

    .line 550
    .line 551
    .line 552
    goto/16 :goto_547

    .line 553
    .line 554
    :pswitch_229
    aget v9, v4, v7

    .line 555
    .line 556
    and-int/2addr v8, v13

    .line 557
    int-to-long v10, v8

    .line 558
    sget-object v8, Lk71;->c:Lh71;

    .line 559
    .line 560
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 561
    .line 562
    .line 563
    move-result-object v8

    .line 564
    check-cast v8, Ljava/util/List;

    .line 565
    .line 566
    invoke-static {v9, v8, v2, v12}, Lis0;->y(ILjava/util/List;Ldb0;Z)V

    .line 567
    .line 568
    .line 569
    goto/16 :goto_547

    .line 570
    .line 571
    :pswitch_23a
    aget v9, v4, v7

    .line 572
    .line 573
    and-int/2addr v8, v13

    .line 574
    int-to-long v10, v8

    .line 575
    sget-object v8, Lk71;->c:Lh71;

    .line 576
    .line 577
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 578
    .line 579
    .line 580
    move-result-object v8

    .line 581
    check-cast v8, Ljava/util/List;

    .line 582
    .line 583
    invoke-static {v9, v8, v2, v12}, Lis0;->C(ILjava/util/List;Ldb0;Z)V

    .line 584
    .line 585
    .line 586
    goto/16 :goto_547

    .line 587
    .line 588
    :pswitch_24b
    aget v9, v4, v7

    .line 589
    .line 590
    and-int/2addr v8, v13

    .line 591
    int-to-long v10, v8

    .line 592
    sget-object v8, Lk71;->c:Lh71;

    .line 593
    .line 594
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 595
    .line 596
    .line 597
    move-result-object v8

    .line 598
    check-cast v8, Ljava/util/List;

    .line 599
    .line 600
    invoke-static {v9, v8, v2, v12}, Lis0;->D(ILjava/util/List;Ldb0;Z)V

    .line 601
    .line 602
    .line 603
    goto/16 :goto_547

    .line 604
    .line 605
    :pswitch_25c
    aget v9, v4, v7

    .line 606
    .line 607
    and-int/2addr v8, v13

    .line 608
    int-to-long v10, v8

    .line 609
    sget-object v8, Lk71;->c:Lh71;

    .line 610
    .line 611
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 612
    .line 613
    .line 614
    move-result-object v8

    .line 615
    check-cast v8, Ljava/util/List;

    .line 616
    .line 617
    invoke-static {v9, v8, v2, v12}, Lis0;->G(ILjava/util/List;Ldb0;Z)V

    .line 618
    .line 619
    .line 620
    goto/16 :goto_547

    .line 621
    .line 622
    :pswitch_26d
    aget v9, v4, v7

    .line 623
    .line 624
    and-int/2addr v8, v13

    .line 625
    int-to-long v10, v8

    .line 626
    sget-object v8, Lk71;->c:Lh71;

    .line 627
    .line 628
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 629
    .line 630
    .line 631
    move-result-object v8

    .line 632
    check-cast v8, Ljava/util/List;

    .line 633
    .line 634
    invoke-static {v9, v8, v2, v12}, Lis0;->P(ILjava/util/List;Ldb0;Z)V

    .line 635
    .line 636
    .line 637
    goto/16 :goto_547

    .line 638
    .line 639
    :pswitch_27e
    aget v9, v4, v7

    .line 640
    .line 641
    and-int/2addr v8, v13

    .line 642
    int-to-long v10, v8

    .line 643
    sget-object v8, Lk71;->c:Lh71;

    .line 644
    .line 645
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 646
    .line 647
    .line 648
    move-result-object v8

    .line 649
    check-cast v8, Ljava/util/List;

    .line 650
    .line 651
    invoke-static {v9, v8, v2, v12}, Lis0;->H(ILjava/util/List;Ldb0;Z)V

    .line 652
    .line 653
    .line 654
    goto/16 :goto_547

    .line 655
    .line 656
    :pswitch_28f
    aget v9, v4, v7

    .line 657
    .line 658
    and-int/2addr v8, v13

    .line 659
    int-to-long v10, v8

    .line 660
    sget-object v8, Lk71;->c:Lh71;

    .line 661
    .line 662
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 663
    .line 664
    .line 665
    move-result-object v8

    .line 666
    check-cast v8, Ljava/util/List;

    .line 667
    .line 668
    invoke-static {v9, v8, v2, v12}, Lis0;->E(ILjava/util/List;Ldb0;Z)V

    .line 669
    .line 670
    .line 671
    goto/16 :goto_547

    .line 672
    .line 673
    :pswitch_2a0
    aget v9, v4, v7

    .line 674
    .line 675
    and-int/2addr v8, v13

    .line 676
    int-to-long v10, v8

    .line 677
    sget-object v8, Lk71;->c:Lh71;

    .line 678
    .line 679
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 680
    .line 681
    .line 682
    move-result-object v8

    .line 683
    check-cast v8, Ljava/util/List;

    .line 684
    .line 685
    invoke-static {v9, v8, v2, v12}, Lis0;->A(ILjava/util/List;Ldb0;Z)V

    .line 686
    .line 687
    .line 688
    goto/16 :goto_547

    .line 689
    .line 690
    :pswitch_2b1
    aget v9, v4, v7

    .line 691
    .line 692
    and-int/2addr v8, v13

    .line 693
    int-to-long v10, v8

    .line 694
    sget-object v8, Lk71;->c:Lh71;

    .line 695
    .line 696
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 697
    .line 698
    .line 699
    move-result-object v8

    .line 700
    check-cast v8, Ljava/util/List;

    .line 701
    .line 702
    invoke-static {v9, v8, v2, v6}, Lis0;->M(ILjava/util/List;Ldb0;Z)V

    .line 703
    .line 704
    .line 705
    goto/16 :goto_547

    .line 706
    .line 707
    :pswitch_2c2
    aget v9, v4, v7

    .line 708
    .line 709
    and-int/2addr v8, v13

    .line 710
    int-to-long v10, v8

    .line 711
    sget-object v8, Lk71;->c:Lh71;

    .line 712
    .line 713
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 714
    .line 715
    .line 716
    move-result-object v8

    .line 717
    check-cast v8, Ljava/util/List;

    .line 718
    .line 719
    invoke-static {v9, v8, v2, v6}, Lis0;->L(ILjava/util/List;Ldb0;Z)V

    .line 720
    .line 721
    .line 722
    goto/16 :goto_547

    .line 723
    .line 724
    :pswitch_2d3
    aget v9, v4, v7

    .line 725
    .line 726
    and-int/2addr v8, v13

    .line 727
    int-to-long v10, v8

    .line 728
    sget-object v8, Lk71;->c:Lh71;

    .line 729
    .line 730
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 731
    .line 732
    .line 733
    move-result-object v8

    .line 734
    check-cast v8, Ljava/util/List;

    .line 735
    .line 736
    invoke-static {v9, v8, v2, v6}, Lis0;->K(ILjava/util/List;Ldb0;Z)V

    .line 737
    .line 738
    .line 739
    goto/16 :goto_547

    .line 740
    .line 741
    :pswitch_2e4
    aget v9, v4, v7

    .line 742
    .line 743
    and-int/2addr v8, v13

    .line 744
    int-to-long v10, v8

    .line 745
    sget-object v8, Lk71;->c:Lh71;

    .line 746
    .line 747
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 748
    .line 749
    .line 750
    move-result-object v8

    .line 751
    check-cast v8, Ljava/util/List;

    .line 752
    .line 753
    invoke-static {v9, v8, v2, v6}, Lis0;->J(ILjava/util/List;Ldb0;Z)V

    .line 754
    .line 755
    .line 756
    goto/16 :goto_547

    .line 757
    .line 758
    :pswitch_2f5
    aget v9, v4, v7

    .line 759
    .line 760
    and-int/2addr v8, v13

    .line 761
    int-to-long v10, v8

    .line 762
    sget-object v8, Lk71;->c:Lh71;

    .line 763
    .line 764
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 765
    .line 766
    .line 767
    move-result-object v8

    .line 768
    check-cast v8, Ljava/util/List;

    .line 769
    .line 770
    invoke-static {v9, v8, v2, v6}, Lis0;->B(ILjava/util/List;Ldb0;Z)V

    .line 771
    .line 772
    .line 773
    goto/16 :goto_547

    .line 774
    .line 775
    :pswitch_306
    aget v9, v4, v7

    .line 776
    .line 777
    and-int/2addr v8, v13

    .line 778
    int-to-long v10, v8

    .line 779
    sget-object v8, Lk71;->c:Lh71;

    .line 780
    .line 781
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 782
    .line 783
    .line 784
    move-result-object v8

    .line 785
    check-cast v8, Ljava/util/List;

    .line 786
    .line 787
    invoke-static {v9, v8, v2, v6}, Lis0;->O(ILjava/util/List;Ldb0;Z)V

    .line 788
    .line 789
    .line 790
    goto/16 :goto_547

    .line 791
    .line 792
    :pswitch_317
    aget v9, v4, v7

    .line 793
    .line 794
    and-int/2addr v8, v13

    .line 795
    int-to-long v10, v8

    .line 796
    sget-object v8, Lk71;->c:Lh71;

    .line 797
    .line 798
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 799
    .line 800
    .line 801
    move-result-object v8

    .line 802
    check-cast v8, Ljava/util/List;

    .line 803
    .line 804
    invoke-static {v9, v8, v2}, Lis0;->z(ILjava/util/List;Ldb0;)V

    .line 805
    .line 806
    .line 807
    goto/16 :goto_547

    .line 808
    .line 809
    :pswitch_328
    aget v9, v4, v7

    .line 810
    .line 811
    and-int/2addr v8, v13

    .line 812
    int-to-long v10, v8

    .line 813
    sget-object v8, Lk71;->c:Lh71;

    .line 814
    .line 815
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 816
    .line 817
    .line 818
    move-result-object v8

    .line 819
    check-cast v8, Ljava/util/List;

    .line 820
    .line 821
    invoke-virtual {v0, v7}, Lde0;->q(I)Les0;

    .line 822
    .line 823
    .line 824
    move-result-object v10

    .line 825
    invoke-static {v9, v8, v2, v10}, Lis0;->I(ILjava/util/List;Ldb0;Les0;)V

    .line 826
    .line 827
    .line 828
    goto/16 :goto_547

    .line 829
    .line 830
    :pswitch_33d
    aget v9, v4, v7

    .line 831
    .line 832
    and-int/2addr v8, v13

    .line 833
    int-to-long v10, v8

    .line 834
    sget-object v8, Lk71;->c:Lh71;

    .line 835
    .line 836
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 837
    .line 838
    .line 839
    move-result-object v8

    .line 840
    check-cast v8, Ljava/util/List;

    .line 841
    .line 842
    invoke-static {v9, v8, v2}, Lis0;->N(ILjava/util/List;Ldb0;)V

    .line 843
    .line 844
    .line 845
    goto/16 :goto_547

    .line 846
    .line 847
    :pswitch_34e
    aget v9, v4, v7

    .line 848
    .line 849
    and-int/2addr v8, v13

    .line 850
    int-to-long v10, v8

    .line 851
    sget-object v8, Lk71;->c:Lh71;

    .line 852
    .line 853
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 854
    .line 855
    .line 856
    move-result-object v8

    .line 857
    check-cast v8, Ljava/util/List;

    .line 858
    .line 859
    invoke-static {v9, v8, v2, v6}, Lis0;->y(ILjava/util/List;Ldb0;Z)V

    .line 860
    .line 861
    .line 862
    goto/16 :goto_547

    .line 863
    .line 864
    :pswitch_35f
    aget v9, v4, v7

    .line 865
    .line 866
    and-int/2addr v8, v13

    .line 867
    int-to-long v10, v8

    .line 868
    sget-object v8, Lk71;->c:Lh71;

    .line 869
    .line 870
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 871
    .line 872
    .line 873
    move-result-object v8

    .line 874
    check-cast v8, Ljava/util/List;

    .line 875
    .line 876
    invoke-static {v9, v8, v2, v6}, Lis0;->C(ILjava/util/List;Ldb0;Z)V

    .line 877
    .line 878
    .line 879
    goto/16 :goto_547

    .line 880
    .line 881
    :pswitch_370
    aget v9, v4, v7

    .line 882
    .line 883
    and-int/2addr v8, v13

    .line 884
    int-to-long v10, v8

    .line 885
    sget-object v8, Lk71;->c:Lh71;

    .line 886
    .line 887
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 888
    .line 889
    .line 890
    move-result-object v8

    .line 891
    check-cast v8, Ljava/util/List;

    .line 892
    .line 893
    invoke-static {v9, v8, v2, v6}, Lis0;->D(ILjava/util/List;Ldb0;Z)V

    .line 894
    .line 895
    .line 896
    goto/16 :goto_547

    .line 897
    .line 898
    :pswitch_381
    aget v9, v4, v7

    .line 899
    .line 900
    and-int/2addr v8, v13

    .line 901
    int-to-long v10, v8

    .line 902
    sget-object v8, Lk71;->c:Lh71;

    .line 903
    .line 904
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 905
    .line 906
    .line 907
    move-result-object v8

    .line 908
    check-cast v8, Ljava/util/List;

    .line 909
    .line 910
    invoke-static {v9, v8, v2, v6}, Lis0;->G(ILjava/util/List;Ldb0;Z)V

    .line 911
    .line 912
    .line 913
    goto/16 :goto_547

    .line 914
    .line 915
    :pswitch_392
    aget v9, v4, v7

    .line 916
    .line 917
    and-int/2addr v8, v13

    .line 918
    int-to-long v10, v8

    .line 919
    sget-object v8, Lk71;->c:Lh71;

    .line 920
    .line 921
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 922
    .line 923
    .line 924
    move-result-object v8

    .line 925
    check-cast v8, Ljava/util/List;

    .line 926
    .line 927
    invoke-static {v9, v8, v2, v6}, Lis0;->P(ILjava/util/List;Ldb0;Z)V

    .line 928
    .line 929
    .line 930
    goto/16 :goto_547

    .line 931
    .line 932
    :pswitch_3a3
    aget v9, v4, v7

    .line 933
    .line 934
    and-int/2addr v8, v13

    .line 935
    int-to-long v10, v8

    .line 936
    sget-object v8, Lk71;->c:Lh71;

    .line 937
    .line 938
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 939
    .line 940
    .line 941
    move-result-object v8

    .line 942
    check-cast v8, Ljava/util/List;

    .line 943
    .line 944
    invoke-static {v9, v8, v2, v6}, Lis0;->H(ILjava/util/List;Ldb0;Z)V

    .line 945
    .line 946
    .line 947
    goto/16 :goto_547

    .line 948
    .line 949
    :pswitch_3b4
    aget v9, v4, v7

    .line 950
    .line 951
    and-int/2addr v8, v13

    .line 952
    int-to-long v10, v8

    .line 953
    sget-object v8, Lk71;->c:Lh71;

    .line 954
    .line 955
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 956
    .line 957
    .line 958
    move-result-object v8

    .line 959
    check-cast v8, Ljava/util/List;

    .line 960
    .line 961
    invoke-static {v9, v8, v2, v6}, Lis0;->E(ILjava/util/List;Ldb0;Z)V

    .line 962
    .line 963
    .line 964
    goto/16 :goto_547

    .line 965
    .line 966
    :pswitch_3c5
    aget v9, v4, v7

    .line 967
    .line 968
    and-int/2addr v8, v13

    .line 969
    int-to-long v10, v8

    .line 970
    sget-object v8, Lk71;->c:Lh71;

    .line 971
    .line 972
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 973
    .line 974
    .line 975
    move-result-object v8

    .line 976
    check-cast v8, Ljava/util/List;

    .line 977
    .line 978
    invoke-static {v9, v8, v2, v6}, Lis0;->A(ILjava/util/List;Ldb0;Z)V

    .line 979
    .line 980
    .line 981
    goto/16 :goto_547

    .line 982
    .line 983
    :pswitch_3d6
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 984
    .line 985
    .line 986
    move-result v10

    .line 987
    if-eqz v10, :cond_547

    .line 988
    .line 989
    and-int/2addr v8, v13

    .line 990
    int-to-long v10, v8

    .line 991
    sget-object v8, Lk71;->c:Lh71;

    .line 992
    .line 993
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 994
    .line 995
    .line 996
    move-result-object v8

    .line 997
    invoke-virtual {v0, v7}, Lde0;->q(I)Les0;

    .line 998
    .line 999
    .line 1000
    move-result-object v10

    .line 1001
    invoke-virtual {v2, v9, v8, v10}, Ldb0;->B(ILjava/lang/Object;Les0;)V

    .line 1002
    .line 1003
    .line 1004
    goto/16 :goto_547

    .line 1005
    .line 1006
    :pswitch_3ed
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1007
    .line 1008
    .line 1009
    move-result v10

    .line 1010
    if-eqz v10, :cond_547

    .line 1011
    .line 1012
    and-int/2addr v8, v13

    .line 1013
    int-to-long v13, v8

    .line 1014
    sget-object v8, Lk71;->c:Lh71;

    .line 1015
    .line 1016
    invoke-virtual {v8, v13, v14, v1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1017
    .line 1018
    .line 1019
    move-result-wide v13

    .line 1020
    shl-long v15, v13, v12

    .line 1021
    .line 1022
    shr-long v10, v13, v11

    .line 1023
    .line 1024
    xor-long/2addr v10, v15

    .line 1025
    invoke-virtual {v3, v9, v10, v11}, Lde;->F(IJ)V

    .line 1026
    .line 1027
    .line 1028
    goto/16 :goto_547

    .line 1029
    .line 1030
    :pswitch_405
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1031
    .line 1032
    .line 1033
    move-result v10

    .line 1034
    if-eqz v10, :cond_547

    .line 1035
    .line 1036
    and-int/2addr v8, v13

    .line 1037
    int-to-long v10, v8

    .line 1038
    sget-object v8, Lk71;->c:Lh71;

    .line 1039
    .line 1040
    invoke-virtual {v8, v10, v11, v1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1041
    .line 1042
    .line 1043
    move-result v8

    .line 1044
    shl-int/lit8 v10, v8, 0x1

    .line 1045
    .line 1046
    shr-int/lit8 v8, v8, 0x1f

    .line 1047
    .line 1048
    xor-int/2addr v8, v10

    .line 1049
    invoke-virtual {v3, v9, v8}, Lde;->D(II)V

    .line 1050
    .line 1051
    .line 1052
    goto/16 :goto_547

    .line 1053
    .line 1054
    :pswitch_41d
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1055
    .line 1056
    .line 1057
    move-result v10

    .line 1058
    if-eqz v10, :cond_547

    .line 1059
    .line 1060
    and-int/2addr v8, v13

    .line 1061
    int-to-long v10, v8

    .line 1062
    sget-object v8, Lk71;->c:Lh71;

    .line 1063
    .line 1064
    invoke-virtual {v8, v10, v11, v1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1065
    .line 1066
    .line 1067
    move-result-wide v10

    .line 1068
    invoke-virtual {v3, v9, v10, v11}, Lde;->t(IJ)V

    .line 1069
    .line 1070
    .line 1071
    goto/16 :goto_547

    .line 1072
    .line 1073
    :pswitch_430
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1074
    .line 1075
    .line 1076
    move-result v10

    .line 1077
    if-eqz v10, :cond_547

    .line 1078
    .line 1079
    and-int/2addr v8, v13

    .line 1080
    int-to-long v10, v8

    .line 1081
    sget-object v8, Lk71;->c:Lh71;

    .line 1082
    .line 1083
    invoke-virtual {v8, v10, v11, v1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1084
    .line 1085
    .line 1086
    move-result v8

    .line 1087
    invoke-virtual {v3, v9, v8}, Lde;->r(II)V

    .line 1088
    .line 1089
    .line 1090
    goto/16 :goto_547

    .line 1091
    .line 1092
    :pswitch_443
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1093
    .line 1094
    .line 1095
    move-result v10

    .line 1096
    if-eqz v10, :cond_547

    .line 1097
    .line 1098
    and-int/2addr v8, v13

    .line 1099
    int-to-long v10, v8

    .line 1100
    sget-object v8, Lk71;->c:Lh71;

    .line 1101
    .line 1102
    invoke-virtual {v8, v10, v11, v1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1103
    .line 1104
    .line 1105
    move-result v8

    .line 1106
    invoke-virtual {v3, v9, v8}, Lde;->v(II)V

    .line 1107
    .line 1108
    .line 1109
    goto/16 :goto_547

    .line 1110
    .line 1111
    :pswitch_456
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1112
    .line 1113
    .line 1114
    move-result v10

    .line 1115
    if-eqz v10, :cond_547

    .line 1116
    .line 1117
    and-int/2addr v8, v13

    .line 1118
    int-to-long v10, v8

    .line 1119
    sget-object v8, Lk71;->c:Lh71;

    .line 1120
    .line 1121
    invoke-virtual {v8, v10, v11, v1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1122
    .line 1123
    .line 1124
    move-result v8

    .line 1125
    invoke-virtual {v3, v9, v8}, Lde;->D(II)V

    .line 1126
    .line 1127
    .line 1128
    goto/16 :goto_547

    .line 1129
    .line 1130
    :pswitch_469
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1131
    .line 1132
    .line 1133
    move-result v10

    .line 1134
    if-eqz v10, :cond_547

    .line 1135
    .line 1136
    and-int/2addr v8, v13

    .line 1137
    int-to-long v10, v8

    .line 1138
    sget-object v8, Lk71;->c:Lh71;

    .line 1139
    .line 1140
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 1141
    .line 1142
    .line 1143
    move-result-object v8

    .line 1144
    check-cast v8, Lqb;

    .line 1145
    .line 1146
    invoke-virtual {v2, v9, v8}, Ldb0;->x(ILqb;)V

    .line 1147
    .line 1148
    .line 1149
    goto/16 :goto_547

    .line 1150
    .line 1151
    :pswitch_47e
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1152
    .line 1153
    .line 1154
    move-result v10

    .line 1155
    if-eqz v10, :cond_547

    .line 1156
    .line 1157
    and-int/2addr v8, v13

    .line 1158
    int-to-long v10, v8

    .line 1159
    sget-object v8, Lk71;->c:Lh71;

    .line 1160
    .line 1161
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 1162
    .line 1163
    .line 1164
    move-result-object v8

    .line 1165
    invoke-virtual {v0, v7}, Lde0;->q(I)Les0;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v10

    .line 1169
    invoke-virtual {v2, v9, v8, v10}, Ldb0;->G(ILjava/lang/Object;Les0;)V

    .line 1170
    .line 1171
    .line 1172
    goto/16 :goto_547

    .line 1173
    .line 1174
    :pswitch_495
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1175
    .line 1176
    .line 1177
    move-result v10

    .line 1178
    if-eqz v10, :cond_547

    .line 1179
    .line 1180
    and-int/2addr v8, v13

    .line 1181
    int-to-long v10, v8

    .line 1182
    sget-object v8, Lk71;->c:Lh71;

    .line 1183
    .line 1184
    invoke-virtual {v8, v10, v11, v1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 1185
    .line 1186
    .line 1187
    move-result-object v8

    .line 1188
    invoke-static {v9, v8, v2}, Lde0;->Z(ILjava/lang/Object;Ldb0;)V

    .line 1189
    .line 1190
    .line 1191
    goto/16 :goto_547

    .line 1192
    .line 1193
    :pswitch_4a8
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1194
    .line 1195
    .line 1196
    move-result v10

    .line 1197
    if-eqz v10, :cond_547

    .line 1198
    .line 1199
    and-int/2addr v8, v13

    .line 1200
    int-to-long v10, v8

    .line 1201
    sget-object v8, Lk71;->c:Lh71;

    .line 1202
    .line 1203
    invoke-virtual {v8, v10, v11, v1}, Lh71;->d(JLjava/lang/Object;)Z

    .line 1204
    .line 1205
    .line 1206
    move-result v8

    .line 1207
    invoke-virtual {v3, v9, v8}, Lde;->n(IZ)V

    .line 1208
    .line 1209
    .line 1210
    goto/16 :goto_547

    .line 1211
    .line 1212
    :pswitch_4bb
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1213
    .line 1214
    .line 1215
    move-result v10

    .line 1216
    if-eqz v10, :cond_547

    .line 1217
    .line 1218
    and-int/2addr v8, v13

    .line 1219
    int-to-long v10, v8

    .line 1220
    sget-object v8, Lk71;->c:Lh71;

    .line 1221
    .line 1222
    invoke-virtual {v8, v10, v11, v1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1223
    .line 1224
    .line 1225
    move-result v8

    .line 1226
    invoke-virtual {v2, v9, v8}, Ldb0;->y(II)V

    .line 1227
    .line 1228
    .line 1229
    goto/16 :goto_547

    .line 1230
    .line 1231
    :pswitch_4ce
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1232
    .line 1233
    .line 1234
    move-result v10

    .line 1235
    if-eqz v10, :cond_547

    .line 1236
    .line 1237
    and-int/2addr v8, v13

    .line 1238
    int-to-long v10, v8

    .line 1239
    sget-object v8, Lk71;->c:Lh71;

    .line 1240
    .line 1241
    invoke-virtual {v8, v10, v11, v1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1242
    .line 1243
    .line 1244
    move-result-wide v10

    .line 1245
    invoke-virtual {v2, v9, v10, v11}, Ldb0;->z(IJ)V

    .line 1246
    .line 1247
    .line 1248
    goto :goto_547

    .line 1249
    :pswitch_4e0
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1250
    .line 1251
    .line 1252
    move-result v10

    .line 1253
    if-eqz v10, :cond_547

    .line 1254
    .line 1255
    and-int/2addr v8, v13

    .line 1256
    int-to-long v10, v8

    .line 1257
    sget-object v8, Lk71;->c:Lh71;

    .line 1258
    .line 1259
    invoke-virtual {v8, v10, v11, v1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1260
    .line 1261
    .line 1262
    move-result v8

    .line 1263
    invoke-virtual {v2, v9, v8}, Ldb0;->D(II)V

    .line 1264
    .line 1265
    .line 1266
    goto :goto_547

    .line 1267
    :pswitch_4f2
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1268
    .line 1269
    .line 1270
    move-result v10

    .line 1271
    if-eqz v10, :cond_547

    .line 1272
    .line 1273
    and-int/2addr v8, v13

    .line 1274
    int-to-long v10, v8

    .line 1275
    sget-object v8, Lk71;->c:Lh71;

    .line 1276
    .line 1277
    invoke-virtual {v8, v10, v11, v1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1278
    .line 1279
    .line 1280
    move-result-wide v10

    .line 1281
    invoke-virtual {v3, v9, v10, v11}, Lde;->F(IJ)V

    .line 1282
    .line 1283
    .line 1284
    goto :goto_547

    .line 1285
    :pswitch_504
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1286
    .line 1287
    .line 1288
    move-result v10

    .line 1289
    if-eqz v10, :cond_547

    .line 1290
    .line 1291
    and-int/2addr v8, v13

    .line 1292
    int-to-long v10, v8

    .line 1293
    sget-object v8, Lk71;->c:Lh71;

    .line 1294
    .line 1295
    invoke-virtual {v8, v10, v11, v1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1296
    .line 1297
    .line 1298
    move-result-wide v10

    .line 1299
    invoke-virtual {v2, v9, v10, v11}, Ldb0;->E(IJ)V

    .line 1300
    .line 1301
    .line 1302
    goto :goto_547

    .line 1303
    :pswitch_516
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1304
    .line 1305
    .line 1306
    move-result v10

    .line 1307
    if-eqz v10, :cond_547

    .line 1308
    .line 1309
    and-int/2addr v8, v13

    .line 1310
    int-to-long v10, v8

    .line 1311
    sget-object v8, Lk71;->c:Lh71;

    .line 1312
    .line 1313
    invoke-virtual {v8, v10, v11, v1}, Lh71;->h(JLjava/lang/Object;)F

    .line 1314
    .line 1315
    .line 1316
    move-result v8

    .line 1317
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1318
    .line 1319
    .line 1320
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 1321
    .line 1322
    .line 1323
    move-result v8

    .line 1324
    invoke-virtual {v3, v9, v8}, Lde;->r(II)V

    .line 1325
    .line 1326
    .line 1327
    goto :goto_547

    .line 1328
    :pswitch_52f
    invoke-virtual {v0, v7, v1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1329
    .line 1330
    .line 1331
    move-result v10

    .line 1332
    if-eqz v10, :cond_547

    .line 1333
    .line 1334
    and-int/2addr v8, v13

    .line 1335
    int-to-long v10, v8

    .line 1336
    sget-object v8, Lk71;->c:Lh71;

    .line 1337
    .line 1338
    invoke-virtual {v8, v10, v11, v1}, Lh71;->g(JLjava/lang/Object;)D

    .line 1339
    .line 1340
    .line 1341
    move-result-wide v10

    .line 1342
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1343
    .line 1344
    .line 1345
    invoke-static {v10, v11}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 1346
    .line 1347
    .line 1348
    move-result-wide v10

    .line 1349
    invoke-virtual {v3, v9, v10, v11}, Lde;->t(IJ)V

    .line 1350
    .line 1351
    .line 1352
    :cond_547
    :goto_547
    add-int/lit8 v7, v7, 0x3

    .line 1353
    .line 1354
    goto/16 :goto_16

    .line 1355
    .line 1356
    :cond_54b
    iget-object v0, v0, Lde0;->m:Lp61;

    .line 1357
    .line 1358
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1359
    .line 1360
    .line 1361
    move-object v0, v1

    .line 1362
    check-cast v0, Lr00;

    .line 1363
    .line 1364
    iget-object v0, v0, Lr00;->unknownFields:Lm61;

    .line 1365
    .line 1366
    invoke-virtual {v0, v2}, Lm61;->g(Ldb0;)V

    .line 1367
    .line 1368
    .line 1369
    return-void

    .line 1370
    :cond_559
    invoke-virtual/range {p0 .. p2}, Lde0;->X(Ljava/lang/Object;Ldb0;)V

    .line 1371
    .line 1372
    .line 1373
    return-void

    .line 1374
    nop

    .line 1375
    :pswitch_data_55e
    .packed-switch 0x0
        :pswitch_52f
        :pswitch_516
        :pswitch_504
        :pswitch_4f2
        :pswitch_4e0
        :pswitch_4ce
        :pswitch_4bb
        :pswitch_4a8
        :pswitch_495
        :pswitch_47e
        :pswitch_469
        :pswitch_456
        :pswitch_443
        :pswitch_430
        :pswitch_41d
        :pswitch_405
        :pswitch_3ed
        :pswitch_3d6
        :pswitch_3c5
        :pswitch_3b4
        :pswitch_3a3
        :pswitch_392
        :pswitch_381
        :pswitch_370
        :pswitch_35f
        :pswitch_34e
        :pswitch_33d
        :pswitch_328
        :pswitch_317
        :pswitch_306
        :pswitch_2f5
        :pswitch_2e4
        :pswitch_2d3
        :pswitch_2c2
        :pswitch_2b1
        :pswitch_2a0
        :pswitch_28f
        :pswitch_27e
        :pswitch_26d
        :pswitch_25c
        :pswitch_24b
        :pswitch_23a
        :pswitch_229
        :pswitch_218
        :pswitch_207
        :pswitch_1f6
        :pswitch_1e5
        :pswitch_1d4
        :pswitch_1c3
        :pswitch_1ae
        :pswitch_1a1
        :pswitch_181
        :pswitch_161
        :pswitch_150
        :pswitch_13f
        :pswitch_12e
        :pswitch_11d
        :pswitch_10c
        :pswitch_f3
        :pswitch_e0
        :pswitch_c9
        :pswitch_b4
        :pswitch_a3
        :pswitch_92
        :pswitch_81
        :pswitch_70
        :pswitch_5a
        :pswitch_44
        :pswitch_2d
    .end packed-switch
.end method

.method public final i(Lr00;Lr00;)Z
    .registers 14

    .line 1
    iget-object v0, p0, Lde0;->a:[I

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    const/4 v2, 0x0

    .line 5
    move v3, v2

    .line 6
    :goto_5
    const/4 v4, 0x1

    .line 7
    if-ge v3, v1, :cond_1f5

    .line 8
    .line 9
    invoke-virtual {p0, v3}, Lde0;->W(I)I

    .line 10
    .line 11
    .line 12
    move-result v5

    .line 13
    const v6, 0xfffff

    .line 14
    .line 15
    .line 16
    and-int v7, v5, v6

    .line 17
    .line 18
    int-to-long v7, v7

    .line 19
    invoke-static {v5}, Lde0;->V(I)I

    .line 20
    .line 21
    .line 22
    move-result v5

    .line 23
    packed-switch v5, :pswitch_data_206

    .line 24
    .line 25
    .line 26
    goto/16 :goto_1ee

    .line 27
    .line 28
    :pswitch_1b
    add-int/lit8 v5, v3, 0x2

    .line 29
    .line 30
    aget v5, v0, v5

    .line 31
    .line 32
    and-int/2addr v5, v6

    .line 33
    int-to-long v5, v5

    .line 34
    sget-object v9, Lk71;->c:Lh71;

    .line 35
    .line 36
    invoke-virtual {v9, v5, v6, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 37
    .line 38
    .line 39
    move-result v10

    .line 40
    invoke-virtual {v9, v5, v6, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 41
    .line 42
    .line 43
    move-result v5

    .line 44
    if-ne v10, v5, :cond_3d

    .line 45
    .line 46
    invoke-virtual {v9, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    move-result-object v5

    .line 50
    invoke-virtual {v9, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v6

    .line 54
    invoke-static {v5, v6}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 55
    .line 56
    .line 57
    move-result v5

    .line 58
    if-eqz v5, :cond_3d

    .line 59
    .line 60
    goto/16 :goto_1ee

    .line 61
    .line 62
    :cond_3d
    move v4, v2

    .line 63
    goto/16 :goto_1ee

    .line 64
    .line 65
    :pswitch_40
    sget-object v4, Lk71;->c:Lh71;

    .line 66
    .line 67
    invoke-virtual {v4, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    invoke-virtual {v4, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    move-result-object v4

    .line 75
    invoke-static {v5, v4}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 76
    .line 77
    .line 78
    move-result v4

    .line 79
    goto/16 :goto_1ee

    .line 80
    .line 81
    :pswitch_50
    sget-object v4, Lk71;->c:Lh71;

    .line 82
    .line 83
    invoke-virtual {v4, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v5

    .line 87
    invoke-virtual {v4, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object v4

    .line 91
    invoke-static {v5, v4}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 92
    .line 93
    .line 94
    move-result v4

    .line 95
    goto/16 :goto_1ee

    .line 96
    .line 97
    :pswitch_60
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 98
    .line 99
    .line 100
    move-result v5

    .line 101
    if-eqz v5, :cond_3d

    .line 102
    .line 103
    sget-object v5, Lk71;->c:Lh71;

    .line 104
    .line 105
    invoke-virtual {v5, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 106
    .line 107
    .line 108
    move-result-object v6

    .line 109
    invoke-virtual {v5, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 110
    .line 111
    .line 112
    move-result-object v5

    .line 113
    invoke-static {v6, v5}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move-result v5

    .line 117
    if-eqz v5, :cond_3d

    .line 118
    .line 119
    goto/16 :goto_1ee

    .line 120
    .line 121
    :pswitch_78
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 122
    .line 123
    .line 124
    move-result v5

    .line 125
    if-eqz v5, :cond_3d

    .line 126
    .line 127
    sget-object v5, Lk71;->c:Lh71;

    .line 128
    .line 129
    invoke-virtual {v5, v7, v8, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 130
    .line 131
    .line 132
    move-result-wide v9

    .line 133
    invoke-virtual {v5, v7, v8, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 134
    .line 135
    .line 136
    move-result-wide v5

    .line 137
    cmp-long v5, v9, v5

    .line 138
    .line 139
    if-nez v5, :cond_3d

    .line 140
    .line 141
    goto/16 :goto_1ee

    .line 142
    .line 143
    :pswitch_8e
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 144
    .line 145
    .line 146
    move-result v5

    .line 147
    if-eqz v5, :cond_3d

    .line 148
    .line 149
    sget-object v5, Lk71;->c:Lh71;

    .line 150
    .line 151
    invoke-virtual {v5, v7, v8, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 152
    .line 153
    .line 154
    move-result v6

    .line 155
    invoke-virtual {v5, v7, v8, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 156
    .line 157
    .line 158
    move-result v5

    .line 159
    if-ne v6, v5, :cond_3d

    .line 160
    .line 161
    goto/16 :goto_1ee

    .line 162
    .line 163
    :pswitch_a2
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 164
    .line 165
    .line 166
    move-result v5

    .line 167
    if-eqz v5, :cond_3d

    .line 168
    .line 169
    sget-object v5, Lk71;->c:Lh71;

    .line 170
    .line 171
    invoke-virtual {v5, v7, v8, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 172
    .line 173
    .line 174
    move-result-wide v9

    .line 175
    invoke-virtual {v5, v7, v8, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 176
    .line 177
    .line 178
    move-result-wide v5

    .line 179
    cmp-long v5, v9, v5

    .line 180
    .line 181
    if-nez v5, :cond_3d

    .line 182
    .line 183
    goto/16 :goto_1ee

    .line 184
    .line 185
    :pswitch_b8
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 186
    .line 187
    .line 188
    move-result v5

    .line 189
    if-eqz v5, :cond_3d

    .line 190
    .line 191
    sget-object v5, Lk71;->c:Lh71;

    .line 192
    .line 193
    invoke-virtual {v5, v7, v8, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 194
    .line 195
    .line 196
    move-result v6

    .line 197
    invoke-virtual {v5, v7, v8, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 198
    .line 199
    .line 200
    move-result v5

    .line 201
    if-ne v6, v5, :cond_3d

    .line 202
    .line 203
    goto/16 :goto_1ee

    .line 204
    .line 205
    :pswitch_cc
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 206
    .line 207
    .line 208
    move-result v5

    .line 209
    if-eqz v5, :cond_3d

    .line 210
    .line 211
    sget-object v5, Lk71;->c:Lh71;

    .line 212
    .line 213
    invoke-virtual {v5, v7, v8, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 214
    .line 215
    .line 216
    move-result v6

    .line 217
    invoke-virtual {v5, v7, v8, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 218
    .line 219
    .line 220
    move-result v5

    .line 221
    if-ne v6, v5, :cond_3d

    .line 222
    .line 223
    goto/16 :goto_1ee

    .line 224
    .line 225
    :pswitch_e0
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 226
    .line 227
    .line 228
    move-result v5

    .line 229
    if-eqz v5, :cond_3d

    .line 230
    .line 231
    sget-object v5, Lk71;->c:Lh71;

    .line 232
    .line 233
    invoke-virtual {v5, v7, v8, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 234
    .line 235
    .line 236
    move-result v6

    .line 237
    invoke-virtual {v5, v7, v8, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 238
    .line 239
    .line 240
    move-result v5

    .line 241
    if-ne v6, v5, :cond_3d

    .line 242
    .line 243
    goto/16 :goto_1ee

    .line 244
    .line 245
    :pswitch_f4
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 246
    .line 247
    .line 248
    move-result v5

    .line 249
    if-eqz v5, :cond_3d

    .line 250
    .line 251
    sget-object v5, Lk71;->c:Lh71;

    .line 252
    .line 253
    invoke-virtual {v5, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v6

    .line 257
    invoke-virtual {v5, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 258
    .line 259
    .line 260
    move-result-object v5

    .line 261
    invoke-static {v6, v5}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 262
    .line 263
    .line 264
    move-result v5

    .line 265
    if-eqz v5, :cond_3d

    .line 266
    .line 267
    goto/16 :goto_1ee

    .line 268
    .line 269
    :pswitch_10c
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 270
    .line 271
    .line 272
    move-result v5

    .line 273
    if-eqz v5, :cond_3d

    .line 274
    .line 275
    sget-object v5, Lk71;->c:Lh71;

    .line 276
    .line 277
    invoke-virtual {v5, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 278
    .line 279
    .line 280
    move-result-object v6

    .line 281
    invoke-virtual {v5, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v5

    .line 285
    invoke-static {v6, v5}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 286
    .line 287
    .line 288
    move-result v5

    .line 289
    if-eqz v5, :cond_3d

    .line 290
    .line 291
    goto/16 :goto_1ee

    .line 292
    .line 293
    :pswitch_124
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 294
    .line 295
    .line 296
    move-result v5

    .line 297
    if-eqz v5, :cond_3d

    .line 298
    .line 299
    sget-object v5, Lk71;->c:Lh71;

    .line 300
    .line 301
    invoke-virtual {v5, v7, v8, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object v6

    .line 305
    invoke-virtual {v5, v7, v8, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 306
    .line 307
    .line 308
    move-result-object v5

    .line 309
    invoke-static {v6, v5}, Lis0;->x(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 310
    .line 311
    .line 312
    move-result v5

    .line 313
    if-eqz v5, :cond_3d

    .line 314
    .line 315
    goto/16 :goto_1ee

    .line 316
    .line 317
    :pswitch_13c
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 318
    .line 319
    .line 320
    move-result v5

    .line 321
    if-eqz v5, :cond_3d

    .line 322
    .line 323
    sget-object v5, Lk71;->c:Lh71;

    .line 324
    .line 325
    invoke-virtual {v5, v7, v8, p1}, Lh71;->d(JLjava/lang/Object;)Z

    .line 326
    .line 327
    .line 328
    move-result v6

    .line 329
    invoke-virtual {v5, v7, v8, p2}, Lh71;->d(JLjava/lang/Object;)Z

    .line 330
    .line 331
    .line 332
    move-result v5

    .line 333
    if-ne v6, v5, :cond_3d

    .line 334
    .line 335
    goto/16 :goto_1ee

    .line 336
    .line 337
    :pswitch_150
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 338
    .line 339
    .line 340
    move-result v5

    .line 341
    if-eqz v5, :cond_3d

    .line 342
    .line 343
    sget-object v5, Lk71;->c:Lh71;

    .line 344
    .line 345
    invoke-virtual {v5, v7, v8, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 346
    .line 347
    .line 348
    move-result v6

    .line 349
    invoke-virtual {v5, v7, v8, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 350
    .line 351
    .line 352
    move-result v5

    .line 353
    if-ne v6, v5, :cond_3d

    .line 354
    .line 355
    goto/16 :goto_1ee

    .line 356
    .line 357
    :pswitch_164
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 358
    .line 359
    .line 360
    move-result v5

    .line 361
    if-eqz v5, :cond_3d

    .line 362
    .line 363
    sget-object v5, Lk71;->c:Lh71;

    .line 364
    .line 365
    invoke-virtual {v5, v7, v8, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 366
    .line 367
    .line 368
    move-result-wide v9

    .line 369
    invoke-virtual {v5, v7, v8, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 370
    .line 371
    .line 372
    move-result-wide v5

    .line 373
    cmp-long v5, v9, v5

    .line 374
    .line 375
    if-nez v5, :cond_3d

    .line 376
    .line 377
    goto/16 :goto_1ee

    .line 378
    .line 379
    :pswitch_17a
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 380
    .line 381
    .line 382
    move-result v5

    .line 383
    if-eqz v5, :cond_3d

    .line 384
    .line 385
    sget-object v5, Lk71;->c:Lh71;

    .line 386
    .line 387
    invoke-virtual {v5, v7, v8, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 388
    .line 389
    .line 390
    move-result v6

    .line 391
    invoke-virtual {v5, v7, v8, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 392
    .line 393
    .line 394
    move-result v5

    .line 395
    if-ne v6, v5, :cond_3d

    .line 396
    .line 397
    goto :goto_1ee

    .line 398
    :pswitch_18d
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 399
    .line 400
    .line 401
    move-result v5

    .line 402
    if-eqz v5, :cond_3d

    .line 403
    .line 404
    sget-object v5, Lk71;->c:Lh71;

    .line 405
    .line 406
    invoke-virtual {v5, v7, v8, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 407
    .line 408
    .line 409
    move-result-wide v9

    .line 410
    invoke-virtual {v5, v7, v8, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 411
    .line 412
    .line 413
    move-result-wide v5

    .line 414
    cmp-long v5, v9, v5

    .line 415
    .line 416
    if-nez v5, :cond_3d

    .line 417
    .line 418
    goto :goto_1ee

    .line 419
    :pswitch_1a2
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 420
    .line 421
    .line 422
    move-result v5

    .line 423
    if-eqz v5, :cond_3d

    .line 424
    .line 425
    sget-object v5, Lk71;->c:Lh71;

    .line 426
    .line 427
    invoke-virtual {v5, v7, v8, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 428
    .line 429
    .line 430
    move-result-wide v9

    .line 431
    invoke-virtual {v5, v7, v8, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 432
    .line 433
    .line 434
    move-result-wide v5

    .line 435
    cmp-long v5, v9, v5

    .line 436
    .line 437
    if-nez v5, :cond_3d

    .line 438
    .line 439
    goto :goto_1ee

    .line 440
    :pswitch_1b7
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 441
    .line 442
    .line 443
    move-result v5

    .line 444
    if-eqz v5, :cond_3d

    .line 445
    .line 446
    sget-object v5, Lk71;->c:Lh71;

    .line 447
    .line 448
    invoke-virtual {v5, v7, v8, p1}, Lh71;->h(JLjava/lang/Object;)F

    .line 449
    .line 450
    .line 451
    move-result v6

    .line 452
    invoke-static {v6}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 453
    .line 454
    .line 455
    move-result v6

    .line 456
    invoke-virtual {v5, v7, v8, p2}, Lh71;->h(JLjava/lang/Object;)F

    .line 457
    .line 458
    .line 459
    move-result v5

    .line 460
    invoke-static {v5}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 461
    .line 462
    .line 463
    move-result v5

    .line 464
    if-ne v6, v5, :cond_3d

    .line 465
    .line 466
    goto :goto_1ee

    .line 467
    :pswitch_1d2
    invoke-virtual {p0, p1, p2, v3}, Lde0;->k(Lr00;Lr00;I)Z

    .line 468
    .line 469
    .line 470
    move-result v5

    .line 471
    if-eqz v5, :cond_3d

    .line 472
    .line 473
    sget-object v5, Lk71;->c:Lh71;

    .line 474
    .line 475
    invoke-virtual {v5, v7, v8, p1}, Lh71;->g(JLjava/lang/Object;)D

    .line 476
    .line 477
    .line 478
    move-result-wide v9

    .line 479
    invoke-static {v9, v10}, Ljava/lang/Double;->doubleToLongBits(D)J

    .line 480
    .line 481
    .line 482
    move-result-wide v9

    .line 483
    invoke-virtual {v5, v7, v8, p2}, Lh71;->g(JLjava/lang/Object;)D

    .line 484
    .line 485
    .line 486
    move-result-wide v5

    .line 487
    invoke-static {v5, v6}, Ljava/lang/Double;->doubleToLongBits(D)J

    .line 488
    .line 489
    .line 490
    move-result-wide v5

    .line 491
    cmp-long v5, v9, v5

    .line 492
    .line 493
    if-nez v5, :cond_3d

    .line 494
    .line 495
    :goto_1ee
    if-nez v4, :cond_1f1

    .line 496
    .line 497
    goto :goto_204

    .line 498
    :cond_1f1
    add-int/lit8 v3, v3, 0x3

    .line 499
    .line 500
    goto/16 :goto_5

    .line 501
    .line 502
    :cond_1f5
    iget-object p0, p0, Lde0;->m:Lp61;

    .line 503
    .line 504
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 505
    .line 506
    .line 507
    iget-object p0, p1, Lr00;->unknownFields:Lm61;

    .line 508
    .line 509
    iget-object p1, p2, Lr00;->unknownFields:Lm61;

    .line 510
    .line 511
    invoke-virtual {p0, p1}, Lm61;->equals(Ljava/lang/Object;)Z

    .line 512
    .line 513
    .line 514
    move-result p0

    .line 515
    if-nez p0, :cond_205

    .line 516
    .line 517
    :goto_204
    return v2

    .line 518
    :cond_205
    return v4

    .line 519
    :pswitch_data_206
    .packed-switch 0x0
        :pswitch_1d2
        :pswitch_1b7
        :pswitch_1a2
        :pswitch_18d
        :pswitch_17a
        :pswitch_164
        :pswitch_150
        :pswitch_13c
        :pswitch_124
        :pswitch_10c
        :pswitch_f4
        :pswitch_e0
        :pswitch_cc
        :pswitch_b8
        :pswitch_a2
        :pswitch_8e
        :pswitch_78
        :pswitch_60
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_50
        :pswitch_40
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
        :pswitch_1b
    .end packed-switch
.end method

.method public final j(Lr00;)I
    .registers 13

    .line 1
    iget-object v0, p0, Lde0;->a:[I

    .line 2
    .line 3
    array-length v1, v0

    .line 4
    const/4 v2, 0x0

    .line 5
    move v3, v2

    .line 6
    :goto_5
    if-ge v2, v1, :cond_27c

    .line 7
    .line 8
    invoke-virtual {p0, v2}, Lde0;->W(I)I

    .line 9
    .line 10
    .line 11
    move-result v4

    .line 12
    aget v5, v0, v2

    .line 13
    .line 14
    const v6, 0xfffff

    .line 15
    .line 16
    .line 17
    and-int/2addr v6, v4

    .line 18
    int-to-long v6, v6

    .line 19
    invoke-static {v4}, Lde0;->V(I)I

    .line 20
    .line 21
    .line 22
    move-result v4

    .line 23
    const/16 v8, 0x4d5

    .line 24
    .line 25
    const/16 v9, 0x4cf

    .line 26
    .line 27
    const/16 v10, 0x25

    .line 28
    .line 29
    packed-switch v4, :pswitch_data_28c

    .line 30
    .line 31
    .line 32
    goto/16 :goto_278

    .line 33
    .line 34
    :pswitch_21
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result v4

    .line 38
    if-eqz v4, :cond_278

    .line 39
    .line 40
    sget-object v4, Lk71;->c:Lh71;

    .line 41
    .line 42
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    mul-int/lit8 v3, v3, 0x35

    .line 47
    .line 48
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 49
    .line 50
    .line 51
    move-result v4

    .line 52
    :goto_33
    add-int/2addr v4, v3

    .line 53
    move v3, v4

    .line 54
    goto/16 :goto_278

    .line 55
    .line 56
    :pswitch_37
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 57
    .line 58
    .line 59
    move-result v4

    .line 60
    if-eqz v4, :cond_278

    .line 61
    .line 62
    mul-int/lit8 v3, v3, 0x35

    .line 63
    .line 64
    invoke-static {v6, v7, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 65
    .line 66
    .line 67
    move-result-wide v4

    .line 68
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 69
    .line 70
    .line 71
    move-result v4

    .line 72
    goto :goto_33

    .line 73
    :pswitch_48
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 74
    .line 75
    .line 76
    move-result v4

    .line 77
    if-eqz v4, :cond_278

    .line 78
    .line 79
    mul-int/lit8 v3, v3, 0x35

    .line 80
    .line 81
    invoke-static {v6, v7, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 82
    .line 83
    .line 84
    move-result v4

    .line 85
    goto :goto_33

    .line 86
    :pswitch_55
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    if-eqz v4, :cond_278

    .line 91
    .line 92
    mul-int/lit8 v3, v3, 0x35

    .line 93
    .line 94
    invoke-static {v6, v7, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 95
    .line 96
    .line 97
    move-result-wide v4

    .line 98
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 99
    .line 100
    .line 101
    move-result v4

    .line 102
    goto :goto_33

    .line 103
    :pswitch_66
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v4

    .line 107
    if-eqz v4, :cond_278

    .line 108
    .line 109
    mul-int/lit8 v3, v3, 0x35

    .line 110
    .line 111
    invoke-static {v6, v7, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 112
    .line 113
    .line 114
    move-result v4

    .line 115
    goto :goto_33

    .line 116
    :pswitch_73
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 117
    .line 118
    .line 119
    move-result v4

    .line 120
    if-eqz v4, :cond_278

    .line 121
    .line 122
    mul-int/lit8 v3, v3, 0x35

    .line 123
    .line 124
    invoke-static {v6, v7, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 125
    .line 126
    .line 127
    move-result v4

    .line 128
    goto :goto_33

    .line 129
    :pswitch_80
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 130
    .line 131
    .line 132
    move-result v4

    .line 133
    if-eqz v4, :cond_278

    .line 134
    .line 135
    mul-int/lit8 v3, v3, 0x35

    .line 136
    .line 137
    invoke-static {v6, v7, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 138
    .line 139
    .line 140
    move-result v4

    .line 141
    goto :goto_33

    .line 142
    :pswitch_8d
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 143
    .line 144
    .line 145
    move-result v4

    .line 146
    if-eqz v4, :cond_278

    .line 147
    .line 148
    mul-int/lit8 v3, v3, 0x35

    .line 149
    .line 150
    sget-object v4, Lk71;->c:Lh71;

    .line 151
    .line 152
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 153
    .line 154
    .line 155
    move-result-object v4

    .line 156
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 157
    .line 158
    .line 159
    move-result v4

    .line 160
    goto :goto_33

    .line 161
    :pswitch_a0
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 162
    .line 163
    .line 164
    move-result v4

    .line 165
    if-eqz v4, :cond_278

    .line 166
    .line 167
    sget-object v4, Lk71;->c:Lh71;

    .line 168
    .line 169
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 170
    .line 171
    .line 172
    move-result-object v4

    .line 173
    mul-int/lit8 v3, v3, 0x35

    .line 174
    .line 175
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 176
    .line 177
    .line 178
    move-result v4

    .line 179
    goto :goto_33

    .line 180
    :pswitch_b3
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 181
    .line 182
    .line 183
    move-result v4

    .line 184
    if-eqz v4, :cond_278

    .line 185
    .line 186
    mul-int/lit8 v3, v3, 0x35

    .line 187
    .line 188
    sget-object v4, Lk71;->c:Lh71;

    .line 189
    .line 190
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v4

    .line 194
    check-cast v4, Ljava/lang/String;

    .line 195
    .line 196
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    .line 197
    .line 198
    .line 199
    move-result v4

    .line 200
    goto/16 :goto_33

    .line 201
    .line 202
    :pswitch_c9
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 203
    .line 204
    .line 205
    move-result v4

    .line 206
    if-eqz v4, :cond_278

    .line 207
    .line 208
    mul-int/lit8 v3, v3, 0x35

    .line 209
    .line 210
    sget-object v4, Lk71;->c:Lh71;

    .line 211
    .line 212
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 213
    .line 214
    .line 215
    move-result-object v4

    .line 216
    check-cast v4, Ljava/lang/Boolean;

    .line 217
    .line 218
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 219
    .line 220
    .line 221
    move-result v4

    .line 222
    sget-object v5, Ll40;->a:Ljava/nio/charset/Charset;

    .line 223
    .line 224
    if-eqz v4, :cond_e2

    .line 225
    .line 226
    :goto_e1
    move v8, v9

    .line 227
    :cond_e2
    add-int/2addr v8, v3

    .line 228
    move v3, v8

    .line 229
    goto/16 :goto_278

    .line 230
    .line 231
    :pswitch_e6
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    move-result v4

    .line 235
    if-eqz v4, :cond_278

    .line 236
    .line 237
    mul-int/lit8 v3, v3, 0x35

    .line 238
    .line 239
    invoke-static {v6, v7, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 240
    .line 241
    .line 242
    move-result v4

    .line 243
    goto/16 :goto_33

    .line 244
    .line 245
    :pswitch_f4
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 246
    .line 247
    .line 248
    move-result v4

    .line 249
    if-eqz v4, :cond_278

    .line 250
    .line 251
    mul-int/lit8 v3, v3, 0x35

    .line 252
    .line 253
    invoke-static {v6, v7, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 254
    .line 255
    .line 256
    move-result-wide v4

    .line 257
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 258
    .line 259
    .line 260
    move-result v4

    .line 261
    goto/16 :goto_33

    .line 262
    .line 263
    :pswitch_106
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    move-result v4

    .line 267
    if-eqz v4, :cond_278

    .line 268
    .line 269
    mul-int/lit8 v3, v3, 0x35

    .line 270
    .line 271
    invoke-static {v6, v7, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 272
    .line 273
    .line 274
    move-result v4

    .line 275
    goto/16 :goto_33

    .line 276
    .line 277
    :pswitch_114
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    move-result v4

    .line 281
    if-eqz v4, :cond_278

    .line 282
    .line 283
    mul-int/lit8 v3, v3, 0x35

    .line 284
    .line 285
    invoke-static {v6, v7, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 286
    .line 287
    .line 288
    move-result-wide v4

    .line 289
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 290
    .line 291
    .line 292
    move-result v4

    .line 293
    goto/16 :goto_33

    .line 294
    .line 295
    :pswitch_126
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 296
    .line 297
    .line 298
    move-result v4

    .line 299
    if-eqz v4, :cond_278

    .line 300
    .line 301
    mul-int/lit8 v3, v3, 0x35

    .line 302
    .line 303
    invoke-static {v6, v7, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 304
    .line 305
    .line 306
    move-result-wide v4

    .line 307
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 308
    .line 309
    .line 310
    move-result v4

    .line 311
    goto/16 :goto_33

    .line 312
    .line 313
    :pswitch_138
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 314
    .line 315
    .line 316
    move-result v4

    .line 317
    if-eqz v4, :cond_278

    .line 318
    .line 319
    mul-int/lit8 v3, v3, 0x35

    .line 320
    .line 321
    sget-object v4, Lk71;->c:Lh71;

    .line 322
    .line 323
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object v4

    .line 327
    check-cast v4, Ljava/lang/Float;

    .line 328
    .line 329
    invoke-virtual {v4}, Ljava/lang/Float;->floatValue()F

    .line 330
    .line 331
    .line 332
    move-result v4

    .line 333
    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 334
    .line 335
    .line 336
    move-result v4

    .line 337
    goto/16 :goto_33

    .line 338
    .line 339
    :pswitch_152
    invoke-virtual {p0, v5, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 340
    .line 341
    .line 342
    move-result v4

    .line 343
    if-eqz v4, :cond_278

    .line 344
    .line 345
    mul-int/lit8 v3, v3, 0x35

    .line 346
    .line 347
    sget-object v4, Lk71;->c:Lh71;

    .line 348
    .line 349
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 350
    .line 351
    .line 352
    move-result-object v4

    .line 353
    check-cast v4, Ljava/lang/Double;

    .line 354
    .line 355
    invoke-virtual {v4}, Ljava/lang/Double;->doubleValue()D

    .line 356
    .line 357
    .line 358
    move-result-wide v4

    .line 359
    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    .line 360
    .line 361
    .line 362
    move-result-wide v4

    .line 363
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 364
    .line 365
    .line 366
    move-result v4

    .line 367
    goto/16 :goto_33

    .line 368
    .line 369
    :pswitch_170
    mul-int/lit8 v3, v3, 0x35

    .line 370
    .line 371
    sget-object v4, Lk71;->c:Lh71;

    .line 372
    .line 373
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 374
    .line 375
    .line 376
    move-result-object v4

    .line 377
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 378
    .line 379
    .line 380
    move-result v4

    .line 381
    goto/16 :goto_33

    .line 382
    .line 383
    :pswitch_17e
    mul-int/lit8 v3, v3, 0x35

    .line 384
    .line 385
    sget-object v4, Lk71;->c:Lh71;

    .line 386
    .line 387
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v4

    .line 391
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 392
    .line 393
    .line 394
    move-result v4

    .line 395
    goto/16 :goto_33

    .line 396
    .line 397
    :pswitch_18c
    sget-object v4, Lk71;->c:Lh71;

    .line 398
    .line 399
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 400
    .line 401
    .line 402
    move-result-object v4

    .line 403
    if-eqz v4, :cond_198

    .line 404
    .line 405
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 406
    .line 407
    .line 408
    move-result v10

    .line 409
    :cond_198
    :goto_198
    mul-int/lit8 v3, v3, 0x35

    .line 410
    .line 411
    add-int/2addr v3, v10

    .line 412
    goto/16 :goto_278

    .line 413
    .line 414
    :pswitch_19d
    mul-int/lit8 v3, v3, 0x35

    .line 415
    .line 416
    sget-object v4, Lk71;->c:Lh71;

    .line 417
    .line 418
    invoke-virtual {v4, v6, v7, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 419
    .line 420
    .line 421
    move-result-wide v4

    .line 422
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 423
    .line 424
    .line 425
    move-result v4

    .line 426
    goto/16 :goto_33

    .line 427
    .line 428
    :pswitch_1ab
    mul-int/lit8 v3, v3, 0x35

    .line 429
    .line 430
    sget-object v4, Lk71;->c:Lh71;

    .line 431
    .line 432
    invoke-virtual {v4, v6, v7, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 433
    .line 434
    .line 435
    move-result v4

    .line 436
    goto/16 :goto_33

    .line 437
    .line 438
    :pswitch_1b5
    mul-int/lit8 v3, v3, 0x35

    .line 439
    .line 440
    sget-object v4, Lk71;->c:Lh71;

    .line 441
    .line 442
    invoke-virtual {v4, v6, v7, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 443
    .line 444
    .line 445
    move-result-wide v4

    .line 446
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 447
    .line 448
    .line 449
    move-result v4

    .line 450
    goto/16 :goto_33

    .line 451
    .line 452
    :pswitch_1c3
    mul-int/lit8 v3, v3, 0x35

    .line 453
    .line 454
    sget-object v4, Lk71;->c:Lh71;

    .line 455
    .line 456
    invoke-virtual {v4, v6, v7, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 457
    .line 458
    .line 459
    move-result v4

    .line 460
    goto/16 :goto_33

    .line 461
    .line 462
    :pswitch_1cd
    mul-int/lit8 v3, v3, 0x35

    .line 463
    .line 464
    sget-object v4, Lk71;->c:Lh71;

    .line 465
    .line 466
    invoke-virtual {v4, v6, v7, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 467
    .line 468
    .line 469
    move-result v4

    .line 470
    goto/16 :goto_33

    .line 471
    .line 472
    :pswitch_1d7
    mul-int/lit8 v3, v3, 0x35

    .line 473
    .line 474
    sget-object v4, Lk71;->c:Lh71;

    .line 475
    .line 476
    invoke-virtual {v4, v6, v7, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 477
    .line 478
    .line 479
    move-result v4

    .line 480
    goto/16 :goto_33

    .line 481
    .line 482
    :pswitch_1e1
    mul-int/lit8 v3, v3, 0x35

    .line 483
    .line 484
    sget-object v4, Lk71;->c:Lh71;

    .line 485
    .line 486
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 487
    .line 488
    .line 489
    move-result-object v4

    .line 490
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 491
    .line 492
    .line 493
    move-result v4

    .line 494
    goto/16 :goto_33

    .line 495
    .line 496
    :pswitch_1ef
    sget-object v4, Lk71;->c:Lh71;

    .line 497
    .line 498
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 499
    .line 500
    .line 501
    move-result-object v4

    .line 502
    if-eqz v4, :cond_198

    .line 503
    .line 504
    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    .line 505
    .line 506
    .line 507
    move-result v10

    .line 508
    goto :goto_198

    .line 509
    :pswitch_1fc
    mul-int/lit8 v3, v3, 0x35

    .line 510
    .line 511
    sget-object v4, Lk71;->c:Lh71;

    .line 512
    .line 513
    invoke-virtual {v4, v6, v7, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 514
    .line 515
    .line 516
    move-result-object v4

    .line 517
    check-cast v4, Ljava/lang/String;

    .line 518
    .line 519
    invoke-virtual {v4}, Ljava/lang/String;->hashCode()I

    .line 520
    .line 521
    .line 522
    move-result v4

    .line 523
    goto/16 :goto_33

    .line 524
    .line 525
    :pswitch_20c
    mul-int/lit8 v3, v3, 0x35

    .line 526
    .line 527
    sget-object v4, Lk71;->c:Lh71;

    .line 528
    .line 529
    invoke-virtual {v4, v6, v7, p1}, Lh71;->d(JLjava/lang/Object;)Z

    .line 530
    .line 531
    .line 532
    move-result v4

    .line 533
    sget-object v5, Ll40;->a:Ljava/nio/charset/Charset;

    .line 534
    .line 535
    if-eqz v4, :cond_e2

    .line 536
    .line 537
    goto/16 :goto_e1

    .line 538
    .line 539
    :pswitch_21a
    mul-int/lit8 v3, v3, 0x35

    .line 540
    .line 541
    sget-object v4, Lk71;->c:Lh71;

    .line 542
    .line 543
    invoke-virtual {v4, v6, v7, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 544
    .line 545
    .line 546
    move-result v4

    .line 547
    goto/16 :goto_33

    .line 548
    .line 549
    :pswitch_224
    mul-int/lit8 v3, v3, 0x35

    .line 550
    .line 551
    sget-object v4, Lk71;->c:Lh71;

    .line 552
    .line 553
    invoke-virtual {v4, v6, v7, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 554
    .line 555
    .line 556
    move-result-wide v4

    .line 557
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 558
    .line 559
    .line 560
    move-result v4

    .line 561
    goto/16 :goto_33

    .line 562
    .line 563
    :pswitch_232
    mul-int/lit8 v3, v3, 0x35

    .line 564
    .line 565
    sget-object v4, Lk71;->c:Lh71;

    .line 566
    .line 567
    invoke-virtual {v4, v6, v7, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 568
    .line 569
    .line 570
    move-result v4

    .line 571
    goto/16 :goto_33

    .line 572
    .line 573
    :pswitch_23c
    mul-int/lit8 v3, v3, 0x35

    .line 574
    .line 575
    sget-object v4, Lk71;->c:Lh71;

    .line 576
    .line 577
    invoke-virtual {v4, v6, v7, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 578
    .line 579
    .line 580
    move-result-wide v4

    .line 581
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 582
    .line 583
    .line 584
    move-result v4

    .line 585
    goto/16 :goto_33

    .line 586
    .line 587
    :pswitch_24a
    mul-int/lit8 v3, v3, 0x35

    .line 588
    .line 589
    sget-object v4, Lk71;->c:Lh71;

    .line 590
    .line 591
    invoke-virtual {v4, v6, v7, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 592
    .line 593
    .line 594
    move-result-wide v4

    .line 595
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 596
    .line 597
    .line 598
    move-result v4

    .line 599
    goto/16 :goto_33

    .line 600
    .line 601
    :pswitch_258
    mul-int/lit8 v3, v3, 0x35

    .line 602
    .line 603
    sget-object v4, Lk71;->c:Lh71;

    .line 604
    .line 605
    invoke-virtual {v4, v6, v7, p1}, Lh71;->h(JLjava/lang/Object;)F

    .line 606
    .line 607
    .line 608
    move-result v4

    .line 609
    invoke-static {v4}, Ljava/lang/Float;->floatToIntBits(F)I

    .line 610
    .line 611
    .line 612
    move-result v4

    .line 613
    goto/16 :goto_33

    .line 614
    .line 615
    :pswitch_266
    mul-int/lit8 v3, v3, 0x35

    .line 616
    .line 617
    sget-object v4, Lk71;->c:Lh71;

    .line 618
    .line 619
    invoke-virtual {v4, v6, v7, p1}, Lh71;->g(JLjava/lang/Object;)D

    .line 620
    .line 621
    .line 622
    move-result-wide v4

    .line 623
    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToLongBits(D)J

    .line 624
    .line 625
    .line 626
    move-result-wide v4

    .line 627
    invoke-static {v4, v5}, Ll40;->b(J)I

    .line 628
    .line 629
    .line 630
    move-result v4

    .line 631
    goto/16 :goto_33

    .line 632
    .line 633
    :cond_278
    :goto_278
    add-int/lit8 v2, v2, 0x3

    .line 634
    .line 635
    goto/16 :goto_5

    .line 636
    .line 637
    :cond_27c
    mul-int/lit8 v3, v3, 0x35

    .line 638
    .line 639
    iget-object p0, p0, Lde0;->m:Lp61;

    .line 640
    .line 641
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 642
    .line 643
    .line 644
    iget-object p0, p1, Lr00;->unknownFields:Lm61;

    .line 645
    .line 646
    invoke-virtual {p0}, Lm61;->hashCode()I

    .line 647
    .line 648
    .line 649
    move-result p0

    .line 650
    add-int/2addr p0, v3

    .line 651
    return p0

    .line 652
    nop

    .line 653
    :pswitch_data_28c
    .packed-switch 0x0
        :pswitch_266
        :pswitch_258
        :pswitch_24a
        :pswitch_23c
        :pswitch_232
        :pswitch_224
        :pswitch_21a
        :pswitch_20c
        :pswitch_1fc
        :pswitch_1ef
        :pswitch_1e1
        :pswitch_1d7
        :pswitch_1cd
        :pswitch_1c3
        :pswitch_1b5
        :pswitch_1ab
        :pswitch_19d
        :pswitch_18c
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_17e
        :pswitch_170
        :pswitch_152
        :pswitch_138
        :pswitch_126
        :pswitch_114
        :pswitch_106
        :pswitch_f4
        :pswitch_e6
        :pswitch_c9
        :pswitch_b3
        :pswitch_a0
        :pswitch_8d
        :pswitch_80
        :pswitch_73
        :pswitch_66
        :pswitch_55
        :pswitch_48
        :pswitch_37
        :pswitch_21
    .end packed-switch
.end method

.method public final k(Lr00;Lr00;I)Z
    .registers 4

    .line 1
    invoke-virtual {p0, p3, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    invoke-virtual {p0, p3, p2}, Lde0;->t(ILjava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-ne p1, p0, :cond_c

    .line 10
    .line 11
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :cond_c
    const/4 p0, 0x0

    .line 14
    return p0
.end method

.method public final n(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 6

    .line 1
    iget-object p3, p0, Lde0;->a:[I

    .line 2
    .line 3
    aget p3, p3, p2

    .line 4
    .line 5
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 6
    .line 7
    .line 8
    move-result p3

    .line 9
    const v0, 0xfffff

    .line 10
    .line 11
    .line 12
    and-int/2addr p3, v0

    .line 13
    int-to-long v0, p3

    .line 14
    sget-object p3, Lk71;->c:Lh71;

    .line 15
    .line 16
    invoke-virtual {p3, v0, v1, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    if-nez p1, :cond_16

    .line 21
    .line 22
    return-void

    .line 23
    :cond_16
    invoke-virtual {p0, p2}, Lde0;->o(I)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public final o(I)V
    .registers 2

    .line 1
    div-int/lit8 p1, p1, 0x3

    .line 2
    .line 3
    mul-int/lit8 p1, p1, 0x2

    .line 4
    .line 5
    add-int/lit8 p1, p1, 0x1

    .line 6
    .line 7
    iget-object p0, p0, Lde0;->b:[Ljava/lang/Object;

    .line 8
    .line 9
    aget-object p0, p0, p1

    .line 10
    .line 11
    if-nez p0, :cond_d

    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    invoke-static {}, Lm0;->o()V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public final p(I)Ljava/lang/Object;
    .registers 2

    .line 1
    div-int/lit8 p1, p1, 0x3

    .line 2
    .line 3
    mul-int/lit8 p1, p1, 0x2

    .line 4
    .line 5
    iget-object p0, p0, Lde0;->b:[Ljava/lang/Object;

    .line 6
    .line 7
    aget-object p0, p0, p1

    .line 8
    .line 9
    return-object p0
.end method

.method public final q(I)Les0;
    .registers 4

    .line 1
    div-int/lit8 p1, p1, 0x3

    .line 2
    .line 3
    mul-int/lit8 p1, p1, 0x2

    .line 4
    .line 5
    iget-object p0, p0, Lde0;->b:[Ljava/lang/Object;

    .line 6
    .line 7
    aget-object v0, p0, p1

    .line 8
    .line 9
    check-cast v0, Les0;

    .line 10
    .line 11
    if-eqz v0, :cond_d

    .line 12
    .line 13
    return-object v0

    .line 14
    :cond_d
    sget-object v0, Lhn0;->c:Lhn0;

    .line 15
    .line 16
    add-int/lit8 v1, p1, 0x1

    .line 17
    .line 18
    aget-object v1, p0, v1

    .line 19
    .line 20
    check-cast v1, Ljava/lang/Class;

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Lhn0;->a(Ljava/lang/Class;)Les0;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    aput-object v0, p0, p1

    .line 27
    .line 28
    return-object v0
.end method

.method public final r(Lr00;)I
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    sget-object v2, Lde0;->p:Lsun/misc/Unsafe;

    .line 6
    .line 7
    const v4, 0xfffff

    .line 8
    .line 9
    .line 10
    move v7, v4

    .line 11
    const/4 v5, 0x0

    .line 12
    const/4 v6, 0x0

    .line 13
    const/4 v8, 0x0

    .line 14
    :goto_d
    iget-object v9, v0, Lde0;->a:[I

    .line 15
    .line 16
    array-length v10, v9

    .line 17
    if-ge v5, v10, :cond_4bb

    .line 18
    .line 19
    invoke-virtual {v0, v5}, Lde0;->W(I)I

    .line 20
    .line 21
    .line 22
    move-result v10

    .line 23
    aget v11, v9, v5

    .line 24
    .line 25
    invoke-static {v10}, Lde0;->V(I)I

    .line 26
    .line 27
    .line 28
    move-result v12

    .line 29
    const/16 v13, 0x11

    .line 30
    .line 31
    const/4 v14, 0x1

    .line 32
    if-gt v12, v13, :cond_34

    .line 33
    .line 34
    add-int/lit8 v13, v5, 0x2

    .line 35
    .line 36
    aget v9, v9, v13

    .line 37
    .line 38
    and-int v13, v9, v4

    .line 39
    .line 40
    ushr-int/lit8 v9, v9, 0x14

    .line 41
    .line 42
    shl-int v9, v14, v9

    .line 43
    .line 44
    if-eq v13, v7, :cond_35

    .line 45
    .line 46
    int-to-long v7, v13

    .line 47
    invoke-virtual {v2, v1, v7, v8}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 48
    .line 49
    .line 50
    move-result v8

    .line 51
    move v7, v13

    .line 52
    goto :goto_35

    .line 53
    :cond_34
    const/4 v9, 0x0

    .line 54
    :cond_35
    :goto_35
    and-int/2addr v10, v4

    .line 55
    int-to-long v3, v10

    .line 56
    const/16 v15, 0x3f

    .line 57
    .line 58
    const/4 v10, 0x4

    .line 59
    const/16 v13, 0x8

    .line 60
    .line 61
    packed-switch v12, :pswitch_data_4c8

    .line 62
    .line 63
    .line 64
    goto/16 :goto_4b4

    .line 65
    .line 66
    :pswitch_41
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    move-result v9

    .line 70
    if-eqz v9, :cond_4b4

    .line 71
    .line 72
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v3

    .line 76
    check-cast v3, Lxd0;

    .line 77
    .line 78
    invoke-virtual {v0, v5}, Lde0;->q(I)Les0;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    invoke-static {v11, v3, v4}, Lde;->e(ILxd0;Les0;)I

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    :goto_55
    add-int/2addr v6, v3

    .line 87
    goto/16 :goto_4b4

    .line 88
    .line 89
    :pswitch_58
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 90
    .line 91
    .line 92
    move-result v9

    .line 93
    if-eqz v9, :cond_4b4

    .line 94
    .line 95
    invoke-static {v3, v4, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 96
    .line 97
    .line 98
    move-result-wide v3

    .line 99
    invoke-static {v11}, Lde;->h(I)I

    .line 100
    .line 101
    .line 102
    move-result v9

    .line 103
    shl-long v10, v3, v14

    .line 104
    .line 105
    shr-long/2addr v3, v15

    .line 106
    xor-long/2addr v3, v10

    .line 107
    invoke-static {v3, v4}, Lde;->k(J)I

    .line 108
    .line 109
    .line 110
    move-result v3

    .line 111
    :goto_6e
    add-int/2addr v3, v9

    .line 112
    goto :goto_55

    .line 113
    :pswitch_70
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 114
    .line 115
    .line 116
    move-result v9

    .line 117
    if-eqz v9, :cond_4b4

    .line 118
    .line 119
    invoke-static {v3, v4, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 120
    .line 121
    .line 122
    move-result v3

    .line 123
    invoke-static {v11}, Lde;->h(I)I

    .line 124
    .line 125
    .line 126
    move-result v4

    .line 127
    shl-int/lit8 v9, v3, 0x1

    .line 128
    .line 129
    shr-int/lit8 v3, v3, 0x1f

    .line 130
    .line 131
    xor-int/2addr v3, v9

    .line 132
    invoke-static {v3}, Lde;->j(I)I

    .line 133
    .line 134
    .line 135
    move-result v3

    .line 136
    :goto_87
    add-int/2addr v3, v4

    .line 137
    goto :goto_55

    .line 138
    :pswitch_89
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result v3

    .line 142
    if-eqz v3, :cond_4b4

    .line 143
    .line 144
    :goto_8f
    invoke-static {v11, v13, v6}, Lzi0;->w(III)I

    .line 145
    .line 146
    .line 147
    move-result v6

    .line 148
    goto/16 :goto_4b4

    .line 149
    .line 150
    :pswitch_95
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 151
    .line 152
    .line 153
    move-result v3

    .line 154
    if-eqz v3, :cond_4b4

    .line 155
    .line 156
    :goto_9b
    invoke-static {v11, v10, v6}, Lzi0;->w(III)I

    .line 157
    .line 158
    .line 159
    move-result v6

    .line 160
    goto/16 :goto_4b4

    .line 161
    .line 162
    :pswitch_a1
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 163
    .line 164
    .line 165
    move-result v9

    .line 166
    if-eqz v9, :cond_4b4

    .line 167
    .line 168
    invoke-static {v3, v4, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 169
    .line 170
    .line 171
    move-result v3

    .line 172
    invoke-static {v11}, Lde;->h(I)I

    .line 173
    .line 174
    .line 175
    move-result v4

    .line 176
    invoke-static {v3}, Lde;->f(I)I

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    goto :goto_87

    .line 181
    :pswitch_b4
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 182
    .line 183
    .line 184
    move-result v9

    .line 185
    if-eqz v9, :cond_4b4

    .line 186
    .line 187
    invoke-static {v3, v4, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 188
    .line 189
    .line 190
    move-result v3

    .line 191
    invoke-static {v11, v3}, Lde;->i(II)I

    .line 192
    .line 193
    .line 194
    move-result v3

    .line 195
    goto :goto_55

    .line 196
    :pswitch_c3
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 197
    .line 198
    .line 199
    move-result v9

    .line 200
    if-eqz v9, :cond_4b4

    .line 201
    .line 202
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v3

    .line 206
    check-cast v3, Lqb;

    .line 207
    .line 208
    invoke-static {v11, v3}, Lde;->a(ILqb;)I

    .line 209
    .line 210
    .line 211
    move-result v3

    .line 212
    goto :goto_55

    .line 213
    :pswitch_d4
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 214
    .line 215
    .line 216
    move-result v9

    .line 217
    if-eqz v9, :cond_4b4

    .line 218
    .line 219
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object v3

    .line 223
    invoke-virtual {v0, v5}, Lde0;->q(I)Les0;

    .line 224
    .line 225
    .line 226
    move-result-object v4

    .line 227
    sget-object v9, Lis0;->a:Ljava/lang/Class;

    .line 228
    .line 229
    check-cast v3, Lxd0;

    .line 230
    .line 231
    invoke-static {v11}, Lde;->h(I)I

    .line 232
    .line 233
    .line 234
    move-result v9

    .line 235
    check-cast v3, Lr;

    .line 236
    .line 237
    invoke-virtual {v3, v4}, Lr;->getSerializedSize(Les0;)I

    .line 238
    .line 239
    .line 240
    move-result v3

    .line 241
    :goto_f0
    invoke-static {v3, v3, v9, v6}, Lzi0;->h(IIII)I

    .line 242
    .line 243
    .line 244
    move-result v6

    .line 245
    goto/16 :goto_4b4

    .line 246
    .line 247
    :pswitch_f6
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    move-result v9

    .line 251
    if-eqz v9, :cond_4b4

    .line 252
    .line 253
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v3

    .line 257
    instance-of v4, v3, Lqb;

    .line 258
    .line 259
    if-eqz v4, :cond_115

    .line 260
    .line 261
    check-cast v3, Lqb;

    .line 262
    .line 263
    invoke-static {v11}, Lde;->h(I)I

    .line 264
    .line 265
    .line 266
    move-result v4

    .line 267
    invoke-virtual {v3}, Lqb;->size()I

    .line 268
    .line 269
    .line 270
    move-result v3

    .line 271
    :goto_10e
    invoke-static {v3, v3, v4, v6}, Lzi0;->h(IIII)I

    .line 272
    .line 273
    .line 274
    move-result v3

    .line 275
    :goto_112
    move v6, v3

    .line 276
    goto/16 :goto_4b4

    .line 277
    .line 278
    :cond_115
    check-cast v3, Ljava/lang/String;

    .line 279
    .line 280
    invoke-static {v11}, Lde;->h(I)I

    .line 281
    .line 282
    .line 283
    move-result v4

    .line 284
    invoke-static {v3}, Lde;->g(Ljava/lang/String;)I

    .line 285
    .line 286
    .line 287
    move-result v3

    .line 288
    :goto_11f
    add-int/2addr v3, v4

    .line 289
    add-int/2addr v3, v6

    .line 290
    goto :goto_112

    .line 291
    :pswitch_122
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 292
    .line 293
    .line 294
    move-result v3

    .line 295
    if-eqz v3, :cond_4b4

    .line 296
    .line 297
    :goto_128
    invoke-static {v11, v14, v6}, Lzi0;->w(III)I

    .line 298
    .line 299
    .line 300
    move-result v6

    .line 301
    goto/16 :goto_4b4

    .line 302
    .line 303
    :pswitch_12e
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 304
    .line 305
    .line 306
    move-result v3

    .line 307
    if-eqz v3, :cond_4b4

    .line 308
    .line 309
    invoke-static {v11}, Lde;->c(I)I

    .line 310
    .line 311
    .line 312
    move-result v3

    .line 313
    goto/16 :goto_55

    .line 314
    .line 315
    :pswitch_13a
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 316
    .line 317
    .line 318
    move-result v3

    .line 319
    if-eqz v3, :cond_4b4

    .line 320
    .line 321
    invoke-static {v11}, Lde;->d(I)I

    .line 322
    .line 323
    .line 324
    move-result v3

    .line 325
    goto/16 :goto_55

    .line 326
    .line 327
    :pswitch_146
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 328
    .line 329
    .line 330
    move-result v9

    .line 331
    if-eqz v9, :cond_4b4

    .line 332
    .line 333
    invoke-static {v3, v4, v1}, Lde0;->F(JLjava/lang/Object;)I

    .line 334
    .line 335
    .line 336
    move-result v3

    .line 337
    invoke-static {v11}, Lde;->h(I)I

    .line 338
    .line 339
    .line 340
    move-result v4

    .line 341
    invoke-static {v3}, Lde;->f(I)I

    .line 342
    .line 343
    .line 344
    move-result v3

    .line 345
    goto/16 :goto_87

    .line 346
    .line 347
    :pswitch_15a
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 348
    .line 349
    .line 350
    move-result v9

    .line 351
    if-eqz v9, :cond_4b4

    .line 352
    .line 353
    invoke-static {v3, v4, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 354
    .line 355
    .line 356
    move-result-wide v3

    .line 357
    invoke-static {v11}, Lde;->h(I)I

    .line 358
    .line 359
    .line 360
    move-result v9

    .line 361
    invoke-static {v3, v4}, Lde;->k(J)I

    .line 362
    .line 363
    .line 364
    move-result v3

    .line 365
    goto/16 :goto_6e

    .line 366
    .line 367
    :pswitch_16e
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 368
    .line 369
    .line 370
    move-result v9

    .line 371
    if-eqz v9, :cond_4b4

    .line 372
    .line 373
    invoke-static {v3, v4, v1}, Lde0;->G(JLjava/lang/Object;)J

    .line 374
    .line 375
    .line 376
    move-result-wide v3

    .line 377
    invoke-static {v11}, Lde;->h(I)I

    .line 378
    .line 379
    .line 380
    move-result v9

    .line 381
    invoke-static {v3, v4}, Lde;->k(J)I

    .line 382
    .line 383
    .line 384
    move-result v3

    .line 385
    goto/16 :goto_6e

    .line 386
    .line 387
    :pswitch_182
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 388
    .line 389
    .line 390
    move-result v3

    .line 391
    if-eqz v3, :cond_4b4

    .line 392
    .line 393
    goto/16 :goto_9b

    .line 394
    .line 395
    :pswitch_18a
    invoke-virtual {v0, v11, v5, v1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 396
    .line 397
    .line 398
    move-result v3

    .line 399
    if-eqz v3, :cond_4b4

    .line 400
    .line 401
    goto/16 :goto_8f

    .line 402
    .line 403
    :pswitch_192
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    move-result-object v3

    .line 407
    invoke-virtual {v0, v5}, Lde0;->p(I)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object v4

    .line 411
    iget-object v9, v0, Lde0;->n:Lrb0;

    .line 412
    .line 413
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 414
    .line 415
    .line 416
    invoke-static {v3, v11, v4}, Lrb0;->a(Ljava/lang/Object;ILjava/lang/Object;)I

    .line 417
    .line 418
    .line 419
    move-result v3

    .line 420
    goto/16 :goto_55

    .line 421
    .line 422
    :pswitch_1a5
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 423
    .line 424
    .line 425
    move-result-object v3

    .line 426
    check-cast v3, Ljava/util/List;

    .line 427
    .line 428
    invoke-virtual {v0, v5}, Lde0;->q(I)Les0;

    .line 429
    .line 430
    .line 431
    move-result-object v4

    .line 432
    sget-object v9, Lis0;->a:Ljava/lang/Class;

    .line 433
    .line 434
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 435
    .line 436
    .line 437
    move-result v9

    .line 438
    if-nez v9, :cond_1b9

    .line 439
    .line 440
    const/4 v12, 0x0

    .line 441
    goto :goto_1cb

    .line 442
    :cond_1b9
    const/4 v10, 0x0

    .line 443
    const/4 v12, 0x0

    .line 444
    :goto_1bb
    if-ge v10, v9, :cond_1cb

    .line 445
    .line 446
    invoke-interface {v3, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 447
    .line 448
    .line 449
    move-result-object v13

    .line 450
    check-cast v13, Lxd0;

    .line 451
    .line 452
    invoke-static {v11, v13, v4}, Lde;->e(ILxd0;Les0;)I

    .line 453
    .line 454
    .line 455
    move-result v13

    .line 456
    add-int/2addr v12, v13

    .line 457
    add-int/lit8 v10, v10, 0x1

    .line 458
    .line 459
    goto :goto_1bb

    .line 460
    :cond_1cb
    :goto_1cb
    add-int/2addr v6, v12

    .line 461
    goto/16 :goto_4b4

    .line 462
    .line 463
    :pswitch_1ce
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object v3

    .line 467
    check-cast v3, Ljava/util/List;

    .line 468
    .line 469
    invoke-static {v3}, Lis0;->p(Ljava/util/List;)I

    .line 470
    .line 471
    .line 472
    move-result v3

    .line 473
    if-lez v3, :cond_4b4

    .line 474
    .line 475
    invoke-static {v11}, Lde;->h(I)I

    .line 476
    .line 477
    .line 478
    move-result v4

    .line 479
    :goto_1de
    invoke-static {v3, v4, v3, v6}, Lzi0;->h(IIII)I

    .line 480
    .line 481
    .line 482
    move-result v6

    .line 483
    goto/16 :goto_4b4

    .line 484
    .line 485
    :pswitch_1e4
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 486
    .line 487
    .line 488
    move-result-object v3

    .line 489
    check-cast v3, Ljava/util/List;

    .line 490
    .line 491
    invoke-static {v3}, Lis0;->n(Ljava/util/List;)I

    .line 492
    .line 493
    .line 494
    move-result v3

    .line 495
    if-lez v3, :cond_4b4

    .line 496
    .line 497
    invoke-static {v11}, Lde;->h(I)I

    .line 498
    .line 499
    .line 500
    move-result v4

    .line 501
    goto :goto_1de

    .line 502
    :pswitch_1f5
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 503
    .line 504
    .line 505
    move-result-object v3

    .line 506
    check-cast v3, Ljava/util/List;

    .line 507
    .line 508
    invoke-static {v3}, Lis0;->g(Ljava/util/List;)I

    .line 509
    .line 510
    .line 511
    move-result v3

    .line 512
    if-lez v3, :cond_4b4

    .line 513
    .line 514
    invoke-static {v11}, Lde;->h(I)I

    .line 515
    .line 516
    .line 517
    move-result v4

    .line 518
    goto :goto_1de

    .line 519
    :pswitch_206
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 520
    .line 521
    .line 522
    move-result-object v3

    .line 523
    check-cast v3, Ljava/util/List;

    .line 524
    .line 525
    invoke-static {v3}, Lis0;->e(Ljava/util/List;)I

    .line 526
    .line 527
    .line 528
    move-result v3

    .line 529
    if-lez v3, :cond_4b4

    .line 530
    .line 531
    invoke-static {v11}, Lde;->h(I)I

    .line 532
    .line 533
    .line 534
    move-result v4

    .line 535
    goto :goto_1de

    .line 536
    :pswitch_217
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 537
    .line 538
    .line 539
    move-result-object v3

    .line 540
    check-cast v3, Ljava/util/List;

    .line 541
    .line 542
    invoke-static {v3}, Lis0;->c(Ljava/util/List;)I

    .line 543
    .line 544
    .line 545
    move-result v3

    .line 546
    if-lez v3, :cond_4b4

    .line 547
    .line 548
    invoke-static {v11}, Lde;->h(I)I

    .line 549
    .line 550
    .line 551
    move-result v4

    .line 552
    goto :goto_1de

    .line 553
    :pswitch_228
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 554
    .line 555
    .line 556
    move-result-object v3

    .line 557
    check-cast v3, Ljava/util/List;

    .line 558
    .line 559
    invoke-static {v3}, Lis0;->s(Ljava/util/List;)I

    .line 560
    .line 561
    .line 562
    move-result v3

    .line 563
    if-lez v3, :cond_4b4

    .line 564
    .line 565
    invoke-static {v11}, Lde;->h(I)I

    .line 566
    .line 567
    .line 568
    move-result v4

    .line 569
    goto :goto_1de

    .line 570
    :pswitch_239
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 571
    .line 572
    .line 573
    move-result-object v3

    .line 574
    check-cast v3, Ljava/util/List;

    .line 575
    .line 576
    sget-object v4, Lis0;->a:Ljava/lang/Class;

    .line 577
    .line 578
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 579
    .line 580
    .line 581
    move-result v3

    .line 582
    if-lez v3, :cond_4b4

    .line 583
    .line 584
    invoke-static {v11}, Lde;->h(I)I

    .line 585
    .line 586
    .line 587
    move-result v4

    .line 588
    goto :goto_1de

    .line 589
    :pswitch_24c
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 590
    .line 591
    .line 592
    move-result-object v3

    .line 593
    check-cast v3, Ljava/util/List;

    .line 594
    .line 595
    invoke-static {v3}, Lis0;->e(Ljava/util/List;)I

    .line 596
    .line 597
    .line 598
    move-result v3

    .line 599
    if-lez v3, :cond_4b4

    .line 600
    .line 601
    invoke-static {v11}, Lde;->h(I)I

    .line 602
    .line 603
    .line 604
    move-result v4

    .line 605
    goto :goto_1de

    .line 606
    :pswitch_25d
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 607
    .line 608
    .line 609
    move-result-object v3

    .line 610
    check-cast v3, Ljava/util/List;

    .line 611
    .line 612
    invoke-static {v3}, Lis0;->g(Ljava/util/List;)I

    .line 613
    .line 614
    .line 615
    move-result v3

    .line 616
    if-lez v3, :cond_4b4

    .line 617
    .line 618
    invoke-static {v11}, Lde;->h(I)I

    .line 619
    .line 620
    .line 621
    move-result v4

    .line 622
    goto/16 :goto_1de

    .line 623
    .line 624
    :pswitch_26f
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 625
    .line 626
    .line 627
    move-result-object v3

    .line 628
    check-cast v3, Ljava/util/List;

    .line 629
    .line 630
    invoke-static {v3}, Lis0;->i(Ljava/util/List;)I

    .line 631
    .line 632
    .line 633
    move-result v3

    .line 634
    if-lez v3, :cond_4b4

    .line 635
    .line 636
    invoke-static {v11}, Lde;->h(I)I

    .line 637
    .line 638
    .line 639
    move-result v4

    .line 640
    goto/16 :goto_1de

    .line 641
    .line 642
    :pswitch_281
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 643
    .line 644
    .line 645
    move-result-object v3

    .line 646
    check-cast v3, Ljava/util/List;

    .line 647
    .line 648
    invoke-static {v3}, Lis0;->u(Ljava/util/List;)I

    .line 649
    .line 650
    .line 651
    move-result v3

    .line 652
    if-lez v3, :cond_4b4

    .line 653
    .line 654
    invoke-static {v11}, Lde;->h(I)I

    .line 655
    .line 656
    .line 657
    move-result v4

    .line 658
    goto/16 :goto_1de

    .line 659
    .line 660
    :pswitch_293
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 661
    .line 662
    .line 663
    move-result-object v3

    .line 664
    check-cast v3, Ljava/util/List;

    .line 665
    .line 666
    invoke-static {v3}, Lis0;->k(Ljava/util/List;)I

    .line 667
    .line 668
    .line 669
    move-result v3

    .line 670
    if-lez v3, :cond_4b4

    .line 671
    .line 672
    invoke-static {v11}, Lde;->h(I)I

    .line 673
    .line 674
    .line 675
    move-result v4

    .line 676
    goto/16 :goto_1de

    .line 677
    .line 678
    :pswitch_2a5
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 679
    .line 680
    .line 681
    move-result-object v3

    .line 682
    check-cast v3, Ljava/util/List;

    .line 683
    .line 684
    invoke-static {v3}, Lis0;->e(Ljava/util/List;)I

    .line 685
    .line 686
    .line 687
    move-result v3

    .line 688
    if-lez v3, :cond_4b4

    .line 689
    .line 690
    invoke-static {v11}, Lde;->h(I)I

    .line 691
    .line 692
    .line 693
    move-result v4

    .line 694
    goto/16 :goto_1de

    .line 695
    .line 696
    :pswitch_2b7
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 697
    .line 698
    .line 699
    move-result-object v3

    .line 700
    check-cast v3, Ljava/util/List;

    .line 701
    .line 702
    invoke-static {v3}, Lis0;->g(Ljava/util/List;)I

    .line 703
    .line 704
    .line 705
    move-result v3

    .line 706
    if-lez v3, :cond_4b4

    .line 707
    .line 708
    invoke-static {v11}, Lde;->h(I)I

    .line 709
    .line 710
    .line 711
    move-result v4

    .line 712
    goto/16 :goto_1de

    .line 713
    .line 714
    :pswitch_2c9
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 715
    .line 716
    .line 717
    move-result-object v3

    .line 718
    check-cast v3, Ljava/util/List;

    .line 719
    .line 720
    invoke-static {v3, v11}, Lis0;->o(Ljava/util/List;I)I

    .line 721
    .line 722
    .line 723
    move-result v3

    .line 724
    goto/16 :goto_55

    .line 725
    .line 726
    :pswitch_2d5
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 727
    .line 728
    .line 729
    move-result-object v3

    .line 730
    check-cast v3, Ljava/util/List;

    .line 731
    .line 732
    invoke-static {v3, v11}, Lis0;->m(Ljava/util/List;I)I

    .line 733
    .line 734
    .line 735
    move-result v3

    .line 736
    goto/16 :goto_55

    .line 737
    .line 738
    :pswitch_2e1
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 739
    .line 740
    .line 741
    move-result-object v3

    .line 742
    check-cast v3, Ljava/util/List;

    .line 743
    .line 744
    invoke-static {v3, v11}, Lis0;->f(Ljava/util/List;I)I

    .line 745
    .line 746
    .line 747
    move-result v3

    .line 748
    goto/16 :goto_55

    .line 749
    .line 750
    :pswitch_2ed
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 751
    .line 752
    .line 753
    move-result-object v3

    .line 754
    check-cast v3, Ljava/util/List;

    .line 755
    .line 756
    invoke-static {v3, v11}, Lis0;->d(Ljava/util/List;I)I

    .line 757
    .line 758
    .line 759
    move-result v3

    .line 760
    goto/16 :goto_55

    .line 761
    .line 762
    :pswitch_2f9
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 763
    .line 764
    .line 765
    move-result-object v3

    .line 766
    check-cast v3, Ljava/util/List;

    .line 767
    .line 768
    invoke-static {v3, v11}, Lis0;->b(Ljava/util/List;I)I

    .line 769
    .line 770
    .line 771
    move-result v3

    .line 772
    goto/16 :goto_55

    .line 773
    .line 774
    :pswitch_305
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 775
    .line 776
    .line 777
    move-result-object v3

    .line 778
    check-cast v3, Ljava/util/List;

    .line 779
    .line 780
    invoke-static {v3, v11}, Lis0;->r(Ljava/util/List;I)I

    .line 781
    .line 782
    .line 783
    move-result v3

    .line 784
    goto/16 :goto_55

    .line 785
    .line 786
    :pswitch_311
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    move-result-object v3

    .line 790
    check-cast v3, Ljava/util/List;

    .line 791
    .line 792
    invoke-static {v3, v11}, Lis0;->a(Ljava/util/List;I)I

    .line 793
    .line 794
    .line 795
    move-result v3

    .line 796
    goto/16 :goto_55

    .line 797
    .line 798
    :pswitch_31d
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 799
    .line 800
    .line 801
    move-result-object v3

    .line 802
    check-cast v3, Ljava/util/List;

    .line 803
    .line 804
    invoke-virtual {v0, v5}, Lde0;->q(I)Les0;

    .line 805
    .line 806
    .line 807
    move-result-object v4

    .line 808
    invoke-static {v11, v3, v4}, Lis0;->l(ILjava/util/List;Les0;)I

    .line 809
    .line 810
    .line 811
    move-result v3

    .line 812
    goto/16 :goto_55

    .line 813
    .line 814
    :pswitch_32d
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 815
    .line 816
    .line 817
    move-result-object v3

    .line 818
    check-cast v3, Ljava/util/List;

    .line 819
    .line 820
    invoke-static {v3, v11}, Lis0;->q(Ljava/util/List;I)I

    .line 821
    .line 822
    .line 823
    move-result v3

    .line 824
    goto/16 :goto_55

    .line 825
    .line 826
    :pswitch_339
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 827
    .line 828
    .line 829
    move-result-object v3

    .line 830
    check-cast v3, Ljava/util/List;

    .line 831
    .line 832
    sget-object v4, Lis0;->a:Ljava/lang/Class;

    .line 833
    .line 834
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 835
    .line 836
    .line 837
    move-result v3

    .line 838
    if-nez v3, :cond_349

    .line 839
    .line 840
    const/4 v4, 0x0

    .line 841
    goto :goto_34f

    .line 842
    :cond_349
    invoke-static {v11}, Lde;->h(I)I

    .line 843
    .line 844
    .line 845
    move-result v4

    .line 846
    add-int/2addr v4, v14

    .line 847
    mul-int/2addr v4, v3

    .line 848
    :goto_34f
    add-int/2addr v6, v4

    .line 849
    goto/16 :goto_4b4

    .line 850
    .line 851
    :pswitch_352
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 852
    .line 853
    .line 854
    move-result-object v3

    .line 855
    check-cast v3, Ljava/util/List;

    .line 856
    .line 857
    invoke-static {v3, v11}, Lis0;->d(Ljava/util/List;I)I

    .line 858
    .line 859
    .line 860
    move-result v3

    .line 861
    goto/16 :goto_55

    .line 862
    .line 863
    :pswitch_35e
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 864
    .line 865
    .line 866
    move-result-object v3

    .line 867
    check-cast v3, Ljava/util/List;

    .line 868
    .line 869
    invoke-static {v3, v11}, Lis0;->f(Ljava/util/List;I)I

    .line 870
    .line 871
    .line 872
    move-result v3

    .line 873
    goto/16 :goto_55

    .line 874
    .line 875
    :pswitch_36a
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 876
    .line 877
    .line 878
    move-result-object v3

    .line 879
    check-cast v3, Ljava/util/List;

    .line 880
    .line 881
    invoke-static {v3, v11}, Lis0;->h(Ljava/util/List;I)I

    .line 882
    .line 883
    .line 884
    move-result v3

    .line 885
    goto/16 :goto_55

    .line 886
    .line 887
    :pswitch_376
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 888
    .line 889
    .line 890
    move-result-object v3

    .line 891
    check-cast v3, Ljava/util/List;

    .line 892
    .line 893
    invoke-static {v3, v11}, Lis0;->t(Ljava/util/List;I)I

    .line 894
    .line 895
    .line 896
    move-result v3

    .line 897
    goto/16 :goto_55

    .line 898
    .line 899
    :pswitch_382
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 900
    .line 901
    .line 902
    move-result-object v3

    .line 903
    check-cast v3, Ljava/util/List;

    .line 904
    .line 905
    invoke-static {v3, v11}, Lis0;->j(Ljava/util/List;I)I

    .line 906
    .line 907
    .line 908
    move-result v3

    .line 909
    goto/16 :goto_55

    .line 910
    .line 911
    :pswitch_38e
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 912
    .line 913
    .line 914
    move-result-object v3

    .line 915
    check-cast v3, Ljava/util/List;

    .line 916
    .line 917
    invoke-static {v3, v11}, Lis0;->d(Ljava/util/List;I)I

    .line 918
    .line 919
    .line 920
    move-result v3

    .line 921
    goto/16 :goto_55

    .line 922
    .line 923
    :pswitch_39a
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 924
    .line 925
    .line 926
    move-result-object v3

    .line 927
    check-cast v3, Ljava/util/List;

    .line 928
    .line 929
    invoke-static {v3, v11}, Lis0;->f(Ljava/util/List;I)I

    .line 930
    .line 931
    .line 932
    move-result v3

    .line 933
    goto/16 :goto_55

    .line 934
    .line 935
    :pswitch_3a6
    and-int/2addr v9, v8

    .line 936
    if-eqz v9, :cond_4b4

    .line 937
    .line 938
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 939
    .line 940
    .line 941
    move-result-object v3

    .line 942
    check-cast v3, Lxd0;

    .line 943
    .line 944
    invoke-virtual {v0, v5}, Lde0;->q(I)Les0;

    .line 945
    .line 946
    .line 947
    move-result-object v4

    .line 948
    invoke-static {v11, v3, v4}, Lde;->e(ILxd0;Les0;)I

    .line 949
    .line 950
    .line 951
    move-result v3

    .line 952
    goto/16 :goto_55

    .line 953
    .line 954
    :pswitch_3b9
    and-int/2addr v9, v8

    .line 955
    if-eqz v9, :cond_4b4

    .line 956
    .line 957
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 958
    .line 959
    .line 960
    move-result-wide v3

    .line 961
    invoke-static {v11}, Lde;->h(I)I

    .line 962
    .line 963
    .line 964
    move-result v9

    .line 965
    shl-long v10, v3, v14

    .line 966
    .line 967
    shr-long/2addr v3, v15

    .line 968
    xor-long/2addr v3, v10

    .line 969
    invoke-static {v3, v4}, Lde;->k(J)I

    .line 970
    .line 971
    .line 972
    move-result v3

    .line 973
    goto/16 :goto_6e

    .line 974
    .line 975
    :pswitch_3ce
    and-int/2addr v9, v8

    .line 976
    if-eqz v9, :cond_4b4

    .line 977
    .line 978
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 979
    .line 980
    .line 981
    move-result v3

    .line 982
    invoke-static {v11}, Lde;->h(I)I

    .line 983
    .line 984
    .line 985
    move-result v4

    .line 986
    shl-int/lit8 v9, v3, 0x1

    .line 987
    .line 988
    shr-int/lit8 v3, v3, 0x1f

    .line 989
    .line 990
    xor-int/2addr v3, v9

    .line 991
    invoke-static {v3}, Lde;->j(I)I

    .line 992
    .line 993
    .line 994
    move-result v3

    .line 995
    goto/16 :goto_87

    .line 996
    .line 997
    :pswitch_3e4
    and-int v3, v8, v9

    .line 998
    .line 999
    if-eqz v3, :cond_4b4

    .line 1000
    .line 1001
    goto/16 :goto_8f

    .line 1002
    .line 1003
    :pswitch_3ea
    and-int v3, v8, v9

    .line 1004
    .line 1005
    if-eqz v3, :cond_4b4

    .line 1006
    .line 1007
    goto/16 :goto_9b

    .line 1008
    .line 1009
    :pswitch_3f0
    and-int/2addr v9, v8

    .line 1010
    if-eqz v9, :cond_4b4

    .line 1011
    .line 1012
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1013
    .line 1014
    .line 1015
    move-result v3

    .line 1016
    invoke-static {v11}, Lde;->h(I)I

    .line 1017
    .line 1018
    .line 1019
    move-result v4

    .line 1020
    invoke-static {v3}, Lde;->f(I)I

    .line 1021
    .line 1022
    .line 1023
    move-result v3

    .line 1024
    goto/16 :goto_87

    .line 1025
    .line 1026
    :pswitch_401
    and-int/2addr v9, v8

    .line 1027
    if-eqz v9, :cond_4b4

    .line 1028
    .line 1029
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1030
    .line 1031
    .line 1032
    move-result v3

    .line 1033
    invoke-static {v11, v3}, Lde;->i(II)I

    .line 1034
    .line 1035
    .line 1036
    move-result v3

    .line 1037
    goto/16 :goto_55

    .line 1038
    .line 1039
    :pswitch_40e
    and-int/2addr v9, v8

    .line 1040
    if-eqz v9, :cond_4b4

    .line 1041
    .line 1042
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 1043
    .line 1044
    .line 1045
    move-result-object v3

    .line 1046
    check-cast v3, Lqb;

    .line 1047
    .line 1048
    invoke-static {v11, v3}, Lde;->a(ILqb;)I

    .line 1049
    .line 1050
    .line 1051
    move-result v3

    .line 1052
    goto/16 :goto_55

    .line 1053
    .line 1054
    :pswitch_41d
    and-int/2addr v9, v8

    .line 1055
    if-eqz v9, :cond_4b4

    .line 1056
    .line 1057
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v3

    .line 1061
    invoke-virtual {v0, v5}, Lde0;->q(I)Les0;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v4

    .line 1065
    sget-object v9, Lis0;->a:Ljava/lang/Class;

    .line 1066
    .line 1067
    check-cast v3, Lxd0;

    .line 1068
    .line 1069
    invoke-static {v11}, Lde;->h(I)I

    .line 1070
    .line 1071
    .line 1072
    move-result v9

    .line 1073
    check-cast v3, Lr;

    .line 1074
    .line 1075
    invoke-virtual {v3, v4}, Lr;->getSerializedSize(Les0;)I

    .line 1076
    .line 1077
    .line 1078
    move-result v3

    .line 1079
    goto/16 :goto_f0

    .line 1080
    .line 1081
    :pswitch_438
    and-int/2addr v9, v8

    .line 1082
    if-eqz v9, :cond_4b4

    .line 1083
    .line 1084
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 1085
    .line 1086
    .line 1087
    move-result-object v3

    .line 1088
    instance-of v4, v3, Lqb;

    .line 1089
    .line 1090
    if-eqz v4, :cond_44f

    .line 1091
    .line 1092
    check-cast v3, Lqb;

    .line 1093
    .line 1094
    invoke-static {v11}, Lde;->h(I)I

    .line 1095
    .line 1096
    .line 1097
    move-result v4

    .line 1098
    invoke-virtual {v3}, Lqb;->size()I

    .line 1099
    .line 1100
    .line 1101
    move-result v3

    .line 1102
    goto/16 :goto_10e

    .line 1103
    .line 1104
    :cond_44f
    check-cast v3, Ljava/lang/String;

    .line 1105
    .line 1106
    invoke-static {v11}, Lde;->h(I)I

    .line 1107
    .line 1108
    .line 1109
    move-result v4

    .line 1110
    invoke-static {v3}, Lde;->g(Ljava/lang/String;)I

    .line 1111
    .line 1112
    .line 1113
    move-result v3

    .line 1114
    goto/16 :goto_11f

    .line 1115
    .line 1116
    :pswitch_45b
    and-int v3, v8, v9

    .line 1117
    .line 1118
    if-eqz v3, :cond_4b4

    .line 1119
    .line 1120
    goto/16 :goto_128

    .line 1121
    .line 1122
    :pswitch_461
    and-int v3, v8, v9

    .line 1123
    .line 1124
    if-eqz v3, :cond_4b4

    .line 1125
    .line 1126
    invoke-static {v11}, Lde;->c(I)I

    .line 1127
    .line 1128
    .line 1129
    move-result v3

    .line 1130
    goto/16 :goto_55

    .line 1131
    .line 1132
    :pswitch_46b
    and-int v3, v8, v9

    .line 1133
    .line 1134
    if-eqz v3, :cond_4b4

    .line 1135
    .line 1136
    invoke-static {v11}, Lde;->d(I)I

    .line 1137
    .line 1138
    .line 1139
    move-result v3

    .line 1140
    goto/16 :goto_55

    .line 1141
    .line 1142
    :pswitch_475
    and-int/2addr v9, v8

    .line 1143
    if-eqz v9, :cond_4b4

    .line 1144
    .line 1145
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getInt(Ljava/lang/Object;J)I

    .line 1146
    .line 1147
    .line 1148
    move-result v3

    .line 1149
    invoke-static {v11}, Lde;->h(I)I

    .line 1150
    .line 1151
    .line 1152
    move-result v4

    .line 1153
    invoke-static {v3}, Lde;->f(I)I

    .line 1154
    .line 1155
    .line 1156
    move-result v3

    .line 1157
    goto/16 :goto_87

    .line 1158
    .line 1159
    :pswitch_486
    and-int/2addr v9, v8

    .line 1160
    if-eqz v9, :cond_4b4

    .line 1161
    .line 1162
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1163
    .line 1164
    .line 1165
    move-result-wide v3

    .line 1166
    invoke-static {v11}, Lde;->h(I)I

    .line 1167
    .line 1168
    .line 1169
    move-result v9

    .line 1170
    invoke-static {v3, v4}, Lde;->k(J)I

    .line 1171
    .line 1172
    .line 1173
    move-result v3

    .line 1174
    goto/16 :goto_6e

    .line 1175
    .line 1176
    :pswitch_497
    and-int/2addr v9, v8

    .line 1177
    if-eqz v9, :cond_4b4

    .line 1178
    .line 1179
    invoke-virtual {v2, v1, v3, v4}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    .line 1180
    .line 1181
    .line 1182
    move-result-wide v3

    .line 1183
    invoke-static {v11}, Lde;->h(I)I

    .line 1184
    .line 1185
    .line 1186
    move-result v9

    .line 1187
    invoke-static {v3, v4}, Lde;->k(J)I

    .line 1188
    .line 1189
    .line 1190
    move-result v3

    .line 1191
    goto/16 :goto_6e

    .line 1192
    .line 1193
    :pswitch_4a8
    and-int v3, v8, v9

    .line 1194
    .line 1195
    if-eqz v3, :cond_4b4

    .line 1196
    .line 1197
    goto/16 :goto_9b

    .line 1198
    .line 1199
    :pswitch_4ae
    and-int v3, v8, v9

    .line 1200
    .line 1201
    if-eqz v3, :cond_4b4

    .line 1202
    .line 1203
    goto/16 :goto_8f

    .line 1204
    .line 1205
    :cond_4b4
    :goto_4b4
    add-int/lit8 v5, v5, 0x3

    .line 1206
    .line 1207
    const v4, 0xfffff

    .line 1208
    .line 1209
    .line 1210
    goto/16 :goto_d

    .line 1211
    .line 1212
    :cond_4bb
    iget-object v0, v0, Lde0;->m:Lp61;

    .line 1213
    .line 1214
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1215
    .line 1216
    .line 1217
    iget-object v0, v1, Lr00;->unknownFields:Lm61;

    .line 1218
    .line 1219
    invoke-virtual {v0}, Lm61;->c()I

    .line 1220
    .line 1221
    .line 1222
    move-result v0

    .line 1223
    add-int/2addr v0, v6

    .line 1224
    return v0

    .line 1225
    :pswitch_data_4c8
    .packed-switch 0x0
        :pswitch_4ae
        :pswitch_4a8
        :pswitch_497
        :pswitch_486
        :pswitch_475
        :pswitch_46b
        :pswitch_461
        :pswitch_45b
        :pswitch_438
        :pswitch_41d
        :pswitch_40e
        :pswitch_401
        :pswitch_3f0
        :pswitch_3ea
        :pswitch_3e4
        :pswitch_3ce
        :pswitch_3b9
        :pswitch_3a6
        :pswitch_39a
        :pswitch_38e
        :pswitch_382
        :pswitch_376
        :pswitch_36a
        :pswitch_35e
        :pswitch_352
        :pswitch_339
        :pswitch_32d
        :pswitch_31d
        :pswitch_311
        :pswitch_305
        :pswitch_2f9
        :pswitch_2ed
        :pswitch_2e1
        :pswitch_2d5
        :pswitch_2c9
        :pswitch_2b7
        :pswitch_2a5
        :pswitch_293
        :pswitch_281
        :pswitch_26f
        :pswitch_25d
        :pswitch_24c
        :pswitch_239
        :pswitch_228
        :pswitch_217
        :pswitch_206
        :pswitch_1f5
        :pswitch_1e4
        :pswitch_1ce
        :pswitch_1a5
        :pswitch_192
        :pswitch_18a
        :pswitch_182
        :pswitch_16e
        :pswitch_15a
        :pswitch_146
        :pswitch_13a
        :pswitch_12e
        :pswitch_122
        :pswitch_f6
        :pswitch_d4
        :pswitch_c3
        :pswitch_b4
        :pswitch_a1
        :pswitch_95
        :pswitch_89
        :pswitch_70
        :pswitch_58
        :pswitch_41
    .end packed-switch
.end method

.method public final s(Lr00;)I
    .registers 14

    .line 1
    sget-object v0, Lde0;->p:Lsun/misc/Unsafe;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    move v2, v1

    .line 5
    move v3, v2

    .line 6
    :goto_5
    iget-object v4, p0, Lde0;->a:[I

    .line 7
    .line 8
    array-length v5, v4

    .line 9
    if-ge v2, v5, :cond_4da

    .line 10
    .line 11
    invoke-virtual {p0, v2}, Lde0;->W(I)I

    .line 12
    .line 13
    .line 14
    move-result v5

    .line 15
    invoke-static {v5}, Lde0;->V(I)I

    .line 16
    .line 17
    .line 18
    move-result v6

    .line 19
    aget v7, v4, v2

    .line 20
    .line 21
    const v8, 0xfffff

    .line 22
    .line 23
    .line 24
    and-int/2addr v5, v8

    .line 25
    int-to-long v8, v5

    .line 26
    sget-object v5, Lat;->g:Lat;

    .line 27
    .line 28
    iget v5, v5, Lat;->f:I

    .line 29
    .line 30
    if-lt v6, v5, :cond_29

    .line 31
    .line 32
    sget-object v5, Lat;->h:Lat;

    .line 33
    .line 34
    iget v5, v5, Lat;->f:I

    .line 35
    .line 36
    if-gt v6, v5, :cond_29

    .line 37
    .line 38
    add-int/lit8 v5, v2, 0x2

    .line 39
    .line 40
    aget v4, v4, v5

    .line 41
    .line 42
    :cond_29
    const/16 v4, 0x3f

    .line 43
    .line 44
    const/4 v5, 0x4

    .line 45
    const/16 v10, 0x8

    .line 46
    .line 47
    const/4 v11, 0x1

    .line 48
    packed-switch v6, :pswitch_data_4e8

    .line 49
    .line 50
    .line 51
    goto/16 :goto_4d6

    .line 52
    .line 53
    :pswitch_34
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    if-eqz v4, :cond_4d6

    .line 58
    .line 59
    sget-object v4, Lk71;->c:Lh71;

    .line 60
    .line 61
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v4

    .line 65
    check-cast v4, Lxd0;

    .line 66
    .line 67
    invoke-virtual {p0, v2}, Lde0;->q(I)Les0;

    .line 68
    .line 69
    .line 70
    move-result-object v5

    .line 71
    invoke-static {v7, v4, v5}, Lde;->e(ILxd0;Les0;)I

    .line 72
    .line 73
    .line 74
    move-result v4

    .line 75
    :goto_4a
    add-int/2addr v3, v4

    .line 76
    goto/16 :goto_4d6

    .line 77
    .line 78
    :pswitch_4d
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v5

    .line 82
    if-eqz v5, :cond_4d6

    .line 83
    .line 84
    invoke-static {v8, v9, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 85
    .line 86
    .line 87
    move-result-wide v5

    .line 88
    invoke-static {v7}, Lde;->h(I)I

    .line 89
    .line 90
    .line 91
    move-result v7

    .line 92
    shl-long v8, v5, v11

    .line 93
    .line 94
    shr-long v4, v5, v4

    .line 95
    .line 96
    xor-long/2addr v4, v8

    .line 97
    invoke-static {v4, v5}, Lde;->k(J)I

    .line 98
    .line 99
    .line 100
    move-result v4

    .line 101
    :goto_64
    add-int/2addr v4, v7

    .line 102
    goto :goto_4a

    .line 103
    :pswitch_66
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v4

    .line 107
    if-eqz v4, :cond_4d6

    .line 108
    .line 109
    invoke-static {v8, v9, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 110
    .line 111
    .line 112
    move-result v4

    .line 113
    invoke-static {v7}, Lde;->h(I)I

    .line 114
    .line 115
    .line 116
    move-result v5

    .line 117
    shl-int/lit8 v6, v4, 0x1

    .line 118
    .line 119
    shr-int/lit8 v4, v4, 0x1f

    .line 120
    .line 121
    xor-int/2addr v4, v6

    .line 122
    invoke-static {v4}, Lde;->j(I)I

    .line 123
    .line 124
    .line 125
    move-result v4

    .line 126
    :goto_7d
    add-int/2addr v4, v5

    .line 127
    goto :goto_4a

    .line 128
    :pswitch_7f
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    move-result v4

    .line 132
    if-eqz v4, :cond_4d6

    .line 133
    .line 134
    :goto_85
    invoke-static {v7, v10, v3}, Lzi0;->w(III)I

    .line 135
    .line 136
    .line 137
    move-result v3

    .line 138
    goto/16 :goto_4d6

    .line 139
    .line 140
    :pswitch_8b
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 141
    .line 142
    .line 143
    move-result v4

    .line 144
    if-eqz v4, :cond_4d6

    .line 145
    .line 146
    :goto_91
    invoke-static {v7, v5, v3}, Lzi0;->w(III)I

    .line 147
    .line 148
    .line 149
    move-result v3

    .line 150
    goto/16 :goto_4d6

    .line 151
    .line 152
    :pswitch_97
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 153
    .line 154
    .line 155
    move-result v4

    .line 156
    if-eqz v4, :cond_4d6

    .line 157
    .line 158
    invoke-static {v8, v9, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 159
    .line 160
    .line 161
    move-result v4

    .line 162
    invoke-static {v7}, Lde;->h(I)I

    .line 163
    .line 164
    .line 165
    move-result v5

    .line 166
    invoke-static {v4}, Lde;->f(I)I

    .line 167
    .line 168
    .line 169
    move-result v4

    .line 170
    goto :goto_7d

    .line 171
    :pswitch_aa
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v4

    .line 175
    if-eqz v4, :cond_4d6

    .line 176
    .line 177
    invoke-static {v8, v9, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 178
    .line 179
    .line 180
    move-result v4

    .line 181
    invoke-static {v7, v4}, Lde;->i(II)I

    .line 182
    .line 183
    .line 184
    move-result v4

    .line 185
    goto :goto_4a

    .line 186
    :pswitch_b9
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 187
    .line 188
    .line 189
    move-result v4

    .line 190
    if-eqz v4, :cond_4d6

    .line 191
    .line 192
    sget-object v4, Lk71;->c:Lh71;

    .line 193
    .line 194
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 195
    .line 196
    .line 197
    move-result-object v4

    .line 198
    check-cast v4, Lqb;

    .line 199
    .line 200
    invoke-static {v7, v4}, Lde;->a(ILqb;)I

    .line 201
    .line 202
    .line 203
    move-result v4

    .line 204
    goto/16 :goto_4a

    .line 205
    .line 206
    :pswitch_cd
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 207
    .line 208
    .line 209
    move-result v4

    .line 210
    if-eqz v4, :cond_4d6

    .line 211
    .line 212
    sget-object v4, Lk71;->c:Lh71;

    .line 213
    .line 214
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 215
    .line 216
    .line 217
    move-result-object v4

    .line 218
    invoke-virtual {p0, v2}, Lde0;->q(I)Les0;

    .line 219
    .line 220
    .line 221
    move-result-object v5

    .line 222
    sget-object v6, Lis0;->a:Ljava/lang/Class;

    .line 223
    .line 224
    check-cast v4, Lxd0;

    .line 225
    .line 226
    invoke-static {v7}, Lde;->h(I)I

    .line 227
    .line 228
    .line 229
    move-result v6

    .line 230
    check-cast v4, Lr;

    .line 231
    .line 232
    invoke-virtual {v4, v5}, Lr;->getSerializedSize(Les0;)I

    .line 233
    .line 234
    .line 235
    move-result v4

    .line 236
    :goto_eb
    invoke-static {v4, v4, v6, v3}, Lzi0;->h(IIII)I

    .line 237
    .line 238
    .line 239
    move-result v3

    .line 240
    goto/16 :goto_4d6

    .line 241
    .line 242
    :pswitch_f1
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 243
    .line 244
    .line 245
    move-result v4

    .line 246
    if-eqz v4, :cond_4d6

    .line 247
    .line 248
    sget-object v4, Lk71;->c:Lh71;

    .line 249
    .line 250
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v4

    .line 254
    instance-of v5, v4, Lqb;

    .line 255
    .line 256
    if-eqz v5, :cond_111

    .line 257
    .line 258
    check-cast v4, Lqb;

    .line 259
    .line 260
    invoke-static {v7}, Lde;->h(I)I

    .line 261
    .line 262
    .line 263
    move-result v5

    .line 264
    invoke-virtual {v4}, Lqb;->size()I

    .line 265
    .line 266
    .line 267
    move-result v4

    .line 268
    :goto_10b
    invoke-static {v4, v4, v5, v3}, Lzi0;->h(IIII)I

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    goto/16 :goto_4d6

    .line 273
    .line 274
    :cond_111
    check-cast v4, Ljava/lang/String;

    .line 275
    .line 276
    invoke-static {v7}, Lde;->h(I)I

    .line 277
    .line 278
    .line 279
    move-result v5

    .line 280
    invoke-static {v4}, Lde;->g(Ljava/lang/String;)I

    .line 281
    .line 282
    .line 283
    move-result v4

    .line 284
    :goto_11b
    add-int/2addr v4, v5

    .line 285
    add-int/2addr v4, v3

    .line 286
    move v3, v4

    .line 287
    goto/16 :goto_4d6

    .line 288
    .line 289
    :pswitch_120
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 290
    .line 291
    .line 292
    move-result v4

    .line 293
    if-eqz v4, :cond_4d6

    .line 294
    .line 295
    :goto_126
    invoke-static {v7, v11, v3}, Lzi0;->w(III)I

    .line 296
    .line 297
    .line 298
    move-result v3

    .line 299
    goto/16 :goto_4d6

    .line 300
    .line 301
    :pswitch_12c
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 302
    .line 303
    .line 304
    move-result v4

    .line 305
    if-eqz v4, :cond_4d6

    .line 306
    .line 307
    invoke-static {v7}, Lde;->c(I)I

    .line 308
    .line 309
    .line 310
    move-result v4

    .line 311
    goto/16 :goto_4a

    .line 312
    .line 313
    :pswitch_138
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 314
    .line 315
    .line 316
    move-result v4

    .line 317
    if-eqz v4, :cond_4d6

    .line 318
    .line 319
    invoke-static {v7}, Lde;->d(I)I

    .line 320
    .line 321
    .line 322
    move-result v4

    .line 323
    goto/16 :goto_4a

    .line 324
    .line 325
    :pswitch_144
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 326
    .line 327
    .line 328
    move-result v4

    .line 329
    if-eqz v4, :cond_4d6

    .line 330
    .line 331
    invoke-static {v8, v9, p1}, Lde0;->F(JLjava/lang/Object;)I

    .line 332
    .line 333
    .line 334
    move-result v4

    .line 335
    invoke-static {v7}, Lde;->h(I)I

    .line 336
    .line 337
    .line 338
    move-result v5

    .line 339
    invoke-static {v4}, Lde;->f(I)I

    .line 340
    .line 341
    .line 342
    move-result v4

    .line 343
    goto/16 :goto_7d

    .line 344
    .line 345
    :pswitch_158
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 346
    .line 347
    .line 348
    move-result v4

    .line 349
    if-eqz v4, :cond_4d6

    .line 350
    .line 351
    invoke-static {v8, v9, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 352
    .line 353
    .line 354
    move-result-wide v4

    .line 355
    invoke-static {v7}, Lde;->h(I)I

    .line 356
    .line 357
    .line 358
    move-result v6

    .line 359
    invoke-static {v4, v5}, Lde;->k(J)I

    .line 360
    .line 361
    .line 362
    move-result v4

    .line 363
    :goto_16a
    add-int/2addr v4, v6

    .line 364
    goto/16 :goto_4a

    .line 365
    .line 366
    :pswitch_16d
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 367
    .line 368
    .line 369
    move-result v4

    .line 370
    if-eqz v4, :cond_4d6

    .line 371
    .line 372
    invoke-static {v8, v9, p1}, Lde0;->G(JLjava/lang/Object;)J

    .line 373
    .line 374
    .line 375
    move-result-wide v4

    .line 376
    invoke-static {v7}, Lde;->h(I)I

    .line 377
    .line 378
    .line 379
    move-result v6

    .line 380
    invoke-static {v4, v5}, Lde;->k(J)I

    .line 381
    .line 382
    .line 383
    move-result v4

    .line 384
    goto :goto_16a

    .line 385
    :pswitch_180
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 386
    .line 387
    .line 388
    move-result v4

    .line 389
    if-eqz v4, :cond_4d6

    .line 390
    .line 391
    goto/16 :goto_91

    .line 392
    .line 393
    :pswitch_188
    invoke-virtual {p0, v7, v2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 394
    .line 395
    .line 396
    move-result v4

    .line 397
    if-eqz v4, :cond_4d6

    .line 398
    .line 399
    goto/16 :goto_85

    .line 400
    .line 401
    :pswitch_190
    sget-object v4, Lk71;->c:Lh71;

    .line 402
    .line 403
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 404
    .line 405
    .line 406
    move-result-object v4

    .line 407
    invoke-virtual {p0, v2}, Lde0;->p(I)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object v5

    .line 411
    iget-object v6, p0, Lde0;->n:Lrb0;

    .line 412
    .line 413
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 414
    .line 415
    .line 416
    invoke-static {v4, v7, v5}, Lrb0;->a(Ljava/lang/Object;ILjava/lang/Object;)I

    .line 417
    .line 418
    .line 419
    move-result v4

    .line 420
    goto/16 :goto_4a

    .line 421
    .line 422
    :pswitch_1a5
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 423
    .line 424
    .line 425
    move-result-object v4

    .line 426
    invoke-virtual {p0, v2}, Lde0;->q(I)Les0;

    .line 427
    .line 428
    .line 429
    move-result-object v5

    .line 430
    sget-object v6, Lis0;->a:Ljava/lang/Class;

    .line 431
    .line 432
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 433
    .line 434
    .line 435
    move-result v6

    .line 436
    if-nez v6, :cond_1b7

    .line 437
    .line 438
    move v9, v1

    .line 439
    goto :goto_1c9

    .line 440
    :cond_1b7
    move v8, v1

    .line 441
    move v9, v8

    .line 442
    :goto_1b9
    if-ge v8, v6, :cond_1c9

    .line 443
    .line 444
    invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 445
    .line 446
    .line 447
    move-result-object v10

    .line 448
    check-cast v10, Lxd0;

    .line 449
    .line 450
    invoke-static {v7, v10, v5}, Lde;->e(ILxd0;Les0;)I

    .line 451
    .line 452
    .line 453
    move-result v10

    .line 454
    add-int/2addr v9, v10

    .line 455
    add-int/lit8 v8, v8, 0x1

    .line 456
    .line 457
    goto :goto_1b9

    .line 458
    :cond_1c9
    :goto_1c9
    add-int/2addr v3, v9

    .line 459
    goto/16 :goto_4d6

    .line 460
    .line 461
    :pswitch_1cc
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 462
    .line 463
    .line 464
    move-result-object v4

    .line 465
    check-cast v4, Ljava/util/List;

    .line 466
    .line 467
    invoke-static {v4}, Lis0;->p(Ljava/util/List;)I

    .line 468
    .line 469
    .line 470
    move-result v4

    .line 471
    if-lez v4, :cond_4d6

    .line 472
    .line 473
    invoke-static {v7}, Lde;->h(I)I

    .line 474
    .line 475
    .line 476
    move-result v5

    .line 477
    :goto_1dc
    invoke-static {v4, v5, v4, v3}, Lzi0;->h(IIII)I

    .line 478
    .line 479
    .line 480
    move-result v3

    .line 481
    goto/16 :goto_4d6

    .line 482
    .line 483
    :pswitch_1e2
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 484
    .line 485
    .line 486
    move-result-object v4

    .line 487
    check-cast v4, Ljava/util/List;

    .line 488
    .line 489
    invoke-static {v4}, Lis0;->n(Ljava/util/List;)I

    .line 490
    .line 491
    .line 492
    move-result v4

    .line 493
    if-lez v4, :cond_4d6

    .line 494
    .line 495
    invoke-static {v7}, Lde;->h(I)I

    .line 496
    .line 497
    .line 498
    move-result v5

    .line 499
    goto :goto_1dc

    .line 500
    :pswitch_1f3
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 501
    .line 502
    .line 503
    move-result-object v4

    .line 504
    check-cast v4, Ljava/util/List;

    .line 505
    .line 506
    invoke-static {v4}, Lis0;->g(Ljava/util/List;)I

    .line 507
    .line 508
    .line 509
    move-result v4

    .line 510
    if-lez v4, :cond_4d6

    .line 511
    .line 512
    invoke-static {v7}, Lde;->h(I)I

    .line 513
    .line 514
    .line 515
    move-result v5

    .line 516
    goto :goto_1dc

    .line 517
    :pswitch_204
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 518
    .line 519
    .line 520
    move-result-object v4

    .line 521
    check-cast v4, Ljava/util/List;

    .line 522
    .line 523
    invoke-static {v4}, Lis0;->e(Ljava/util/List;)I

    .line 524
    .line 525
    .line 526
    move-result v4

    .line 527
    if-lez v4, :cond_4d6

    .line 528
    .line 529
    invoke-static {v7}, Lde;->h(I)I

    .line 530
    .line 531
    .line 532
    move-result v5

    .line 533
    goto :goto_1dc

    .line 534
    :pswitch_215
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 535
    .line 536
    .line 537
    move-result-object v4

    .line 538
    check-cast v4, Ljava/util/List;

    .line 539
    .line 540
    invoke-static {v4}, Lis0;->c(Ljava/util/List;)I

    .line 541
    .line 542
    .line 543
    move-result v4

    .line 544
    if-lez v4, :cond_4d6

    .line 545
    .line 546
    invoke-static {v7}, Lde;->h(I)I

    .line 547
    .line 548
    .line 549
    move-result v5

    .line 550
    goto :goto_1dc

    .line 551
    :pswitch_226
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 552
    .line 553
    .line 554
    move-result-object v4

    .line 555
    check-cast v4, Ljava/util/List;

    .line 556
    .line 557
    invoke-static {v4}, Lis0;->s(Ljava/util/List;)I

    .line 558
    .line 559
    .line 560
    move-result v4

    .line 561
    if-lez v4, :cond_4d6

    .line 562
    .line 563
    invoke-static {v7}, Lde;->h(I)I

    .line 564
    .line 565
    .line 566
    move-result v5

    .line 567
    goto :goto_1dc

    .line 568
    :pswitch_237
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 569
    .line 570
    .line 571
    move-result-object v4

    .line 572
    check-cast v4, Ljava/util/List;

    .line 573
    .line 574
    sget-object v5, Lis0;->a:Ljava/lang/Class;

    .line 575
    .line 576
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 577
    .line 578
    .line 579
    move-result v4

    .line 580
    if-lez v4, :cond_4d6

    .line 581
    .line 582
    invoke-static {v7}, Lde;->h(I)I

    .line 583
    .line 584
    .line 585
    move-result v5

    .line 586
    goto :goto_1dc

    .line 587
    :pswitch_24a
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 588
    .line 589
    .line 590
    move-result-object v4

    .line 591
    check-cast v4, Ljava/util/List;

    .line 592
    .line 593
    invoke-static {v4}, Lis0;->e(Ljava/util/List;)I

    .line 594
    .line 595
    .line 596
    move-result v4

    .line 597
    if-lez v4, :cond_4d6

    .line 598
    .line 599
    invoke-static {v7}, Lde;->h(I)I

    .line 600
    .line 601
    .line 602
    move-result v5

    .line 603
    goto :goto_1dc

    .line 604
    :pswitch_25b
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 605
    .line 606
    .line 607
    move-result-object v4

    .line 608
    check-cast v4, Ljava/util/List;

    .line 609
    .line 610
    invoke-static {v4}, Lis0;->g(Ljava/util/List;)I

    .line 611
    .line 612
    .line 613
    move-result v4

    .line 614
    if-lez v4, :cond_4d6

    .line 615
    .line 616
    invoke-static {v7}, Lde;->h(I)I

    .line 617
    .line 618
    .line 619
    move-result v5

    .line 620
    goto/16 :goto_1dc

    .line 621
    .line 622
    :pswitch_26d
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 623
    .line 624
    .line 625
    move-result-object v4

    .line 626
    check-cast v4, Ljava/util/List;

    .line 627
    .line 628
    invoke-static {v4}, Lis0;->i(Ljava/util/List;)I

    .line 629
    .line 630
    .line 631
    move-result v4

    .line 632
    if-lez v4, :cond_4d6

    .line 633
    .line 634
    invoke-static {v7}, Lde;->h(I)I

    .line 635
    .line 636
    .line 637
    move-result v5

    .line 638
    goto/16 :goto_1dc

    .line 639
    .line 640
    :pswitch_27f
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 641
    .line 642
    .line 643
    move-result-object v4

    .line 644
    check-cast v4, Ljava/util/List;

    .line 645
    .line 646
    invoke-static {v4}, Lis0;->u(Ljava/util/List;)I

    .line 647
    .line 648
    .line 649
    move-result v4

    .line 650
    if-lez v4, :cond_4d6

    .line 651
    .line 652
    invoke-static {v7}, Lde;->h(I)I

    .line 653
    .line 654
    .line 655
    move-result v5

    .line 656
    goto/16 :goto_1dc

    .line 657
    .line 658
    :pswitch_291
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 659
    .line 660
    .line 661
    move-result-object v4

    .line 662
    check-cast v4, Ljava/util/List;

    .line 663
    .line 664
    invoke-static {v4}, Lis0;->k(Ljava/util/List;)I

    .line 665
    .line 666
    .line 667
    move-result v4

    .line 668
    if-lez v4, :cond_4d6

    .line 669
    .line 670
    invoke-static {v7}, Lde;->h(I)I

    .line 671
    .line 672
    .line 673
    move-result v5

    .line 674
    goto/16 :goto_1dc

    .line 675
    .line 676
    :pswitch_2a3
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 677
    .line 678
    .line 679
    move-result-object v4

    .line 680
    check-cast v4, Ljava/util/List;

    .line 681
    .line 682
    invoke-static {v4}, Lis0;->e(Ljava/util/List;)I

    .line 683
    .line 684
    .line 685
    move-result v4

    .line 686
    if-lez v4, :cond_4d6

    .line 687
    .line 688
    invoke-static {v7}, Lde;->h(I)I

    .line 689
    .line 690
    .line 691
    move-result v5

    .line 692
    goto/16 :goto_1dc

    .line 693
    .line 694
    :pswitch_2b5
    invoke-virtual {v0, p1, v8, v9}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 695
    .line 696
    .line 697
    move-result-object v4

    .line 698
    check-cast v4, Ljava/util/List;

    .line 699
    .line 700
    invoke-static {v4}, Lis0;->g(Ljava/util/List;)I

    .line 701
    .line 702
    .line 703
    move-result v4

    .line 704
    if-lez v4, :cond_4d6

    .line 705
    .line 706
    invoke-static {v7}, Lde;->h(I)I

    .line 707
    .line 708
    .line 709
    move-result v5

    .line 710
    goto/16 :goto_1dc

    .line 711
    .line 712
    :pswitch_2c7
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 713
    .line 714
    .line 715
    move-result-object v4

    .line 716
    invoke-static {v4, v7}, Lis0;->o(Ljava/util/List;I)I

    .line 717
    .line 718
    .line 719
    move-result v4

    .line 720
    goto/16 :goto_4a

    .line 721
    .line 722
    :pswitch_2d1
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 723
    .line 724
    .line 725
    move-result-object v4

    .line 726
    invoke-static {v4, v7}, Lis0;->m(Ljava/util/List;I)I

    .line 727
    .line 728
    .line 729
    move-result v4

    .line 730
    goto/16 :goto_4a

    .line 731
    .line 732
    :pswitch_2db
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 733
    .line 734
    .line 735
    move-result-object v4

    .line 736
    invoke-static {v4, v7}, Lis0;->f(Ljava/util/List;I)I

    .line 737
    .line 738
    .line 739
    move-result v4

    .line 740
    goto/16 :goto_4a

    .line 741
    .line 742
    :pswitch_2e5
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 743
    .line 744
    .line 745
    move-result-object v4

    .line 746
    invoke-static {v4, v7}, Lis0;->d(Ljava/util/List;I)I

    .line 747
    .line 748
    .line 749
    move-result v4

    .line 750
    goto/16 :goto_4a

    .line 751
    .line 752
    :pswitch_2ef
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 753
    .line 754
    .line 755
    move-result-object v4

    .line 756
    invoke-static {v4, v7}, Lis0;->b(Ljava/util/List;I)I

    .line 757
    .line 758
    .line 759
    move-result v4

    .line 760
    goto/16 :goto_4a

    .line 761
    .line 762
    :pswitch_2f9
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 763
    .line 764
    .line 765
    move-result-object v4

    .line 766
    invoke-static {v4, v7}, Lis0;->r(Ljava/util/List;I)I

    .line 767
    .line 768
    .line 769
    move-result v4

    .line 770
    goto/16 :goto_4a

    .line 771
    .line 772
    :pswitch_303
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 773
    .line 774
    .line 775
    move-result-object v4

    .line 776
    invoke-static {v4, v7}, Lis0;->a(Ljava/util/List;I)I

    .line 777
    .line 778
    .line 779
    move-result v4

    .line 780
    goto/16 :goto_4a

    .line 781
    .line 782
    :pswitch_30d
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 783
    .line 784
    .line 785
    move-result-object v4

    .line 786
    invoke-virtual {p0, v2}, Lde0;->q(I)Les0;

    .line 787
    .line 788
    .line 789
    move-result-object v5

    .line 790
    invoke-static {v7, v4, v5}, Lis0;->l(ILjava/util/List;Les0;)I

    .line 791
    .line 792
    .line 793
    move-result v4

    .line 794
    goto/16 :goto_4a

    .line 795
    .line 796
    :pswitch_31b
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 797
    .line 798
    .line 799
    move-result-object v4

    .line 800
    invoke-static {v4, v7}, Lis0;->q(Ljava/util/List;I)I

    .line 801
    .line 802
    .line 803
    move-result v4

    .line 804
    goto/16 :goto_4a

    .line 805
    .line 806
    :pswitch_325
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 807
    .line 808
    .line 809
    move-result-object v4

    .line 810
    sget-object v5, Lis0;->a:Ljava/lang/Class;

    .line 811
    .line 812
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 813
    .line 814
    .line 815
    move-result v4

    .line 816
    if-nez v4, :cond_333

    .line 817
    .line 818
    move v5, v1

    .line 819
    goto :goto_339

    .line 820
    :cond_333
    invoke-static {v7}, Lde;->h(I)I

    .line 821
    .line 822
    .line 823
    move-result v5

    .line 824
    add-int/2addr v5, v11

    .line 825
    mul-int/2addr v5, v4

    .line 826
    :goto_339
    add-int/2addr v3, v5

    .line 827
    goto/16 :goto_4d6

    .line 828
    .line 829
    :pswitch_33c
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 830
    .line 831
    .line 832
    move-result-object v4

    .line 833
    invoke-static {v4, v7}, Lis0;->d(Ljava/util/List;I)I

    .line 834
    .line 835
    .line 836
    move-result v4

    .line 837
    goto/16 :goto_4a

    .line 838
    .line 839
    :pswitch_346
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 840
    .line 841
    .line 842
    move-result-object v4

    .line 843
    invoke-static {v4, v7}, Lis0;->f(Ljava/util/List;I)I

    .line 844
    .line 845
    .line 846
    move-result v4

    .line 847
    goto/16 :goto_4a

    .line 848
    .line 849
    :pswitch_350
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 850
    .line 851
    .line 852
    move-result-object v4

    .line 853
    invoke-static {v4, v7}, Lis0;->h(Ljava/util/List;I)I

    .line 854
    .line 855
    .line 856
    move-result v4

    .line 857
    goto/16 :goto_4a

    .line 858
    .line 859
    :pswitch_35a
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 860
    .line 861
    .line 862
    move-result-object v4

    .line 863
    invoke-static {v4, v7}, Lis0;->t(Ljava/util/List;I)I

    .line 864
    .line 865
    .line 866
    move-result v4

    .line 867
    goto/16 :goto_4a

    .line 868
    .line 869
    :pswitch_364
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 870
    .line 871
    .line 872
    move-result-object v4

    .line 873
    invoke-static {v4, v7}, Lis0;->j(Ljava/util/List;I)I

    .line 874
    .line 875
    .line 876
    move-result v4

    .line 877
    goto/16 :goto_4a

    .line 878
    .line 879
    :pswitch_36e
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 880
    .line 881
    .line 882
    move-result-object v4

    .line 883
    invoke-static {v4, v7}, Lis0;->d(Ljava/util/List;I)I

    .line 884
    .line 885
    .line 886
    move-result v4

    .line 887
    goto/16 :goto_4a

    .line 888
    .line 889
    :pswitch_378
    invoke-static {p1, v8, v9}, Lde0;->w(Lr00;J)Ljava/util/List;

    .line 890
    .line 891
    .line 892
    move-result-object v4

    .line 893
    invoke-static {v4, v7}, Lis0;->f(Ljava/util/List;I)I

    .line 894
    .line 895
    .line 896
    move-result v4

    .line 897
    goto/16 :goto_4a

    .line 898
    .line 899
    :pswitch_382
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 900
    .line 901
    .line 902
    move-result v4

    .line 903
    if-eqz v4, :cond_4d6

    .line 904
    .line 905
    sget-object v4, Lk71;->c:Lh71;

    .line 906
    .line 907
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 908
    .line 909
    .line 910
    move-result-object v4

    .line 911
    check-cast v4, Lxd0;

    .line 912
    .line 913
    invoke-virtual {p0, v2}, Lde0;->q(I)Les0;

    .line 914
    .line 915
    .line 916
    move-result-object v5

    .line 917
    invoke-static {v7, v4, v5}, Lde;->e(ILxd0;Les0;)I

    .line 918
    .line 919
    .line 920
    move-result v4

    .line 921
    goto/16 :goto_4a

    .line 922
    .line 923
    :pswitch_39a
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 924
    .line 925
    .line 926
    move-result v5

    .line 927
    if-eqz v5, :cond_4d6

    .line 928
    .line 929
    sget-object v5, Lk71;->c:Lh71;

    .line 930
    .line 931
    invoke-virtual {v5, v8, v9, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 932
    .line 933
    .line 934
    move-result-wide v5

    .line 935
    invoke-static {v7}, Lde;->h(I)I

    .line 936
    .line 937
    .line 938
    move-result v7

    .line 939
    shl-long v8, v5, v11

    .line 940
    .line 941
    shr-long v4, v5, v4

    .line 942
    .line 943
    xor-long/2addr v4, v8

    .line 944
    invoke-static {v4, v5}, Lde;->k(J)I

    .line 945
    .line 946
    .line 947
    move-result v4

    .line 948
    goto/16 :goto_64

    .line 949
    .line 950
    :pswitch_3b5
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 951
    .line 952
    .line 953
    move-result v4

    .line 954
    if-eqz v4, :cond_4d6

    .line 955
    .line 956
    sget-object v4, Lk71;->c:Lh71;

    .line 957
    .line 958
    invoke-virtual {v4, v8, v9, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 959
    .line 960
    .line 961
    move-result v4

    .line 962
    invoke-static {v7}, Lde;->h(I)I

    .line 963
    .line 964
    .line 965
    move-result v5

    .line 966
    shl-int/lit8 v6, v4, 0x1

    .line 967
    .line 968
    shr-int/lit8 v4, v4, 0x1f

    .line 969
    .line 970
    xor-int/2addr v4, v6

    .line 971
    invoke-static {v4}, Lde;->j(I)I

    .line 972
    .line 973
    .line 974
    move-result v4

    .line 975
    goto/16 :goto_7d

    .line 976
    .line 977
    :pswitch_3d0
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 978
    .line 979
    .line 980
    move-result v4

    .line 981
    if-eqz v4, :cond_4d6

    .line 982
    .line 983
    goto/16 :goto_85

    .line 984
    .line 985
    :pswitch_3d8
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 986
    .line 987
    .line 988
    move-result v4

    .line 989
    if-eqz v4, :cond_4d6

    .line 990
    .line 991
    goto/16 :goto_91

    .line 992
    .line 993
    :pswitch_3e0
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 994
    .line 995
    .line 996
    move-result v4

    .line 997
    if-eqz v4, :cond_4d6

    .line 998
    .line 999
    sget-object v4, Lk71;->c:Lh71;

    .line 1000
    .line 1001
    invoke-virtual {v4, v8, v9, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1002
    .line 1003
    .line 1004
    move-result v4

    .line 1005
    invoke-static {v7}, Lde;->h(I)I

    .line 1006
    .line 1007
    .line 1008
    move-result v5

    .line 1009
    invoke-static {v4}, Lde;->f(I)I

    .line 1010
    .line 1011
    .line 1012
    move-result v4

    .line 1013
    goto/16 :goto_7d

    .line 1014
    .line 1015
    :pswitch_3f6
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1016
    .line 1017
    .line 1018
    move-result v4

    .line 1019
    if-eqz v4, :cond_4d6

    .line 1020
    .line 1021
    sget-object v4, Lk71;->c:Lh71;

    .line 1022
    .line 1023
    invoke-virtual {v4, v8, v9, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1024
    .line 1025
    .line 1026
    move-result v4

    .line 1027
    invoke-static {v7, v4}, Lde;->i(II)I

    .line 1028
    .line 1029
    .line 1030
    move-result v4

    .line 1031
    goto/16 :goto_4a

    .line 1032
    .line 1033
    :pswitch_408
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1034
    .line 1035
    .line 1036
    move-result v4

    .line 1037
    if-eqz v4, :cond_4d6

    .line 1038
    .line 1039
    sget-object v4, Lk71;->c:Lh71;

    .line 1040
    .line 1041
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 1042
    .line 1043
    .line 1044
    move-result-object v4

    .line 1045
    check-cast v4, Lqb;

    .line 1046
    .line 1047
    invoke-static {v7, v4}, Lde;->a(ILqb;)I

    .line 1048
    .line 1049
    .line 1050
    move-result v4

    .line 1051
    goto/16 :goto_4a

    .line 1052
    .line 1053
    :pswitch_41c
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1054
    .line 1055
    .line 1056
    move-result v4

    .line 1057
    if-eqz v4, :cond_4d6

    .line 1058
    .line 1059
    sget-object v4, Lk71;->c:Lh71;

    .line 1060
    .line 1061
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 1062
    .line 1063
    .line 1064
    move-result-object v4

    .line 1065
    invoke-virtual {p0, v2}, Lde0;->q(I)Les0;

    .line 1066
    .line 1067
    .line 1068
    move-result-object v5

    .line 1069
    sget-object v6, Lis0;->a:Ljava/lang/Class;

    .line 1070
    .line 1071
    check-cast v4, Lxd0;

    .line 1072
    .line 1073
    invoke-static {v7}, Lde;->h(I)I

    .line 1074
    .line 1075
    .line 1076
    move-result v6

    .line 1077
    check-cast v4, Lr;

    .line 1078
    .line 1079
    invoke-virtual {v4, v5}, Lr;->getSerializedSize(Les0;)I

    .line 1080
    .line 1081
    .line 1082
    move-result v4

    .line 1083
    goto/16 :goto_eb

    .line 1084
    .line 1085
    :pswitch_43c
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1086
    .line 1087
    .line 1088
    move-result v4

    .line 1089
    if-eqz v4, :cond_4d6

    .line 1090
    .line 1091
    sget-object v4, Lk71;->c:Lh71;

    .line 1092
    .line 1093
    invoke-virtual {v4, v8, v9, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 1094
    .line 1095
    .line 1096
    move-result-object v4

    .line 1097
    instance-of v5, v4, Lqb;

    .line 1098
    .line 1099
    if-eqz v5, :cond_458

    .line 1100
    .line 1101
    check-cast v4, Lqb;

    .line 1102
    .line 1103
    invoke-static {v7}, Lde;->h(I)I

    .line 1104
    .line 1105
    .line 1106
    move-result v5

    .line 1107
    invoke-virtual {v4}, Lqb;->size()I

    .line 1108
    .line 1109
    .line 1110
    move-result v4

    .line 1111
    goto/16 :goto_10b

    .line 1112
    .line 1113
    :cond_458
    check-cast v4, Ljava/lang/String;

    .line 1114
    .line 1115
    invoke-static {v7}, Lde;->h(I)I

    .line 1116
    .line 1117
    .line 1118
    move-result v5

    .line 1119
    invoke-static {v4}, Lde;->g(Ljava/lang/String;)I

    .line 1120
    .line 1121
    .line 1122
    move-result v4

    .line 1123
    goto/16 :goto_11b

    .line 1124
    .line 1125
    :pswitch_464
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1126
    .line 1127
    .line 1128
    move-result v4

    .line 1129
    if-eqz v4, :cond_4d6

    .line 1130
    .line 1131
    goto/16 :goto_126

    .line 1132
    .line 1133
    :pswitch_46c
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1134
    .line 1135
    .line 1136
    move-result v4

    .line 1137
    if-eqz v4, :cond_4d6

    .line 1138
    .line 1139
    invoke-static {v7}, Lde;->c(I)I

    .line 1140
    .line 1141
    .line 1142
    move-result v4

    .line 1143
    goto/16 :goto_4a

    .line 1144
    .line 1145
    :pswitch_478
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1146
    .line 1147
    .line 1148
    move-result v4

    .line 1149
    if-eqz v4, :cond_4d6

    .line 1150
    .line 1151
    invoke-static {v7}, Lde;->d(I)I

    .line 1152
    .line 1153
    .line 1154
    move-result v4

    .line 1155
    goto/16 :goto_4a

    .line 1156
    .line 1157
    :pswitch_484
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1158
    .line 1159
    .line 1160
    move-result v4

    .line 1161
    if-eqz v4, :cond_4d6

    .line 1162
    .line 1163
    sget-object v4, Lk71;->c:Lh71;

    .line 1164
    .line 1165
    invoke-virtual {v4, v8, v9, p1}, Lh71;->i(JLjava/lang/Object;)I

    .line 1166
    .line 1167
    .line 1168
    move-result v4

    .line 1169
    invoke-static {v7}, Lde;->h(I)I

    .line 1170
    .line 1171
    .line 1172
    move-result v5

    .line 1173
    invoke-static {v4}, Lde;->f(I)I

    .line 1174
    .line 1175
    .line 1176
    move-result v4

    .line 1177
    goto/16 :goto_7d

    .line 1178
    .line 1179
    :pswitch_49a
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1180
    .line 1181
    .line 1182
    move-result v4

    .line 1183
    if-eqz v4, :cond_4d6

    .line 1184
    .line 1185
    sget-object v4, Lk71;->c:Lh71;

    .line 1186
    .line 1187
    invoke-virtual {v4, v8, v9, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1188
    .line 1189
    .line 1190
    move-result-wide v4

    .line 1191
    invoke-static {v7}, Lde;->h(I)I

    .line 1192
    .line 1193
    .line 1194
    move-result v6

    .line 1195
    invoke-static {v4, v5}, Lde;->k(J)I

    .line 1196
    .line 1197
    .line 1198
    move-result v4

    .line 1199
    goto/16 :goto_16a

    .line 1200
    .line 1201
    :pswitch_4b0
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1202
    .line 1203
    .line 1204
    move-result v4

    .line 1205
    if-eqz v4, :cond_4d6

    .line 1206
    .line 1207
    sget-object v4, Lk71;->c:Lh71;

    .line 1208
    .line 1209
    invoke-virtual {v4, v8, v9, p1}, Lh71;->j(JLjava/lang/Object;)J

    .line 1210
    .line 1211
    .line 1212
    move-result-wide v4

    .line 1213
    invoke-static {v7}, Lde;->h(I)I

    .line 1214
    .line 1215
    .line 1216
    move-result v6

    .line 1217
    invoke-static {v4, v5}, Lde;->k(J)I

    .line 1218
    .line 1219
    .line 1220
    move-result v4

    .line 1221
    goto/16 :goto_16a

    .line 1222
    .line 1223
    :pswitch_4c6
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1224
    .line 1225
    .line 1226
    move-result v4

    .line 1227
    if-eqz v4, :cond_4d6

    .line 1228
    .line 1229
    goto/16 :goto_91

    .line 1230
    .line 1231
    :pswitch_4ce
    invoke-virtual {p0, v2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 1232
    .line 1233
    .line 1234
    move-result v4

    .line 1235
    if-eqz v4, :cond_4d6

    .line 1236
    .line 1237
    goto/16 :goto_85

    .line 1238
    .line 1239
    :cond_4d6
    :goto_4d6
    add-int/lit8 v2, v2, 0x3

    .line 1240
    .line 1241
    goto/16 :goto_5

    .line 1242
    .line 1243
    :cond_4da
    iget-object p0, p0, Lde0;->m:Lp61;

    .line 1244
    .line 1245
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1246
    .line 1247
    .line 1248
    iget-object p0, p1, Lr00;->unknownFields:Lm61;

    .line 1249
    .line 1250
    invoke-virtual {p0}, Lm61;->c()I

    .line 1251
    .line 1252
    .line 1253
    move-result p0

    .line 1254
    add-int/2addr p0, v3

    .line 1255
    return p0

    .line 1256
    nop

    .line 1257
    :pswitch_data_4e8
    .packed-switch 0x0
        :pswitch_4ce
        :pswitch_4c6
        :pswitch_4b0
        :pswitch_49a
        :pswitch_484
        :pswitch_478
        :pswitch_46c
        :pswitch_464
        :pswitch_43c
        :pswitch_41c
        :pswitch_408
        :pswitch_3f6
        :pswitch_3e0
        :pswitch_3d8
        :pswitch_3d0
        :pswitch_3b5
        :pswitch_39a
        :pswitch_382
        :pswitch_378
        :pswitch_36e
        :pswitch_364
        :pswitch_35a
        :pswitch_350
        :pswitch_346
        :pswitch_33c
        :pswitch_325
        :pswitch_31b
        :pswitch_30d
        :pswitch_303
        :pswitch_2f9
        :pswitch_2ef
        :pswitch_2e5
        :pswitch_2db
        :pswitch_2d1
        :pswitch_2c7
        :pswitch_2b5
        :pswitch_2a3
        :pswitch_291
        :pswitch_27f
        :pswitch_26d
        :pswitch_25b
        :pswitch_24a
        :pswitch_237
        :pswitch_226
        :pswitch_215
        :pswitch_204
        :pswitch_1f3
        :pswitch_1e2
        :pswitch_1cc
        :pswitch_1a5
        :pswitch_190
        :pswitch_188
        :pswitch_180
        :pswitch_16d
        :pswitch_158
        :pswitch_144
        :pswitch_138
        :pswitch_12c
        :pswitch_120
        :pswitch_f1
        :pswitch_cd
        :pswitch_b9
        :pswitch_aa
        :pswitch_97
        :pswitch_8b
        :pswitch_7f
        :pswitch_66
        :pswitch_4d
        :pswitch_34
    .end packed-switch
.end method

.method public final t(ILjava/lang/Object;)Z
    .registers 10

    .line 1
    add-int/lit8 v0, p1, 0x2

    .line 2
    .line 3
    iget-object v1, p0, Lde0;->a:[I

    .line 4
    .line 5
    aget v0, v1, v0

    .line 6
    .line 7
    const v1, 0xfffff

    .line 8
    .line 9
    .line 10
    and-int v2, v0, v1

    .line 11
    .line 12
    int-to-long v2, v2

    .line 13
    const-wide/32 v4, 0xfffff

    .line 14
    .line 15
    .line 16
    cmp-long v4, v2, v4

    .line 17
    .line 18
    const/4 v5, 0x0

    .line 19
    const/4 v6, 0x1

    .line 20
    if-nez v4, :cond_103

    .line 21
    .line 22
    invoke-virtual {p0, p1}, Lde0;->W(I)I

    .line 23
    .line 24
    .line 25
    move-result p0

    .line 26
    and-int p1, p0, v1

    .line 27
    .line 28
    int-to-long v0, p1

    .line 29
    invoke-static {p0}, Lde0;->V(I)I

    .line 30
    .line 31
    .line 32
    move-result p0

    .line 33
    const-wide/16 v2, 0x0

    .line 34
    .line 35
    packed-switch p0, :pswitch_data_112

    .line 36
    .line 37
    .line 38
    invoke-static {}, Lm0;->a()V

    .line 39
    .line 40
    .line 41
    return v5

    .line 42
    :pswitch_29
    sget-object p0, Lk71;->c:Lh71;

    .line 43
    .line 44
    invoke-virtual {p0, v0, v1, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    if-eqz p0, :cond_111

    .line 49
    .line 50
    goto/16 :goto_110

    .line 51
    .line 52
    :pswitch_33
    sget-object p0, Lk71;->c:Lh71;

    .line 53
    .line 54
    invoke-virtual {p0, v0, v1, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 55
    .line 56
    .line 57
    move-result-wide p0

    .line 58
    cmp-long p0, p0, v2

    .line 59
    .line 60
    if-eqz p0, :cond_111

    .line 61
    .line 62
    goto/16 :goto_110

    .line 63
    .line 64
    :pswitch_3f
    sget-object p0, Lk71;->c:Lh71;

    .line 65
    .line 66
    invoke-virtual {p0, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 67
    .line 68
    .line 69
    move-result p0

    .line 70
    if-eqz p0, :cond_111

    .line 71
    .line 72
    goto/16 :goto_110

    .line 73
    .line 74
    :pswitch_49
    sget-object p0, Lk71;->c:Lh71;

    .line 75
    .line 76
    invoke-virtual {p0, v0, v1, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 77
    .line 78
    .line 79
    move-result-wide p0

    .line 80
    cmp-long p0, p0, v2

    .line 81
    .line 82
    if-eqz p0, :cond_111

    .line 83
    .line 84
    goto/16 :goto_110

    .line 85
    .line 86
    :pswitch_55
    sget-object p0, Lk71;->c:Lh71;

    .line 87
    .line 88
    invoke-virtual {p0, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 89
    .line 90
    .line 91
    move-result p0

    .line 92
    if-eqz p0, :cond_111

    .line 93
    .line 94
    goto/16 :goto_110

    .line 95
    .line 96
    :pswitch_5f
    sget-object p0, Lk71;->c:Lh71;

    .line 97
    .line 98
    invoke-virtual {p0, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 99
    .line 100
    .line 101
    move-result p0

    .line 102
    if-eqz p0, :cond_111

    .line 103
    .line 104
    goto/16 :goto_110

    .line 105
    .line 106
    :pswitch_69
    sget-object p0, Lk71;->c:Lh71;

    .line 107
    .line 108
    invoke-virtual {p0, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 109
    .line 110
    .line 111
    move-result p0

    .line 112
    if-eqz p0, :cond_111

    .line 113
    .line 114
    goto/16 :goto_110

    .line 115
    .line 116
    :pswitch_73
    sget-object p0, Lqb;->g:Lnb;

    .line 117
    .line 118
    sget-object p1, Lk71;->c:Lh71;

    .line 119
    .line 120
    invoke-virtual {p1, v0, v1, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p1

    .line 124
    invoke-virtual {p0, p1}, Lnb;->equals(Ljava/lang/Object;)Z

    .line 125
    .line 126
    .line 127
    move-result p0

    .line 128
    xor-int/2addr p0, v6

    .line 129
    return p0

    .line 130
    :pswitch_81
    sget-object p0, Lk71;->c:Lh71;

    .line 131
    .line 132
    invoke-virtual {p0, v0, v1, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    if-eqz p0, :cond_111

    .line 137
    .line 138
    goto/16 :goto_110

    .line 139
    .line 140
    :pswitch_8b
    sget-object p0, Lk71;->c:Lh71;

    .line 141
    .line 142
    invoke-virtual {p0, v0, v1, p2}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object p0

    .line 146
    instance-of p1, p0, Ljava/lang/String;

    .line 147
    .line 148
    if-eqz p1, :cond_9d

    .line 149
    .line 150
    check-cast p0, Ljava/lang/String;

    .line 151
    .line 152
    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    .line 153
    .line 154
    .line 155
    move-result p0

    .line 156
    xor-int/2addr p0, v6

    .line 157
    return p0

    .line 158
    :cond_9d
    instance-of p1, p0, Lqb;

    .line 159
    .line 160
    if-eqz p1, :cond_a9

    .line 161
    .line 162
    sget-object p1, Lqb;->g:Lnb;

    .line 163
    .line 164
    invoke-virtual {p1, p0}, Lnb;->equals(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result p0

    .line 168
    xor-int/2addr p0, v6

    .line 169
    return p0

    .line 170
    :cond_a9
    invoke-static {}, Lm0;->a()V

    .line 171
    .line 172
    .line 173
    return v5

    .line 174
    :pswitch_ad
    sget-object p0, Lk71;->c:Lh71;

    .line 175
    .line 176
    invoke-virtual {p0, v0, v1, p2}, Lh71;->d(JLjava/lang/Object;)Z

    .line 177
    .line 178
    .line 179
    move-result p0

    .line 180
    return p0

    .line 181
    :pswitch_b4
    sget-object p0, Lk71;->c:Lh71;

    .line 182
    .line 183
    invoke-virtual {p0, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 184
    .line 185
    .line 186
    move-result p0

    .line 187
    if-eqz p0, :cond_111

    .line 188
    .line 189
    goto :goto_110

    .line 190
    :pswitch_bd
    sget-object p0, Lk71;->c:Lh71;

    .line 191
    .line 192
    invoke-virtual {p0, v0, v1, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 193
    .line 194
    .line 195
    move-result-wide p0

    .line 196
    cmp-long p0, p0, v2

    .line 197
    .line 198
    if-eqz p0, :cond_111

    .line 199
    .line 200
    goto :goto_110

    .line 201
    :pswitch_c8
    sget-object p0, Lk71;->c:Lh71;

    .line 202
    .line 203
    invoke-virtual {p0, v0, v1, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 204
    .line 205
    .line 206
    move-result p0

    .line 207
    if-eqz p0, :cond_111

    .line 208
    .line 209
    goto :goto_110

    .line 210
    :pswitch_d1
    sget-object p0, Lk71;->c:Lh71;

    .line 211
    .line 212
    invoke-virtual {p0, v0, v1, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 213
    .line 214
    .line 215
    move-result-wide p0

    .line 216
    cmp-long p0, p0, v2

    .line 217
    .line 218
    if-eqz p0, :cond_111

    .line 219
    .line 220
    goto :goto_110

    .line 221
    :pswitch_dc
    sget-object p0, Lk71;->c:Lh71;

    .line 222
    .line 223
    invoke-virtual {p0, v0, v1, p2}, Lh71;->j(JLjava/lang/Object;)J

    .line 224
    .line 225
    .line 226
    move-result-wide p0

    .line 227
    cmp-long p0, p0, v2

    .line 228
    .line 229
    if-eqz p0, :cond_111

    .line 230
    .line 231
    goto :goto_110

    .line 232
    :pswitch_e7
    sget-object p0, Lk71;->c:Lh71;

    .line 233
    .line 234
    invoke-virtual {p0, v0, v1, p2}, Lh71;->h(JLjava/lang/Object;)F

    .line 235
    .line 236
    .line 237
    move-result p0

    .line 238
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 239
    .line 240
    .line 241
    move-result p0

    .line 242
    if-eqz p0, :cond_111

    .line 243
    .line 244
    goto :goto_110

    .line 245
    :pswitch_f4
    sget-object p0, Lk71;->c:Lh71;

    .line 246
    .line 247
    invoke-virtual {p0, v0, v1, p2}, Lh71;->g(JLjava/lang/Object;)D

    .line 248
    .line 249
    .line 250
    move-result-wide p0

    .line 251
    invoke-static {p0, p1}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 252
    .line 253
    .line 254
    move-result-wide p0

    .line 255
    cmp-long p0, p0, v2

    .line 256
    .line 257
    if-eqz p0, :cond_111

    .line 258
    .line 259
    goto :goto_110

    .line 260
    :cond_103
    ushr-int/lit8 p0, v0, 0x14

    .line 261
    .line 262
    shl-int p0, v6, p0

    .line 263
    .line 264
    sget-object p1, Lk71;->c:Lh71;

    .line 265
    .line 266
    invoke-virtual {p1, v2, v3, p2}, Lh71;->i(JLjava/lang/Object;)I

    .line 267
    .line 268
    .line 269
    move-result p1

    .line 270
    and-int/2addr p0, p1

    .line 271
    if-eqz p0, :cond_111

    .line 272
    .line 273
    :goto_110
    return v6

    .line 274
    :cond_111
    return v5

    .line 275
    :pswitch_data_112
    .packed-switch 0x0
        :pswitch_f4
        :pswitch_e7
        :pswitch_dc
        :pswitch_d1
        :pswitch_c8
        :pswitch_bd
        :pswitch_b4
        :pswitch_ad
        :pswitch_8b
        :pswitch_81
        :pswitch_73
        :pswitch_69
        :pswitch_5f
        :pswitch_55
        :pswitch_49
        :pswitch_3f
        :pswitch_33
        :pswitch_29
    .end packed-switch
.end method

.method public final v(IILjava/lang/Object;)Z
    .registers 6

    .line 1
    add-int/lit8 p2, p2, 0x2

    .line 2
    .line 3
    iget-object p0, p0, Lde0;->a:[I

    .line 4
    .line 5
    aget p0, p0, p2

    .line 6
    .line 7
    const p2, 0xfffff

    .line 8
    .line 9
    .line 10
    and-int/2addr p0, p2

    .line 11
    int-to-long v0, p0

    .line 12
    sget-object p0, Lk71;->c:Lh71;

    .line 13
    .line 14
    invoke-virtual {p0, v0, v1, p3}, Lh71;->i(JLjava/lang/Object;)I

    .line 15
    .line 16
    .line 17
    move-result p0

    .line 18
    if-ne p0, p1, :cond_15

    .line 19
    .line 20
    const/4 p0, 0x1

    .line 21
    return p0

    .line 22
    :cond_15
    const/4 p0, 0x0

    .line 23
    return p0
.end method

.method public final x(Ljava/lang/Object;ILjava/lang/Object;Lcs;Lcd;)V
    .registers 13

    .line 1
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 2
    .line 3
    .line 4
    move-result p2

    .line 5
    const v0, 0xfffff

    .line 6
    .line 7
    .line 8
    and-int/2addr p2, v0

    .line 9
    int-to-long v0, p2

    .line 10
    sget-object p2, Lk71;->c:Lh71;

    .line 11
    .line 12
    invoke-virtual {p2, v0, v1, p1}, Lh71;->k(JLjava/lang/Object;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p2

    .line 16
    iget-object p0, p0, Lde0;->n:Lrb0;

    .line 17
    .line 18
    if-nez p2, :cond_20

    .line 19
    .line 20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 21
    .line 22
    .line 23
    sget-object p2, Lob0;->g:Lob0;

    .line 24
    .line 25
    invoke-virtual {p2}, Lob0;->b()Lob0;

    .line 26
    .line 27
    .line 28
    move-result-object p2

    .line 29
    invoke-static {v0, v1, p1, p2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    goto :goto_37

    .line 33
    :cond_20
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 34
    .line 35
    .line 36
    move-object v2, p2

    .line 37
    check-cast v2, Lob0;

    .line 38
    .line 39
    iget-boolean v2, v2, Lob0;->f:Z

    .line 40
    .line 41
    if-nez v2, :cond_37

    .line 42
    .line 43
    sget-object v2, Lob0;->g:Lob0;

    .line 44
    .line 45
    invoke-virtual {v2}, Lob0;->b()Lob0;

    .line 46
    .line 47
    .line 48
    move-result-object v2

    .line 49
    invoke-static {v2, p2}, Lrb0;->b(Ljava/lang/Object;Ljava/lang/Object;)Lob0;

    .line 50
    .line 51
    .line 52
    invoke-static {v0, v1, p1, v2}, Lk71;->p(JLjava/lang/Object;Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    move-object p2, v2

    .line 56
    :cond_37
    :goto_37
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    check-cast p2, Lob0;

    .line 60
    .line 61
    check-cast p3, Llb0;

    .line 62
    .line 63
    iget-object p0, p3, Llb0;->a:Ld8;

    .line 64
    .line 65
    const/4 p1, 0x2

    .line 66
    invoke-virtual {p5, p1}, Lcd;->T(I)V

    .line 67
    .line 68
    .line 69
    iget-object p3, p5, Lcd;->e:Ljava/lang/Object;

    .line 70
    .line 71
    check-cast p3, Lwd;

    .line 72
    .line 73
    invoke-virtual {p3}, Lwd;->A()I

    .line 74
    .line 75
    .line 76
    move-result v0

    .line 77
    invoke-virtual {p3, v0}, Lwd;->i(I)I

    .line 78
    .line 79
    .line 80
    move-result v0

    .line 81
    iget-object v1, p0, Ld8;->h:Ljava/lang/Object;

    .line 82
    .line 83
    const-string v2, ""

    .line 84
    .line 85
    move-object v3, v1

    .line 86
    :goto_55
    :try_start_55
    invoke-virtual {p5}, Lcd;->b()I

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    const v5, 0x7fffffff

    .line 91
    .line 92
    .line 93
    if-eq v4, v5, :cond_9f

    .line 94
    .line 95
    invoke-virtual {p3}, Lwd;->e()Z

    .line 96
    .line 97
    .line 98
    move-result v5
    :try_end_62
    .catchall {:try_start_55 .. :try_end_62} :catchall_79

    .line 99
    if-eqz v5, :cond_65

    .line 100
    .line 101
    goto :goto_9f

    .line 102
    :cond_65
    const/4 v5, 0x1

    .line 103
    const-string v6, "Unable to parse map entry."

    .line 104
    .line 105
    if-eq v4, v5, :cond_88

    .line 106
    .line 107
    if-eq v4, p1, :cond_7b

    .line 108
    .line 109
    :try_start_6c
    invoke-virtual {p5}, Lcd;->U()Z

    .line 110
    .line 111
    .line 112
    move-result v4

    .line 113
    if-eqz v4, :cond_73

    .line 114
    .line 115
    goto :goto_55

    .line 116
    :cond_73
    new-instance v4, La50;

    .line 117
    .line 118
    invoke-direct {v4, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    throw v4

    .line 122
    :catchall_79
    move-exception p0

    .line 123
    goto :goto_a6

    .line 124
    :cond_7b
    iget-object v4, p0, Ld8;->g:Ljava/lang/Object;

    .line 125
    .line 126
    check-cast v4, Lnd1;

    .line 127
    .line 128
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 129
    .line 130
    .line 131
    move-result-object v5

    .line 132
    invoke-virtual {p5, v4, v5, p4}, Lcd;->s(Lnd1;Ljava/lang/Class;Lcs;)Ljava/lang/Object;

    .line 133
    .line 134
    .line 135
    move-result-object v3

    .line 136
    goto :goto_55

    .line 137
    :cond_88
    iget-object v4, p0, Ld8;->f:Ljava/lang/Object;

    .line 138
    .line 139
    check-cast v4, Lnd1;

    .line 140
    .line 141
    const/4 v5, 0x0

    .line 142
    invoke-virtual {p5, v4, v5, v5}, Lcd;->s(Lnd1;Ljava/lang/Class;Lcs;)Ljava/lang/Object;

    .line 143
    .line 144
    .line 145
    move-result-object v2
    :try_end_91
    .catch Lx40; {:try_start_6c .. :try_end_91} :catch_92
    .catchall {:try_start_6c .. :try_end_91} :catchall_79

    .line 146
    goto :goto_55

    .line 147
    :catch_92
    :try_start_92
    invoke-virtual {p5}, Lcd;->U()Z

    .line 148
    .line 149
    .line 150
    move-result v4

    .line 151
    if-eqz v4, :cond_99

    .line 152
    .line 153
    goto :goto_55

    .line 154
    :cond_99
    new-instance p0, La50;

    .line 155
    .line 156
    invoke-direct {p0, v6}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 157
    .line 158
    .line 159
    throw p0

    .line 160
    :cond_9f
    :goto_9f
    invoke-virtual {p2, v2, v3}, Lob0;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_a2
    .catchall {:try_start_92 .. :try_end_a2} :catchall_79

    .line 161
    .line 162
    .line 163
    invoke-virtual {p3, v0}, Lwd;->h(I)V

    .line 164
    .line 165
    .line 166
    return-void

    .line 167
    :goto_a6
    invoke-virtual {p3, v0}, Lwd;->h(I)V

    .line 168
    .line 169
    .line 170
    throw p0
.end method

.method public final y(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 9

    .line 1
    invoke-virtual {p0, p2, p3}, Lde0;->t(ILjava/lang/Object;)Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_7

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const v1, 0xfffff

    .line 13
    .line 14
    .line 15
    and-int/2addr v0, v1

    .line 16
    int-to-long v0, v0

    .line 17
    sget-object v2, Lde0;->p:Lsun/misc/Unsafe;

    .line 18
    .line 19
    invoke-virtual {v2, p3, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object v3

    .line 23
    if-eqz v3, :cond_53

    .line 24
    .line 25
    invoke-virtual {p0, p2}, Lde0;->q(I)Les0;

    .line 26
    .line 27
    .line 28
    move-result-object p3

    .line 29
    invoke-virtual {p0, p2, p1}, Lde0;->t(ILjava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    if-nez v4, :cond_3a

    .line 34
    .line 35
    invoke-static {v3}, Lde0;->u(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    move-result v4

    .line 39
    if-nez v4, :cond_2c

    .line 40
    .line 41
    invoke-virtual {v2, p1, v0, v1, v3}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_36

    .line 45
    :cond_2c
    invoke-interface {p3}, Les0;->d()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    invoke-interface {p3, v4, v3}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {v2, p1, v0, v1, v4}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    :goto_36
    invoke-virtual {p0, p2, p1}, Lde0;->Q(ILjava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    invoke-virtual {v2, p1, v0, v1}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    invoke-static {p0}, Lde0;->u(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result p2

    .line 67
    if-nez p2, :cond_4f

    .line 68
    .line 69
    invoke-interface {p3}, Les0;->d()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p2

    .line 73
    invoke-interface {p3, p2, p0}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v2, p1, v0, v1, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    move-object p0, p2

    .line 80
    :cond_4f
    invoke-interface {p3, p0, v3}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    return-void

    .line 84
    :cond_53
    iget-object p0, p0, Lde0;->a:[I

    .line 85
    .line 86
    aget p0, p0, p2

    .line 87
    .line 88
    invoke-static {p0, p3}, Lm0;->b(ILjava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    return-void
.end method

.method public final z(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 10

    .line 1
    iget-object v0, p0, Lde0;->a:[I

    .line 2
    .line 3
    aget v1, v0, p2

    .line 4
    .line 5
    invoke-virtual {p0, v1, p2, p3}, Lde0;->v(IILjava/lang/Object;)Z

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    if-nez v2, :cond_b

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    invoke-virtual {p0, p2}, Lde0;->W(I)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    const v3, 0xfffff

    .line 17
    .line 18
    .line 19
    and-int/2addr v2, v3

    .line 20
    int-to-long v2, v2

    .line 21
    sget-object v4, Lde0;->p:Lsun/misc/Unsafe;

    .line 22
    .line 23
    invoke-virtual {v4, p3, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v5

    .line 27
    if-eqz v5, :cond_57

    .line 28
    .line 29
    invoke-virtual {p0, p2}, Lde0;->q(I)Les0;

    .line 30
    .line 31
    .line 32
    move-result-object p3

    .line 33
    invoke-virtual {p0, v1, p2, p1}, Lde0;->v(IILjava/lang/Object;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    if-nez v0, :cond_3e

    .line 38
    .line 39
    invoke-static {v5}, Lde0;->u(Ljava/lang/Object;)Z

    .line 40
    .line 41
    .line 42
    move-result v0

    .line 43
    if-nez v0, :cond_30

    .line 44
    .line 45
    invoke-virtual {v4, p1, v2, v3, v5}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    goto :goto_3a

    .line 49
    :cond_30
    invoke-interface {p3}, Les0;->d()Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-interface {p3, v0, v5}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 54
    .line 55
    .line 56
    invoke-virtual {v4, p1, v2, v3, v0}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 57
    .line 58
    .line 59
    :goto_3a
    invoke-virtual {p0, v1, p2, p1}, Lde0;->R(IILjava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_3e
    invoke-virtual {v4, p1, v2, v3}, Lsun/misc/Unsafe;->getObject(Ljava/lang/Object;J)Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p0

    .line 67
    invoke-static {p0}, Lde0;->u(Ljava/lang/Object;)Z

    .line 68
    .line 69
    .line 70
    move-result p2

    .line 71
    if-nez p2, :cond_53

    .line 72
    .line 73
    invoke-interface {p3}, Les0;->d()Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object p2

    .line 77
    invoke-interface {p3, p2, p0}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v4, p1, v2, v3, p2}, Lsun/misc/Unsafe;->putObject(Ljava/lang/Object;JLjava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    move-object p0, p2

    .line 84
    :cond_53
    invoke-interface {p3, p0, v5}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    return-void

    .line 88
    :cond_57
    aget p0, v0, p2

    .line 89
    .line 90
    invoke-static {p0, p3}, Lm0;->b(ILjava/lang/Object;)V

    .line 91
    .line 92
    .line 93
    return-void
.end method
