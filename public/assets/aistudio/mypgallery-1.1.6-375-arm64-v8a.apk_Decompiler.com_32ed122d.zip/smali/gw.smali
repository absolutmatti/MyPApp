###### Class defpackage.gw (gw)
.class public final Lgw;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Landroid/graphics/Rect;

.field public final b:I

.field public final c:I


# direct methods
.method public constructor <init>(Landroid/graphics/Rect;II)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgw;->a:Landroid/graphics/Rect;

    .line 5
    .line 6
    iput p2, p0, Lgw;->b:I

    .line 7
    .line 8
    iput p3, p0, Lgw;->c:I

    .line 9
    .line 10
    return-void
.end method
