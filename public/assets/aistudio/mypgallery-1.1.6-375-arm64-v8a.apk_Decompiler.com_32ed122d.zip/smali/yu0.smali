###### Class defpackage.yu0 (yu0)
.class public final Lyu0;
.super Lj0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:J

.field public b:Lgc;


# virtual methods
.method public final a(Li0;)Z
    .registers 6

    .line 1
    check-cast p1, Lxu0;

    .line 2
    .line 3
    iget-wide v0, p0, Lyu0;->a:J

    .line 4
    .line 5
    const-wide/16 v2, 0x0

    .line 6
    .line 7
    cmp-long v0, v0, v2

    .line 8
    .line 9
    if-ltz v0, :cond_c

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    return p0

    .line 13
    :cond_c
    iget-wide v0, p1, Lxu0;->m:J

    .line 14
    .line 15
    iget-wide v2, p1, Lxu0;->n:J

    .line 16
    .line 17
    cmp-long v2, v0, v2

    .line 18
    .line 19
    if-gez v2, :cond_16

    .line 20
    .line 21
    iput-wide v0, p1, Lxu0;->n:J

    .line 22
    .line 23
    :cond_16
    iput-wide v0, p0, Lyu0;->a:J

    .line 24
    .line 25
    const/4 p0, 0x1

    .line 26
    return p0
.end method

.method public final b(Li0;)[Lkotlin/coroutines/Continuation;
    .registers 6

    .line 1
    check-cast p1, Lxu0;

    .line 2
    .line 3
    iget-wide v0, p0, Lyu0;->a:J

    .line 4
    .line 5
    const-wide/16 v2, -0x1

    .line 6
    .line 7
    iput-wide v2, p0, Lyu0;->a:J

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    iput-object v2, p0, Lyu0;->b:Lgc;

    .line 11
    .line 12
    invoke-virtual {p1, v0, v1}, Lxu0;->u(J)[Lkotlin/coroutines/Continuation;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
