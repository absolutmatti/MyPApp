###### Class defpackage.ea1 (ea1)
.class public final Lea1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ler;


# instance fields
.field public final f:Landroid/content/Context;

.field public final g:Landroid/media/AudioManager;

.field public h:Le6;

.field public i:Lqi;

.field public j:Ljava/lang/Double;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/media/AudioManager;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lea1;->f:Landroid/content/Context;

    .line 8
    .line 9
    iput-object p2, p0, Lea1;->g:Landroid/media/AudioManager;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ldr;)V
    .registers 10

    .line 1
    instance-of v0, p1, Ljava/util/Map;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_8

    .line 5
    .line 6
    check-cast p1, Ljava/util/Map;

    .line 7
    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move-object p1, v1

    .line 10
    :goto_9
    if-eqz p1, :cond_12

    .line 11
    .line 12
    const-string v0, "fetchInitialVolume"

    .line 13
    .line 14
    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    move-object p1, v1

    .line 20
    :goto_13
    instance-of v0, p1, Ljava/lang/Boolean;

    .line 21
    .line 22
    if-eqz v0, :cond_1a

    .line 23
    .line 24
    check-cast p1, Ljava/lang/Boolean;

    .line 25
    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    move-object p1, v1

    .line 28
    :goto_1b
    if-eqz p1, :cond_22

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 p1, 0x0

    .line 36
    :goto_23
    iget-object v0, p0, Lea1;->h:Le6;

    .line 37
    .line 38
    iget-object v2, p0, Lea1;->f:Landroid/content/Context;

    .line 39
    .line 40
    if-eqz v0, :cond_2e

    .line 41
    .line 42
    :try_start_29
    invoke-virtual {v2, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_2c
    .catch Ljava/lang/IllegalArgumentException; {:try_start_29 .. :try_end_2c} :catch_2c

    .line 43
    .line 44
    .line 45
    :catch_2c
    iput-object v1, p0, Lea1;->h:Le6;

    .line 46
    .line 47
    :cond_2e
    iget-object v0, p0, Lea1;->i:Lqi;

    .line 48
    .line 49
    if-eqz v0, :cond_3b

    .line 50
    .line 51
    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    invoke-virtual {v3, v0}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 56
    .line 57
    .line 58
    iput-object v1, p0, Lea1;->i:Lqi;

    .line 59
    .line 60
    :cond_3b
    new-instance v0, Lbl0;

    .line 61
    .line 62
    new-instance v1, Lda1;

    .line 63
    .line 64
    invoke-direct {v1, p0, p2}, Lda1;-><init>(Lea1;Ldr;)V

    .line 65
    .line 66
    .line 67
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 68
    .line 69
    .line 70
    iget-object p2, p0, Lea1;->g:Landroid/media/AudioManager;

    .line 71
    .line 72
    iput-object p2, v0, Lbl0;->f:Ljava/lang/Object;

    .line 73
    .line 74
    iput-object v1, v0, Lbl0;->g:Ljava/lang/Object;

    .line 75
    .line 76
    new-instance v3, Le6;

    .line 77
    .line 78
    invoke-direct {v3, v0}, Le6;-><init>(Lbl0;)V

    .line 79
    .line 80
    .line 81
    iput-object v3, p0, Lea1;->h:Le6;

    .line 82
    .line 83
    new-instance v4, Landroid/content/IntentFilter;

    .line 84
    .line 85
    const-string v5, "android.media.VOLUME_CHANGED_ACTION"

    .line 86
    .line 87
    invoke-direct {v4, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 91
    .line 92
    const/16 v6, 0x21

    .line 93
    .line 94
    if-lt v5, v6, :cond_64

    .line 95
    .line 96
    const/4 v5, 0x2

    .line 97
    invoke-virtual {v2, v3, v4, v5}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    .line 98
    .line 99
    .line 100
    goto :goto_67

    .line 101
    :cond_64
    invoke-virtual {v2, v3, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 102
    .line 103
    .line 104
    :goto_67
    new-instance v3, Lqi;

    .line 105
    .line 106
    invoke-direct {v3, v0}, Lqi;-><init>(Lbl0;)V

    .line 107
    .line 108
    .line 109
    iput-object v3, p0, Lea1;->i:Lqi;

    .line 110
    .line 111
    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    sget-object v2, Landroid/provider/Settings$System;->CONTENT_URI:Landroid/net/Uri;

    .line 116
    .line 117
    iget-object p0, p0, Lea1;->i:Lqi;

    .line 118
    .line 119
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 120
    .line 121
    .line 122
    const/4 v3, 0x1

    .line 123
    invoke-virtual {v0, v2, v3, p0}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 124
    .line 125
    .line 126
    if-eqz p1, :cond_8c

    .line 127
    .line 128
    invoke-static {p2}, Ln40;->G(Landroid/media/AudioManager;)D

    .line 129
    .line 130
    .line 131
    move-result-wide p0

    .line 132
    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 133
    .line 134
    .line 135
    move-result-object p0

    .line 136
    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 137
    .line 138
    invoke-virtual {v1, p0, p1}, Lda1;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    :cond_8c
    return-void
.end method

.method public final onCancel()V
    .registers 4

    .line 1
    iget-object v0, p0, Lea1;->h:Le6;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, Lea1;->f:Landroid/content/Context;

    .line 5
    .line 6
    if-eqz v0, :cond_c

    .line 7
    .line 8
    :try_start_7
    invoke-virtual {v2, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_a} :catch_a

    .line 9
    .line 10
    .line 11
    :catch_a
    iput-object v1, p0, Lea1;->h:Le6;

    .line 12
    .line 13
    :cond_c
    iget-object v0, p0, Lea1;->i:Lqi;

    .line 14
    .line 15
    if-eqz v0, :cond_19

    .line 16
    .line 17
    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-virtual {v2, v0}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 22
    .line 23
    .line 24
    iput-object v1, p0, Lea1;->i:Lqi;

    .line 25
    .line 26
    :cond_19
    iput-object v1, p0, Lea1;->j:Ljava/lang/Double;

    .line 27
    .line 28
    return-void
.end method
