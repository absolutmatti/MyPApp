###### Class defpackage.qh0 (qh0)
.class public final Lqh0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ldc;


# instance fields
.field public final a:Liy;

.field public final synthetic b:Lsh0;


# direct methods
.method public constructor <init>(Lsh0;Liy;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lqh0;->b:Lsh0;

    .line 8
    .line 9
    iput-object p2, p0, Lqh0;->a:Liy;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final cancel()V
    .registers 5

    .line 1
    iget-object v0, p0, Lqh0;->b:Lsh0;

    .line 2
    .line 3
    iget-object v1, v0, Lsh0;->b:Lb9;

    .line 4
    .line 5
    iget-object v2, p0, Lqh0;->a:Liy;

    .line 6
    .line 7
    invoke-virtual {v1, v2}, Lb9;->remove(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    iget-object v1, v0, Lsh0;->c:Liy;

    .line 11
    .line 12
    invoke-static {v1, v2}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    const/4 v3, 0x0

    .line 17
    if-eqz v1, :cond_17

    .line 18
    .line 19
    invoke-virtual {v2}, Liy;->a()V

    .line 20
    .line 21
    .line 22
    iput-object v3, v0, Lsh0;->c:Liy;

    .line 23
    .line 24
    :cond_17
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    iget-object v0, v2, Liy;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 28
    .line 29
    invoke-virtual {v0, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    iget-object p0, v2, Liy;->c:Loz;

    .line 33
    .line 34
    if-eqz p0, :cond_26

    .line 35
    .line 36
    invoke-interface {p0}, Loz;->a()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    :cond_26
    iput-object v3, v2, Liy;->c:Loz;

    .line 40
    .line 41
    return-void
.end method
