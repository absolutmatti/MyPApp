###### Class defpackage.h1 (h1)
.class public final Lh1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final d:Lh1;

.field public static final e:Lh1;

.field public static final f:Lh1;

.field public static final g:Lh1;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:I

.field public final c:Ljava/lang/Class;


# direct methods
.method static constructor <clinit>()V
    .registers 21

    .line 1
    new-instance v0, Lh1;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Lh1;-><init>(I)V

    .line 5
    .line 6
    .line 7
    new-instance v0, Lh1;

    .line 8
    .line 9
    const/4 v1, 0x2

    .line 10
    invoke-direct {v0, v1}, Lh1;-><init>(I)V

    .line 11
    .line 12
    .line 13
    new-instance v0, Lh1;

    .line 14
    .line 15
    const/4 v1, 0x4

    .line 16
    invoke-direct {v0, v1}, Lh1;-><init>(I)V

    .line 17
    .line 18
    .line 19
    new-instance v0, Lh1;

    .line 20
    .line 21
    const/16 v1, 0x8

    .line 22
    .line 23
    invoke-direct {v0, v1}, Lh1;-><init>(I)V

    .line 24
    .line 25
    .line 26
    new-instance v0, Lh1;

    .line 27
    .line 28
    const/16 v1, 0x10

    .line 29
    .line 30
    invoke-direct {v0, v1}, Lh1;-><init>(I)V

    .line 31
    .line 32
    .line 33
    new-instance v0, Lh1;

    .line 34
    .line 35
    const/16 v1, 0x20

    .line 36
    .line 37
    invoke-direct {v0, v1}, Lh1;-><init>(I)V

    .line 38
    .line 39
    .line 40
    new-instance v0, Lh1;

    .line 41
    .line 42
    const/16 v2, 0x40

    .line 43
    .line 44
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 45
    .line 46
    .line 47
    new-instance v0, Lh1;

    .line 48
    .line 49
    const/16 v2, 0x80

    .line 50
    .line 51
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 52
    .line 53
    .line 54
    new-instance v0, Lh1;

    .line 55
    .line 56
    const/16 v2, 0x100

    .line 57
    .line 58
    const-class v3, Lr1;

    .line 59
    .line 60
    invoke-direct {v0, v2, v3}, Lh1;-><init>(ILjava/lang/Class;)V

    .line 61
    .line 62
    .line 63
    new-instance v0, Lh1;

    .line 64
    .line 65
    const/16 v2, 0x200

    .line 66
    .line 67
    invoke-direct {v0, v2, v3}, Lh1;-><init>(ILjava/lang/Class;)V

    .line 68
    .line 69
    .line 70
    new-instance v0, Lh1;

    .line 71
    .line 72
    const/16 v2, 0x400

    .line 73
    .line 74
    const-class v3, Ls1;

    .line 75
    .line 76
    invoke-direct {v0, v2, v3}, Lh1;-><init>(ILjava/lang/Class;)V

    .line 77
    .line 78
    .line 79
    new-instance v0, Lh1;

    .line 80
    .line 81
    const/16 v2, 0x800

    .line 82
    .line 83
    invoke-direct {v0, v2, v3}, Lh1;-><init>(ILjava/lang/Class;)V

    .line 84
    .line 85
    .line 86
    new-instance v0, Lh1;

    .line 87
    .line 88
    const/16 v2, 0x1000

    .line 89
    .line 90
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 91
    .line 92
    .line 93
    sput-object v0, Lh1;->d:Lh1;

    .line 94
    .line 95
    new-instance v0, Lh1;

    .line 96
    .line 97
    const/16 v2, 0x2000

    .line 98
    .line 99
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 100
    .line 101
    .line 102
    sput-object v0, Lh1;->e:Lh1;

    .line 103
    .line 104
    new-instance v0, Lh1;

    .line 105
    .line 106
    const/16 v2, 0x4000

    .line 107
    .line 108
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 109
    .line 110
    .line 111
    new-instance v0, Lh1;

    .line 112
    .line 113
    const v2, 0x8000

    .line 114
    .line 115
    .line 116
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 117
    .line 118
    .line 119
    new-instance v0, Lh1;

    .line 120
    .line 121
    const/high16 v2, 0x10000

    .line 122
    .line 123
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 124
    .line 125
    .line 126
    new-instance v0, Lh1;

    .line 127
    .line 128
    const/high16 v2, 0x20000

    .line 129
    .line 130
    const-class v3, Lw1;

    .line 131
    .line 132
    invoke-direct {v0, v2, v3}, Lh1;-><init>(ILjava/lang/Class;)V

    .line 133
    .line 134
    .line 135
    new-instance v0, Lh1;

    .line 136
    .line 137
    const/high16 v2, 0x40000

    .line 138
    .line 139
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 140
    .line 141
    .line 142
    new-instance v0, Lh1;

    .line 143
    .line 144
    const/high16 v2, 0x80000

    .line 145
    .line 146
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 147
    .line 148
    .line 149
    new-instance v0, Lh1;

    .line 150
    .line 151
    const/high16 v2, 0x100000

    .line 152
    .line 153
    invoke-direct {v0, v2}, Lh1;-><init>(I)V

    .line 154
    .line 155
    .line 156
    new-instance v0, Lh1;

    .line 157
    .line 158
    const/high16 v2, 0x200000

    .line 159
    .line 160
    const-class v3, Lx1;

    .line 161
    .line 162
    invoke-direct {v0, v2, v3}, Lh1;-><init>(ILjava/lang/Class;)V

    .line 163
    .line 164
    .line 165
    new-instance v4, Lh1;

    .line 166
    .line 167
    sget-object v5, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SHOW_ON_SCREEN:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 168
    .line 169
    const/4 v8, 0x0

    .line 170
    const/4 v9, 0x0

    .line 171
    const v6, 0x1020036

    .line 172
    .line 173
    .line 174
    const/4 v7, 0x0

    .line 175
    invoke-direct/range {v4 .. v9}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 176
    .line 177
    .line 178
    new-instance v10, Lh1;

    .line 179
    .line 180
    sget-object v11, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_TO_POSITION:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 181
    .line 182
    const/4 v14, 0x0

    .line 183
    const-class v15, Lu1;

    .line 184
    .line 185
    const v12, 0x1020037

    .line 186
    .line 187
    .line 188
    const/4 v13, 0x0

    .line 189
    invoke-direct/range {v10 .. v15}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 190
    .line 191
    .line 192
    new-instance v2, Lh1;

    .line 193
    .line 194
    sget-object v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_UP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 195
    .line 196
    const/4 v6, 0x0

    .line 197
    const v4, 0x1020038

    .line 198
    .line 199
    .line 200
    const/4 v5, 0x0

    .line 201
    invoke-direct/range {v2 .. v7}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 202
    .line 203
    .line 204
    sput-object v2, Lh1;->f:Lh1;

    .line 205
    .line 206
    new-instance v3, Lh1;

    .line 207
    .line 208
    sget-object v4, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_LEFT:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 209
    .line 210
    const v5, 0x1020039

    .line 211
    .line 212
    .line 213
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 214
    .line 215
    .line 216
    new-instance v9, Lh1;

    .line 217
    .line 218
    sget-object v10, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_DOWN:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 219
    .line 220
    const v11, 0x102003a

    .line 221
    .line 222
    .line 223
    const/4 v12, 0x0

    .line 224
    invoke-direct/range {v9 .. v14}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 225
    .line 226
    .line 227
    sput-object v9, Lh1;->g:Lh1;

    .line 228
    .line 229
    new-instance v2, Lh1;

    .line 230
    .line 231
    sget-object v3, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SCROLL_RIGHT:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 232
    .line 233
    const v4, 0x102003b

    .line 234
    .line 235
    .line 236
    const/4 v5, 0x0

    .line 237
    invoke-direct/range {v2 .. v7}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 238
    .line 239
    .line 240
    new-instance v8, Lh1;

    .line 241
    .line 242
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 243
    .line 244
    const/4 v2, 0x0

    .line 245
    const/16 v3, 0x1d

    .line 246
    .line 247
    if-lt v0, v3, :cond_fe

    .line 248
    .line 249
    invoke-static {}, Ld1;->h()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 250
    .line 251
    .line 252
    move-result-object v4

    .line 253
    move-object v9, v4

    .line 254
    goto :goto_ff

    .line 255
    :cond_fe
    move-object v9, v2

    .line 256
    :goto_ff
    const/4 v12, 0x0

    .line 257
    const/4 v13, 0x0

    .line 258
    const v10, 0x1020046

    .line 259
    .line 260
    .line 261
    const/4 v11, 0x0

    .line 262
    invoke-direct/range {v8 .. v13}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 263
    .line 264
    .line 265
    new-instance v14, Lh1;

    .line 266
    .line 267
    if-lt v0, v3, :cond_112

    .line 268
    .line 269
    invoke-static {}, Ld1;->w()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 270
    .line 271
    .line 272
    move-result-object v4

    .line 273
    move-object v15, v4

    .line 274
    goto :goto_113

    .line 275
    :cond_112
    move-object v15, v2

    .line 276
    :goto_113
    const/16 v18, 0x0

    .line 277
    .line 278
    const/16 v19, 0x0

    .line 279
    .line 280
    const v16, 0x1020047

    .line 281
    .line 282
    .line 283
    const/16 v17, 0x0

    .line 284
    .line 285
    invoke-direct/range {v14 .. v19}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 286
    .line 287
    .line 288
    new-instance v4, Lh1;

    .line 289
    .line 290
    if-lt v0, v3, :cond_128

    .line 291
    .line 292
    invoke-static {}, Ld1;->A()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 293
    .line 294
    .line 295
    move-result-object v5

    .line 296
    goto :goto_129

    .line 297
    :cond_128
    move-object v5, v2

    .line 298
    :goto_129
    const/4 v8, 0x0

    .line 299
    const/4 v9, 0x0

    .line 300
    const v6, 0x1020048

    .line 301
    .line 302
    .line 303
    const/4 v7, 0x0

    .line 304
    invoke-direct/range {v4 .. v9}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 305
    .line 306
    .line 307
    new-instance v10, Lh1;

    .line 308
    .line 309
    if-lt v0, v3, :cond_13c

    .line 310
    .line 311
    invoke-static {}, Ld1;->C()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 312
    .line 313
    .line 314
    move-result-object v3

    .line 315
    move-object v11, v3

    .line 316
    goto :goto_13d

    .line 317
    :cond_13c
    move-object v11, v2

    .line 318
    :goto_13d
    const/4 v14, 0x0

    .line 319
    const/4 v15, 0x0

    .line 320
    const v12, 0x1020049

    .line 321
    .line 322
    .line 323
    const/4 v13, 0x0

    .line 324
    invoke-direct/range {v10 .. v15}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 325
    .line 326
    .line 327
    new-instance v3, Lh1;

    .line 328
    .line 329
    sget-object v4, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_CONTEXT_CLICK:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 330
    .line 331
    const/4 v7, 0x0

    .line 332
    const/4 v8, 0x0

    .line 333
    const v5, 0x102003c

    .line 334
    .line 335
    .line 336
    const/4 v6, 0x0

    .line 337
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 338
    .line 339
    .line 340
    new-instance v9, Lh1;

    .line 341
    .line 342
    sget-object v10, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SET_PROGRESS:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 343
    .line 344
    const-class v14, Lv1;

    .line 345
    .line 346
    const v11, 0x102003d

    .line 347
    .line 348
    .line 349
    const/4 v12, 0x0

    .line 350
    invoke-direct/range {v9 .. v14}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 351
    .line 352
    .line 353
    new-instance v3, Lh1;

    .line 354
    .line 355
    sget-object v4, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_MOVE_WINDOW:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 356
    .line 357
    const-class v8, Lt1;

    .line 358
    .line 359
    const v5, 0x1020042

    .line 360
    .line 361
    .line 362
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 363
    .line 364
    .line 365
    new-instance v9, Lh1;

    .line 366
    .line 367
    sget-object v10, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_SHOW_TOOLTIP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 368
    .line 369
    const/4 v14, 0x0

    .line 370
    const v11, 0x1020044

    .line 371
    .line 372
    .line 373
    invoke-direct/range {v9 .. v14}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 374
    .line 375
    .line 376
    new-instance v3, Lh1;

    .line 377
    .line 378
    sget-object v4, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->ACTION_HIDE_TOOLTIP:Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 379
    .line 380
    const/4 v8, 0x0

    .line 381
    const v5, 0x1020045

    .line 382
    .line 383
    .line 384
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 385
    .line 386
    .line 387
    new-instance v9, Lh1;

    .line 388
    .line 389
    const/16 v3, 0x1e

    .line 390
    .line 391
    if-lt v0, v3, :cond_18e

    .line 392
    .line 393
    invoke-static {}, Le1;->n()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 394
    .line 395
    .line 396
    move-result-object v4

    .line 397
    move-object v10, v4

    .line 398
    goto :goto_18f

    .line 399
    :cond_18e
    move-object v10, v2

    .line 400
    :goto_18f
    const/4 v13, 0x0

    .line 401
    const/4 v14, 0x0

    .line 402
    const v11, 0x102004a

    .line 403
    .line 404
    .line 405
    const/4 v12, 0x0

    .line 406
    invoke-direct/range {v9 .. v14}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 407
    .line 408
    .line 409
    new-instance v15, Lh1;

    .line 410
    .line 411
    if-lt v0, v3, :cond_1a3

    .line 412
    .line 413
    invoke-static {}, Le1;->A()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 414
    .line 415
    .line 416
    move-result-object v3

    .line 417
    move-object/from16 v16, v3

    .line 418
    .line 419
    goto :goto_1a5

    .line 420
    :cond_1a3
    move-object/from16 v16, v2

    .line 421
    .line 422
    :goto_1a5
    const/16 v19, 0x0

    .line 423
    .line 424
    const/16 v20, 0x0

    .line 425
    .line 426
    const v17, 0x1020054

    .line 427
    .line 428
    .line 429
    const/16 v18, 0x0

    .line 430
    .line 431
    invoke-direct/range {v15 .. v20}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 432
    .line 433
    .line 434
    new-instance v3, Lh1;

    .line 435
    .line 436
    if-lt v0, v1, :cond_1ba

    .line 437
    .line 438
    invoke-static {}, Lf1;->a()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 439
    .line 440
    .line 441
    move-result-object v4

    .line 442
    goto :goto_1bb

    .line 443
    :cond_1ba
    move-object v4, v2

    .line 444
    :goto_1bb
    const/4 v7, 0x0

    .line 445
    const/4 v8, 0x0

    .line 446
    const v5, 0x1020055

    .line 447
    .line 448
    .line 449
    const/4 v6, 0x0

    .line 450
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 451
    .line 452
    .line 453
    new-instance v9, Lh1;

    .line 454
    .line 455
    if-lt v0, v1, :cond_1ce

    .line 456
    .line 457
    invoke-static {}, Lf1;->b()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 458
    .line 459
    .line 460
    move-result-object v3

    .line 461
    move-object v10, v3

    .line 462
    goto :goto_1cf

    .line 463
    :cond_1ce
    move-object v10, v2

    .line 464
    :goto_1cf
    const/4 v13, 0x0

    .line 465
    const/4 v14, 0x0

    .line 466
    const v11, 0x1020056

    .line 467
    .line 468
    .line 469
    const/4 v12, 0x0

    .line 470
    invoke-direct/range {v9 .. v14}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 471
    .line 472
    .line 473
    new-instance v3, Lh1;

    .line 474
    .line 475
    if-lt v0, v1, :cond_1e2

    .line 476
    .line 477
    invoke-static {}, Lf1;->c()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 478
    .line 479
    .line 480
    move-result-object v1

    .line 481
    move-object v4, v1

    .line 482
    goto :goto_1e3

    .line 483
    :cond_1e2
    move-object v4, v2

    .line 484
    :goto_1e3
    const/4 v7, 0x0

    .line 485
    const/4 v8, 0x0

    .line 486
    const v5, 0x1020057

    .line 487
    .line 488
    .line 489
    const/4 v6, 0x0

    .line 490
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 491
    .line 492
    .line 493
    new-instance v9, Lh1;

    .line 494
    .line 495
    const/16 v1, 0x21

    .line 496
    .line 497
    if-lt v0, v1, :cond_1f8

    .line 498
    .line 499
    invoke-static {}, Lg1;->j()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 500
    .line 501
    .line 502
    move-result-object v1

    .line 503
    move-object v10, v1

    .line 504
    goto :goto_1f9

    .line 505
    :cond_1f8
    move-object v10, v2

    .line 506
    :goto_1f9
    const/4 v13, 0x0

    .line 507
    const/4 v14, 0x0

    .line 508
    const v11, 0x1020058

    .line 509
    .line 510
    .line 511
    const/4 v12, 0x0

    .line 512
    invoke-direct/range {v9 .. v14}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 513
    .line 514
    .line 515
    new-instance v3, Lh1;

    .line 516
    .line 517
    const/16 v1, 0x22

    .line 518
    .line 519
    if-lt v0, v1, :cond_20c

    .line 520
    .line 521
    invoke-static {}, Lk1;->a()Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 522
    .line 523
    .line 524
    move-result-object v2

    .line 525
    :cond_20c
    move-object v4, v2

    .line 526
    const/4 v7, 0x0

    .line 527
    const/4 v8, 0x0

    .line 528
    const v5, 0x102005e

    .line 529
    .line 530
    .line 531
    const/4 v6, 0x0

    .line 532
    invoke-direct/range {v3 .. v8}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    .line 533
    .line 534
    .line 535
    return-void
.end method

.method public constructor <init>(I)V
    .registers 8

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    move-object v0, p0

    move v2, p1

    .line 22
    invoke-direct/range {v0 .. v5}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    return-void
.end method

.method public constructor <init>(ILjava/lang/Class;)V
    .registers 9

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    move-object v0, p0

    move v2, p1

    move-object v5, p2

    .line 21
    invoke-direct/range {v0 .. v5}, Lh1;-><init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Object;ILjava/lang/String;Lrl;Ljava/lang/Class;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p2, p0, Lh1;->b:I

    .line 5
    .line 6
    if-nez p1, :cond_f

    .line 7
    .line 8
    new-instance p1, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 9
    .line 10
    invoke-direct {p1, p2, p3}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;-><init>(ILjava/lang/CharSequence;)V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lh1;->a:Ljava/lang/Object;

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :cond_f
    iput-object p1, p0, Lh1;->a:Ljava/lang/Object;

    .line 17
    .line 18
    :goto_11
    iput-object p5, p0, Lh1;->c:Ljava/lang/Class;

    .line 19
    .line 20
    return-void
.end method


# virtual methods
.method public final a()I
    .registers 1

    .line 1
    iget-object p0, p0, Lh1;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getId()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    if-nez p1, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lh1;

    .line 6
    .line 7
    if-nez v1, :cond_9

    .line 8
    .line 9
    return v0

    .line 10
    :cond_9
    check-cast p1, Lh1;

    .line 11
    .line 12
    iget-object p1, p1, Lh1;->a:Ljava/lang/Object;

    .line 13
    .line 14
    iget-object p0, p0, Lh1;->a:Ljava/lang/Object;

    .line 15
    .line 16
    if-nez p0, :cond_14

    .line 17
    .line 18
    if-eqz p1, :cond_1b

    .line 19
    .line 20
    return v0

    .line 21
    :cond_14
    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result p0

    .line 25
    if-nez p0, :cond_1b

    .line 26
    .line 27
    return v0

    .line 28
    :cond_1b
    const/4 p0, 0x1

    .line 29
    return p0
.end method

.method public final hashCode()I
    .registers 1

    .line 1
    iget-object p0, p0, Lh1;->a:Ljava/lang/Object;

    .line 2
    .line 3
    if-eqz p0, :cond_9

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0

    .line 10
    :cond_9
    const/4 p0, 0x0

    .line 11
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "AccessibilityActionCompat: "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget v1, p0, Lh1;->b:I

    .line 9
    .line 10
    invoke-static {v1}, Lm1;->b(I)Ljava/lang/String;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    const-string v2, "ACTION_UNKNOWN"

    .line 15
    .line 16
    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_2a

    .line 21
    .line 22
    iget-object p0, p0, Lh1;->a:Ljava/lang/Object;

    .line 23
    .line 24
    move-object v2, p0

    .line 25
    check-cast v2, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 26
    .line 27
    invoke-virtual {v2}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getLabel()Ljava/lang/CharSequence;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    if-eqz v2, :cond_2a

    .line 32
    .line 33
    check-cast p0, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 34
    .line 35
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;->getLabel()Ljava/lang/CharSequence;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v1

    .line 43
    :cond_2a
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 44
    .line 45
    .line 46
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 47
    .line 48
    .line 49
    move-result-object p0

    .line 50
    return-object p0
.end method
