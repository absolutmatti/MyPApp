###### Class defpackage.ty (ty)
.class public Lty;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ln91;


# static fields
.field public static b:Lty;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lty;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/Class;)Ll91;
    .registers 4

    .line 1
    iget p0, p0, Lty;->a:I

    .line 2
    .line 3
    packed-switch p0, :pswitch_data_36

    .line 4
    .line 5
    .line 6
    const-string p0, "Cannot create an instance of "

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    :try_start_8
    invoke-virtual {p1, v0}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    invoke-virtual {v1, v0}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    .line 19
    .line 20
    check-cast v1, Ll91;
    :try_end_15
    .catch Ljava/lang/NoSuchMethodException; {:try_start_8 .. :try_end_15} :catch_1b
    .catch Ljava/lang/InstantiationException; {:try_start_8 .. :try_end_15} :catch_19
    .catch Ljava/lang/IllegalAccessException; {:try_start_8 .. :try_end_15} :catch_17

    .line 21
    .line 22
    move-object v0, v1

    .line 23
    goto :goto_28

    .line 24
    :catch_17
    move-exception v1

    .line 25
    goto :goto_1d

    .line 26
    :catch_19
    move-exception v1

    .line 27
    goto :goto_21

    .line 28
    :catch_1b
    move-exception v1

    .line 29
    goto :goto_25

    .line 30
    :goto_1d
    invoke-static {p0, p1, v1}, Lm0;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 31
    .line 32
    .line 33
    goto :goto_28

    .line 34
    :goto_21
    invoke-static {p0, p1, v1}, Lm0;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 35
    .line 36
    .line 37
    goto :goto_28

    .line 38
    :goto_25
    invoke-static {p0, p1, v1}, Lm0;->m(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Throwable;)V

    .line 39
    .line 40
    .line 41
    :goto_28
    return-object v0

    .line 42
    :pswitch_29
    new-instance p0, Lha0;

    .line 43
    .line 44
    invoke-direct {p0}, Lha0;-><init>()V

    .line 45
    .line 46
    .line 47
    return-object p0

    .line 48
    :pswitch_2f
    new-instance p0, Luy;

    .line 49
    .line 50
    const/4 p1, 0x1

    .line 51
    invoke-direct {p0, p1}, Luy;-><init>(Z)V

    .line 52
    .line 53
    .line 54
    return-object p0

    .line 55
    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_2f
        :pswitch_29
    .end packed-switch
.end method
