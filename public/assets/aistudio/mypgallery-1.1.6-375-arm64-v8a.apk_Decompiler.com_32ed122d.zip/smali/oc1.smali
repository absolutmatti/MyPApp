###### Class defpackage.oc1 (oc1)
.class public Loc1;
.super Lnc1;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public o:Lo30;

.field public p:Lo30;

.field public q:Lo30;


# direct methods
.method public constructor <init>(Lvc1;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Lnc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, Loc1;->o:Lo30;

    .line 6
    .line 7
    iput-object p1, p0, Loc1;->p:Lo30;

    .line 8
    .line 9
    iput-object p1, p0, Loc1;->q:Lo30;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public f()Lo30;
    .registers 2

    .line 1
    iget-object v0, p0, Loc1;->p:Lo30;

    .line 2
    .line 3
    if-nez v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-static {v0}, Lu51;->p(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lo30;->b(Landroid/graphics/Insets;)Lo30;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Loc1;->p:Lo30;

    .line 16
    .line 17
    :cond_10
    iget-object p0, p0, Loc1;->p:Lo30;

    .line 18
    .line 19
    return-object p0
.end method

.method public h()Lo30;
    .registers 2

    .line 1
    iget-object v0, p0, Loc1;->o:Lo30;

    .line 2
    .line 3
    if-nez v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-static {v0}, Lu51;->s(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lo30;->b(Landroid/graphics/Insets;)Lo30;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Loc1;->o:Lo30;

    .line 16
    .line 17
    :cond_10
    iget-object p0, p0, Loc1;->o:Lo30;

    .line 18
    .line 19
    return-object p0
.end method

.method public j()Lo30;
    .registers 2

    .line 1
    iget-object v0, p0, Loc1;->q:Lo30;

    .line 2
    .line 3
    if-nez v0, :cond_10

    .line 4
    .line 5
    iget-object v0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-static {v0}, Lu51;->b(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-static {v0}, Lo30;->b(Landroid/graphics/Insets;)Lo30;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Loc1;->q:Lo30;

    .line 16
    .line 17
    :cond_10
    iget-object p0, p0, Loc1;->q:Lo30;

    .line 18
    .line 19
    return-object p0
.end method

.method public k(IIII)Lvc1;
    .registers 5

    .line 1
    iget-object p0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-static {p0, p1, p2, p3, p4}, Lu51;->j(Landroid/view/WindowInsets;IIII)Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const/4 p1, 0x0

    .line 8
    invoke-static {p0, p1}, Lvc1;->c(Landroid/view/WindowInsets;Landroid/view/View;)Lvc1;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public q(Lo30;)V
    .registers 2

    .line 1
    return-void
.end method
