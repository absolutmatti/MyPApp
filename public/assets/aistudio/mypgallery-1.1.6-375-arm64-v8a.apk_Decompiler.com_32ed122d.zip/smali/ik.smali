###### Class defpackage.ik (ik)
.class public final Lik;
.super Lsh;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public i:Ljava/lang/Object;

.field public j:Ljava/lang/Object;

.field public k:Ljava/lang/Object;

.field public l:Lvo0;

.field public m:Lel;

.field public synthetic n:Ljava/lang/Object;

.field public final synthetic o:Ljk;

.field public p:I


# direct methods
.method public constructor <init>(Ljk;Lsh;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lik;->o:Ljk;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lsh;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lik;->n:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lik;->p:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lik;->p:I

    .line 9
    .line 10
    iget-object p1, p0, Lik;->o:Ljk;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Ljk;->a(Lek;Lsh;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
