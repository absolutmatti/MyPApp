###### Class defpackage.vl0 (vl0)
.class public final Lvl0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lqz;

.field public final c:Lhi;

.field public final d:Ljava/lang/Object;

.field public volatile e:Lul0;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lqz;Lhi;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvl0;->a:Ljava/lang/String;

    .line 5
    .line 6
    iput-object p2, p0, Lvl0;->b:Lqz;

    .line 7
    .line 8
    iput-object p3, p0, Lvl0;->c:Lhi;

    .line 9
    .line 10
    new-instance p1, Ljava/lang/Object;

    .line 11
    .line 12
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Lvl0;->d:Ljava/lang/Object;

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ld60;)Ljava/lang/Object;
    .registers 10

    .line 1
    check-cast p1, Landroid/content/Context;

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    iget-object p2, p0, Lvl0;->e:Lul0;

    .line 10
    .line 11
    if-nez p2, :cond_69

    .line 12
    .line 13
    iget-object p2, p0, Lvl0;->d:Ljava/lang/Object;

    .line 14
    .line 15
    monitor-enter p2

    .line 16
    :try_start_f
    iget-object v0, p0, Lvl0;->e:Lul0;

    .line 17
    .line 18
    if-nez v0, :cond_60

    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    iget-object v0, p0, Lvl0;->b:Lqz;

    .line 25
    .line 26
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    invoke-interface {v0, p1}, Lqz;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    check-cast v0, Ljava/util/List;

    .line 34
    .line 35
    iget-object v1, p0, Lvl0;->c:Lhi;

    .line 36
    .line 37
    new-instance v2, Lw9;

    .line 38
    .line 39
    const/4 v3, 0x2

    .line 40
    invoke-direct {v2, p1, v3, p0}, Lw9;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    new-instance p1, Lst;

    .line 47
    .line 48
    new-instance v3, Log;

    .line 49
    .line 50
    const/16 v4, 0xa

    .line 51
    .line 52
    invoke-direct {v3, v4, v2}, Log;-><init>(ILjava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    invoke-direct {p1, v3}, Lst;-><init>(Log;)V

    .line 56
    .line 57
    .line 58
    new-instance v2, Lul0;

    .line 59
    .line 60
    new-instance v3, Ls10;

    .line 61
    .line 62
    const/16 v4, 0x1a

    .line 63
    .line 64
    invoke-direct {v3, v4}, Ls10;-><init>(I)V

    .line 65
    .line 66
    .line 67
    new-instance v4, Lq8;

    .line 68
    .line 69
    const/16 v5, 0x8

    .line 70
    .line 71
    const/4 v6, 0x0

    .line 72
    invoke-direct {v4, v0, v6, v5}, Lq8;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 73
    .line 74
    .line 75
    invoke-static {v4}, Llf1;->y(Ljava/lang/Object;)Ljava/util/List;

    .line 76
    .line 77
    .line 78
    move-result-object v0

    .line 79
    new-instance v4, Lel;

    .line 80
    .line 81
    invoke-direct {v4, p1, v0, v3, v1}, Lel;-><init>(Lst;Ljava/util/List;Ls10;Lhi;)V

    .line 82
    .line 83
    .line 84
    invoke-direct {v2, v4}, Lul0;-><init>(Lfk;)V

    .line 85
    .line 86
    .line 87
    new-instance p1, Lul0;

    .line 88
    .line 89
    invoke-direct {p1, v2}, Lul0;-><init>(Lfk;)V

    .line 90
    .line 91
    .line 92
    iput-object p1, p0, Lvl0;->e:Lul0;

    .line 93
    .line 94
    goto :goto_60

    .line 95
    :catchall_5e
    move-exception p0

    .line 96
    goto :goto_67

    .line 97
    :cond_60
    :goto_60
    iget-object p0, p0, Lvl0;->e:Lul0;

    .line 98
    .line 99
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_65
    .catchall {:try_start_f .. :try_end_65} :catchall_5e

    .line 100
    .line 101
    .line 102
    monitor-exit p2

    .line 103
    return-object p0

    .line 104
    :goto_67
    monitor-exit p2

    .line 105
    throw p0

    .line 106
    :cond_69
    return-object p2
.end method
