###### Class defpackage.c00 (c00)
.class public final Lc00;
.super Lyz0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lc00;->d:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final f(BLjava/nio/ByteBuffer;)Ljava/lang/Object;
    .registers 14

    .line 1
    iget v0, p0, Lc00;->d:I

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    const/4 v2, 0x1

    .line 5
    const/16 v3, -0x7e

    .line 6
    .line 7
    const/16 v4, -0x7f

    .line 8
    .line 9
    const/4 v5, 0x0

    .line 10
    const/4 v6, 0x0

    .line 11
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    packed-switch v0, :pswitch_data_180

    .line 15
    .line 16
    .line 17
    if-ne p1, v4, :cond_2c

    .line 18
    .line 19
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    instance-of p1, p0, Ljava/util/List;

    .line 24
    .line 25
    if-eqz p1, :cond_1d

    .line 26
    .line 27
    check-cast p0, Ljava/util/List;

    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move-object p0, v5

    .line 31
    :goto_1e
    if-eqz p0, :cond_4c

    .line 32
    .line 33
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object p0

    .line 37
    check-cast p0, Ljava/lang/Boolean;

    .line 38
    .line 39
    new-instance v5, Ld41;

    .line 40
    .line 41
    invoke-direct {v5, p0}, Ld41;-><init>(Ljava/lang/Boolean;)V

    .line 42
    .line 43
    .line 44
    goto :goto_4c

    .line 45
    :cond_2c
    if-ne p1, v3, :cond_48

    .line 46
    .line 47
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    instance-of p1, p0, Ljava/util/List;

    .line 52
    .line 53
    if-eqz p1, :cond_39

    .line 54
    .line 55
    check-cast p0, Ljava/util/List;

    .line 56
    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    move-object p0, v5

    .line 59
    :goto_3a
    if-eqz p0, :cond_4c

    .line 60
    .line 61
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    check-cast p0, Ljava/lang/Boolean;

    .line 66
    .line 67
    new-instance v5, Lf50;

    .line 68
    .line 69
    invoke-direct {v5, p0}, Lf50;-><init>(Ljava/lang/Boolean;)V

    .line 70
    .line 71
    .line 72
    goto :goto_4c

    .line 73
    :cond_48
    invoke-super {p0, p1, p2}, Lyz0;->f(BLjava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v5

    .line 77
    :cond_4c
    :goto_4c
    return-object v5

    .line 78
    :pswitch_4d
    if-ne p1, v4, :cond_86

    .line 79
    .line 80
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    instance-of p1, p0, Ljava/util/List;

    .line 85
    .line 86
    if-eqz p1, :cond_5a

    .line 87
    .line 88
    check-cast p0, Ljava/util/List;

    .line 89
    .line 90
    goto :goto_5b

    .line 91
    :cond_5a
    move-object p0, v5

    .line 92
    :goto_5b
    if-eqz p0, :cond_ad

    .line 93
    .line 94
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 95
    .line 96
    .line 97
    move-result-object p1

    .line 98
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    .line 100
    .line 101
    check-cast p1, Ljava/lang/Boolean;

    .line 102
    .line 103
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 104
    .line 105
    .line 106
    move-result p1

    .line 107
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object p2

    .line 111
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 112
    .line 113
    .line 114
    check-cast p2, Ljava/lang/Boolean;

    .line 115
    .line 116
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 117
    .line 118
    .line 119
    move-result p2

    .line 120
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p0

    .line 124
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 125
    .line 126
    .line 127
    check-cast p0, Ljava/util/Map;

    .line 128
    .line 129
    new-instance v5, Lpb1;

    .line 130
    .line 131
    invoke-direct {v5, p1, p2, p0}, Lpb1;-><init>(ZZLjava/util/Map;)V

    .line 132
    .line 133
    .line 134
    goto :goto_ad

    .line 135
    :cond_86
    if-ne p1, v3, :cond_a9

    .line 136
    .line 137
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    instance-of p1, p0, Ljava/util/List;

    .line 142
    .line 143
    if-eqz p1, :cond_93

    .line 144
    .line 145
    check-cast p0, Ljava/util/List;

    .line 146
    .line 147
    goto :goto_94

    .line 148
    :cond_93
    move-object p0, v5

    .line 149
    :goto_94
    if-eqz p0, :cond_ad

    .line 150
    .line 151
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object p0

    .line 155
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    .line 157
    .line 158
    check-cast p0, Ljava/lang/Boolean;

    .line 159
    .line 160
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 161
    .line 162
    .line 163
    move-result p0

    .line 164
    new-instance v5, Lza;

    .line 165
    .line 166
    invoke-direct {v5, p0}, Lza;-><init>(Z)V

    .line 167
    .line 168
    .line 169
    goto :goto_ad

    .line 170
    :cond_a9
    invoke-super {p0, p1, p2}, Lyz0;->f(BLjava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 171
    .line 172
    .line 173
    move-result-object v5

    .line 174
    :cond_ad
    :goto_ad
    return-object v5

    .line 175
    :pswitch_ae
    if-ne p1, v4, :cond_d5

    .line 176
    .line 177
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    move-result-object p0

    .line 181
    check-cast p0, Ljava/lang/Long;

    .line 182
    .line 183
    if-eqz p0, :cond_17e

    .line 184
    .line 185
    invoke-virtual {p0}, Ljava/lang/Number;->longValue()J

    .line 186
    .line 187
    .line 188
    move-result-wide p0

    .line 189
    long-to-int p0, p0

    .line 190
    sget-object p1, Lqt;->g:Ls10;

    .line 191
    .line 192
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 193
    .line 194
    .line 195
    invoke-static {}, Lqt;->values()[Lqt;

    .line 196
    .line 197
    .line 198
    move-result-object p1

    .line 199
    array-length p2, p1

    .line 200
    :goto_c7
    if-ge v6, p2, :cond_17e

    .line 201
    .line 202
    aget-object v0, p1, v6

    .line 203
    .line 204
    iget v1, v0, Lqt;->f:I

    .line 205
    .line 206
    if-ne v1, p0, :cond_d2

    .line 207
    .line 208
    move-object v5, v0

    .line 209
    goto/16 :goto_17e

    .line 210
    .line 211
    :cond_d2
    add-int/lit8 v6, v6, 0x1

    .line 212
    .line 213
    goto :goto_c7

    .line 214
    :cond_d5
    if-ne p1, v3, :cond_fe

    .line 215
    .line 216
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 217
    .line 218
    .line 219
    move-result-object p0

    .line 220
    instance-of p1, p0, Ljava/util/List;

    .line 221
    .line 222
    if-eqz p1, :cond_e2

    .line 223
    .line 224
    check-cast p0, Ljava/util/List;

    .line 225
    .line 226
    goto :goto_e3

    .line 227
    :cond_e2
    move-object p0, v5

    .line 228
    :goto_e3
    if-eqz p0, :cond_17e

    .line 229
    .line 230
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 231
    .line 232
    .line 233
    move-result-object p1

    .line 234
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 235
    .line 236
    .line 237
    check-cast p1, Lqt;

    .line 238
    .line 239
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object p0

    .line 243
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 244
    .line 245
    .line 246
    check-cast p0, Ljava/lang/String;

    .line 247
    .line 248
    new-instance v5, Lrt;

    .line 249
    .line 250
    invoke-direct {v5, p1, p0}, Lrt;-><init>(Lqt;Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    goto/16 :goto_17e

    .line 254
    .line 255
    :cond_fe
    const/16 v0, -0x7d

    .line 256
    .line 257
    if-ne p1, v0, :cond_150

    .line 258
    .line 259
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 260
    .line 261
    .line 262
    move-result-object p0

    .line 263
    instance-of p1, p0, Ljava/util/List;

    .line 264
    .line 265
    if-eqz p1, :cond_10d

    .line 266
    .line 267
    check-cast p0, Ljava/util/List;

    .line 268
    .line 269
    goto :goto_10e

    .line 270
    :cond_10d
    move-object p0, v5

    .line 271
    :goto_10e
    if-eqz p0, :cond_17e

    .line 272
    .line 273
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object p1

    .line 277
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 278
    .line 279
    .line 280
    move-object v4, p1

    .line 281
    check-cast v4, Ljava/lang/String;

    .line 282
    .line 283
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 284
    .line 285
    .line 286
    move-result-object p1

    .line 287
    move-object v5, p1

    .line 288
    check-cast v5, Ljava/lang/String;

    .line 289
    .line 290
    invoke-interface {p0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object p1

    .line 294
    move-object v6, p1

    .line 295
    check-cast v6, Ljava/lang/String;

    .line 296
    .line 297
    const/4 p1, 0x3

    .line 298
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 299
    .line 300
    .line 301
    move-result-object p1

    .line 302
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 303
    .line 304
    .line 305
    check-cast p1, Ljava/lang/Long;

    .line 306
    .line 307
    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    .line 308
    .line 309
    .line 310
    move-result-wide v7

    .line 311
    const/4 p1, 0x4

    .line 312
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 313
    .line 314
    .line 315
    move-result-object p1

    .line 316
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 317
    .line 318
    .line 319
    move-object v9, p1

    .line 320
    check-cast v9, [B

    .line 321
    .line 322
    const/4 p1, 0x5

    .line 323
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 324
    .line 325
    .line 326
    move-result-object p0

    .line 327
    move-object v10, p0

    .line 328
    check-cast v10, Lrt;

    .line 329
    .line 330
    new-instance v3, Lht;

    .line 331
    .line 332
    invoke-direct/range {v3 .. v10}, Lht;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J[BLrt;)V

    .line 333
    .line 334
    .line 335
    move-object v5, v3

    .line 336
    goto :goto_17e

    .line 337
    :cond_150
    const/16 v0, -0x7c

    .line 338
    .line 339
    if-ne p1, v0, :cond_17a

    .line 340
    .line 341
    invoke-virtual {p0, p2}, Lyz0;->e(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 342
    .line 343
    .line 344
    move-result-object p0

    .line 345
    instance-of p1, p0, Ljava/util/List;

    .line 346
    .line 347
    if-eqz p1, :cond_15f

    .line 348
    .line 349
    check-cast p0, Ljava/util/List;

    .line 350
    .line 351
    goto :goto_160

    .line 352
    :cond_15f
    move-object p0, v5

    .line 353
    :goto_160
    if-eqz p0, :cond_17e

    .line 354
    .line 355
    invoke-interface {p0, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 356
    .line 357
    .line 358
    move-result-object p1

    .line 359
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 360
    .line 361
    .line 362
    check-cast p1, Ljava/util/List;

    .line 363
    .line 364
    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 365
    .line 366
    .line 367
    move-result-object p0

    .line 368
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 369
    .line 370
    .line 371
    check-cast p0, Ljava/util/List;

    .line 372
    .line 373
    new-instance v5, Lxt;

    .line 374
    .line 375
    invoke-direct {v5, p1, p0}, Lxt;-><init>(Ljava/util/List;Ljava/util/List;)V

    .line 376
    .line 377
    .line 378
    goto :goto_17e

    .line 379
    :cond_17a
    invoke-super {p0, p1, p2}, Lyz0;->f(BLjava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 380
    .line 381
    .line 382
    move-result-object v5

    .line 383
    :cond_17e
    :goto_17e
    return-object v5

    .line 384
    nop

    .line 385
    :pswitch_data_180
    .packed-switch 0x0
        :pswitch_ae
        :pswitch_4d
    .end packed-switch
.end method

.method public final k(Lxz0;Ljava/lang/Object;)V
    .registers 9

    .line 1
    iget v0, p0, Lc00;->d:I

    .line 2
    .line 3
    const/16 v1, 0x82

    .line 4
    .line 5
    const/16 v2, 0x81

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_ea

    .line 8
    .line 9
    .line 10
    instance-of v0, p2, Ld41;

    .line 11
    .line 12
    if-eqz v0, :cond_1c

    .line 13
    .line 14
    invoke-virtual {p1, v2}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 15
    .line 16
    .line 17
    check-cast p2, Ld41;

    .line 18
    .line 19
    iget-object p2, p2, Ld41;->a:Ljava/lang/Boolean;

    .line 20
    .line 21
    invoke-static {p2}, Llf1;->y(Ljava/lang/Object;)Ljava/util/List;

    .line 22
    .line 23
    .line 24
    move-result-object p2

    .line 25
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    goto :goto_32

    .line 29
    :cond_1c
    instance-of v0, p2, Lf50;

    .line 30
    .line 31
    if-eqz v0, :cond_2f

    .line 32
    .line 33
    invoke-virtual {p1, v1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 34
    .line 35
    .line 36
    check-cast p2, Lf50;

    .line 37
    .line 38
    iget-object p2, p2, Lf50;->a:Ljava/lang/Boolean;

    .line 39
    .line 40
    invoke-static {p2}, Llf1;->y(Ljava/lang/Object;)Ljava/util/List;

    .line 41
    .line 42
    .line 43
    move-result-object p2

    .line 44
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    goto :goto_32

    .line 48
    :cond_2f
    invoke-super {p0, p1, p2}, Lyz0;->k(Lxz0;Ljava/lang/Object;)V

    .line 49
    .line 50
    .line 51
    :goto_32
    return-void

    .line 52
    :pswitch_33
    instance-of v0, p2, Lpb1;

    .line 53
    .line 54
    if-eqz v0, :cond_56

    .line 55
    .line 56
    invoke-virtual {p1, v2}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 57
    .line 58
    .line 59
    check-cast p2, Lpb1;

    .line 60
    .line 61
    iget-boolean v0, p2, Lpb1;->a:Z

    .line 62
    .line 63
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 64
    .line 65
    .line 66
    move-result-object v0

    .line 67
    iget-boolean v1, p2, Lpb1;->b:Z

    .line 68
    .line 69
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 70
    .line 71
    .line 72
    move-result-object v1

    .line 73
    iget-object p2, p2, Lpb1;->c:Ljava/util/Map;

    .line 74
    .line 75
    filled-new-array {v0, v1, p2}, [Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object p2

    .line 79
    invoke-static {p2}, Llf1;->z([Ljava/lang/Object;)Ljava/util/List;

    .line 80
    .line 81
    .line 82
    move-result-object p2

    .line 83
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 84
    .line 85
    .line 86
    goto :goto_70

    .line 87
    :cond_56
    instance-of v0, p2, Lza;

    .line 88
    .line 89
    if-eqz v0, :cond_6d

    .line 90
    .line 91
    invoke-virtual {p1, v1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 92
    .line 93
    .line 94
    check-cast p2, Lza;

    .line 95
    .line 96
    iget-boolean p2, p2, Lza;->a:Z

    .line 97
    .line 98
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 99
    .line 100
    .line 101
    move-result-object p2

    .line 102
    invoke-static {p2}, Llf1;->y(Ljava/lang/Object;)Ljava/util/List;

    .line 103
    .line 104
    .line 105
    move-result-object p2

    .line 106
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    goto :goto_70

    .line 110
    :cond_6d
    invoke-super {p0, p1, p2}, Lyz0;->k(Lxz0;Ljava/lang/Object;)V

    .line 111
    .line 112
    .line 113
    :goto_70
    return-void

    .line 114
    :pswitch_71
    instance-of v0, p2, Lqt;

    .line 115
    .line 116
    if-eqz v0, :cond_85

    .line 117
    .line 118
    invoke-virtual {p1, v2}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 119
    .line 120
    .line 121
    check-cast p2, Lqt;

    .line 122
    .line 123
    iget p2, p2, Lqt;->f:I

    .line 124
    .line 125
    int-to-long v0, p2

    .line 126
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 127
    .line 128
    .line 129
    move-result-object p2

    .line 130
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 131
    .line 132
    .line 133
    goto :goto_e8

    .line 134
    :cond_85
    instance-of v0, p2, Lrt;

    .line 135
    .line 136
    if-eqz v0, :cond_9e

    .line 137
    .line 138
    invoke-virtual {p1, v1}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 139
    .line 140
    .line 141
    check-cast p2, Lrt;

    .line 142
    .line 143
    iget-object v0, p2, Lrt;->a:Lqt;

    .line 144
    .line 145
    iget-object p2, p2, Lrt;->b:Ljava/lang/String;

    .line 146
    .line 147
    filled-new-array {v0, p2}, [Ljava/lang/Object;

    .line 148
    .line 149
    .line 150
    move-result-object p2

    .line 151
    invoke-static {p2}, Llf1;->z([Ljava/lang/Object;)Ljava/util/List;

    .line 152
    .line 153
    .line 154
    move-result-object p2

    .line 155
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 156
    .line 157
    .line 158
    goto :goto_e8

    .line 159
    :cond_9e
    instance-of v0, p2, Lht;

    .line 160
    .line 161
    if-eqz v0, :cond_c5

    .line 162
    .line 163
    const/16 v0, 0x83

    .line 164
    .line 165
    invoke-virtual {p1, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 166
    .line 167
    .line 168
    check-cast p2, Lht;

    .line 169
    .line 170
    iget-object v0, p2, Lht;->a:Ljava/lang/String;

    .line 171
    .line 172
    iget-object v1, p2, Lht;->b:Ljava/lang/String;

    .line 173
    .line 174
    iget-object v2, p2, Lht;->c:Ljava/lang/String;

    .line 175
    .line 176
    iget-wide v3, p2, Lht;->d:J

    .line 177
    .line 178
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 179
    .line 180
    .line 181
    move-result-object v3

    .line 182
    iget-object v4, p2, Lht;->e:[B

    .line 183
    .line 184
    iget-object v5, p2, Lht;->f:Lrt;

    .line 185
    .line 186
    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    .line 187
    .line 188
    .line 189
    move-result-object p2

    .line 190
    invoke-static {p2}, Llf1;->z([Ljava/lang/Object;)Ljava/util/List;

    .line 191
    .line 192
    .line 193
    move-result-object p2

    .line 194
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 195
    .line 196
    .line 197
    goto :goto_e8

    .line 198
    :cond_c5
    instance-of v0, p2, Lxt;

    .line 199
    .line 200
    if-eqz v0, :cond_e5

    .line 201
    .line 202
    const/16 v0, 0x84

    .line 203
    .line 204
    invoke-virtual {p1, v0}, Ljava/io/ByteArrayOutputStream;->write(I)V

    .line 205
    .line 206
    .line 207
    check-cast p2, Lxt;

    .line 208
    .line 209
    iget-object v0, p2, Lxt;->a:Ljava/util/List;

    .line 210
    .line 211
    iget-object p2, p2, Lxt;->b:Ljava/util/List;

    .line 212
    .line 213
    const/4 v1, 0x2

    .line 214
    new-array v1, v1, [Ljava/util/List;

    .line 215
    .line 216
    const/4 v2, 0x0

    .line 217
    aput-object v0, v1, v2

    .line 218
    .line 219
    const/4 v0, 0x1

    .line 220
    aput-object p2, v1, v0

    .line 221
    .line 222
    invoke-static {v1}, Llf1;->z([Ljava/lang/Object;)Ljava/util/List;

    .line 223
    .line 224
    .line 225
    move-result-object p2

    .line 226
    invoke-virtual {p0, p1, p2}, Lc00;->k(Lxz0;Ljava/lang/Object;)V

    .line 227
    .line 228
    .line 229
    goto :goto_e8

    .line 230
    :cond_e5
    invoke-super {p0, p1, p2}, Lyz0;->k(Lxz0;Ljava/lang/Object;)V

    .line 231
    .line 232
    .line 233
    :goto_e8
    return-void

    .line 234
    nop

    .line 235
    :pswitch_data_ea
    .packed-switch 0x0
        :pswitch_71
        :pswitch_33
    .end packed-switch
.end method
