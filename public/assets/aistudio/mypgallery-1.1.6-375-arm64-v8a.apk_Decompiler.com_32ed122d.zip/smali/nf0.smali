###### Class defpackage.nf0 (nf0)
.class public final Lnf0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:[J

.field public b:[Ljava/lang/Object;

.field public c:[I

.field public d:I

.field public e:I

.field public f:I


# virtual methods
.method public final a(I)I
    .registers 11

    .line 1
    iget v0, p0, Lnf0;->d:I

    .line 2
    .line 3
    and-int/2addr p1, v0

    .line 4
    const/4 v1, 0x0

    .line 5
    :goto_4
    iget-object v2, p0, Lnf0;->a:[J

    .line 6
    .line 7
    shr-int/lit8 v3, p1, 0x3

    .line 8
    .line 9
    and-int/lit8 v4, p1, 0x7

    .line 10
    .line 11
    shl-int/lit8 v4, v4, 0x3

    .line 12
    .line 13
    aget-wide v5, v2, v3

    .line 14
    .line 15
    ushr-long/2addr v5, v4

    .line 16
    add-int/lit8 v3, v3, 0x1

    .line 17
    .line 18
    aget-wide v2, v2, v3

    .line 19
    .line 20
    rsub-int/lit8 v7, v4, 0x40

    .line 21
    .line 22
    shl-long/2addr v2, v7

    .line 23
    int-to-long v7, v4

    .line 24
    neg-long v7, v7

    .line 25
    const/16 v4, 0x3f

    .line 26
    .line 27
    shr-long/2addr v7, v4

    .line 28
    and-long/2addr v2, v7

    .line 29
    or-long/2addr v2, v5

    .line 30
    not-long v4, v2

    .line 31
    const/4 v6, 0x7

    .line 32
    shl-long/2addr v4, v6

    .line 33
    and-long/2addr v2, v4

    .line 34
    const-wide v4, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    and-long/2addr v2, v4

    .line 40
    const-wide/16 v4, 0x0

    .line 41
    .line 42
    cmp-long v4, v2, v4

    .line 43
    .line 44
    if-eqz v4, :cond_37

    .line 45
    .line 46
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    shr-int/lit8 p0, p0, 0x3

    .line 51
    .line 52
    add-int/2addr p1, p0

    .line 53
    and-int p0, p1, v0

    .line 54
    .line 55
    return p0

    .line 56
    :cond_37
    add-int/lit8 v1, v1, 0x8

    .line 57
    .line 58
    add-int/2addr p1, v1

    .line 59
    and-int/2addr p1, v0

    .line 60
    goto :goto_4
.end method

.method public final b(I)V
    .registers 11

    .line 1
    if-lez p1, :cond_c

    .line 2
    .line 3
    invoke-static {p1}, Lvr0;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    const/4 v0, 0x7

    .line 8
    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 p1, 0x0

    .line 14
    :goto_d
    iput p1, p0, Lnf0;->d:I

    .line 15
    .line 16
    if-nez p1, :cond_14

    .line 17
    .line 18
    sget-object v0, Lvr0;->a:[J

    .line 19
    .line 20
    goto :goto_1f

    .line 21
    :cond_14
    add-int/lit8 v0, p1, 0xf

    .line 22
    .line 23
    and-int/lit8 v0, v0, -0x8

    .line 24
    .line 25
    shr-int/lit8 v0, v0, 0x3

    .line 26
    .line 27
    new-array v0, v0, [J

    .line 28
    .line 29
    invoke-static {v0}, Lj9;->Y([J)V

    .line 30
    .line 31
    .line 32
    :goto_1f
    iput-object v0, p0, Lnf0;->a:[J

    .line 33
    .line 34
    shr-int/lit8 v1, p1, 0x3

    .line 35
    .line 36
    and-int/lit8 v2, p1, 0x7

    .line 37
    .line 38
    shl-int/lit8 v2, v2, 0x3

    .line 39
    .line 40
    aget-wide v3, v0, v1

    .line 41
    .line 42
    const-wide/16 v5, 0xff

    .line 43
    .line 44
    shl-long/2addr v5, v2

    .line 45
    not-long v7, v5

    .line 46
    and-long v2, v3, v7

    .line 47
    .line 48
    or-long/2addr v2, v5

    .line 49
    aput-wide v2, v0, v1

    .line 50
    .line 51
    iget v0, p0, Lnf0;->d:I

    .line 52
    .line 53
    invoke-static {v0}, Lvr0;->c(I)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    iget v1, p0, Lnf0;->e:I

    .line 58
    .line 59
    sub-int/2addr v0, v1

    .line 60
    iput v0, p0, Lnf0;->f:I

    .line 61
    .line 62
    new-array v0, p1, [Ljava/lang/Object;

    .line 63
    .line 64
    iput-object v0, p0, Lnf0;->b:[Ljava/lang/Object;

    .line 65
    .line 66
    new-array p1, p1, [I

    .line 67
    .line 68
    iput-object p1, p0, Lnf0;->c:[I

    .line 69
    .line 70
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-ne v1, v0, :cond_8

    .line 7
    .line 8
    return v2

    .line 9
    :cond_8
    instance-of v3, v1, Lnf0;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    if-nez v3, :cond_e

    .line 13
    .line 14
    return v4

    .line 15
    :cond_e
    check-cast v1, Lnf0;

    .line 16
    .line 17
    iget v3, v1, Lnf0;->e:I

    .line 18
    .line 19
    iget v5, v0, Lnf0;->e:I

    .line 20
    .line 21
    if-eq v3, v5, :cond_17

    .line 22
    .line 23
    return v4

    .line 24
    :cond_17
    iget-object v3, v0, Lnf0;->b:[Ljava/lang/Object;

    .line 25
    .line 26
    iget-object v5, v0, Lnf0;->c:[I

    .line 27
    .line 28
    iget-object v0, v0, Lnf0;->a:[J

    .line 29
    .line 30
    array-length v6, v0

    .line 31
    add-int/lit8 v6, v6, -0x2

    .line 32
    .line 33
    if-ltz v6, :cond_149

    .line 34
    .line 35
    move v7, v4

    .line 36
    :goto_23
    aget-wide v8, v0, v7

    .line 37
    .line 38
    not-long v10, v8

    .line 39
    const/4 v12, 0x7

    .line 40
    shl-long/2addr v10, v12

    .line 41
    and-long/2addr v10, v8

    .line 42
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    and-long/2addr v10, v13

    .line 48
    cmp-long v10, v10, v13

    .line 49
    .line 50
    if-eqz v10, :cond_137

    .line 51
    .line 52
    sub-int v10, v7, v6

    .line 53
    .line 54
    not-int v10, v10

    .line 55
    ushr-int/lit8 v10, v10, 0x1f

    .line 56
    .line 57
    const/16 v11, 0x8

    .line 58
    .line 59
    rsub-int/lit8 v10, v10, 0x8

    .line 60
    .line 61
    move v15, v4

    .line 62
    :goto_3d
    if-ge v15, v10, :cond_12d

    .line 63
    .line 64
    const-wide/16 v16, 0xff

    .line 65
    .line 66
    and-long v16, v8, v16

    .line 67
    .line 68
    const-wide/16 v18, 0x80

    .line 69
    .line 70
    cmp-long v16, v16, v18

    .line 71
    .line 72
    if-gez v16, :cond_10d

    .line 73
    .line 74
    shl-int/lit8 v16, v7, 0x3

    .line 75
    .line 76
    add-int v16, v16, v15

    .line 77
    .line 78
    move/from16 v17, v2

    .line 79
    .line 80
    aget-object v2, v3, v16

    .line 81
    .line 82
    move/from16 v18, v4

    .line 83
    .line 84
    aget v4, v5, v16

    .line 85
    .line 86
    if-eqz v2, :cond_5c

    .line 87
    .line 88
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 89
    .line 90
    .line 91
    move-result v16

    .line 92
    goto :goto_5e

    .line 93
    :cond_5c
    move/from16 v16, v18

    .line 94
    .line 95
    :goto_5e
    const v19, -0x3361d2af    # -8.293031E7f

    .line 96
    .line 97
    .line 98
    mul-int v16, v16, v19

    .line 99
    .line 100
    shl-int/lit8 v19, v16, 0x10

    .line 101
    .line 102
    xor-int v16, v16, v19

    .line 103
    .line 104
    move/from16 p0, v12

    .line 105
    .line 106
    and-int/lit8 v12, v16, 0x7f

    .line 107
    .line 108
    move-wide/from16 v19, v13

    .line 109
    .line 110
    iget v13, v1, Lnf0;->d:I

    .line 111
    .line 112
    ushr-int/lit8 v14, v16, 0x7

    .line 113
    .line 114
    and-int/2addr v14, v13

    .line 115
    move/from16 p1, v11

    .line 116
    .line 117
    move/from16 v16, v18

    .line 118
    .line 119
    :goto_76
    iget-object v11, v1, Lnf0;->a:[J

    .line 120
    .line 121
    shr-int/lit8 v21, v14, 0x3

    .line 122
    .line 123
    and-int/lit8 v22, v14, 0x7

    .line 124
    .line 125
    move-object/from16 v23, v0

    .line 126
    .line 127
    shl-int/lit8 v0, v22, 0x3

    .line 128
    .line 129
    aget-wide v24, v11, v21

    .line 130
    .line 131
    ushr-long v24, v24, v0

    .line 132
    .line 133
    add-int/lit8 v21, v21, 0x1

    .line 134
    .line 135
    aget-wide v21, v11, v21

    .line 136
    .line 137
    rsub-int/lit8 v11, v0, 0x40

    .line 138
    .line 139
    shl-long v21, v21, v11

    .line 140
    .line 141
    move-wide/from16 v26, v8

    .line 142
    .line 143
    int-to-long v8, v0

    .line 144
    neg-long v8, v8

    .line 145
    const/16 v0, 0x3f

    .line 146
    .line 147
    shr-long/2addr v8, v0

    .line 148
    and-long v8, v21, v8

    .line 149
    .line 150
    or-long v8, v24, v8

    .line 151
    .line 152
    move v0, v13

    .line 153
    move v11, v14

    .line 154
    int-to-long v13, v12

    .line 155
    const-wide v21, 0x101010101010101L

    .line 156
    .line 157
    .line 158
    .line 159
    .line 160
    mul-long v13, v13, v21

    .line 161
    .line 162
    xor-long/2addr v13, v8

    .line 163
    sub-long v21, v13, v21

    .line 164
    .line 165
    not-long v13, v13

    .line 166
    and-long v13, v21, v13

    .line 167
    .line 168
    and-long v13, v13, v19

    .line 169
    .line 170
    :goto_a9
    const-wide/16 v21, 0x0

    .line 171
    .line 172
    cmp-long v24, v13, v21

    .line 173
    .line 174
    if-eqz v24, :cond_cf

    .line 175
    .line 176
    invoke-static {v13, v14}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 177
    .line 178
    .line 179
    move-result v21

    .line 180
    shr-int/lit8 v21, v21, 0x3

    .line 181
    .line 182
    add-int v21, v11, v21

    .line 183
    .line 184
    and-int v21, v21, v0

    .line 185
    .line 186
    move/from16 v24, v0

    .line 187
    .line 188
    iget-object v0, v1, Lnf0;->b:[Ljava/lang/Object;

    .line 189
    .line 190
    aget-object v0, v0, v21

    .line 191
    .line 192
    invoke-static {v0, v2}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 193
    .line 194
    .line 195
    move-result v0

    .line 196
    if-eqz v0, :cond_c6

    .line 197
    .line 198
    goto :goto_dd

    .line 199
    :cond_c6
    const-wide/16 v21, 0x1

    .line 200
    .line 201
    sub-long v21, v13, v21

    .line 202
    .line 203
    and-long v13, v13, v21

    .line 204
    .line 205
    move/from16 v0, v24

    .line 206
    .line 207
    goto :goto_a9

    .line 208
    :cond_cf
    move/from16 v24, v0

    .line 209
    .line 210
    not-long v13, v8

    .line 211
    const/4 v0, 0x6

    .line 212
    shl-long/2addr v13, v0

    .line 213
    and-long/2addr v8, v13

    .line 214
    and-long v8, v8, v19

    .line 215
    .line 216
    cmp-long v0, v8, v21

    .line 217
    .line 218
    if-eqz v0, :cond_ff

    .line 219
    .line 220
    const/16 v21, -0x1

    .line 221
    .line 222
    :goto_dd
    if-ltz v21, :cond_e6

    .line 223
    .line 224
    iget-object v0, v1, Lnf0;->c:[I

    .line 225
    .line 226
    aget v0, v0, v21

    .line 227
    .line 228
    if-eq v4, v0, :cond_11b

    .line 229
    .line 230
    return v18

    .line 231
    :cond_e6
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 232
    .line 233
    new-instance v1, Ljava/lang/StringBuilder;

    .line 234
    .line 235
    const-string v3, "There is no key "

    .line 236
    .line 237
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 241
    .line 242
    .line 243
    const-string v2, " in the map"

    .line 244
    .line 245
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 246
    .line 247
    .line 248
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object v1

    .line 252
    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 253
    .line 254
    .line 255
    throw v0

    .line 256
    :cond_ff
    add-int/lit8 v16, v16, 0x8

    .line 257
    .line 258
    add-int v14, v11, v16

    .line 259
    .line 260
    and-int v14, v14, v24

    .line 261
    .line 262
    move-object/from16 v0, v23

    .line 263
    .line 264
    move/from16 v13, v24

    .line 265
    .line 266
    move-wide/from16 v8, v26

    .line 267
    .line 268
    goto/16 :goto_76

    .line 269
    .line 270
    :cond_10d
    move-object/from16 v23, v0

    .line 271
    .line 272
    move/from16 v17, v2

    .line 273
    .line 274
    move/from16 v18, v4

    .line 275
    .line 276
    move-wide/from16 v26, v8

    .line 277
    .line 278
    move/from16 p1, v11

    .line 279
    .line 280
    move/from16 p0, v12

    .line 281
    .line 282
    move-wide/from16 v19, v13

    .line 283
    .line 284
    :cond_11b
    shr-long v8, v26, p1

    .line 285
    .line 286
    add-int/lit8 v15, v15, 0x1

    .line 287
    .line 288
    move/from16 v12, p0

    .line 289
    .line 290
    move/from16 v11, p1

    .line 291
    .line 292
    move/from16 v2, v17

    .line 293
    .line 294
    move/from16 v4, v18

    .line 295
    .line 296
    move-wide/from16 v13, v19

    .line 297
    .line 298
    move-object/from16 v0, v23

    .line 299
    .line 300
    goto/16 :goto_3d

    .line 301
    .line 302
    :cond_12d
    move-object/from16 v23, v0

    .line 303
    .line 304
    move/from16 v17, v2

    .line 305
    .line 306
    move/from16 v18, v4

    .line 307
    .line 308
    move v0, v11

    .line 309
    if-ne v10, v0, :cond_14b

    .line 310
    .line 311
    goto :goto_13d

    .line 312
    :cond_137
    move-object/from16 v23, v0

    .line 313
    .line 314
    move/from16 v17, v2

    .line 315
    .line 316
    move/from16 v18, v4

    .line 317
    .line 318
    :goto_13d
    if-eq v7, v6, :cond_14b

    .line 319
    .line 320
    add-int/lit8 v7, v7, 0x1

    .line 321
    .line 322
    move/from16 v2, v17

    .line 323
    .line 324
    move/from16 v4, v18

    .line 325
    .line 326
    move-object/from16 v0, v23

    .line 327
    .line 328
    goto/16 :goto_23

    .line 329
    .line 330
    :cond_149
    move/from16 v17, v2

    .line 331
    .line 332
    :cond_14b
    return v17
.end method

.method public final hashCode()I
    .registers 16

    .line 1
    iget-object v0, p0, Lnf0;->b:[Ljava/lang/Object;

    .line 2
    .line 3
    iget-object v1, p0, Lnf0;->c:[I

    .line 4
    .line 5
    iget-object p0, p0, Lnf0;->a:[J

    .line 6
    .line 7
    array-length v2, p0

    .line 8
    add-int/lit8 v2, v2, -0x2

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    if-ltz v2, :cond_56

    .line 12
    .line 13
    move v4, v3

    .line 14
    move v5, v4

    .line 15
    :goto_e
    aget-wide v6, p0, v4

    .line 16
    .line 17
    not-long v8, v6

    .line 18
    const/4 v10, 0x7

    .line 19
    shl-long/2addr v8, v10

    .line 20
    and-long/2addr v8, v6

    .line 21
    const-wide v10, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    and-long/2addr v8, v10

    .line 27
    cmp-long v8, v8, v10

    .line 28
    .line 29
    if-eqz v8, :cond_50

    .line 30
    .line 31
    sub-int v8, v4, v2

    .line 32
    .line 33
    not-int v8, v8

    .line 34
    ushr-int/lit8 v8, v8, 0x1f

    .line 35
    .line 36
    const/16 v9, 0x8

    .line 37
    .line 38
    rsub-int/lit8 v8, v8, 0x8

    .line 39
    .line 40
    move v10, v3

    .line 41
    :goto_28
    if-ge v10, v8, :cond_4c

    .line 42
    .line 43
    const-wide/16 v11, 0xff

    .line 44
    .line 45
    and-long/2addr v11, v6

    .line 46
    const-wide/16 v13, 0x80

    .line 47
    .line 48
    cmp-long v11, v11, v13

    .line 49
    .line 50
    if-gez v11, :cond_48

    .line 51
    .line 52
    shl-int/lit8 v11, v4, 0x3

    .line 53
    .line 54
    add-int/2addr v11, v10

    .line 55
    aget-object v12, v0, v11

    .line 56
    .line 57
    aget v11, v1, v11

    .line 58
    .line 59
    if-eqz v12, :cond_41

    .line 60
    .line 61
    invoke-virtual {v12}, Ljava/lang/Object;->hashCode()I

    .line 62
    .line 63
    .line 64
    move-result v12

    .line 65
    goto :goto_42

    .line 66
    :cond_41
    move v12, v3

    .line 67
    :goto_42
    invoke-static {v11}, Ljava/lang/Integer;->hashCode(I)I

    .line 68
    .line 69
    .line 70
    move-result v11

    .line 71
    xor-int/2addr v11, v12

    .line 72
    add-int/2addr v5, v11

    .line 73
    :cond_48
    shr-long/2addr v6, v9

    .line 74
    add-int/lit8 v10, v10, 0x1

    .line 75
    .line 76
    goto :goto_28

    .line 77
    :cond_4c
    if-ne v8, v9, :cond_4f

    .line 78
    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    return v5

    .line 81
    :cond_50
    :goto_50
    if-eq v4, v2, :cond_55

    .line 82
    .line 83
    add-int/lit8 v4, v4, 0x1

    .line 84
    .line 85
    goto :goto_e

    .line 86
    :cond_55
    return v5

    .line 87
    :cond_56
    return v3
.end method

.method public final toString()Ljava/lang/String;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lnf0;->e:I

    .line 4
    .line 5
    if-nez v1, :cond_9

    .line 6
    .line 7
    const-string v0, "{}"

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_9
    new-instance v1, Ljava/lang/StringBuilder;

    .line 11
    .line 12
    const-string v2, "{"

    .line 13
    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v2, v0, Lnf0;->b:[Ljava/lang/Object;

    .line 18
    .line 19
    iget-object v3, v0, Lnf0;->c:[I

    .line 20
    .line 21
    iget-object v4, v0, Lnf0;->a:[J

    .line 22
    .line 23
    array-length v5, v4

    .line 24
    add-int/lit8 v5, v5, -0x2

    .line 25
    .line 26
    if-ltz v5, :cond_6f

    .line 27
    .line 28
    const/4 v6, 0x0

    .line 29
    move v7, v6

    .line 30
    move v8, v7

    .line 31
    :goto_1e
    aget-wide v9, v4, v7

    .line 32
    .line 33
    not-long v11, v9

    .line 34
    const/4 v13, 0x7

    .line 35
    shl-long/2addr v11, v13

    .line 36
    and-long/2addr v11, v9

    .line 37
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    and-long/2addr v11, v13

    .line 43
    cmp-long v11, v11, v13

    .line 44
    .line 45
    if-eqz v11, :cond_6a

    .line 46
    .line 47
    sub-int v11, v7, v5

    .line 48
    .line 49
    not-int v11, v11

    .line 50
    ushr-int/lit8 v11, v11, 0x1f

    .line 51
    .line 52
    const/16 v12, 0x8

    .line 53
    .line 54
    rsub-int/lit8 v11, v11, 0x8

    .line 55
    .line 56
    move v13, v6

    .line 57
    :goto_38
    if-ge v13, v11, :cond_68

    .line 58
    .line 59
    const-wide/16 v14, 0xff

    .line 60
    .line 61
    and-long/2addr v14, v9

    .line 62
    const-wide/16 v16, 0x80

    .line 63
    .line 64
    cmp-long v14, v14, v16

    .line 65
    .line 66
    if-gez v14, :cond_64

    .line 67
    .line 68
    shl-int/lit8 v14, v7, 0x3

    .line 69
    .line 70
    add-int/2addr v14, v13

    .line 71
    aget-object v15, v2, v14

    .line 72
    .line 73
    aget v14, v3, v14

    .line 74
    .line 75
    if-ne v15, v0, :cond_4e

    .line 76
    .line 77
    const-string v15, "(this)"

    .line 78
    .line 79
    :cond_4e
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    const-string v15, "="

    .line 83
    .line 84
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 85
    .line 86
    .line 87
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    add-int/lit8 v8, v8, 0x1

    .line 91
    .line 92
    iget v14, v0, Lnf0;->e:I

    .line 93
    .line 94
    if-ge v8, v14, :cond_64

    .line 95
    .line 96
    const-string v14, ", "

    .line 97
    .line 98
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    :cond_64
    shr-long/2addr v9, v12

    .line 102
    add-int/lit8 v13, v13, 0x1

    .line 103
    .line 104
    goto :goto_38

    .line 105
    :cond_68
    if-ne v11, v12, :cond_6f

    .line 106
    .line 107
    :cond_6a
    if-eq v7, v5, :cond_6f

    .line 108
    .line 109
    add-int/lit8 v7, v7, 0x1

    .line 110
    .line 111
    goto :goto_1e

    .line 112
    :cond_6f
    const/16 v0, 0x7d

    .line 113
    .line 114
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    return-object v0
.end method
