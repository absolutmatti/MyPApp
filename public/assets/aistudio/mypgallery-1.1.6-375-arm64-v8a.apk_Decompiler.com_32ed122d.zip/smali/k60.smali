###### Class defpackage.k60 (k60)
.class public final Lk60;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:I

.field public final b:Ljava/lang/Object;

.field public final c:I

.field public final d:I


# direct methods
.method public constructor <init>(Ljava/lang/Object;III)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p2, p0, Lk60;->a:I

    .line 5
    .line 6
    iput-object p1, p0, Lk60;->b:Ljava/lang/Object;

    .line 7
    .line 8
    iput p3, p0, Lk60;->c:I

    .line 9
    .line 10
    iput p4, p0, Lk60;->d:I

    .line 11
    .line 12
    return-void
.end method
