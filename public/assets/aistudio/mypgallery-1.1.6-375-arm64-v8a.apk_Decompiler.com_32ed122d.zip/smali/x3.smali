###### Class defpackage.x3 (x3)
.class public final Lx3;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:I

.field public b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 39
    iput p1, p0, Lx3;->a:I

    iput-object p2, p0, Lx3;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(IZ)V
    .registers 3

    .line 1
    packed-switch p1, :pswitch_data_1c

    .line 2
    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    iput p1, p0, Lx3;->a:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    invoke-static {p1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    iput-object p1, p0, Lx3;->b:Ljava/lang/Object;

    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    .line 20
    .line 21
    const/16 p1, 0xa

    .line 22
    .line 23
    new-array p1, p1, [I

    .line 24
    .line 25
    iput-object p1, p0, Lx3;->b:Ljava/lang/Object;

    .line 26
    .line 27
    return-void

    .line 28
    nop

    .line 29
    :pswitch_data_1c
    .packed-switch 0x3
        :pswitch_11
    .end packed-switch
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    const/4 v0, 0x0

    .line 34
    invoke-static {p1, v0}, Ly3;->e(Landroid/content/Context;I)I

    move-result v0

    invoke-direct {p0, p1, v0}, Lx3;-><init>(Landroid/content/Context;I)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .registers 6

    .line 35
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 36
    new-instance v0, Lt3;

    new-instance v1, Landroid/view/ContextThemeWrapper;

    .line 37
    invoke-static {p1, p2}, Ly3;->e(Landroid/content/Context;I)I

    move-result v2

    invoke-direct {v1, p1, v2}, Landroid/view/ContextThemeWrapper;-><init>(Landroid/content/Context;I)V

    invoke-direct {v0, v1}, Lt3;-><init>(Landroid/view/ContextThemeWrapper;)V

    iput-object v0, p0, Lx3;->b:Ljava/lang/Object;

    .line 38
    iput p2, p0, Lx3;->a:I

    return-void
.end method

.method public constructor <init>(Lb51;I)V
    .registers 3

    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lx3;->b:Ljava/lang/Object;

    iput p2, p0, Lx3;->a:I

    return-void
.end method

.method public constructor <init>(Ldq0;I)V
    .registers 3

    .line 31
    iput-object p1, p0, Lx3;->b:Ljava/lang/Object;

    .line 32
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 33
    iput p2, p0, Lx3;->a:I

    return-void
.end method

.method public constructor <init>(Lrg;I)V
    .registers 3

    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lr30;->j(Ljava/lang/Object;)V

    iput-object p1, p0, Lx3;->b:Ljava/lang/Object;

    iput p2, p0, Lx3;->a:I

    return-void
.end method

.method public static b(Ljava/lang/String;)V
    .registers 8

    .line 1
    const-string v0, ":memory:"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_5f

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x1

    .line 14
    sub-int/2addr v0, v1

    .line 15
    const/4 v2, 0x0

    .line 16
    move v3, v2

    .line 17
    move v4, v3

    .line 18
    :goto_11
    if-gt v3, v0, :cond_35

    .line 19
    .line 20
    if-nez v4, :cond_17

    .line 21
    .line 22
    move v5, v3

    .line 23
    goto :goto_18

    .line 24
    :cond_17
    move v5, v0

    .line 25
    :goto_18
    invoke-virtual {p0, v5}, Ljava/lang/String;->charAt(I)C

    .line 26
    .line 27
    .line 28
    move-result v5

    .line 29
    const/16 v6, 0x20

    .line 30
    .line 31
    if-ge v5, v6, :cond_21

    .line 32
    .line 33
    goto :goto_23

    .line 34
    :cond_21
    if-ne v5, v6, :cond_25

    .line 35
    .line 36
    :goto_23
    move v5, v1

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    move v5, v2

    .line 39
    :goto_26
    if-nez v4, :cond_2f

    .line 40
    .line 41
    if-nez v5, :cond_2c

    .line 42
    .line 43
    move v4, v1

    .line 44
    goto :goto_11

    .line 45
    :cond_2c
    add-int/lit8 v3, v3, 0x1

    .line 46
    .line 47
    goto :goto_11

    .line 48
    :cond_2f
    if-nez v5, :cond_32

    .line 49
    .line 50
    goto :goto_35

    .line 51
    :cond_32
    add-int/lit8 v0, v0, -0x1

    .line 52
    .line 53
    goto :goto_11

    .line 54
    :cond_35
    :goto_35
    add-int/2addr v0, v1

    .line 55
    invoke-virtual {p0, v3, v0}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    .line 56
    .line 57
    .line 58
    move-result-object v0

    .line 59
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v0

    .line 63
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 64
    .line 65
    .line 66
    move-result v0

    .line 67
    if-nez v0, :cond_45

    .line 68
    .line 69
    goto :goto_5f

    .line 70
    :cond_45
    const-string v0, "deleting the database file: "

    .line 71
    .line 72
    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    const-string v1, "SupportSQLite"

    .line 77
    .line 78
    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 79
    .line 80
    .line 81
    :try_start_50
    new-instance v0, Ljava/io/File;

    .line 82
    .line 83
    invoke-direct {v0, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    invoke-static {v0}, Landroid/database/sqlite/SQLiteDatabase;->deleteDatabase(Ljava/io/File;)Z
    :try_end_58
    .catch Ljava/lang/Exception; {:try_start_50 .. :try_end_58} :catch_59

    .line 87
    .line 88
    .line 89
    return-void

    .line 90
    :catch_59
    move-exception p0

    .line 91
    const-string v0, "delete failed: "

    .line 92
    .line 93
    invoke-static {v1, v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 94
    .line 95
    .line 96
    :cond_5f
    :goto_5f
    return-void
.end method


# virtual methods
.method public a()Ly3;
    .registers 10

    .line 1
    new-instance v0, Ly3;

    .line 2
    .line 3
    iget-object v1, p0, Lx3;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Lt3;

    .line 6
    .line 7
    iget-object v2, v1, Lt3;->a:Landroid/view/ContextThemeWrapper;

    .line 8
    .line 9
    iget p0, p0, Lx3;->a:I

    .line 10
    .line 11
    invoke-direct {v0, v2, p0}, Ly3;-><init>(Landroid/view/ContextThemeWrapper;I)V

    .line 12
    .line 13
    .line 14
    iget-object p0, v1, Lt3;->e:Landroid/view/View;

    .line 15
    .line 16
    iget-object v2, v0, Ly3;->k:Lw3;

    .line 17
    .line 18
    if-eqz p0, :cond_16

    .line 19
    .line 20
    iput-object p0, v2, Lw3;->w:Landroid/view/View;

    .line 21
    .line 22
    goto :goto_36

    .line 23
    :cond_16
    iget-object p0, v1, Lt3;->d:Ljava/lang/CharSequence;

    .line 24
    .line 25
    if-eqz p0, :cond_23

    .line 26
    .line 27
    iput-object p0, v2, Lw3;->d:Ljava/lang/CharSequence;

    .line 28
    .line 29
    iget-object v3, v2, Lw3;->u:Landroid/widget/TextView;

    .line 30
    .line 31
    if-eqz v3, :cond_23

    .line 32
    .line 33
    invoke-virtual {v3, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 34
    .line 35
    .line 36
    :cond_23
    iget-object p0, v1, Lt3;->c:Landroid/graphics/drawable/Drawable;

    .line 37
    .line 38
    if-eqz p0, :cond_36

    .line 39
    .line 40
    iput-object p0, v2, Lw3;->s:Landroid/graphics/drawable/Drawable;

    .line 41
    .line 42
    iget-object v3, v2, Lw3;->t:Landroid/widget/ImageView;

    .line 43
    .line 44
    if-eqz v3, :cond_36

    .line 45
    .line 46
    const/4 v4, 0x0

    .line 47
    invoke-virtual {v3, v4}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 48
    .line 49
    .line 50
    iget-object v3, v2, Lw3;->t:Landroid/widget/ImageView;

    .line 51
    .line 52
    invoke-virtual {v3, p0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 53
    .line 54
    .line 55
    :cond_36
    :goto_36
    iget-object p0, v1, Lt3;->f:Ljava/lang/String;

    .line 56
    .line 57
    if-eqz p0, :cond_43

    .line 58
    .line 59
    iput-object p0, v2, Lw3;->e:Ljava/lang/String;

    .line 60
    .line 61
    iget-object v3, v2, Lw3;->v:Landroid/widget/TextView;

    .line 62
    .line 63
    if-eqz v3, :cond_43

    .line 64
    .line 65
    invoke-virtual {v3, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 66
    .line 67
    .line 68
    :cond_43
    iget-object p0, v1, Lt3;->g:Ljava/lang/CharSequence;

    .line 69
    .line 70
    if-nez p0, :cond_48

    .line 71
    .line 72
    goto :goto_4e

    .line 73
    :cond_48
    const/4 v3, -0x1

    .line 74
    iget-object v4, v1, Lt3;->h:Landroid/content/DialogInterface$OnClickListener;

    .line 75
    .line 76
    invoke-virtual {v2, v3, p0, v4}, Lw3;->c(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    .line 77
    .line 78
    .line 79
    :goto_4e
    iget-object p0, v1, Lt3;->i:Ljava/lang/CharSequence;

    .line 80
    .line 81
    if-nez p0, :cond_53

    .line 82
    .line 83
    goto :goto_59

    .line 84
    :cond_53
    const/4 v3, -0x2

    .line 85
    iget-object v4, v1, Lt3;->j:Landroid/content/DialogInterface$OnClickListener;

    .line 86
    .line 87
    invoke-virtual {v2, v3, p0, v4}, Lw3;->c(ILjava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)V

    .line 88
    .line 89
    .line 90
    :goto_59
    iget-object p0, v1, Lt3;->m:Landroid/widget/ListAdapter;

    .line 91
    .line 92
    const/4 v3, 0x0

    .line 93
    const/4 v4, 0x1

    .line 94
    if-eqz p0, :cond_9c

    .line 95
    .line 96
    iget-object p0, v1, Lt3;->b:Landroid/view/LayoutInflater;

    .line 97
    .line 98
    iget v5, v2, Lw3;->A:I

    .line 99
    .line 100
    invoke-virtual {p0, v5, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;)Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object p0

    .line 104
    check-cast p0, Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 105
    .line 106
    iget-boolean v5, v1, Lt3;->o:Z

    .line 107
    .line 108
    if-eqz v5, :cond_70

    .line 109
    .line 110
    iget v5, v2, Lw3;->B:I

    .line 111
    .line 112
    goto :goto_72

    .line 113
    :cond_70
    iget v5, v2, Lw3;->C:I

    .line 114
    .line 115
    :goto_72
    iget-object v6, v1, Lt3;->m:Landroid/widget/ListAdapter;

    .line 116
    .line 117
    if-eqz v6, :cond_77

    .line 118
    .line 119
    goto :goto_81

    .line 120
    :cond_77
    new-instance v6, Lv3;

    .line 121
    .line 122
    iget-object v7, v1, Lt3;->a:Landroid/view/ContextThemeWrapper;

    .line 123
    .line 124
    const v8, 0x1020014

    .line 125
    .line 126
    .line 127
    invoke-direct {v6, v7, v5, v8, v3}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;II[Ljava/lang/Object;)V

    .line 128
    .line 129
    .line 130
    :goto_81
    iput-object v6, v2, Lw3;->x:Landroid/widget/ListAdapter;

    .line 131
    .line 132
    iget v5, v1, Lt3;->p:I

    .line 133
    .line 134
    iput v5, v2, Lw3;->y:I

    .line 135
    .line 136
    iget-object v5, v1, Lt3;->n:Landroid/content/DialogInterface$OnClickListener;

    .line 137
    .line 138
    if-eqz v5, :cond_93

    .line 139
    .line 140
    new-instance v5, Ls3;

    .line 141
    .line 142
    invoke-direct {v5, v1, v2}, Ls3;-><init>(Lt3;Lw3;)V

    .line 143
    .line 144
    .line 145
    invoke-virtual {p0, v5}, Landroid/widget/AdapterView;->setOnItemClickListener(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 146
    .line 147
    .line 148
    :cond_93
    iget-boolean v5, v1, Lt3;->o:Z

    .line 149
    .line 150
    if-eqz v5, :cond_9a

    .line 151
    .line 152
    invoke-virtual {p0, v4}, Landroid/widget/AbsListView;->setChoiceMode(I)V

    .line 153
    .line 154
    .line 155
    :cond_9a
    iput-object p0, v2, Lw3;->f:Landroidx/appcompat/app/AlertController$RecycleListView;

    .line 156
    .line 157
    :cond_9c
    invoke-virtual {v0, v4}, Landroid/app/Dialog;->setCancelable(Z)V

    .line 158
    .line 159
    .line 160
    invoke-virtual {v0, v4}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    .line 161
    .line 162
    .line 163
    iget-object p0, v1, Lt3;->k:Landroid/content/DialogInterface$OnCancelListener;

    .line 164
    .line 165
    invoke-virtual {v0, p0}, Landroid/app/Dialog;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)V

    .line 166
    .line 167
    .line 168
    invoke-virtual {v0, v3}, Landroid/app/Dialog;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)V

    .line 169
    .line 170
    .line 171
    iget-object p0, v1, Lt3;->l:Lsc0;

    .line 172
    .line 173
    if-eqz p0, :cond_b1

    .line 174
    .line 175
    invoke-virtual {v0, p0}, Landroid/app/Dialog;->setOnKeyListener(Landroid/content/DialogInterface$OnKeyListener;)V

    .line 176
    .line 177
    .line 178
    :cond_b1
    return-object v0
.end method

.method public c(Lez;II)V
    .registers 5

    .line 1
    iget-object p0, p0, Lx3;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Ldq0;

    .line 4
    .line 5
    new-instance v0, Ln11;

    .line 6
    .line 7
    invoke-direct {v0, p1}, Ln11;-><init>(Lez;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v0, p2, p3}, Ldq0;->e(Loq0;II)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public d()I
    .registers 3

    .line 1
    iget-object v0, p0, Lx3;->b:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [I

    .line 4
    .line 5
    iget v1, p0, Lx3;->a:I

    .line 6
    .line 7
    add-int/lit8 v1, v1, -0x1

    .line 8
    .line 9
    iput v1, p0, Lx3;->a:I

    .line 10
    .line 11
    aget p0, v0, v1

    .line 12
    .line 13
    return p0
.end method

.method public e(I)V
    .registers 5

    .line 1
    iget v0, p0, Lx3;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lx3;->b:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, [I

    .line 6
    .line 7
    array-length v2, v1

    .line 8
    if-lt v0, v2, :cond_12

    .line 9
    .line 10
    array-length v0, v1

    .line 11
    mul-int/lit8 v0, v0, 0x2

    .line 12
    .line 13
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Lx3;->b:Ljava/lang/Object;

    .line 18
    .line 19
    :cond_12
    iget-object v0, p0, Lx3;->b:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, [I

    .line 22
    .line 23
    iget v1, p0, Lx3;->a:I

    .line 24
    .line 25
    add-int/lit8 v2, v1, 0x1

    .line 26
    .line 27
    iput v2, p0, Lx3;->a:I

    .line 28
    .line 29
    aput p1, v0, v1

    .line 30
    .line 31
    return-void
.end method
