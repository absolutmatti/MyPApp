###### Class defpackage.nv (nv)
.class public final Lnv;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Liv;


# instance fields
.field public final synthetic a:Ljv;

.field public final synthetic b:Lpv;


# direct methods
.method public constructor <init>(Lpv;Ljv;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lnv;->b:Lpv;

    .line 5
    .line 6
    iput-object p2, p0, Lnv;->a:Ljv;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 2

    .line 1
    iget-object v0, p0, Lnv;->b:Lpv;

    .line 2
    .line 3
    iget-object v0, v0, Lpv;->a:Ljava/util/ArrayList;

    .line 4
    .line 5
    iget-object p0, p0, Lnv;->a:Ljv;

    .line 6
    .line 7
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final b()V
    .registers 1

    .line 1
    return-void
.end method
