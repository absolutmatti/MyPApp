###### Class defpackage.zn (zn)
.class public final Lzn;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lfu;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lfu;

.field public final synthetic h:Lvo0;


# direct methods
.method public constructor <init>(Lao;Lvo0;Lfu;)V
    .registers 4

    .line 1
    const/4 p1, 0x0

    .line 2
    iput p1, p0, Lzn;->f:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p2, p0, Lzn;->h:Lvo0;

    .line 8
    .line 9
    iput-object p3, p0, Lzn;->g:Lfu;

    .line 10
    .line 11
    return-void
.end method

.method public constructor <init>(Lfu;Lvo0;)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, Lzn;->f:I

    .line 12
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lzn;->g:Lfu;

    iput-object p2, p0, Lzn;->h:Lvo0;

    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget v0, p0, Lzn;->f:I

    .line 2
    .line 3
    iget-object v1, p0, Lzn;->h:Lvo0;

    .line 4
    .line 5
    iget-object v2, p0, Lzn;->g:Lfu;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    .line 9
    .line 10
    const/high16 v5, -0x80000000

    .line 11
    .line 12
    const/4 v6, 0x1

    .line 13
    packed-switch v0, :pswitch_data_98

    .line 14
    .line 15
    .line 16
    instance-of v0, p2, Lnu;

    .line 17
    .line 18
    if-eqz v0, :cond_20

    .line 19
    .line 20
    move-object v0, p2

    .line 21
    check-cast v0, Lnu;

    .line 22
    .line 23
    iget v7, v0, Lnu;->k:I

    .line 24
    .line 25
    and-int v8, v7, v5

    .line 26
    .line 27
    if-eqz v8, :cond_20

    .line 28
    .line 29
    sub-int/2addr v7, v5

    .line 30
    iput v7, v0, Lnu;->k:I

    .line 31
    .line 32
    goto :goto_25

    .line 33
    :cond_20
    new-instance v0, Lnu;

    .line 34
    .line 35
    invoke-direct {v0, p0, p2}, Lnu;-><init>(Lzn;Lkotlin/coroutines/Continuation;)V

    .line 36
    .line 37
    .line 38
    :goto_25
    iget-object p0, v0, Lnu;->i:Ljava/lang/Object;

    .line 39
    .line 40
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object p2

    .line 44
    iget v5, v0, Lnu;->k:I

    .line 45
    .line 46
    if-eqz v5, :cond_3b

    .line 47
    .line 48
    if-ne v5, v6, :cond_37

    .line 49
    .line 50
    :try_start_31
    invoke-static {p0}, Lkotlin/a;->b(Ljava/lang/Object;)V
    :try_end_34
    .catchall {:try_start_31 .. :try_end_34} :catchall_35

    .line 51
    .line 52
    .line 53
    goto :goto_48

    .line 54
    :catchall_35
    move-exception p0

    .line 55
    goto :goto_4b

    .line 56
    :cond_37
    invoke-static {v4}, Lm0;->g(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    goto :goto_4a

    .line 60
    :cond_3b
    invoke-static {p0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 61
    .line 62
    .line 63
    :try_start_3e
    iput v6, v0, Lnu;->k:I

    .line 64
    .line 65
    invoke-interface {v2, p1, v0}, Lfu;->j(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p0
    :try_end_44
    .catchall {:try_start_3e .. :try_end_44} :catchall_35

    .line 69
    if-ne p0, p2, :cond_48

    .line 70
    .line 71
    move-object v3, p2

    .line 72
    goto :goto_4a

    .line 73
    :cond_48
    :goto_48
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 74
    .line 75
    :goto_4a
    return-object v3

    .line 76
    :goto_4b
    iput-object p0, v1, Lvo0;->f:Ljava/lang/Object;

    .line 77
    .line 78
    throw p0

    .line 79
    :pswitch_4e
    instance-of v0, p2, Lyn;

    .line 80
    .line 81
    if-eqz v0, :cond_5f

    .line 82
    .line 83
    move-object v0, p2

    .line 84
    check-cast v0, Lyn;

    .line 85
    .line 86
    iget v7, v0, Lyn;->k:I

    .line 87
    .line 88
    and-int v8, v7, v5

    .line 89
    .line 90
    if-eqz v8, :cond_5f

    .line 91
    .line 92
    sub-int/2addr v7, v5

    .line 93
    iput v7, v0, Lyn;->k:I

    .line 94
    .line 95
    goto :goto_64

    .line 96
    :cond_5f
    new-instance v0, Lyn;

    .line 97
    .line 98
    invoke-direct {v0, p0, p2}, Lyn;-><init>(Lzn;Lkotlin/coroutines/Continuation;)V

    .line 99
    .line 100
    .line 101
    :goto_64
    iget-object p0, v0, Lyn;->i:Ljava/lang/Object;

    .line 102
    .line 103
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p2

    .line 107
    iget v5, v0, Lyn;->k:I

    .line 108
    .line 109
    if-eqz v5, :cond_78

    .line 110
    .line 111
    if-ne v5, v6, :cond_74

    .line 112
    .line 113
    invoke-static {p0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    goto :goto_88

    .line 117
    :cond_74
    invoke-static {v4}, Lm0;->g(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    goto :goto_96

    .line 121
    :cond_78
    invoke-static {p0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 122
    .line 123
    .line 124
    iget-object p0, v1, Lvo0;->f:Ljava/lang/Object;

    .line 125
    .line 126
    sget-object v3, Lsa;->d:Lyw;

    .line 127
    .line 128
    if-eq p0, v3, :cond_8b

    .line 129
    .line 130
    invoke-static {p0, p1}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 131
    .line 132
    .line 133
    move-result p0

    .line 134
    if-nez p0, :cond_88

    .line 135
    .line 136
    goto :goto_8b

    .line 137
    :cond_88
    :goto_88
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 138
    .line 139
    goto :goto_96

    .line 140
    :cond_8b
    :goto_8b
    iput-object p1, v1, Lvo0;->f:Ljava/lang/Object;

    .line 141
    .line 142
    iput v6, v0, Lyn;->k:I

    .line 143
    .line 144
    invoke-interface {v2, p1, v0}, Lfu;->j(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object p0

    .line 148
    if-ne p0, p2, :cond_88

    .line 149
    .line 150
    move-object v3, p2

    .line 151
    :goto_96
    return-object v3

    .line 152
    nop

    .line 153
    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_4e
    .end packed-switch
.end method
