###### Class defpackage.c60 (c60)
.class public interface abstract Lc60;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ld60;
.implements Lqz;


# virtual methods
.method public abstract g()V
.end method

.method public abstract get(Ljava/lang/Object;)Ljava/lang/Object;
.end method
