###### Class defpackage.fu0 (fu0)
.class public final Lfu0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:Lhh1;

.field public b:Lhh1;

.field public c:Lhh1;

.field public d:Lhh1;

.field public e:Luh;

.field public f:Luh;

.field public g:Luh;

.field public h:Luh;

.field public i:Lmp;

.field public j:Lmp;

.field public k:Lmp;

.field public l:Lmp;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lkq0;

    .line 5
    .line 6
    const/16 v1, 0x9

    .line 7
    .line 8
    invoke-direct {v0, v1}, Lhh1;-><init>(I)V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lfu0;->a:Lhh1;

    .line 12
    .line 13
    new-instance v0, Lkq0;

    .line 14
    .line 15
    invoke-direct {v0, v1}, Lhh1;-><init>(I)V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lfu0;->b:Lhh1;

    .line 19
    .line 20
    new-instance v0, Lkq0;

    .line 21
    .line 22
    invoke-direct {v0, v1}, Lhh1;-><init>(I)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Lfu0;->c:Lhh1;

    .line 26
    .line 27
    new-instance v0, Lkq0;

    .line 28
    .line 29
    invoke-direct {v0, v1}, Lhh1;-><init>(I)V

    .line 30
    .line 31
    .line 32
    iput-object v0, p0, Lfu0;->d:Lhh1;

    .line 33
    .line 34
    new-instance v0, Le;

    .line 35
    .line 36
    const/4 v1, 0x0

    .line 37
    invoke-direct {v0, v1}, Le;-><init>(F)V

    .line 38
    .line 39
    .line 40
    iput-object v0, p0, Lfu0;->e:Luh;

    .line 41
    .line 42
    new-instance v0, Le;

    .line 43
    .line 44
    invoke-direct {v0, v1}, Le;-><init>(F)V

    .line 45
    .line 46
    .line 47
    iput-object v0, p0, Lfu0;->f:Luh;

    .line 48
    .line 49
    new-instance v0, Le;

    .line 50
    .line 51
    invoke-direct {v0, v1}, Le;-><init>(F)V

    .line 52
    .line 53
    .line 54
    iput-object v0, p0, Lfu0;->g:Luh;

    .line 55
    .line 56
    new-instance v0, Le;

    .line 57
    .line 58
    invoke-direct {v0, v1}, Le;-><init>(F)V

    .line 59
    .line 60
    .line 61
    iput-object v0, p0, Lfu0;->h:Luh;

    .line 62
    .line 63
    new-instance v0, Lmp;

    .line 64
    .line 65
    const/4 v1, 0x0

    .line 66
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 67
    .line 68
    .line 69
    iput-object v0, p0, Lfu0;->i:Lmp;

    .line 70
    .line 71
    new-instance v0, Lmp;

    .line 72
    .line 73
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 74
    .line 75
    .line 76
    iput-object v0, p0, Lfu0;->j:Lmp;

    .line 77
    .line 78
    new-instance v0, Lmp;

    .line 79
    .line 80
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 81
    .line 82
    .line 83
    iput-object v0, p0, Lfu0;->k:Lmp;

    .line 84
    .line 85
    new-instance v0, Lmp;

    .line 86
    .line 87
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 88
    .line 89
    .line 90
    iput-object v0, p0, Lfu0;->l:Lmp;

    .line 91
    .line 92
    return-void
.end method


# virtual methods
.method public final a()Lgu0;
    .registers 3

    .line 1
    new-instance v0, Lgu0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lfu0;->a:Lhh1;

    .line 7
    .line 8
    iput-object v1, v0, Lgu0;->a:Lhh1;

    .line 9
    .line 10
    iget-object v1, p0, Lfu0;->b:Lhh1;

    .line 11
    .line 12
    iput-object v1, v0, Lgu0;->b:Lhh1;

    .line 13
    .line 14
    iget-object v1, p0, Lfu0;->c:Lhh1;

    .line 15
    .line 16
    iput-object v1, v0, Lgu0;->c:Lhh1;

    .line 17
    .line 18
    iget-object v1, p0, Lfu0;->d:Lhh1;

    .line 19
    .line 20
    iput-object v1, v0, Lgu0;->d:Lhh1;

    .line 21
    .line 22
    iget-object v1, p0, Lfu0;->e:Luh;

    .line 23
    .line 24
    iput-object v1, v0, Lgu0;->e:Luh;

    .line 25
    .line 26
    iget-object v1, p0, Lfu0;->f:Luh;

    .line 27
    .line 28
    iput-object v1, v0, Lgu0;->f:Luh;

    .line 29
    .line 30
    iget-object v1, p0, Lfu0;->g:Luh;

    .line 31
    .line 32
    iput-object v1, v0, Lgu0;->g:Luh;

    .line 33
    .line 34
    iget-object v1, p0, Lfu0;->h:Luh;

    .line 35
    .line 36
    iput-object v1, v0, Lgu0;->h:Luh;

    .line 37
    .line 38
    iget-object v1, p0, Lfu0;->i:Lmp;

    .line 39
    .line 40
    iput-object v1, v0, Lgu0;->i:Lmp;

    .line 41
    .line 42
    iget-object v1, p0, Lfu0;->j:Lmp;

    .line 43
    .line 44
    iput-object v1, v0, Lgu0;->j:Lmp;

    .line 45
    .line 46
    iget-object v1, p0, Lfu0;->k:Lmp;

    .line 47
    .line 48
    iput-object v1, v0, Lgu0;->k:Lmp;

    .line 49
    .line 50
    iget-object p0, p0, Lfu0;->l:Lmp;

    .line 51
    .line 52
    iput-object p0, v0, Lgu0;->l:Lmp;

    .line 53
    .line 54
    return-object v0
.end method
