###### Class defpackage.kc0 (kc0)
.class public final Lkc0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lfw;


# virtual methods
.method public final onAttachedToEngine(Lew;)V
    .registers 2

    .line 1
    const-string p0, "mpv"

    .line 2
    .line 3
    invoke-static {p0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object p0, p1, Lew;->a:Landroid/content/Context;

    .line 7
    .line 8
    invoke-static {p0}, Lcom/alexmercerind/mediakitandroidhelper/MediaKitAndroidHelper;->setApplicationContextJava(Landroid/content/Context;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public final onDetachedFromEngine(Lew;)V
    .registers 2

    .line 1
    return-void
.end method
