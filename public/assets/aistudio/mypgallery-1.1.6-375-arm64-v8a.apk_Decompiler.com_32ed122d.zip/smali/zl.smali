###### Class defpackage.zl (zl)
.class public final Lzl;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lm80;


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 4

    .line 34
    iput p2, p0, Lzl;->a:I

    iput-object p1, p0, Lzl;->b:Ljava/lang/Object;

    iput-object p3, p0, Lzl;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lo80;)V
    .registers 4

    .line 1
    const/4 v0, 0x2

    .line 2
    iput v0, p0, Lzl;->a:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lzl;->b:Ljava/lang/Object;

    .line 8
    .line 9
    sget-object v0, Lmd;->c:Lmd;

    .line 10
    .line 11
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    iget-object v1, v0, Lmd;->a:Ljava/util/HashMap;

    .line 16
    .line 17
    invoke-virtual {v1, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    check-cast v1, Lkd;

    .line 22
    .line 23
    if-eqz v1, :cond_19

    .line 24
    .line 25
    goto :goto_1e

    .line 26
    :cond_19
    const/4 v1, 0x0

    .line 27
    invoke-virtual {v0, p1, v1}, Lmd;->a(Ljava/lang/Class;[Ljava/lang/reflect/Method;)Lkd;

    .line 28
    .line 29
    .line 30
    move-result-object v1

    .line 31
    :goto_1e
    iput-object v1, p0, Lzl;->c:Ljava/lang/Object;

    .line 32
    .line 33
    return-void
.end method


# virtual methods
.method public final a(Lp80;Lg80;)V
    .registers 8

    .line 1
    iget v0, p0, Lzl;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lzl;->b:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object v2, p0, Lzl;->c:Ljava/lang/Object;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_6a

    .line 8
    .line 9
    .line 10
    check-cast v2, Lkd;

    .line 11
    .line 12
    check-cast v1, Lo80;

    .line 13
    .line 14
    iget-object p0, v2, Lkd;->a:Ljava/util/HashMap;

    .line 15
    .line 16
    invoke-virtual {p0, p2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    check-cast v0, Ljava/util/List;

    .line 21
    .line 22
    invoke-static {v0, p1, p2, v1}, Lkd;->a(Ljava/util/List;Lp80;Lg80;Lo80;)V

    .line 23
    .line 24
    .line 25
    sget-object v0, Lg80;->ON_ANY:Lg80;

    .line 26
    .line 27
    invoke-virtual {p0, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Ljava/util/List;

    .line 32
    .line 33
    invoke-static {p0, p1, p2, v1}, Lkd;->a(Ljava/util/List;Lp80;Lg80;Lo80;)V

    .line 34
    .line 35
    .line 36
    return-void

    .line 37
    :pswitch_24
    sget-object p1, Lg80;->ON_START:Lg80;

    .line 38
    .line 39
    if-ne p2, p1, :cond_32

    .line 40
    .line 41
    check-cast v1, Li80;

    .line 42
    .line 43
    invoke-virtual {v1, p0}, Li80;->b(Lo80;)V

    .line 44
    .line 45
    .line 46
    check-cast v2, Lqr0;

    .line 47
    .line 48
    invoke-virtual {v2}, Lqr0;->d()V

    .line 49
    .line 50
    .line 51
    :cond_32
    return-void

    .line 52
    :pswitch_33
    check-cast v1, Lcq;

    .line 53
    .line 54
    sget-object p0, Lyl;->a:[I

    .line 55
    .line 56
    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    .line 57
    .line 58
    .line 59
    move-result v0

    .line 60
    aget p0, p0, v0

    .line 61
    .line 62
    const/4 v0, 0x3

    .line 63
    if-eq p0, v0, :cond_4a

    .line 64
    .line 65
    const/4 v0, 0x7

    .line 66
    if-eq p0, v0, :cond_44

    .line 67
    .line 68
    goto :goto_61

    .line 69
    :cond_44
    const-string p0, "ON_ANY must not been send by anybody"

    .line 70
    .line 71
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    goto :goto_68

    .line 75
    :cond_4a
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    invoke-static {p0}, Lfg;->a(Landroid/os/Looper;)Landroid/os/Handler;

    .line 80
    .line 81
    .line 82
    move-result-object p0

    .line 83
    new-instance v0, Lac;

    .line 84
    .line 85
    invoke-direct {v0}, Lac;-><init>()V

    .line 86
    .line 87
    .line 88
    const-wide/16 v3, 0x1f4

    .line 89
    .line 90
    invoke-virtual {p0, v0, v3, v4}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 91
    .line 92
    .line 93
    iget-object p0, v1, Lcq;->a:Li80;

    .line 94
    .line 95
    invoke-virtual {p0, v1}, Li80;->b(Lo80;)V

    .line 96
    .line 97
    .line 98
    :goto_61
    check-cast v2, Lm80;

    .line 99
    .line 100
    if-eqz v2, :cond_68

    .line 101
    .line 102
    invoke-interface {v2, p1, p2}, Lm80;->a(Lp80;Lg80;)V

    .line 103
    .line 104
    .line 105
    :cond_68
    :goto_68
    return-void

    .line 106
    nop

    .line 107
    :pswitch_data_6a
    .packed-switch 0x0
        :pswitch_33
        :pswitch_24
    .end packed-switch
.end method
