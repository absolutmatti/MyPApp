###### Class defpackage.tr0 (tr0)
.class public final Ltr0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ln91;


# instance fields
.field public final a:Landroid/app/Application;

.field public final b:Lm91;

.field public final c:Landroid/os/Bundle;

.field public final d:Li80;

.field public final e:Lqr0;


# direct methods
.method public constructor <init>(Landroid/app/Application;Lay;Landroid/os/Bundle;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-interface {p2}, Lsr0;->getSavedStateRegistry()Lqr0;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iput-object v0, p0, Ltr0;->e:Lqr0;

    .line 9
    .line 10
    invoke-interface {p2}, Lp80;->getLifecycle()Li80;

    .line 11
    .line 12
    .line 13
    move-result-object p2

    .line 14
    iput-object p2, p0, Ltr0;->d:Li80;

    .line 15
    .line 16
    iput-object p3, p0, Ltr0;->c:Landroid/os/Bundle;

    .line 17
    .line 18
    iput-object p1, p0, Ltr0;->a:Landroid/app/Application;

    .line 19
    .line 20
    if-eqz p1, :cond_26

    .line 21
    .line 22
    sget-object p2, Lm91;->d:Lm91;

    .line 23
    .line 24
    if-nez p2, :cond_20

    .line 25
    .line 26
    new-instance p2, Lm91;

    .line 27
    .line 28
    invoke-direct {p2, p1}, Lm91;-><init>(Landroid/app/Application;)V

    .line 29
    .line 30
    .line 31
    sput-object p2, Lm91;->d:Lm91;

    .line 32
    .line 33
    :cond_20
    sget-object p1, Lm91;->d:Lm91;

    .line 34
    .line 35
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    .line 37
    .line 38
    goto :goto_2c

    .line 39
    :cond_26
    new-instance p1, Lm91;

    .line 40
    .line 41
    const/4 p2, 0x0

    .line 42
    invoke-direct {p1, p2}, Lm91;-><init>(Landroid/app/Application;)V

    .line 43
    .line 44
    .line 45
    :goto_2c
    iput-object p1, p0, Ltr0;->b:Lm91;

    .line 46
    .line 47
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Class;)Ll91;
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-virtual {p0, p1, v0}, Ltr0;->c(Ljava/lang/Class;Ljava/lang/String;)Ll91;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    return-object p0

    .line 12
    :cond_b
    const-string p0, "Local and anonymous classes can not be ViewModels"

    .line 13
    .line 14
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0
.end method

.method public final b(Ljava/lang/Class;Lhf0;)Ll91;
    .registers 7

    .line 1
    sget-object v0, Lmp;->o:Lmp;

    .line 2
    .line 3
    iget-object v1, p2, Lpi;->a:Ljava/util/LinkedHashMap;

    .line 4
    .line 5
    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    check-cast v0, Ljava/lang/String;

    .line 10
    .line 11
    const/4 v2, 0x0

    .line 12
    if-eqz v0, :cond_72

    .line 13
    .line 14
    sget-object v3, Llf1;->c:Liq0;

    .line 15
    .line 16
    invoke-virtual {v1, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v3

    .line 20
    if-eqz v3, :cond_63

    .line 21
    .line 22
    sget-object v3, Llf1;->d:Lkr0;

    .line 23
    .line 24
    invoke-virtual {v1, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 25
    .line 26
    .line 27
    move-result-object v3

    .line 28
    if-eqz v3, :cond_63

    .line 29
    .line 30
    sget-object v0, Liq0;->n:Liq0;

    .line 31
    .line 32
    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    check-cast v0, Landroid/app/Application;

    .line 37
    .line 38
    const-class v1, Ll4;

    .line 39
    .line 40
    invoke-virtual {v1, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-eqz v1, :cond_36

    .line 45
    .line 46
    if-eqz v0, :cond_36

    .line 47
    .line 48
    sget-object v2, Lur0;->a:Ljava/util/List;

    .line 49
    .line 50
    invoke-static {p1, v2}, Lur0;->a(Ljava/lang/Class;Ljava/util/List;)Ljava/lang/reflect/Constructor;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    goto :goto_3c

    .line 55
    :cond_36
    sget-object v2, Lur0;->b:Ljava/util/List;

    .line 56
    .line 57
    invoke-static {p1, v2}, Lur0;->a(Ljava/lang/Class;Ljava/util/List;)Ljava/lang/reflect/Constructor;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    :goto_3c
    if-nez v2, :cond_45

    .line 62
    .line 63
    iget-object p0, p0, Ltr0;->b:Lm91;

    .line 64
    .line 65
    invoke-virtual {p0, p1, p2}, Lm91;->b(Ljava/lang/Class;Lhf0;)Ll91;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    return-object p0

    .line 70
    :cond_45
    if-eqz v1, :cond_56

    .line 71
    .line 72
    if-eqz v0, :cond_56

    .line 73
    .line 74
    invoke-static {p2}, Llf1;->j(Lhf0;)Lir0;

    .line 75
    .line 76
    .line 77
    move-result-object p0

    .line 78
    filled-new-array {v0, p0}, [Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    invoke-static {p1, v2, p0}, Lur0;->b(Ljava/lang/Class;Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Ll91;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    return-object p0

    .line 87
    :cond_56
    invoke-static {p2}, Llf1;->j(Lhf0;)Lir0;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 92
    .line 93
    .line 94
    move-result-object p0

    .line 95
    invoke-static {p1, v2, p0}, Lur0;->b(Ljava/lang/Class;Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Ll91;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    return-object p0

    .line 100
    :cond_63
    iget-object p2, p0, Ltr0;->d:Li80;

    .line 101
    .line 102
    if-eqz p2, :cond_6c

    .line 103
    .line 104
    invoke-virtual {p0, p1, v0}, Ltr0;->c(Ljava/lang/Class;Ljava/lang/String;)Ll91;

    .line 105
    .line 106
    .line 107
    move-result-object p0

    .line 108
    return-object p0

    .line 109
    :cond_6c
    const-string p0, "SAVED_STATE_REGISTRY_OWNER_KEY andVIEW_MODEL_STORE_OWNER_KEY must be provided in the creation extras tosuccessfully create a ViewModel."

    .line 110
    .line 111
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 112
    .line 113
    .line 114
    return-object v2

    .line 115
    :cond_72
    const-string p0, "VIEW_MODEL_KEY must always be provided by ViewModelProvider"

    .line 116
    .line 117
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 118
    .line 119
    .line 120
    return-object v2
.end method

.method public final c(Ljava/lang/Class;Ljava/lang/String;)Ll91;
    .registers 10

    .line 1
    iget-object v0, p0, Ltr0;->d:Li80;

    .line 2
    .line 3
    if-eqz v0, :cond_b3

    .line 4
    .line 5
    const-class v1, Ll4;

    .line 6
    .line 7
    invoke-virtual {v1, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_17

    .line 12
    .line 13
    iget-object v2, p0, Ltr0;->a:Landroid/app/Application;

    .line 14
    .line 15
    if-eqz v2, :cond_17

    .line 16
    .line 17
    sget-object v2, Lur0;->a:Ljava/util/List;

    .line 18
    .line 19
    invoke-static {p1, v2}, Lur0;->a(Ljava/lang/Class;Ljava/util/List;)Ljava/lang/reflect/Constructor;

    .line 20
    .line 21
    .line 22
    move-result-object v2

    .line 23
    goto :goto_1d

    .line 24
    :cond_17
    sget-object v2, Lur0;->b:Ljava/util/List;

    .line 25
    .line 26
    invoke-static {p1, v2}, Lur0;->a(Ljava/lang/Class;Ljava/util/List;)Ljava/lang/reflect/Constructor;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    :goto_1d
    if-nez v2, :cond_40

    .line 31
    .line 32
    iget-object p2, p0, Ltr0;->a:Landroid/app/Application;

    .line 33
    .line 34
    if-eqz p2, :cond_2a

    .line 35
    .line 36
    iget-object p0, p0, Ltr0;->b:Lm91;

    .line 37
    .line 38
    invoke-virtual {p0, p1}, Lm91;->a(Ljava/lang/Class;)Ll91;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    return-object p0

    .line 43
    :cond_2a
    sget-object p0, Lty;->b:Lty;

    .line 44
    .line 45
    if-nez p0, :cond_36

    .line 46
    .line 47
    new-instance p0, Lty;

    .line 48
    .line 49
    const/4 p2, 0x2

    .line 50
    invoke-direct {p0, p2}, Lty;-><init>(I)V

    .line 51
    .line 52
    .line 53
    sput-object p0, Lty;->b:Lty;

    .line 54
    .line 55
    :cond_36
    sget-object p0, Lty;->b:Lty;

    .line 56
    .line 57
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    invoke-virtual {p0, p1}, Lty;->a(Ljava/lang/Class;)Ll91;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    return-object p0

    .line 65
    :cond_40
    iget-object v3, p0, Ltr0;->e:Lqr0;

    .line 66
    .line 67
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 68
    .line 69
    .line 70
    iget-object v4, p0, Ltr0;->c:Landroid/os/Bundle;

    .line 71
    .line 72
    invoke-virtual {v3, p2}, Lqr0;->a(Ljava/lang/String;)Landroid/os/Bundle;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    sget-object v6, Lir0;->f:[Ljava/lang/Class;

    .line 77
    .line 78
    invoke-static {v5, v4}, Lfo0;->j(Landroid/os/Bundle;Landroid/os/Bundle;)Lir0;

    .line 79
    .line 80
    .line 81
    move-result-object v4

    .line 82
    new-instance v5, Ljr0;

    .line 83
    .line 84
    invoke-direct {v5, p2, v4}, Ljr0;-><init>(Ljava/lang/String;Lir0;)V

    .line 85
    .line 86
    .line 87
    invoke-virtual {v5, v3, v0}, Ljr0;->b(Lqr0;Li80;)V

    .line 88
    .line 89
    .line 90
    move-object p2, v0

    .line 91
    check-cast p2, Lr80;

    .line 92
    .line 93
    iget-object p2, p2, Lr80;->c:Lh80;

    .line 94
    .line 95
    sget-object v6, Lh80;->g:Lh80;

    .line 96
    .line 97
    if-eq p2, v6, :cond_75

    .line 98
    .line 99
    sget-object v6, Lh80;->i:Lh80;

    .line 100
    .line 101
    invoke-virtual {p2, v6}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 102
    .line 103
    .line 104
    move-result p2

    .line 105
    if-ltz p2, :cond_6b

    .line 106
    .line 107
    goto :goto_75

    .line 108
    :cond_6b
    new-instance p2, Lzl;

    .line 109
    .line 110
    const/4 v6, 0x1

    .line 111
    invoke-direct {p2, v0, v6, v3}, Lzl;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 112
    .line 113
    .line 114
    invoke-virtual {v0, p2}, Li80;->a(Lo80;)V

    .line 115
    .line 116
    .line 117
    goto :goto_78

    .line 118
    :cond_75
    :goto_75
    invoke-virtual {v3}, Lqr0;->d()V

    .line 119
    .line 120
    .line 121
    :goto_78
    if-eqz v1, :cond_87

    .line 122
    .line 123
    iget-object p0, p0, Ltr0;->a:Landroid/app/Application;

    .line 124
    .line 125
    if-eqz p0, :cond_87

    .line 126
    .line 127
    filled-new-array {p0, v4}, [Ljava/lang/Object;

    .line 128
    .line 129
    .line 130
    move-result-object p0

    .line 131
    invoke-static {p1, v2, p0}, Lur0;->b(Ljava/lang/Class;Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Ll91;

    .line 132
    .line 133
    .line 134
    move-result-object p0

    .line 135
    goto :goto_8f

    .line 136
    :cond_87
    filled-new-array {v4}, [Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    invoke-static {p1, v2, p0}, Lur0;->b(Ljava/lang/Class;Ljava/lang/reflect/Constructor;[Ljava/lang/Object;)Ll91;

    .line 141
    .line 142
    .line 143
    move-result-object p0

    .line 144
    :goto_8f
    const-string p1, "androidx.lifecycle.savedstate.vm.tag"

    .line 145
    .line 146
    iget-object p2, p0, Ll91;->a:Ljava/util/HashMap;

    .line 147
    .line 148
    monitor-enter p2

    .line 149
    :try_start_94
    iget-object v0, p0, Ll91;->a:Ljava/util/HashMap;

    .line 150
    .line 151
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v0

    .line 155
    if-nez v0, :cond_a4

    .line 156
    .line 157
    iget-object v1, p0, Ll91;->a:Ljava/util/HashMap;

    .line 158
    .line 159
    invoke-virtual {v1, p1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 160
    .line 161
    .line 162
    goto :goto_a4

    .line 163
    :catchall_a2
    move-exception p0

    .line 164
    goto :goto_b1

    .line 165
    :cond_a4
    :goto_a4
    monitor-exit p2
    :try_end_a5
    .catchall {:try_start_94 .. :try_end_a5} :catchall_a2

    .line 166
    if-nez v0, :cond_a8

    .line 167
    .line 168
    goto :goto_a9

    .line 169
    :cond_a8
    move-object v5, v0

    .line 170
    :goto_a9
    iget-boolean p1, p0, Ll91;->c:Z

    .line 171
    .line 172
    if-eqz p1, :cond_b0

    .line 173
    .line 174
    invoke-static {v5}, Ll91;->a(Ljava/lang/Object;)V

    .line 175
    .line 176
    .line 177
    :cond_b0
    return-object p0

    .line 178
    :goto_b1
    :try_start_b1
    monitor-exit p2
    :try_end_b2
    .catchall {:try_start_b1 .. :try_end_b2} :catchall_a2

    .line 179
    throw p0

    .line 180
    :cond_b3
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 181
    .line 182
    const-string p1, "SavedStateViewModelFactory constructed with empty constructor supports only calls to create(modelClass: Class<T>, extras: CreationExtras)."

    .line 183
    .line 184
    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 185
    .line 186
    .line 187
    throw p0
.end method
