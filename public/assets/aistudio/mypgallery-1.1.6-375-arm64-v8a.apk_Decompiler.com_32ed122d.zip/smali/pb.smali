###### Class defpackage.pb (pb)
.class public abstract Lpb;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Iterable;
.implements Ljava/io/Serializable;


# static fields
.field public static final g:Lmb;

.field public static final h:Lmp;


# instance fields
.field public f:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lmb;

    .line 2
    .line 3
    sget-object v1, Lk40;->b:[B

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lmb;-><init>([B)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lpb;->g:Lmb;

    .line 9
    .line 10
    invoke-static {}, Lf4;->a()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-eqz v0, :cond_17

    .line 15
    .line 16
    new-instance v0, Lmp;

    .line 17
    .line 18
    const/16 v1, 0xe

    .line 19
    .line 20
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 21
    .line 22
    .line 23
    goto :goto_1e

    .line 24
    :cond_17
    new-instance v0, Lmp;

    .line 25
    .line 26
    const/16 v1, 0xd

    .line 27
    .line 28
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 29
    .line 30
    .line 31
    :goto_1e
    sput-object v0, Lpb;->h:Lmp;

    .line 32
    .line 33
    return-void
.end method

.method public static g(III)I
    .registers 6

    .line 1
    sub-int v0, p1, p0

    .line 2
    .line 3
    or-int v1, p0, p1

    .line 4
    .line 5
    or-int/2addr v1, v0

    .line 6
    sub-int v2, p2, p1

    .line 7
    .line 8
    or-int/2addr v1, v2

    .line 9
    if-gez v1, :cond_33

    .line 10
    .line 11
    if-ltz p0, :cond_27

    .line 12
    .line 13
    if-ge p1, p0, :cond_1b

    .line 14
    .line 15
    const-string p2, "Beginning index larger than ending index: "

    .line 16
    .line 17
    const-string v0, ", "

    .line 18
    .line 19
    invoke-static {p2, v0, p0, p1}, Lzi0;->o(Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    invoke-static {p0}, Lm0;->q(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    :goto_19
    const/4 p0, 0x0

    .line 27
    return p0

    .line 28
    :cond_1b
    const-string p0, "End index: "

    .line 29
    .line 30
    const-string v0, " >= "

    .line 31
    .line 32
    invoke-static {p0, v0, p1, p2}, Lzi0;->o(Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p0

    .line 36
    invoke-static {p0}, Lm0;->q(Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    goto :goto_19

    .line 40
    :cond_27
    const-string p1, "Beginning index: "

    .line 41
    .line 42
    const-string p2, " < 0"

    .line 43
    .line 44
    invoke-static {p0, p1, p2}, Lzi0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-static {p0}, Lm0;->q(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    goto :goto_19

    .line 52
    :cond_33
    return v0
.end method

.method public static h([BII)Lmb;
    .registers 6

    .line 1
    add-int v0, p1, p2

    .line 2
    .line 3
    array-length v1, p0

    .line 4
    invoke-static {p1, v0, v1}, Lpb;->g(III)I

    .line 5
    .line 6
    .line 7
    new-instance v0, Lmb;

    .line 8
    .line 9
    sget-object v1, Lpb;->h:Lmp;

    .line 10
    .line 11
    iget v1, v1, Lmp;->f:I

    .line 12
    .line 13
    packed-switch v1, :pswitch_data_20

    .line 14
    .line 15
    .line 16
    new-array v1, p2, [B

    .line 17
    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-static {p0, p1, v1, v2, p2}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    .line 20
    .line 21
    .line 22
    goto :goto_1b

    .line 23
    :pswitch_16
    add-int/2addr p2, p1

    .line 24
    invoke-static {p0, p1, p2}, Ljava/util/Arrays;->copyOfRange([BII)[B

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    :goto_1b
    invoke-direct {v0, v1}, Lmb;-><init>([B)V

    .line 29
    .line 30
    .line 31
    return-object v0

    .line 32
    nop

    .line 33
    :pswitch_data_20
    .packed-switch 0xd
        :pswitch_16
    .end packed-switch
.end method


# virtual methods
.method public abstract f(I)B
.end method

.method public final hashCode()I
    .registers 7

    .line 1
    iget v0, p0, Lpb;->f:I

    .line 2
    .line 3
    if-nez v0, :cond_25

    .line 4
    .line 5
    invoke-virtual {p0}, Lpb;->size()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    move-object v1, p0

    .line 10
    check-cast v1, Lmb;

    .line 11
    .line 12
    invoke-virtual {v1}, Lmb;->j()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    move v4, v0

    .line 17
    move v3, v2

    .line 18
    :goto_11
    add-int v5, v2, v0

    .line 19
    .line 20
    if-ge v3, v5, :cond_1f

    .line 21
    .line 22
    mul-int/lit8 v4, v4, 0x1f

    .line 23
    .line 24
    iget-object v5, v1, Lmb;->i:[B

    .line 25
    .line 26
    aget-byte v5, v5, v3

    .line 27
    .line 28
    add-int/2addr v4, v5

    .line 29
    add-int/lit8 v3, v3, 0x1

    .line 30
    .line 31
    goto :goto_11

    .line 32
    :cond_1f
    if-nez v4, :cond_22

    .line 33
    .line 34
    const/4 v4, 0x1

    .line 35
    :cond_22
    iput v4, p0, Lpb;->f:I

    .line 36
    .line 37
    return v4

    .line 38
    :cond_25
    return v0
.end method

.method public abstract i(I[B)V
.end method

.method public abstract size()I
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .line 1
    sget-object v0, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 2
    .line 3
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {p0}, Lpb;->size()I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    invoke-virtual {p0}, Lpb;->size()I

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    const/16 v3, 0x32

    .line 20
    .line 21
    if-gt v2, v3, :cond_1b

    .line 22
    .line 23
    invoke-static {p0}, Lt51;->m(Lpb;)Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    goto :goto_43

    .line 28
    :cond_1b
    check-cast p0, Lmb;

    .line 29
    .line 30
    const/4 v2, 0x0

    .line 31
    invoke-virtual {p0}, Lmb;->size()I

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    const/16 v4, 0x2f

    .line 36
    .line 37
    invoke-static {v2, v4, v3}, Lpb;->g(III)I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-nez v2, :cond_2d

    .line 42
    .line 43
    sget-object p0, Lpb;->g:Lmb;

    .line 44
    .line 45
    goto :goto_39

    .line 46
    :cond_2d
    new-instance v3, Ljb;

    .line 47
    .line 48
    iget-object v4, p0, Lmb;->i:[B

    .line 49
    .line 50
    invoke-virtual {p0}, Lmb;->j()I

    .line 51
    .line 52
    .line 53
    move-result p0

    .line 54
    invoke-direct {v3, v4, p0, v2}, Ljb;-><init>([BII)V

    .line 55
    .line 56
    .line 57
    move-object p0, v3

    .line 58
    :goto_39
    invoke-static {p0}, Lt51;->m(Lpb;)Ljava/lang/String;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    const-string v2, "..."

    .line 63
    .line 64
    invoke-virtual {p0, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 65
    .line 66
    .line 67
    move-result-object p0

    .line 68
    :goto_43
    new-instance v2, Ljava/lang/StringBuilder;

    .line 69
    .line 70
    const-string v3, "<ByteString@"

    .line 71
    .line 72
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    const-string v0, " size="

    .line 79
    .line 80
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    const-string v0, " contents=\""

    .line 87
    .line 88
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 89
    .line 90
    .line 91
    const-string v0, "\">"

    .line 92
    .line 93
    invoke-static {v2, p0, v0}, Lzi0;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    return-object p0
.end method
