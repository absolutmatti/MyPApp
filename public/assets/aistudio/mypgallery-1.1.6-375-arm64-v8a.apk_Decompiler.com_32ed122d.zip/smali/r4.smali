###### Class defpackage.r4 (r4)
.class public interface abstract Lr4;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b()Ljava/util/Set;
.end method

.method public abstract c(Ljava/lang/String;)V
.end method

.method public abstract d()I
.end method

.method public abstract e()Z
.end method

.method public abstract f()[Lws;
.end method

.method public abstract g()V
.end method

.method public abstract h(Lz9;)V
.end method

.method public abstract i()Ljava/lang/String;
.end method

.method public abstract j()Z
.end method

.method public abstract k(Lns0;)V
.end method

.method public abstract l(Ll20;Ljava/util/Set;)V
.end method
