###### Class defpackage.g20 (g20)
.class public final Lg20;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lfw;
.implements Lre0;
.implements Lc3;
.implements Ler;


# instance fields
.field public f:Lte0;

.field public g:Landroid/content/Context;

.field public h:Landroid/app/Activity;

.field public i:Le6;


# virtual methods
.method public final a(Landroid/content/Context;)Ljava/util/ArrayList;
    .registers 13

    .line 1
    new-instance v0, Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-static {v1}, Landroid/appwidget/AppWidgetManager;->getInstance(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 15
    .line 16
    .line 17
    move-result-object p1

    .line 18
    const/4 v2, 0x0

    .line 19
    invoke-virtual {v1, p1, v2}, Landroid/appwidget/AppWidgetManager;->getInstalledProvidersForPackage(Ljava/lang/String;Landroid/os/UserHandle;)Ljava/util/List;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 27
    .line 28
    .line 29
    move-result-object p1

    .line 30
    :cond_1d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-eqz v3, :cond_82

    .line 35
    .line 36
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v3

    .line 40
    check-cast v3, Landroid/appwidget/AppWidgetProviderInfo;

    .line 41
    .line 42
    iget-object v3, v3, Landroid/appwidget/AppWidgetProviderInfo;->provider:Landroid/content/ComponentName;

    .line 43
    .line 44
    invoke-virtual {v1, v3}, Landroid/appwidget/AppWidgetManager;->getAppWidgetIds(Landroid/content/ComponentName;)[I

    .line 45
    .line 46
    .line 47
    move-result-object v3

    .line 48
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 49
    .line 50
    .line 51
    array-length v4, v3

    .line 52
    const/4 v5, 0x0

    .line 53
    :goto_34
    if-ge v5, v4, :cond_1d

    .line 54
    .line 55
    aget v6, v3, v5

    .line 56
    .line 57
    invoke-virtual {v1, v6}, Landroid/appwidget/AppWidgetManager;->getAppWidgetInfo(I)Landroid/appwidget/AppWidgetProviderInfo;

    .line 58
    .line 59
    .line 60
    move-result-object v7

    .line 61
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    iget-object v8, p0, Lg20;->g:Landroid/content/Context;

    .line 65
    .line 66
    if-eqz v8, :cond_7c

    .line 67
    .line 68
    invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 69
    .line 70
    .line 71
    move-result-object v8

    .line 72
    invoke-virtual {v7, v8}, Landroid/appwidget/AppWidgetProviderInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v8

    .line 76
    invoke-virtual {v8}, Ljava/lang/String;->toString()Ljava/lang/String;

    .line 77
    .line 78
    .line 79
    move-result-object v8

    .line 80
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 81
    .line 82
    .line 83
    move-result-object v6

    .line 84
    new-instance v9, Lkj0;

    .line 85
    .line 86
    const-string v10, "widgetId"

    .line 87
    .line 88
    invoke-direct {v9, v10, v6}, Lkj0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 89
    .line 90
    .line 91
    iget-object v6, v7, Landroid/appwidget/AppWidgetProviderInfo;->provider:Landroid/content/ComponentName;

    .line 92
    .line 93
    invoke-virtual {v6}, Landroid/content/ComponentName;->getShortClassName()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object v6

    .line 97
    new-instance v7, Lkj0;

    .line 98
    .line 99
    const-string v10, "androidClassName"

    .line 100
    .line 101
    invoke-direct {v7, v10, v6}, Lkj0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    new-instance v6, Lkj0;

    .line 105
    .line 106
    const-string v10, "label"

    .line 107
    .line 108
    invoke-direct {v6, v10, v8}, Lkj0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 109
    .line 110
    .line 111
    filled-new-array {v9, v7, v6}, [Lkj0;

    .line 112
    .line 113
    .line 114
    move-result-object v6

    .line 115
    invoke-static {v6}, Lwb0;->W([Lkj0;)Ljava/util/Map;

    .line 116
    .line 117
    .line 118
    move-result-object v6

    .line 119
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 120
    .line 121
    .line 122
    add-int/lit8 v5, v5, 0x1

    .line 123
    .line 124
    goto :goto_34

    .line 125
    :cond_7c
    const-string p0, "context"

    .line 126
    .line 127
    invoke-static {p0}, Ln40;->W(Ljava/lang/String;)V

    .line 128
    .line 129
    .line 130
    throw v2

    .line 131
    :cond_82
    return-object v0
.end method

.method public final b(Loe0;Lqe0;Ljava/lang/String;)Ljava/lang/Class;
    .registers 9

    .line 1
    const-string v0, "qualifiedAndroidName"

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/String;

    .line 8
    .line 9
    const-string v1, "android"

    .line 10
    .line 11
    invoke-virtual {p1, v1}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Ljava/lang/String;

    .line 16
    .line 17
    if-nez v1, :cond_1a

    .line 18
    .line 19
    const-string v1, "name"

    .line 20
    .line 21
    invoke-virtual {p1, v1}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    check-cast v1, Ljava/lang/String;

    .line 26
    .line 27
    :cond_1a
    const/4 v2, 0x0

    .line 28
    if-nez v0, :cond_34

    .line 29
    .line 30
    if-nez v1, :cond_34

    .line 31
    .line 32
    iget-object p0, p1, Loe0;->a:Ljava/lang/String;

    .line 33
    .line 34
    const-string p1, "InvalidArguments "

    .line 35
    .line 36
    const-string v0, " must be called with one of the \'qualifiedAndroidName\', \'androidName\' or \'name\' parameters"

    .line 37
    .line 38
    invoke-static {p1, p0, v0}, Lzi0;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 43
    .line 44
    const-string v0, "Missing widget class name"

    .line 45
    .line 46
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {p2, p3, p0, p1}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    return-object v2

    .line 53
    :cond_34
    const-string p1, "context"

    .line 54
    .line 55
    if-nez v0, :cond_59

    .line 56
    .line 57
    iget-object v3, p0, Lg20;->g:Landroid/content/Context;

    .line 58
    .line 59
    if-eqz v3, :cond_55

    .line 60
    .line 61
    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object v3

    .line 65
    new-instance v4, Ljava/lang/StringBuilder;

    .line 66
    .line 67
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 68
    .line 69
    .line 70
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    const-string v3, "."

    .line 74
    .line 75
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object v1

    .line 85
    goto :goto_5a

    .line 86
    :cond_55
    invoke-static {p1}, Ln40;->W(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    throw v2

    .line 90
    :cond_59
    move-object v1, v0

    .line 91
    :goto_5a
    :try_start_5a
    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    move-result-object p0
    :try_end_5e
    .catch Ljava/lang/ClassNotFoundException; {:try_start_5a .. :try_end_5e} :catch_5f

    .line 95
    return-object p0

    .line 96
    :catch_5f
    move-exception v3

    .line 97
    if-eqz v0, :cond_65

    .line 98
    .line 99
    const-string p0, "Argument \'qualifiedAndroidName\' must be the fully qualified class name of the AppWidgetProvider you wish to update"

    .line 100
    .line 101
    goto :goto_75

    .line 102
    :cond_65
    iget-object p0, p0, Lg20;->g:Landroid/content/Context;

    .line 103
    .line 104
    if-eqz p0, :cond_8f

    .line 105
    .line 106
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object p0

    .line 110
    const-string p1, "Argument \'name\' must be the class name of the AppWidgetProvider you wish to update; it is resolved against the application id \'"

    .line 111
    .line 112
    const-string v0, "\'. Pass \'qualifiedAndroidName\' if the provider lives in a different package"

    .line 113
    .line 114
    invoke-static {p1, p0, v0}, Lzi0;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object p0

    .line 118
    :goto_75
    new-instance p1, Ljava/lang/StringBuilder;

    .line 119
    .line 120
    const-string v0, "No Widget found with Name "

    .line 121
    .line 122
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    const-string v0, ". "

    .line 129
    .line 130
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    invoke-virtual {p2, p3, p0, v3}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 141
    .line 142
    .line 143
    return-object v2

    .line 144
    :cond_8f
    invoke-static {p1}, Ln40;->W(Ljava/lang/String;)V

    .line 145
    .line 146
    .line 147
    throw v2
.end method

.method public final c()V
    .registers 2

    .line 1
    :try_start_0
    iget-object v0, p0, Lg20;->i:Le6;

    .line 2
    .line 3
    if-eqz v0, :cond_13

    .line 4
    .line 5
    iget-object p0, p0, Lg20;->g:Landroid/content/Context;

    .line 6
    .line 7
    if-eqz p0, :cond_c

    .line 8
    .line 9
    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    const-string p0, "context"

    .line 14
    .line 15
    invoke-static {p0}, Ln40;->W(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const/4 p0, 0x0

    .line 19
    throw p0
    :try_end_13
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_13} :catch_13

    .line 20
    :catch_13
    :cond_13
    return-void
.end method

.method public final h(Ljava/lang/Object;Ldr;)V
    .registers 4

    .line 1
    new-instance p1, Le6;

    .line 2
    .line 3
    const/4 v0, 0x3

    .line 4
    invoke-direct {p1, v0, p2}, Le6;-><init>(ILjava/lang/Object;)V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lg20;->i:Le6;

    .line 8
    .line 9
    return-void
.end method

.method public final onAttachedToActivity(Ld3;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    check-cast p1, Lk6;

    .line 5
    .line 6
    iget-object v0, p1, Lk6;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/app/Activity;

    .line 9
    .line 10
    iput-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 11
    .line 12
    iget-object p1, p1, Lk6;->d:Ljava/io/Serializable;

    .line 13
    .line 14
    check-cast p1, Ljava/util/HashSet;

    .line 15
    .line 16
    invoke-virtual {p1, p0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    return-void
.end method

.method public final onAttachedToEngine(Lew;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Lte0;

    .line 5
    .line 6
    iget-object v1, p1, Lew;->c:Lla;

    .line 7
    .line 8
    const-string v2, "home_widget"

    .line 9
    .line 10
    invoke-direct {v0, v1, v2}, Lte0;-><init>(Lla;Ljava/lang/String;)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lg20;->f:Lte0;

    .line 14
    .line 15
    invoke-virtual {v0, p0}, Lte0;->b(Lre0;)V

    .line 16
    .line 17
    .line 18
    new-instance v0, Ld8;

    .line 19
    .line 20
    const-string v2, "home_widget/updates"

    .line 21
    .line 22
    invoke-direct {v0, v1, v2}, Ld8;-><init>(Lla;Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ld8;->A(Ler;)V

    .line 26
    .line 27
    .line 28
    iget-object p1, p1, Lew;->a:Landroid/content/Context;

    .line 29
    .line 30
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    iput-object p1, p0, Lg20;->g:Landroid/content/Context;

    .line 34
    .line 35
    sget-object p0, Lj20;->a:Lj20;

    .line 36
    .line 37
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 38
    .line 39
    const/16 v0, 0x23

    .line 40
    .line 41
    if-ge p0, v0, :cond_2b

    .line 42
    .line 43
    return-void

    .line 44
    :cond_2b
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    sget-object p1, Ltn;->a:Lam;

    .line 49
    .line 50
    invoke-static {p1}, Lfo0;->a(Lyh;)Lph;

    .line 51
    .line 52
    .line 53
    move-result-object p1

    .line 54
    new-instance v0, Lpc;

    .line 55
    .line 56
    const/4 v1, 0x5

    .line 57
    const/4 v2, 0x0

    .line 58
    invoke-direct {v0, p0, v2, v1}, Lpc;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 59
    .line 60
    .line 61
    const/4 p0, 0x3

    .line 62
    invoke-static {p1, v2, v2, v0, p0}, Lr30;->E(Lhi;Lwh;Lji;Lsz;I)Lvz0;

    .line 63
    .line 64
    .line 65
    return-void
.end method

.method public final onCancel()V
    .registers 2

    .line 1
    invoke-virtual {p0}, Lg20;->c()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lg20;->i:Le6;

    .line 6
    .line 7
    return-void
.end method

.method public final onDetachedFromActivity()V
    .registers 2

    .line 1
    invoke-virtual {p0}, Lg20;->c()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 6
    .line 7
    return-void
.end method

.method public final onDetachedFromActivityForConfigChanges()V
    .registers 2

    .line 1
    invoke-virtual {p0}, Lg20;->c()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 6
    .line 7
    return-void
.end method

.method public final onDetachedFromEngine(Lew;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lg20;->f:Lte0;

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    if-eqz p0, :cond_c

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lte0;->b(Lre0;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    const-string p0, "channel"

    .line 14
    .line 15
    invoke-static {p0}, Ln40;->W(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    throw p1
.end method

.method public final onMethodCall(Loe0;Lse0;)V
    .registers 17

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v2, p1, Loe0;->b:Ljava/lang/Object;

    .line 5
    .line 6
    iget-object v3, p1, Loe0;->a:Ljava/lang/String;

    .line 7
    .line 8
    if-eqz v3, :cond_550

    .line 9
    .line 10
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 11
    .line 12
    .line 13
    move-result v4

    .line 14
    const-string v5, "HomeWidgetPreferences"

    .line 15
    .line 16
    const-string v6, "android.appwidget.action.APPWIDGET_CONFIGURE"

    .line 17
    .line 18
    const-string v7, "home_widget.double."

    .line 19
    .line 20
    const-string v8, "appWidgetId"

    .line 21
    .line 22
    const-string v9, "id"

    .line 23
    .line 24
    const/4 v10, 0x1

    .line 25
    const/4 v11, 0x0

    .line 26
    const-string v12, "context"

    .line 27
    .line 28
    move v13, v4

    .line 29
    const/4 v4, 0x0

    .line 30
    sparse-switch v13, :sswitch_data_558

    .line 31
    .line 32
    .line 33
    goto/16 :goto_550

    .line 34
    .line 35
    :sswitch_22
    const-string v2, "requestPinWidget"

    .line 36
    .line 37
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-nez v2, :cond_2c

    .line 42
    .line 43
    goto/16 :goto_550

    .line 44
    .line 45
    :cond_2c
    move-object/from16 v2, p2

    .line 46
    .line 47
    check-cast v2, Lqe0;

    .line 48
    .line 49
    const-string v3, "-4"

    .line 50
    .line 51
    invoke-virtual {p0, p1, v2, v3}, Lg20;->b(Loe0;Lqe0;Ljava/lang/String;)Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    if-nez v0, :cond_3a

    .line 56
    .line 57
    goto/16 :goto_41e

    .line 58
    .line 59
    :cond_3a
    new-instance v3, Landroid/content/ComponentName;

    .line 60
    .line 61
    iget-object v5, p0, Lg20;->g:Landroid/content/Context;

    .line 62
    .line 63
    if-eqz v5, :cond_60

    .line 64
    .line 65
    invoke-direct {v3, v5, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 66
    .line 67
    .line 68
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 69
    .line 70
    if-eqz v0, :cond_5c

    .line 71
    .line 72
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 73
    .line 74
    .line 75
    move-result-object v0

    .line 76
    invoke-static {v0}, Landroid/appwidget/AppWidgetManager;->getInstance(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;

    .line 77
    .line 78
    .line 79
    move-result-object v0

    .line 80
    invoke-virtual {v0}, Landroid/appwidget/AppWidgetManager;->isRequestPinAppWidgetSupported()Z

    .line 81
    .line 82
    .line 83
    move-result v1

    .line 84
    if-eqz v1, :cond_58

    .line 85
    .line 86
    invoke-virtual {v0, v3, v4, v4}, Landroid/appwidget/AppWidgetManager;->requestPinAppWidget(Landroid/content/ComponentName;Landroid/os/Bundle;Landroid/app/PendingIntent;)Z

    .line 87
    .line 88
    .line 89
    :cond_58
    invoke-virtual {v2, v4}, Lqe0;->success(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    return-void

    .line 93
    :cond_5c
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    throw v4

    .line 97
    :cond_60
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 98
    .line 99
    .line 100
    throw v4

    .line 101
    :sswitch_64
    const-string v0, "setAppGroupId"

    .line 102
    .line 103
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v0

    .line 107
    if-nez v0, :cond_6e

    .line 108
    .line 109
    goto/16 :goto_550

    .line 110
    .line 111
    :cond_6e
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 112
    .line 113
    move-object/from16 v1, p2

    .line 114
    .line 115
    check-cast v1, Lqe0;

    .line 116
    .line 117
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 118
    .line 119
    .line 120
    return-void

    .line 121
    :sswitch_78
    const-string v0, "finishHomeWidgetConfigure"

    .line 122
    .line 123
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v0

    .line 127
    if-nez v0, :cond_82

    .line 128
    .line 129
    goto/16 :goto_550

    .line 130
    .line 131
    :cond_82
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 132
    .line 133
    if-eqz v0, :cond_d2

    .line 134
    .line 135
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 136
    .line 137
    .line 138
    move-result-object v0

    .line 139
    if-eqz v0, :cond_d2

    .line 140
    .line 141
    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    if-eqz v0, :cond_d2

    .line 146
    .line 147
    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 148
    .line 149
    .line 150
    move-result v0

    .line 151
    if-ne v0, v10, :cond_d2

    .line 152
    .line 153
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 154
    .line 155
    if-eqz v0, :cond_ab

    .line 156
    .line 157
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    if-eqz v0, :cond_ab

    .line 162
    .line 163
    invoke-virtual {v0, v8, v11}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 164
    .line 165
    .line 166
    move-result v0

    .line 167
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 168
    .line 169
    .line 170
    move-result-object v0

    .line 171
    goto :goto_ac

    .line 172
    :cond_ab
    move-object v0, v4

    .line 173
    :goto_ac
    if-eqz v0, :cond_d2

    .line 174
    .line 175
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 176
    .line 177
    .line 178
    move-result v2

    .line 179
    if-eqz v2, :cond_d2

    .line 180
    .line 181
    iget-object v2, p0, Lg20;->h:Landroid/app/Activity;

    .line 182
    .line 183
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 184
    .line 185
    .line 186
    new-instance v3, Landroid/content/Intent;

    .line 187
    .line 188
    invoke-direct {v3}, Landroid/content/Intent;-><init>()V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    invoke-virtual {v3, v8, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 196
    .line 197
    .line 198
    move-result-object v0

    .line 199
    const/4 v3, -0x1

    .line 200
    invoke-virtual {v2, v3, v0}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    .line 201
    .line 202
    .line 203
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 204
    .line 205
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    .line 207
    .line 208
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 209
    .line 210
    .line 211
    :cond_d2
    move-object/from16 v0, p2

    .line 212
    .line 213
    check-cast v0, Lqe0;

    .line 214
    .line 215
    invoke-virtual {v0, v4}, Lqe0;->success(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    return-void

    .line 219
    :sswitch_da
    const-string v2, "updateWidgetPreview"

    .line 220
    .line 221
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 222
    .line 223
    .line 224
    move-result v2

    .line 225
    if-nez v2, :cond_e4

    .line 226
    .line 227
    goto/16 :goto_550

    .line 228
    .line 229
    :cond_e4
    move-object/from16 v3, p2

    .line 230
    .line 231
    check-cast v3, Lqe0;

    .line 232
    .line 233
    const-string v2, "-8"

    .line 234
    .line 235
    invoke-virtual {p0, p1, v3, v2}, Lg20;->b(Loe0;Lqe0;Ljava/lang/String;)Ljava/lang/Class;

    .line 236
    .line 237
    .line 238
    move-result-object v2

    .line 239
    if-nez v2, :cond_f2

    .line 240
    .line 241
    goto/16 :goto_41e

    .line 242
    .line 243
    :cond_f2
    sget-object v0, Ltn;->a:Lam;

    .line 244
    .line 245
    invoke-static {v0}, Lfo0;->a(Lyh;)Lph;

    .line 246
    .line 247
    .line 248
    move-result-object v6

    .line 249
    new-instance v0, Ll2;

    .line 250
    .line 251
    const/4 v5, 0x1

    .line 252
    move-object v1, p0

    .line 253
    invoke-direct/range {v0 .. v5}, Ll2;-><init>(Ljava/lang/Object;Ljava/io/Serializable;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 254
    .line 255
    .line 256
    const/4 v1, 0x3

    .line 257
    invoke-static {v6, v4, v4, v0, v1}, Lr30;->E(Lhi;Lwh;Lji;Lsz;I)Lvz0;

    .line 258
    .line 259
    .line 260
    return-void

    .line 261
    :sswitch_104
    const-string v0, "isRequestPinWidgetSupported"

    .line 262
    .line 263
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 264
    .line 265
    .line 266
    move-result v0

    .line 267
    if-nez v0, :cond_10e

    .line 268
    .line 269
    goto/16 :goto_550

    .line 270
    .line 271
    :cond_10e
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 272
    .line 273
    if-eqz v0, :cond_12a

    .line 274
    .line 275
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 276
    .line 277
    .line 278
    move-result-object v0

    .line 279
    invoke-static {v0}, Landroid/appwidget/AppWidgetManager;->getInstance(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;

    .line 280
    .line 281
    .line 282
    move-result-object v0

    .line 283
    invoke-virtual {v0}, Landroid/appwidget/AppWidgetManager;->isRequestPinAppWidgetSupported()Z

    .line 284
    .line 285
    .line 286
    move-result v0

    .line 287
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 288
    .line 289
    .line 290
    move-result-object v0

    .line 291
    move-object/from16 v1, p2

    .line 292
    .line 293
    check-cast v1, Lqe0;

    .line 294
    .line 295
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 296
    .line 297
    .line 298
    return-void

    .line 299
    :cond_12a
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 300
    .line 301
    .line 302
    throw v4

    .line 303
    :sswitch_12e
    const-string v0, "canScheduleExactWidgetUpdates"

    .line 304
    .line 305
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 306
    .line 307
    .line 308
    move-result v0

    .line 309
    if-nez v0, :cond_138

    .line 310
    .line 311
    goto/16 :goto_550

    .line 312
    .line 313
    :cond_138
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 314
    .line 315
    const/16 v2, 0x1f

    .line 316
    .line 317
    if-ge v0, v2, :cond_148

    .line 318
    .line 319
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 320
    .line 321
    move-object/from16 v1, p2

    .line 322
    .line 323
    check-cast v1, Lqe0;

    .line 324
    .line 325
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 326
    .line 327
    .line 328
    return-void

    .line 329
    :cond_148
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 330
    .line 331
    if-eqz v0, :cond_16b

    .line 332
    .line 333
    const-string v1, "alarm"

    .line 334
    .line 335
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 336
    .line 337
    .line 338
    move-result-object v0

    .line 339
    instance-of v1, v0, Landroid/app/AlarmManager;

    .line 340
    .line 341
    if-eqz v1, :cond_159

    .line 342
    .line 343
    move-object v4, v0

    .line 344
    check-cast v4, Landroid/app/AlarmManager;

    .line 345
    .line 346
    :cond_159
    if-eqz v4, :cond_15f

    .line 347
    .line 348
    invoke-static {v4}, Ls0;->u(Landroid/app/AlarmManager;)Z

    .line 349
    .line 350
    .line 351
    move-result v11

    .line 352
    :cond_15f
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 353
    .line 354
    .line 355
    move-result-object v0

    .line 356
    move-object/from16 v1, p2

    .line 357
    .line 358
    check-cast v1, Lqe0;

    .line 359
    .line 360
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 361
    .line 362
    .line 363
    return-void

    .line 364
    :cond_16b
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 365
    .line 366
    .line 367
    throw v4

    .line 368
    :sswitch_16f
    const-string v0, "registerBackgroundCallback"

    .line 369
    .line 370
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 371
    .line 372
    .line 373
    move-result v0

    .line 374
    if-nez v0, :cond_179

    .line 375
    .line 376
    goto/16 :goto_550

    .line 377
    .line 378
    :cond_179
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 379
    .line 380
    .line 381
    check-cast v2, Ljava/lang/Iterable;

    .line 382
    .line 383
    invoke-static {v2}, Lfe;->e0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 384
    .line 385
    .line 386
    move-result-object v0

    .line 387
    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 388
    .line 389
    .line 390
    move-result-object v0

    .line 391
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 392
    .line 393
    .line 394
    check-cast v0, Ljava/lang/Number;

    .line 395
    .line 396
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 397
    .line 398
    .line 399
    move-result-wide v5

    .line 400
    invoke-static {v2}, Lfe;->e0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 401
    .line 402
    .line 403
    move-result-object v0

    .line 404
    invoke-interface {v0, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 405
    .line 406
    .line 407
    move-result-object v0

    .line 408
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 409
    .line 410
    .line 411
    check-cast v0, Ljava/lang/Number;

    .line 412
    .line 413
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 414
    .line 415
    .line 416
    move-result-wide v2

    .line 417
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 418
    .line 419
    if-eqz v0, :cond_1c7

    .line 420
    .line 421
    const-string v1, "InternalHomeWidgetPreferences"

    .line 422
    .line 423
    invoke-virtual {v0, v1, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 424
    .line 425
    .line 426
    move-result-object v0

    .line 427
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 428
    .line 429
    .line 430
    move-result-object v0

    .line 431
    const-string v1, "callbackDispatcherHandle"

    .line 432
    .line 433
    invoke-interface {v0, v1, v5, v6}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 434
    .line 435
    .line 436
    move-result-object v0

    .line 437
    const-string v1, "callbackHandle"

    .line 438
    .line 439
    invoke-interface {v0, v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 440
    .line 441
    .line 442
    move-result-object v0

    .line 443
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    .line 444
    .line 445
    .line 446
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 447
    .line 448
    move-object/from16 v1, p2

    .line 449
    .line 450
    check-cast v1, Lqe0;

    .line 451
    .line 452
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 453
    .line 454
    .line 455
    return-void

    .line 456
    :cond_1c7
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 457
    .line 458
    .line 459
    throw v4

    .line 460
    :sswitch_1cb
    const-string v2, "cancelScheduledWidgetUpdates"

    .line 461
    .line 462
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 463
    .line 464
    .line 465
    move-result v2

    .line 466
    if-nez v2, :cond_1d5

    .line 467
    .line 468
    goto/16 :goto_550

    .line 469
    .line 470
    :cond_1d5
    move-object/from16 v2, p2

    .line 471
    .line 472
    check-cast v2, Lqe0;

    .line 473
    .line 474
    const-string v3, "-7"

    .line 475
    .line 476
    invoke-virtual {p0, p1, v2, v3}, Lg20;->b(Loe0;Lqe0;Ljava/lang/String;)Ljava/lang/Class;

    .line 477
    .line 478
    .line 479
    move-result-object v0

    .line 480
    if-nez v0, :cond_1e3

    .line 481
    .line 482
    goto/16 :goto_41e

    .line 483
    .line 484
    :cond_1e3
    iget-object v1, p0, Lg20;->g:Landroid/content/Context;

    .line 485
    .line 486
    if-eqz v1, :cond_1f4

    .line 487
    .line 488
    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 489
    .line 490
    .line 491
    move-result-object v0

    .line 492
    invoke-static {v1, v0}, Lsa;->k(Landroid/content/Context;Ljava/lang/String;)V

    .line 493
    .line 494
    .line 495
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 496
    .line 497
    invoke-virtual {v2, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 498
    .line 499
    .line 500
    return-void

    .line 501
    :cond_1f4
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 502
    .line 503
    .line 504
    throw v4

    .line 505
    :sswitch_1f8
    const-string v0, "initiallyLaunchedFromHomeWidgetConfigure"

    .line 506
    .line 507
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 508
    .line 509
    .line 510
    move-result v0

    .line 511
    if-nez v0, :cond_202

    .line 512
    .line 513
    goto/16 :goto_550

    .line 514
    .line 515
    :cond_202
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 516
    .line 517
    if-eqz v0, :cond_24c

    .line 518
    .line 519
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 520
    .line 521
    .line 522
    move-result-object v0

    .line 523
    if-eqz v0, :cond_24c

    .line 524
    .line 525
    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 526
    .line 527
    .line 528
    move-result-object v0

    .line 529
    if-eqz v0, :cond_24c

    .line 530
    .line 531
    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 532
    .line 533
    .line 534
    move-result v0

    .line 535
    if-ne v0, v10, :cond_24c

    .line 536
    .line 537
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 538
    .line 539
    if-eqz v0, :cond_22b

    .line 540
    .line 541
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 542
    .line 543
    .line 544
    move-result-object v0

    .line 545
    if-eqz v0, :cond_22b

    .line 546
    .line 547
    invoke-virtual {v0, v8, v11}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    .line 548
    .line 549
    .line 550
    move-result v0

    .line 551
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 552
    .line 553
    .line 554
    move-result-object v0

    .line 555
    goto :goto_22c

    .line 556
    :cond_22b
    move-object v0, v4

    .line 557
    :goto_22c
    if-eqz v0, :cond_24c

    .line 558
    .line 559
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 560
    .line 561
    .line 562
    move-result v2

    .line 563
    if-eqz v2, :cond_24c

    .line 564
    .line 565
    iget-object v1, p0, Lg20;->h:Landroid/app/Activity;

    .line 566
    .line 567
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 568
    .line 569
    .line 570
    invoke-virtual {v1, v11}, Landroid/app/Activity;->setResult(I)V

    .line 571
    .line 572
    .line 573
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 574
    .line 575
    .line 576
    move-result v0

    .line 577
    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 578
    .line 579
    .line 580
    move-result-object v0

    .line 581
    move-object/from16 v1, p2

    .line 582
    .line 583
    check-cast v1, Lqe0;

    .line 584
    .line 585
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 586
    .line 587
    .line 588
    return-void

    .line 589
    :cond_24c
    move-object/from16 v0, p2

    .line 590
    .line 591
    check-cast v0, Lqe0;

    .line 592
    .line 593
    invoke-virtual {v0, v4}, Lqe0;->success(Ljava/lang/Object;)V

    .line 594
    .line 595
    .line 596
    return-void

    .line 597
    :sswitch_254
    const-string v0, "getInstalledWidgets"

    .line 598
    .line 599
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 600
    .line 601
    .line 602
    move-result v0

    .line 603
    if-nez v0, :cond_25e

    .line 604
    .line 605
    goto/16 :goto_550

    .line 606
    .line 607
    :cond_25e
    :try_start_25e
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 608
    .line 609
    if-eqz v0, :cond_270

    .line 610
    .line 611
    invoke-virtual {p0, v0}, Lg20;->a(Landroid/content/Context;)Ljava/util/ArrayList;

    .line 612
    .line 613
    .line 614
    move-result-object v0

    .line 615
    move-object/from16 v1, p2

    .line 616
    .line 617
    check-cast v1, Lqe0;

    .line 618
    .line 619
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 620
    .line 621
    .line 622
    return-void

    .line 623
    :catch_26e
    move-exception v0

    .line 624
    goto :goto_274

    .line 625
    :cond_270
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 626
    .line 627
    .line 628
    throw v4
    :try_end_274
    .catch Ljava/lang/Exception; {:try_start_25e .. :try_end_274} :catch_26e

    .line 629
    :goto_274
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 630
    .line 631
    .line 632
    move-result-object v0

    .line 633
    const-string v1, "Failed to get installed widgets: "

    .line 634
    .line 635
    invoke-static {v1, v0}, Lzi0;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 636
    .line 637
    .line 638
    move-result-object v0

    .line 639
    move-object/from16 v1, p2

    .line 640
    .line 641
    check-cast v1, Lqe0;

    .line 642
    .line 643
    const-string v2, "-5"

    .line 644
    .line 645
    invoke-virtual {v1, v2, v0, v4}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 646
    .line 647
    .line 648
    goto/16 :goto_41e

    .line 649
    .line 650
    :sswitch_289
    const-string v2, "getWidgetData"

    .line 651
    .line 652
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 653
    .line 654
    .line 655
    move-result v2

    .line 656
    if-nez v2, :cond_293

    .line 657
    .line 658
    goto/16 :goto_550

    .line 659
    .line 660
    :cond_293
    invoke-virtual {p1, v9}, Loe0;->b(Ljava/lang/String;)Z

    .line 661
    .line 662
    .line 663
    move-result v2

    .line 664
    if-eqz v2, :cond_2f2

    .line 665
    .line 666
    invoke-virtual {p1, v9}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object v2

    .line 670
    check-cast v2, Ljava/lang/String;

    .line 671
    .line 672
    const-string v3, "defaultValue"

    .line 673
    .line 674
    invoke-virtual {p1, v3}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 675
    .line 676
    .line 677
    move-result-object v0

    .line 678
    iget-object v1, p0, Lg20;->g:Landroid/content/Context;

    .line 679
    .line 680
    if-eqz v1, :cond_2ee

    .line 681
    .line 682
    invoke-virtual {v1, v5, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 683
    .line 684
    .line 685
    move-result-object v1

    .line 686
    invoke-interface {v1}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    .line 687
    .line 688
    .line 689
    move-result-object v3

    .line 690
    invoke-interface {v3, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 691
    .line 692
    .line 693
    move-result-object v3

    .line 694
    if-nez v3, :cond_2b8

    .line 695
    .line 696
    goto :goto_2b9

    .line 697
    :cond_2b8
    move-object v0, v3

    .line 698
    :goto_2b9
    nop

    .line 699
    instance-of v3, v0, Ljava/lang/Long;

    .line 700
    .line 701
    if-eqz v3, :cond_2e6

    .line 702
    .line 703
    new-instance v3, Ljava/lang/StringBuilder;

    .line 704
    .line 705
    invoke-direct {v3, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 706
    .line 707
    .line 708
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 709
    .line 710
    .line 711
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 712
    .line 713
    .line 714
    move-result-object v2

    .line 715
    invoke-interface {v1, v2, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    .line 716
    .line 717
    .line 718
    move-result v1

    .line 719
    if-eqz v1, :cond_2e6

    .line 720
    .line 721
    check-cast v0, Ljava/lang/Number;

    .line 722
    .line 723
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 724
    .line 725
    .line 726
    move-result-wide v0

    .line 727
    invoke-static {v0, v1}, Ljava/lang/Double;->longBitsToDouble(J)D

    .line 728
    .line 729
    .line 730
    move-result-wide v0

    .line 731
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 732
    .line 733
    .line 734
    move-result-object v0

    .line 735
    move-object/from16 v1, p2

    .line 736
    .line 737
    check-cast v1, Lqe0;

    .line 738
    .line 739
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 740
    .line 741
    .line 742
    return-void

    .line 743
    :cond_2e6
    move-object/from16 v1, p2

    .line 744
    .line 745
    check-cast v1, Lqe0;

    .line 746
    .line 747
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 748
    .line 749
    .line 750
    return-void

    .line 751
    :cond_2ee
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 752
    .line 753
    .line 754
    throw v4

    .line 755
    :cond_2f2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 756
    .line 757
    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 758
    .line 759
    .line 760
    move-object/from16 v1, p2

    .line 761
    .line 762
    check-cast v1, Lqe0;

    .line 763
    .line 764
    const-string v2, "-2"

    .line 765
    .line 766
    const-string v3, "InvalidArguments getWidgetData must be called with id"

    .line 767
    .line 768
    invoke-virtual {v1, v2, v3, v0}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 769
    .line 770
    .line 771
    return-void

    .line 772
    :sswitch_303
    const-string v2, "updateWidget"

    .line 773
    .line 774
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 775
    .line 776
    .line 777
    move-result v2

    .line 778
    if-nez v2, :cond_30d

    .line 779
    .line 780
    goto/16 :goto_550

    .line 781
    .line 782
    :cond_30d
    move-object/from16 v2, p2

    .line 783
    .line 784
    check-cast v2, Lqe0;

    .line 785
    .line 786
    const-string v3, "-3"

    .line 787
    .line 788
    invoke-virtual {p0, p1, v2, v3}, Lg20;->b(Loe0;Lqe0;Ljava/lang/String;)Ljava/lang/Class;

    .line 789
    .line 790
    .line 791
    move-result-object v0

    .line 792
    if-nez v0, :cond_31b

    .line 793
    .line 794
    goto/16 :goto_41e

    .line 795
    .line 796
    :cond_31b
    new-instance v3, Landroid/content/Intent;

    .line 797
    .line 798
    iget-object v5, p0, Lg20;->g:Landroid/content/Context;

    .line 799
    .line 800
    if-eqz v5, :cond_368

    .line 801
    .line 802
    invoke-direct {v3, v5, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 803
    .line 804
    .line 805
    const-string v5, "android.appwidget.action.APPWIDGET_UPDATE"

    .line 806
    .line 807
    invoke-virtual {v3, v5}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 808
    .line 809
    .line 810
    iget-object v5, p0, Lg20;->g:Landroid/content/Context;

    .line 811
    .line 812
    if-eqz v5, :cond_364

    .line 813
    .line 814
    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 815
    .line 816
    .line 817
    move-result-object v5

    .line 818
    invoke-static {v5}, Landroid/appwidget/AppWidgetManager;->getInstance(Landroid/content/Context;)Landroid/appwidget/AppWidgetManager;

    .line 819
    .line 820
    .line 821
    move-result-object v5

    .line 822
    new-instance v6, Landroid/content/ComponentName;

    .line 823
    .line 824
    iget-object v7, p0, Lg20;->g:Landroid/content/Context;

    .line 825
    .line 826
    if-eqz v7, :cond_360

    .line 827
    .line 828
    invoke-direct {v6, v7, v0}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 829
    .line 830
    .line 831
    invoke-virtual {v5, v6}, Landroid/appwidget/AppWidgetManager;->getAppWidgetIds(Landroid/content/ComponentName;)[I

    .line 832
    .line 833
    .line 834
    move-result-object v0

    .line 835
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 836
    .line 837
    .line 838
    const-string v5, "appWidgetIds"

    .line 839
    .line 840
    invoke-virtual {v3, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[I)Landroid/content/Intent;

    .line 841
    .line 842
    .line 843
    const-string v0, "triggeredFromHomeWidget"

    .line 844
    .line 845
    invoke-virtual {v3, v0, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 846
    .line 847
    .line 848
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 849
    .line 850
    if-eqz v0, :cond_35c

    .line 851
    .line 852
    invoke-virtual {v0, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    .line 853
    .line 854
    .line 855
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 856
    .line 857
    invoke-virtual {v2, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 858
    .line 859
    .line 860
    return-void

    .line 861
    :cond_35c
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 862
    .line 863
    .line 864
    throw v4

    .line 865
    :cond_360
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 866
    .line 867
    .line 868
    throw v4

    .line 869
    :cond_364
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 870
    .line 871
    .line 872
    throw v4

    .line 873
    :cond_368
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 874
    .line 875
    .line 876
    throw v4

    .line 877
    :sswitch_36c
    const-string v2, "scheduleWidgetUpdates"

    .line 878
    .line 879
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 880
    .line 881
    .line 882
    move-result v2

    .line 883
    if-nez v2, :cond_376

    .line 884
    .line 885
    goto/16 :goto_550

    .line 886
    .line 887
    :cond_376
    move-object/from16 v2, p2

    .line 888
    .line 889
    check-cast v2, Lqe0;

    .line 890
    .line 891
    const-string v3, "-6"

    .line 892
    .line 893
    invoke-virtual {p0, p1, v2, v3}, Lg20;->b(Loe0;Lqe0;Ljava/lang/String;)Ljava/lang/Class;

    .line 894
    .line 895
    .line 896
    move-result-object v3

    .line 897
    if-nez v3, :cond_384

    .line 898
    .line 899
    goto/16 :goto_41e

    .line 900
    .line 901
    :cond_384
    const-string v5, "updateTimes"

    .line 902
    .line 903
    invoke-virtual {p1, v5}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 904
    .line 905
    .line 906
    move-result-object v0

    .line 907
    check-cast v0, Ljava/util/List;

    .line 908
    .line 909
    if-eqz v0, :cond_3b3

    .line 910
    .line 911
    new-instance v5, Ljava/util/ArrayList;

    .line 912
    .line 913
    invoke-static {v0}, Lge;->M(Ljava/lang/Iterable;)I

    .line 914
    .line 915
    .line 916
    move-result v6

    .line 917
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 918
    .line 919
    .line 920
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 921
    .line 922
    .line 923
    move-result-object v0

    .line 924
    :goto_39b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 925
    .line 926
    .line 927
    move-result v6

    .line 928
    if-eqz v6, :cond_3b5

    .line 929
    .line 930
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 931
    .line 932
    .line 933
    move-result-object v6

    .line 934
    check-cast v6, Ljava/lang/Number;

    .line 935
    .line 936
    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    .line 937
    .line 938
    .line 939
    move-result-wide v6

    .line 940
    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 941
    .line 942
    .line 943
    move-result-object v6

    .line 944
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 945
    .line 946
    .line 947
    goto :goto_39b

    .line 948
    :cond_3b3
    sget-object v5, Luq;->f:Luq;

    .line 949
    .line 950
    :cond_3b5
    iget-object v0, p0, Lg20;->g:Landroid/content/Context;

    .line 951
    .line 952
    if-eqz v0, :cond_41f

    .line 953
    .line 954
    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 955
    .line 956
    .line 957
    move-result-object v1

    .line 958
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 959
    .line 960
    .line 961
    move-result-wide v3

    .line 962
    new-instance v6, Ljava/util/ArrayList;

    .line 963
    .line 964
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 965
    .line 966
    .line 967
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 968
    .line 969
    .line 970
    move-result-object v5

    .line 971
    :cond_3ca
    :goto_3ca
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 972
    .line 973
    .line 974
    move-result v7

    .line 975
    if-eqz v7, :cond_3e3

    .line 976
    .line 977
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 978
    .line 979
    .line 980
    move-result-object v7

    .line 981
    move-object v8, v7

    .line 982
    check-cast v8, Ljava/lang/Number;

    .line 983
    .line 984
    invoke-virtual {v8}, Ljava/lang/Number;->longValue()J

    .line 985
    .line 986
    .line 987
    move-result-wide v8

    .line 988
    cmp-long v8, v8, v3

    .line 989
    .line 990
    if-lez v8, :cond_3ca

    .line 991
    .line 992
    invoke-virtual {v6, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 993
    .line 994
    .line 995
    goto :goto_3ca

    .line 996
    :cond_3e3
    invoke-static {v6}, Lfe;->Q(Ljava/lang/Iterable;)Ljava/util/List;

    .line 997
    .line 998
    .line 999
    move-result-object v3

    .line 1000
    invoke-static {v3}, Lfe;->a0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 1001
    .line 1002
    .line 1003
    move-result-object v3

    .line 1004
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 1005
    .line 1006
    .line 1007
    move-result v4

    .line 1008
    if-eqz v4, :cond_3f5

    .line 1009
    .line 1010
    invoke-static {v0, v1}, Lsa;->k(Landroid/content/Context;Ljava/lang/String;)V

    .line 1011
    .line 1012
    .line 1013
    goto :goto_419

    .line 1014
    :cond_3f5
    new-instance v4, Landroid/content/ComponentName;

    .line 1015
    .line 1016
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 1017
    .line 1018
    .line 1019
    move-result-object v5

    .line 1020
    const-class v6, Lk20;

    .line 1021
    .line 1022
    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1023
    .line 1024
    .line 1025
    :try_start_400
    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 1026
    .line 1027
    .line 1028
    move-result-object v5

    .line 1029
    invoke-virtual {v5, v4, v11}, Landroid/content/pm/PackageManager;->getReceiverInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ActivityInfo;

    .line 1030
    .line 1031
    .line 1032
    move-result-object v4

    .line 1033
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_40b
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_400 .. :try_end_40b} :catch_40c

    .line 1034
    .line 1035
    .line 1036
    goto :goto_413

    .line 1037
    :catch_40c
    const-string v4, "HomeWidgetScheduler"

    .line 1038
    .line 1039
    const-string v5, "HomeWidgetScheduledUpdateReceiver is not registered in the app\'s AndroidManifest.xml. Scheduled Widget updates will not be delivered. Add:\n<uses-permission android:name=\"android.permission.RECEIVE_BOOT_COMPLETED\" />\n<receiver android:name=\"es.antonborri.home_widget.HomeWidgetScheduledUpdateReceiver\" android:exported=\"false\">\n  <intent-filter>\n    <action android:name=\"android.intent.action.BOOT_COMPLETED\" />\n    <action android:name=\"android.intent.action.MY_PACKAGE_REPLACED\" />\n    <action android:name=\"android.app.action.SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED\" />\n  </intent-filter>\n</receiver>"

    .line 1040
    .line 1041
    invoke-static {v4, v5}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 1042
    .line 1043
    .line 1044
    :goto_413
    invoke-static {v0, v1, v3}, Lsa;->P(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;)V

    .line 1045
    .line 1046
    .line 1047
    invoke-static {v0, v1, v3}, Lsa;->e(Landroid/content/Context;Ljava/lang/String;Ljava/util/List;)V

    .line 1048
    .line 1049
    .line 1050
    :goto_419
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1051
    .line 1052
    invoke-virtual {v2, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1053
    .line 1054
    .line 1055
    :goto_41e
    return-void

    .line 1056
    :cond_41f
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 1057
    .line 1058
    .line 1059
    throw v4

    .line 1060
    :sswitch_423
    const-string v2, "saveWidgetData"

    .line 1061
    .line 1062
    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1063
    .line 1064
    .line 1065
    move-result v2

    .line 1066
    if-nez v2, :cond_42d

    .line 1067
    .line 1068
    goto/16 :goto_550

    .line 1069
    .line 1070
    :cond_42d
    invoke-virtual {p1, v9}, Loe0;->b(Ljava/lang/String;)Z

    .line 1071
    .line 1072
    .line 1073
    move-result v2

    .line 1074
    if-eqz v2, :cond_4f6

    .line 1075
    .line 1076
    const-string v2, "data"

    .line 1077
    .line 1078
    invoke-virtual {p1, v2}, Loe0;->b(Ljava/lang/String;)Z

    .line 1079
    .line 1080
    .line 1081
    move-result v3

    .line 1082
    if-eqz v3, :cond_4f6

    .line 1083
    .line 1084
    invoke-virtual {p1, v9}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 1085
    .line 1086
    .line 1087
    move-result-object v3

    .line 1088
    check-cast v3, Ljava/lang/String;

    .line 1089
    .line 1090
    invoke-virtual {p1, v2}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 1091
    .line 1092
    .line 1093
    move-result-object v0

    .line 1094
    iget-object v1, p0, Lg20;->g:Landroid/content/Context;

    .line 1095
    .line 1096
    if-eqz v1, :cond_4f2

    .line 1097
    .line 1098
    invoke-virtual {v1, v5, v11}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 1099
    .line 1100
    .line 1101
    move-result-object v1

    .line 1102
    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 1103
    .line 1104
    .line 1105
    move-result-object v1

    .line 1106
    if-eqz v0, :cond_4d0

    .line 1107
    .line 1108
    invoke-static {v7, v3}, Lzi0;->n(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1109
    .line 1110
    .line 1111
    move-result-object v2

    .line 1112
    instance-of v4, v0, Ljava/lang/Double;

    .line 1113
    .line 1114
    invoke-interface {v1, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 1115
    .line 1116
    .line 1117
    instance-of v2, v0, Ljava/lang/Boolean;

    .line 1118
    .line 1119
    if-eqz v2, :cond_46b

    .line 1120
    .line 1121
    check-cast v0, Ljava/lang/Boolean;

    .line 1122
    .line 1123
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1124
    .line 1125
    .line 1126
    move-result v0

    .line 1127
    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 1128
    .line 1129
    .line 1130
    goto/16 :goto_4e2

    .line 1131
    .line 1132
    :cond_46b
    instance-of v2, v0, Ljava/lang/Float;

    .line 1133
    .line 1134
    if-eqz v2, :cond_479

    .line 1135
    .line 1136
    check-cast v0, Ljava/lang/Number;

    .line 1137
    .line 1138
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1139
    .line 1140
    .line 1141
    move-result v0

    .line 1142
    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 1143
    .line 1144
    .line 1145
    goto :goto_4e2

    .line 1146
    :cond_479
    instance-of v2, v0, Ljava/lang/String;

    .line 1147
    .line 1148
    if-eqz v2, :cond_483

    .line 1149
    .line 1150
    check-cast v0, Ljava/lang/String;

    .line 1151
    .line 1152
    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 1153
    .line 1154
    .line 1155
    goto :goto_4e2

    .line 1156
    :cond_483
    if-eqz v4, :cond_493

    .line 1157
    .line 1158
    check-cast v0, Ljava/lang/Number;

    .line 1159
    .line 1160
    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    .line 1161
    .line 1162
    .line 1163
    move-result-wide v4

    .line 1164
    invoke-static {v4, v5}, Ljava/lang/Double;->doubleToRawLongBits(D)J

    .line 1165
    .line 1166
    .line 1167
    move-result-wide v4

    .line 1168
    invoke-interface {v1, v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 1169
    .line 1170
    .line 1171
    goto :goto_4e2

    .line 1172
    :cond_493
    instance-of v2, v0, Ljava/lang/Integer;

    .line 1173
    .line 1174
    if-eqz v2, :cond_4a1

    .line 1175
    .line 1176
    check-cast v0, Ljava/lang/Number;

    .line 1177
    .line 1178
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 1179
    .line 1180
    .line 1181
    move-result v0

    .line 1182
    invoke-interface {v1, v3, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    .line 1183
    .line 1184
    .line 1185
    goto :goto_4e2

    .line 1186
    :cond_4a1
    instance-of v2, v0, Ljava/lang/Long;

    .line 1187
    .line 1188
    if-eqz v2, :cond_4af

    .line 1189
    .line 1190
    check-cast v0, Ljava/lang/Number;

    .line 1191
    .line 1192
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 1193
    .line 1194
    .line 1195
    move-result-wide v4

    .line 1196
    invoke-interface {v1, v3, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    .line 1197
    .line 1198
    .line 1199
    goto :goto_4e2

    .line 1200
    :cond_4af
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1201
    .line 1202
    .line 1203
    move-result-object v0

    .line 1204
    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 1205
    .line 1206
    .line 1207
    move-result-object v0

    .line 1208
    const-string v2, "Invalid Type "

    .line 1209
    .line 1210
    const-string v3, ". Supported types are Boolean, Float, String, Double, Long"

    .line 1211
    .line 1212
    invoke-static {v2, v0, v3}, Lzi0;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1213
    .line 1214
    .line 1215
    move-result-object v0

    .line 1216
    new-instance v2, Ljava/lang/IllegalArgumentException;

    .line 1217
    .line 1218
    invoke-direct {v2}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 1219
    .line 1220
    .line 1221
    move-object/from16 v3, p2

    .line 1222
    .line 1223
    check-cast v3, Lqe0;

    .line 1224
    .line 1225
    const-string v4, "-10"

    .line 1226
    .line 1227
    invoke-virtual {v3, v4, v0, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1228
    .line 1229
    .line 1230
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1231
    .line 1232
    goto :goto_4e2

    .line 1233
    :cond_4d0
    invoke-interface {v1, v3}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 1234
    .line 1235
    .line 1236
    new-instance v0, Ljava/lang/StringBuilder;

    .line 1237
    .line 1238
    invoke-direct {v0, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1239
    .line 1240
    .line 1241
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1242
    .line 1243
    .line 1244
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1245
    .line 1246
    .line 1247
    move-result-object v0

    .line 1248
    invoke-interface {v1, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 1249
    .line 1250
    .line 1251
    :goto_4e2
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 1252
    .line 1253
    .line 1254
    move-result v0

    .line 1255
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1256
    .line 1257
    .line 1258
    move-result-object v0

    .line 1259
    move-object/from16 v1, p2

    .line 1260
    .line 1261
    check-cast v1, Lqe0;

    .line 1262
    .line 1263
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1264
    .line 1265
    .line 1266
    return-void

    .line 1267
    :cond_4f2
    invoke-static {v12}, Ln40;->W(Ljava/lang/String;)V

    .line 1268
    .line 1269
    .line 1270
    throw v4

    .line 1271
    :cond_4f6
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 1272
    .line 1273
    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    .line 1274
    .line 1275
    .line 1276
    move-object/from16 v1, p2

    .line 1277
    .line 1278
    check-cast v1, Lqe0;

    .line 1279
    .line 1280
    const-string v2, "-1"

    .line 1281
    .line 1282
    const-string v3, "InvalidArguments saveWidgetData must be called with id and data"

    .line 1283
    .line 1284
    invoke-virtual {v1, v2, v3, v0}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1285
    .line 1286
    .line 1287
    return-void

    .line 1288
    :sswitch_507
    const-string v0, "initiallyLaunchedFromHomeWidget"

    .line 1289
    .line 1290
    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1291
    .line 1292
    .line 1293
    move-result v0

    .line 1294
    if-nez v0, :cond_510

    .line 1295
    .line 1296
    goto :goto_550

    .line 1297
    :cond_510
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 1298
    .line 1299
    if-eqz v0, :cond_548

    .line 1300
    .line 1301
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 1302
    .line 1303
    .line 1304
    move-result-object v0

    .line 1305
    if-eqz v0, :cond_548

    .line 1306
    .line 1307
    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    .line 1308
    .line 1309
    .line 1310
    move-result-object v0

    .line 1311
    if-eqz v0, :cond_548

    .line 1312
    .line 1313
    const-string v2, "es.antonborri.home_widget.action.LAUNCH"

    .line 1314
    .line 1315
    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1316
    .line 1317
    .line 1318
    move-result v0

    .line 1319
    if-ne v0, v10, :cond_548

    .line 1320
    .line 1321
    iget-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 1322
    .line 1323
    if-eqz v0, :cond_53e

    .line 1324
    .line 1325
    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 1326
    .line 1327
    .line 1328
    move-result-object v0

    .line 1329
    if-eqz v0, :cond_53e

    .line 1330
    .line 1331
    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    .line 1332
    .line 1333
    .line 1334
    move-result-object v0

    .line 1335
    if-eqz v0, :cond_53e

    .line 1336
    .line 1337
    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    .line 1338
    .line 1339
    .line 1340
    move-result-object v0

    .line 1341
    if-nez v0, :cond_540

    .line 1342
    .line 1343
    :cond_53e
    const-string v0, ""

    .line 1344
    .line 1345
    :cond_540
    move-object/from16 v1, p2

    .line 1346
    .line 1347
    check-cast v1, Lqe0;

    .line 1348
    .line 1349
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1350
    .line 1351
    .line 1352
    return-void

    .line 1353
    :cond_548
    move-object/from16 v0, p2

    .line 1354
    .line 1355
    check-cast v0, Lqe0;

    .line 1356
    .line 1357
    invoke-virtual {v0, v4}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1358
    .line 1359
    .line 1360
    return-void

    .line 1361
    :cond_550
    :goto_550
    move-object/from16 v0, p2

    .line 1362
    .line 1363
    check-cast v0, Lqe0;

    .line 1364
    .line 1365
    invoke-virtual {v0}, Lqe0;->notImplemented()V

    .line 1366
    .line 1367
    .line 1368
    return-void

    .line 1369
    :sswitch_data_558
    .sparse-switch
        -0x7b66df50 -> :sswitch_507
        -0x7b215e95 -> :sswitch_423
        -0x7a496b71 -> :sswitch_36c
        -0x31d8fb93 -> :sswitch_303
        -0x24164bfc -> :sswitch_289
        -0x1d32c6b5 -> :sswitch_254
        -0x57d7ea -> :sswitch_1f8
        0x448add53 -> :sswitch_1cb
        0x46027396 -> :sswitch_16f
        0x4e08340e -> :sswitch_12e
        0x54204f5a -> :sswitch_104
        0x57ce129b -> :sswitch_da
        0x6abfd290 -> :sswitch_78
        0x7163089b -> :sswitch_64
        0x7e7f526a -> :sswitch_22
    .end sparse-switch
.end method

.method public final onReattachedToActivityForConfigChanges(Ld3;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    check-cast p1, Lk6;

    .line 5
    .line 6
    iget-object v0, p1, Lk6;->a:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Landroid/app/Activity;

    .line 9
    .line 10
    iput-object v0, p0, Lg20;->h:Landroid/app/Activity;

    .line 11
    .line 12
    iget-object p1, p1, Lk6;->d:Ljava/io/Serializable;

    .line 13
    .line 14
    check-cast p1, Ljava/util/HashSet;

    .line 15
    .line 16
    invoke-virtual {p1, p0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    return-void
.end method
