###### Class defpackage.ie1 (ie1)
.class public final Lie1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Lgq0;

.field public final b:Lvm;


# direct methods
.method public constructor <init>(Lgq0;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lie1;->a:Lgq0;

    .line 5
    .line 6
    new-instance p1, Lvm;

    .line 7
    .line 8
    const/4 v0, 0x3

    .line 9
    invoke-direct {p1, v0}, Lvm;-><init>(I)V

    .line 10
    .line 11
    .line 12
    iput-object p1, p0, Lie1;->b:Lvm;

    .line 13
    .line 14
    return-void
.end method
