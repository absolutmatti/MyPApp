###### Class defpackage.kf0 (kf0)
.class public final Lkf0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:[J

.field public b:[I

.field public c:[Ljava/lang/Object;

.field public d:I

.field public e:I

.field public f:I


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lvr0;->a:[J

    .line 5
    .line 6
    iput-object v0, p0, Lkf0;->a:[J

    .line 7
    .line 8
    sget-object v0, Lx30;->a:[I

    .line 9
    .line 10
    iput-object v0, p0, Lkf0;->b:[I

    .line 11
    .line 12
    sget-object v0, Lsa;->c:[Ljava/lang/Object;

    .line 13
    .line 14
    iput-object v0, p0, Lkf0;->c:[Ljava/lang/Object;

    .line 15
    .line 16
    const/4 v0, 0x6

    .line 17
    invoke-static {v0}, Lvr0;->f(I)I

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p0, v0}, Lkf0;->c(I)V

    .line 22
    .line 23
    .line 24
    return-void
.end method


# virtual methods
.method public final a(I)I
    .registers 11

    .line 1
    iget v0, p0, Lkf0;->d:I

    .line 2
    .line 3
    and-int/2addr p1, v0

    .line 4
    const/4 v1, 0x0

    .line 5
    :goto_4
    iget-object v2, p0, Lkf0;->a:[J

    .line 6
    .line 7
    shr-int/lit8 v3, p1, 0x3

    .line 8
    .line 9
    and-int/lit8 v4, p1, 0x7

    .line 10
    .line 11
    shl-int/lit8 v4, v4, 0x3

    .line 12
    .line 13
    aget-wide v5, v2, v3

    .line 14
    .line 15
    ushr-long/2addr v5, v4

    .line 16
    add-int/lit8 v3, v3, 0x1

    .line 17
    .line 18
    aget-wide v2, v2, v3

    .line 19
    .line 20
    rsub-int/lit8 v7, v4, 0x40

    .line 21
    .line 22
    shl-long/2addr v2, v7

    .line 23
    int-to-long v7, v4

    .line 24
    neg-long v7, v7

    .line 25
    const/16 v4, 0x3f

    .line 26
    .line 27
    shr-long/2addr v7, v4

    .line 28
    and-long/2addr v2, v7

    .line 29
    or-long/2addr v2, v5

    .line 30
    not-long v4, v2

    .line 31
    const/4 v6, 0x7

    .line 32
    shl-long/2addr v4, v6

    .line 33
    and-long/2addr v2, v4

    .line 34
    const-wide v4, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    and-long/2addr v2, v4

    .line 40
    const-wide/16 v4, 0x0

    .line 41
    .line 42
    cmp-long v4, v2, v4

    .line 43
    .line 44
    if-eqz v4, :cond_37

    .line 45
    .line 46
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    shr-int/lit8 p0, p0, 0x3

    .line 51
    .line 52
    add-int/2addr p1, p0

    .line 53
    and-int p0, p1, v0

    .line 54
    .line 55
    return p0

    .line 56
    :cond_37
    add-int/lit8 v1, v1, 0x8

    .line 57
    .line 58
    add-int/2addr p1, v1

    .line 59
    and-int/2addr p1, v0

    .line 60
    goto :goto_4
.end method

.method public final b(I)Ljava/lang/Object;
    .registers 15

    .line 1
    invoke-static {p1}, Ljava/lang/Integer;->hashCode(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const v1, -0x3361d2af    # -8.293031E7f

    .line 6
    .line 7
    .line 8
    mul-int/2addr v0, v1

    .line 9
    shl-int/lit8 v1, v0, 0x10

    .line 10
    .line 11
    xor-int/2addr v0, v1

    .line 12
    and-int/lit8 v1, v0, 0x7f

    .line 13
    .line 14
    iget v2, p0, Lkf0;->d:I

    .line 15
    .line 16
    ushr-int/lit8 v0, v0, 0x7

    .line 17
    .line 18
    and-int/2addr v0, v2

    .line 19
    const/4 v3, 0x0

    .line 20
    :goto_13
    iget-object v4, p0, Lkf0;->a:[J

    .line 21
    .line 22
    shr-int/lit8 v5, v0, 0x3

    .line 23
    .line 24
    and-int/lit8 v6, v0, 0x7

    .line 25
    .line 26
    shl-int/lit8 v6, v6, 0x3

    .line 27
    .line 28
    aget-wide v7, v4, v5

    .line 29
    .line 30
    ushr-long/2addr v7, v6

    .line 31
    add-int/lit8 v5, v5, 0x1

    .line 32
    .line 33
    aget-wide v4, v4, v5

    .line 34
    .line 35
    rsub-int/lit8 v9, v6, 0x40

    .line 36
    .line 37
    shl-long/2addr v4, v9

    .line 38
    int-to-long v9, v6

    .line 39
    neg-long v9, v9

    .line 40
    const/16 v6, 0x3f

    .line 41
    .line 42
    shr-long/2addr v9, v6

    .line 43
    and-long/2addr v4, v9

    .line 44
    or-long/2addr v4, v7

    .line 45
    int-to-long v6, v1

    .line 46
    const-wide v8, 0x101010101010101L

    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    mul-long/2addr v6, v8

    .line 52
    xor-long/2addr v6, v4

    .line 53
    sub-long v8, v6, v8

    .line 54
    .line 55
    not-long v6, v6

    .line 56
    and-long/2addr v6, v8

    .line 57
    const-wide v8, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    and-long/2addr v6, v8

    .line 63
    :goto_3e
    const-wide/16 v10, 0x0

    .line 64
    .line 65
    cmp-long v12, v6, v10

    .line 66
    .line 67
    if-eqz v12, :cond_59

    .line 68
    .line 69
    invoke-static {v6, v7}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 70
    .line 71
    .line 72
    move-result v10

    .line 73
    shr-int/lit8 v10, v10, 0x3

    .line 74
    .line 75
    add-int/2addr v10, v0

    .line 76
    and-int/2addr v10, v2

    .line 77
    iget-object v11, p0, Lkf0;->b:[I

    .line 78
    .line 79
    aget v11, v11, v10

    .line 80
    .line 81
    if-ne v11, p1, :cond_53

    .line 82
    .line 83
    goto :goto_63

    .line 84
    :cond_53
    const-wide/16 v10, 0x1

    .line 85
    .line 86
    sub-long v10, v6, v10

    .line 87
    .line 88
    and-long/2addr v6, v10

    .line 89
    goto :goto_3e

    .line 90
    :cond_59
    not-long v6, v4

    .line 91
    const/4 v12, 0x6

    .line 92
    shl-long/2addr v6, v12

    .line 93
    and-long/2addr v4, v6

    .line 94
    and-long/2addr v4, v8

    .line 95
    cmp-long v4, v4, v10

    .line 96
    .line 97
    if-eqz v4, :cond_6c

    .line 98
    .line 99
    const/4 v10, -0x1

    .line 100
    :goto_63
    if-ltz v10, :cond_6a

    .line 101
    .line 102
    iget-object p0, p0, Lkf0;->c:[Ljava/lang/Object;

    .line 103
    .line 104
    aget-object p0, p0, v10

    .line 105
    .line 106
    return-object p0

    .line 107
    :cond_6a
    const/4 p0, 0x0

    .line 108
    return-object p0

    .line 109
    :cond_6c
    add-int/lit8 v3, v3, 0x8

    .line 110
    .line 111
    add-int/2addr v0, v3

    .line 112
    and-int/2addr v0, v2

    .line 113
    goto :goto_13
.end method

.method public final c(I)V
    .registers 11

    .line 1
    if-lez p1, :cond_c

    .line 2
    .line 3
    invoke-static {p1}, Lvr0;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    const/4 v0, 0x7

    .line 8
    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 p1, 0x0

    .line 14
    :goto_d
    iput p1, p0, Lkf0;->d:I

    .line 15
    .line 16
    if-nez p1, :cond_14

    .line 17
    .line 18
    sget-object v0, Lvr0;->a:[J

    .line 19
    .line 20
    goto :goto_1f

    .line 21
    :cond_14
    add-int/lit8 v0, p1, 0xf

    .line 22
    .line 23
    and-int/lit8 v0, v0, -0x8

    .line 24
    .line 25
    shr-int/lit8 v0, v0, 0x3

    .line 26
    .line 27
    new-array v0, v0, [J

    .line 28
    .line 29
    invoke-static {v0}, Lj9;->Y([J)V

    .line 30
    .line 31
    .line 32
    :goto_1f
    iput-object v0, p0, Lkf0;->a:[J

    .line 33
    .line 34
    shr-int/lit8 v1, p1, 0x3

    .line 35
    .line 36
    and-int/lit8 v2, p1, 0x7

    .line 37
    .line 38
    shl-int/lit8 v2, v2, 0x3

    .line 39
    .line 40
    aget-wide v3, v0, v1

    .line 41
    .line 42
    const-wide/16 v5, 0xff

    .line 43
    .line 44
    shl-long/2addr v5, v2

    .line 45
    not-long v7, v5

    .line 46
    and-long v2, v3, v7

    .line 47
    .line 48
    or-long/2addr v2, v5

    .line 49
    aput-wide v2, v0, v1

    .line 50
    .line 51
    iget v0, p0, Lkf0;->d:I

    .line 52
    .line 53
    invoke-static {v0}, Lvr0;->c(I)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    iget v1, p0, Lkf0;->e:I

    .line 58
    .line 59
    sub-int/2addr v0, v1

    .line 60
    iput v0, p0, Lkf0;->f:I

    .line 61
    .line 62
    new-array v0, p1, [I

    .line 63
    .line 64
    iput-object v0, p0, Lkf0;->b:[I

    .line 65
    .line 66
    new-array p1, p1, [Ljava/lang/Object;

    .line 67
    .line 68
    iput-object p1, p0, Lkf0;->c:[Ljava/lang/Object;

    .line 69
    .line 70
    return-void
.end method

.method public final d(ILjava/lang/Object;)V
    .registers 43

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    invoke-static {v1}, Ljava/lang/Integer;->hashCode(I)I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    const v3, -0x3361d2af    # -8.293031E7f

    .line 10
    .line 11
    .line 12
    mul-int/2addr v2, v3

    .line 13
    shl-int/lit8 v4, v2, 0x10

    .line 14
    .line 15
    xor-int/2addr v2, v4

    .line 16
    ushr-int/lit8 v4, v2, 0x7

    .line 17
    .line 18
    and-int/lit8 v2, v2, 0x7f

    .line 19
    .line 20
    iget v5, v0, Lkf0;->d:I

    .line 21
    .line 22
    and-int v6, v4, v5

    .line 23
    .line 24
    const/4 v8, 0x0

    .line 25
    :goto_18
    iget-object v9, v0, Lkf0;->a:[J

    .line 26
    .line 27
    shr-int/lit8 v10, v6, 0x3

    .line 28
    .line 29
    and-int/lit8 v11, v6, 0x7

    .line 30
    .line 31
    shl-int/lit8 v11, v11, 0x3

    .line 32
    .line 33
    aget-wide v12, v9, v10

    .line 34
    .line 35
    ushr-long/2addr v12, v11

    .line 36
    const/4 v14, 0x1

    .line 37
    add-int/2addr v10, v14

    .line 38
    aget-wide v9, v9, v10

    .line 39
    .line 40
    rsub-int/lit8 v15, v11, 0x40

    .line 41
    .line 42
    shl-long/2addr v9, v15

    .line 43
    move/from16 v16, v8

    .line 44
    .line 45
    const/4 v15, 0x0

    .line 46
    int-to-long v7, v11

    .line 47
    neg-long v7, v7

    .line 48
    const/16 v11, 0x3f

    .line 49
    .line 50
    shr-long/2addr v7, v11

    .line 51
    and-long/2addr v7, v9

    .line 52
    or-long/2addr v7, v12

    .line 53
    int-to-long v9, v2

    .line 54
    const-wide v11, 0x101010101010101L

    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    mul-long v17, v9, v11

    .line 60
    .line 61
    move-wide/from16 v19, v11

    .line 62
    .line 63
    xor-long v11, v7, v17

    .line 64
    .line 65
    sub-long v17, v11, v19

    .line 66
    .line 67
    not-long v11, v11

    .line 68
    and-long v11, v17, v11

    .line 69
    .line 70
    const-wide v17, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    and-long v11, v11, v17

    .line 76
    .line 77
    :goto_4c
    const-wide/16 v19, 0x0

    .line 78
    .line 79
    cmp-long v13, v11, v19

    .line 80
    .line 81
    if-eqz v13, :cond_6d

    .line 82
    .line 83
    invoke-static {v11, v12}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 84
    .line 85
    .line 86
    move-result v13

    .line 87
    shr-int/lit8 v13, v13, 0x3

    .line 88
    .line 89
    add-int/2addr v13, v6

    .line 90
    and-int/2addr v13, v5

    .line 91
    move/from16 v21, v3

    .line 92
    .line 93
    iget-object v3, v0, Lkf0;->b:[I

    .line 94
    .line 95
    aget v3, v3, v13

    .line 96
    .line 97
    if-ne v3, v1, :cond_64

    .line 98
    .line 99
    goto/16 :goto_28a

    .line 100
    .line 101
    :cond_64
    const-wide/16 v19, 0x1

    .line 102
    .line 103
    sub-long v19, v11, v19

    .line 104
    .line 105
    and-long v11, v11, v19

    .line 106
    .line 107
    move/from16 v3, v21

    .line 108
    .line 109
    goto :goto_4c

    .line 110
    :cond_6d
    move/from16 v21, v3

    .line 111
    .line 112
    not-long v11, v7

    .line 113
    const/4 v3, 0x6

    .line 114
    shl-long/2addr v11, v3

    .line 115
    and-long/2addr v7, v11

    .line 116
    and-long v7, v7, v17

    .line 117
    .line 118
    cmp-long v3, v7, v19

    .line 119
    .line 120
    const/16 v7, 0x8

    .line 121
    .line 122
    if-eqz v3, :cond_293

    .line 123
    .line 124
    invoke-virtual {v0, v4}, Lkf0;->a(I)I

    .line 125
    .line 126
    .line 127
    move-result v2

    .line 128
    iget v3, v0, Lkf0;->f:I

    .line 129
    .line 130
    const-wide/16 v11, 0xff

    .line 131
    .line 132
    if-nez v3, :cond_99

    .line 133
    .line 134
    iget-object v3, v0, Lkf0;->a:[J

    .line 135
    .line 136
    shr-int/lit8 v8, v2, 0x3

    .line 137
    .line 138
    aget-wide v16, v3, v8

    .line 139
    .line 140
    and-int/lit8 v3, v2, 0x7

    .line 141
    .line 142
    shl-int/lit8 v3, v3, 0x3

    .line 143
    .line 144
    shr-long v16, v16, v3

    .line 145
    .line 146
    and-long v16, v16, v11

    .line 147
    .line 148
    const-wide/16 v18, 0xfe

    .line 149
    .line 150
    cmp-long v3, v16, v18

    .line 151
    .line 152
    if-nez v3, :cond_a5

    .line 153
    .line 154
    :cond_99
    move-wide/from16 v33, v9

    .line 155
    .line 156
    move-wide/from16 v26, v11

    .line 157
    .line 158
    move/from16 v28, v14

    .line 159
    .line 160
    move/from16 v24, v15

    .line 161
    .line 162
    const-wide/16 v16, 0x80

    .line 163
    .line 164
    goto/16 :goto_252

    .line 165
    .line 166
    :cond_a5
    iget v2, v0, Lkf0;->d:I

    .line 167
    .line 168
    if-le v2, v7, :cond_1da

    .line 169
    .line 170
    iget v3, v0, Lkf0;->e:I

    .line 171
    .line 172
    const-wide/16 v16, 0x80

    .line 173
    .line 174
    int-to-long v5, v3

    .line 175
    const-wide/16 v22, 0x20

    .line 176
    .line 177
    mul-long v5, v5, v22

    .line 178
    .line 179
    int-to-long v2, v2

    .line 180
    const-wide/16 v22, 0x19

    .line 181
    .line 182
    mul-long v2, v2, v22

    .line 183
    .line 184
    invoke-static {v5, v6, v2, v3}, Ljava/lang/Long;->compareUnsigned(JJ)I

    .line 185
    .line 186
    .line 187
    move-result v2

    .line 188
    if-gtz v2, :cond_1d1

    .line 189
    .line 190
    iget-object v2, v0, Lkf0;->a:[J

    .line 191
    .line 192
    iget v3, v0, Lkf0;->d:I

    .line 193
    .line 194
    iget-object v5, v0, Lkf0;->b:[I

    .line 195
    .line 196
    iget-object v6, v0, Lkf0;->c:[Ljava/lang/Object;

    .line 197
    .line 198
    invoke-static {v2, v3}, Lvr0;->a([JI)V

    .line 199
    .line 200
    .line 201
    move/from16 v20, v7

    .line 202
    .line 203
    move v13, v15

    .line 204
    const/4 v7, -0x1

    .line 205
    :goto_cc
    if-eq v13, v3, :cond_1bc

    .line 206
    .line 207
    shr-int/lit8 v22, v13, 0x3

    .line 208
    .line 209
    aget-wide v23, v2, v22

    .line 210
    .line 211
    and-int/lit8 v25, v13, 0x7

    .line 212
    .line 213
    shl-int/lit8 v25, v25, 0x3

    .line 214
    .line 215
    shr-long v23, v23, v25

    .line 216
    .line 217
    and-long v23, v23, v11

    .line 218
    .line 219
    cmp-long v26, v23, v16

    .line 220
    .line 221
    if-nez v26, :cond_e6

    .line 222
    .line 223
    add-int/lit8 v7, v13, 0x1

    .line 224
    .line 225
    move/from16 v39, v13

    .line 226
    .line 227
    move v13, v7

    .line 228
    move/from16 v7, v39

    .line 229
    .line 230
    goto :goto_cc

    .line 231
    :cond_e6
    cmp-long v23, v23, v18

    .line 232
    .line 233
    if-eqz v23, :cond_ed

    .line 234
    .line 235
    add-int/lit8 v13, v13, 0x1

    .line 236
    .line 237
    goto :goto_cc

    .line 238
    :cond_ed
    aget v23, v5, v13

    .line 239
    .line 240
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->hashCode(I)I

    .line 241
    .line 242
    .line 243
    move-result v23

    .line 244
    mul-int v23, v23, v21

    .line 245
    .line 246
    shl-int/lit8 v24, v23, 0x10

    .line 247
    .line 248
    xor-int v23, v23, v24

    .line 249
    .line 250
    move-wide/from16 v26, v11

    .line 251
    .line 252
    ushr-int/lit8 v11, v23, 0x7

    .line 253
    .line 254
    invoke-virtual {v0, v11}, Lkf0;->a(I)I

    .line 255
    .line 256
    .line 257
    move-result v12

    .line 258
    and-int/2addr v11, v3

    .line 259
    sub-int v24, v12, v11

    .line 260
    .line 261
    and-int v24, v24, v3

    .line 262
    .line 263
    move/from16 v28, v14

    .line 264
    .line 265
    div-int/lit8 v14, v24, 0x8

    .line 266
    .line 267
    sub-int v11, v13, v11

    .line 268
    .line 269
    and-int/2addr v11, v3

    .line 270
    div-int/lit8 v11, v11, 0x8

    .line 271
    .line 272
    const-wide v29, 0xffffffffffffffL

    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    const-wide/high16 v31, -0x8000000000000000L

    .line 278
    .line 279
    if-ne v14, v11, :cond_13d

    .line 280
    .line 281
    and-int/lit8 v11, v23, 0x7f

    .line 282
    .line 283
    int-to-long v11, v11

    .line 284
    aget-wide v23, v2, v22

    .line 285
    .line 286
    move-wide/from16 v33, v9

    .line 287
    .line 288
    shl-long v8, v26, v25

    .line 289
    .line 290
    not-long v8, v8

    .line 291
    and-long v8, v23, v8

    .line 292
    .line 293
    shl-long v11, v11, v25

    .line 294
    .line 295
    or-long/2addr v8, v11

    .line 296
    aput-wide v8, v2, v22

    .line 297
    .line 298
    array-length v8, v2

    .line 299
    add-int/lit8 v8, v8, -0x1

    .line 300
    .line 301
    aget-wide v11, v2, v15

    .line 302
    .line 303
    and-long v11, v11, v29

    .line 304
    .line 305
    or-long v11, v11, v31

    .line 306
    .line 307
    aput-wide v11, v2, v8

    .line 308
    .line 309
    add-int/lit8 v13, v13, 0x1

    .line 310
    .line 311
    :goto_136
    move-wide/from16 v11, v26

    .line 312
    .line 313
    move/from16 v14, v28

    .line 314
    .line 315
    move-wide/from16 v9, v33

    .line 316
    .line 317
    goto :goto_cc

    .line 318
    :cond_13d
    move-wide/from16 v33, v9

    .line 319
    .line 320
    shr-int/lit8 v8, v12, 0x3

    .line 321
    .line 322
    aget-wide v35, v2, v8

    .line 323
    .line 324
    and-int/lit8 v9, v12, 0x7

    .line 325
    .line 326
    shl-int/lit8 v9, v9, 0x3

    .line 327
    .line 328
    shr-long v37, v35, v9

    .line 329
    .line 330
    and-long v37, v37, v26

    .line 331
    .line 332
    cmp-long v11, v37, v16

    .line 333
    .line 334
    if-nez v11, :cond_179

    .line 335
    .line 336
    and-int/lit8 v7, v23, 0x7f

    .line 337
    .line 338
    int-to-long v10, v7

    .line 339
    move/from16 v24, v15

    .line 340
    .line 341
    shl-long v14, v26, v9

    .line 342
    .line 343
    not-long v14, v14

    .line 344
    and-long v14, v35, v14

    .line 345
    .line 346
    shl-long v9, v10, v9

    .line 347
    .line 348
    or-long/2addr v9, v14

    .line 349
    aput-wide v9, v2, v8

    .line 350
    .line 351
    aget-wide v7, v2, v22

    .line 352
    .line 353
    shl-long v9, v26, v25

    .line 354
    .line 355
    not-long v9, v9

    .line 356
    and-long/2addr v7, v9

    .line 357
    shl-long v9, v16, v25

    .line 358
    .line 359
    or-long/2addr v7, v9

    .line 360
    aput-wide v7, v2, v22

    .line 361
    .line 362
    aget v7, v5, v13

    .line 363
    .line 364
    aput v7, v5, v12

    .line 365
    .line 366
    aput v24, v5, v13

    .line 367
    .line 368
    aget-object v7, v6, v13

    .line 369
    .line 370
    aput-object v7, v6, v12

    .line 371
    .line 372
    const/4 v7, 0x0

    .line 373
    aput-object v7, v6, v13

    .line 374
    .line 375
    move v7, v13

    .line 376
    const/4 v14, -0x1

    .line 377
    goto :goto_1ab

    .line 378
    :cond_179
    move/from16 v24, v15

    .line 379
    .line 380
    and-int/lit8 v10, v23, 0x7f

    .line 381
    .line 382
    int-to-long v10, v10

    .line 383
    shl-long v14, v26, v9

    .line 384
    .line 385
    not-long v14, v14

    .line 386
    and-long v14, v35, v14

    .line 387
    .line 388
    shl-long v9, v10, v9

    .line 389
    .line 390
    or-long/2addr v9, v14

    .line 391
    aput-wide v9, v2, v8

    .line 392
    .line 393
    const/4 v14, -0x1

    .line 394
    if-ne v7, v14, :cond_191

    .line 395
    .line 396
    add-int/lit8 v7, v13, 0x1

    .line 397
    .line 398
    invoke-static {v2, v7, v3}, Lvr0;->b([JII)I

    .line 399
    .line 400
    .line 401
    move-result v7

    .line 402
    :cond_191
    aget v8, v5, v12

    .line 403
    .line 404
    aput v8, v5, v7

    .line 405
    .line 406
    aget v8, v5, v13

    .line 407
    .line 408
    aput v8, v5, v12

    .line 409
    .line 410
    aget v8, v5, v7

    .line 411
    .line 412
    aput v8, v5, v13

    .line 413
    .line 414
    aget-object v8, v6, v12

    .line 415
    .line 416
    aput-object v8, v6, v7

    .line 417
    .line 418
    aget-object v8, v6, v13

    .line 419
    .line 420
    aput-object v8, v6, v12

    .line 421
    .line 422
    aget-object v8, v6, v7

    .line 423
    .line 424
    aput-object v8, v6, v13

    .line 425
    .line 426
    add-int/lit8 v13, v13, -0x1

    .line 427
    .line 428
    :goto_1ab
    array-length v8, v2

    .line 429
    add-int/lit8 v8, v8, -0x1

    .line 430
    .line 431
    aget-wide v9, v2, v24

    .line 432
    .line 433
    and-long v9, v9, v29

    .line 434
    .line 435
    or-long v9, v9, v31

    .line 436
    .line 437
    aput-wide v9, v2, v8

    .line 438
    .line 439
    add-int/lit8 v13, v13, 0x1

    .line 440
    .line 441
    move/from16 v15, v24

    .line 442
    .line 443
    goto/16 :goto_136

    .line 444
    .line 445
    :cond_1bc
    move-wide/from16 v33, v9

    .line 446
    .line 447
    move-wide/from16 v26, v11

    .line 448
    .line 449
    move/from16 v28, v14

    .line 450
    .line 451
    move/from16 v24, v15

    .line 452
    .line 453
    iget v2, v0, Lkf0;->d:I

    .line 454
    .line 455
    invoke-static {v2}, Lvr0;->c(I)I

    .line 456
    .line 457
    .line 458
    move-result v2

    .line 459
    iget v3, v0, Lkf0;->e:I

    .line 460
    .line 461
    sub-int/2addr v2, v3

    .line 462
    iput v2, v0, Lkf0;->f:I

    .line 463
    .line 464
    goto/16 :goto_24c

    .line 465
    .line 466
    :cond_1d1
    :goto_1d1
    move-wide/from16 v33, v9

    .line 467
    .line 468
    move-wide/from16 v26, v11

    .line 469
    .line 470
    move/from16 v28, v14

    .line 471
    .line 472
    move/from16 v24, v15

    .line 473
    .line 474
    goto :goto_1dd

    .line 475
    :cond_1da
    const-wide/16 v16, 0x80

    .line 476
    .line 477
    goto :goto_1d1

    .line 478
    :goto_1dd
    iget v2, v0, Lkf0;->d:I

    .line 479
    .line 480
    invoke-static {v2}, Lvr0;->d(I)I

    .line 481
    .line 482
    .line 483
    move-result v2

    .line 484
    iget-object v3, v0, Lkf0;->a:[J

    .line 485
    .line 486
    iget-object v5, v0, Lkf0;->b:[I

    .line 487
    .line 488
    iget-object v6, v0, Lkf0;->c:[Ljava/lang/Object;

    .line 489
    .line 490
    iget v7, v0, Lkf0;->d:I

    .line 491
    .line 492
    invoke-virtual {v0, v2}, Lkf0;->c(I)V

    .line 493
    .line 494
    .line 495
    iget-object v2, v0, Lkf0;->a:[J

    .line 496
    .line 497
    iget-object v8, v0, Lkf0;->b:[I

    .line 498
    .line 499
    iget-object v9, v0, Lkf0;->c:[Ljava/lang/Object;

    .line 500
    .line 501
    iget v10, v0, Lkf0;->d:I

    .line 502
    .line 503
    move/from16 v11, v24

    .line 504
    .line 505
    :goto_1f8
    if-ge v11, v7, :cond_24c

    .line 506
    .line 507
    shr-int/lit8 v12, v11, 0x3

    .line 508
    .line 509
    aget-wide v12, v3, v12

    .line 510
    .line 511
    and-int/lit8 v14, v11, 0x7

    .line 512
    .line 513
    shl-int/lit8 v14, v14, 0x3

    .line 514
    .line 515
    shr-long/2addr v12, v14

    .line 516
    and-long v12, v12, v26

    .line 517
    .line 518
    cmp-long v12, v12, v16

    .line 519
    .line 520
    if-gez v12, :cond_245

    .line 521
    .line 522
    aget v12, v5, v11

    .line 523
    .line 524
    invoke-static {v12}, Ljava/lang/Integer;->hashCode(I)I

    .line 525
    .line 526
    .line 527
    move-result v13

    .line 528
    mul-int v13, v13, v21

    .line 529
    .line 530
    shl-int/lit8 v14, v13, 0x10

    .line 531
    .line 532
    xor-int/2addr v13, v14

    .line 533
    ushr-int/lit8 v14, v13, 0x7

    .line 534
    .line 535
    invoke-virtual {v0, v14}, Lkf0;->a(I)I

    .line 536
    .line 537
    .line 538
    move-result v14

    .line 539
    and-int/lit8 v13, v13, 0x7f

    .line 540
    .line 541
    move-object v15, v2

    .line 542
    int-to-long v1, v13

    .line 543
    shr-int/lit8 v13, v14, 0x3

    .line 544
    .line 545
    and-int/lit8 v18, v14, 0x7

    .line 546
    .line 547
    shl-int/lit8 v18, v18, 0x3

    .line 548
    .line 549
    aget-wide v19, v15, v13

    .line 550
    .line 551
    move-wide/from16 v22, v1

    .line 552
    .line 553
    shl-long v1, v26, v18

    .line 554
    .line 555
    not-long v1, v1

    .line 556
    and-long v1, v19, v1

    .line 557
    .line 558
    shl-long v18, v22, v18

    .line 559
    .line 560
    or-long v1, v1, v18

    .line 561
    .line 562
    aput-wide v1, v15, v13

    .line 563
    .line 564
    add-int/lit8 v13, v14, -0x7

    .line 565
    .line 566
    and-int/2addr v13, v10

    .line 567
    and-int/lit8 v18, v10, 0x7

    .line 568
    .line 569
    add-int v13, v13, v18

    .line 570
    .line 571
    shr-int/lit8 v13, v13, 0x3

    .line 572
    .line 573
    aput-wide v1, v15, v13

    .line 574
    .line 575
    aput v12, v8, v14

    .line 576
    .line 577
    aget-object v1, v6, v11

    .line 578
    .line 579
    aput-object v1, v9, v14

    .line 580
    .line 581
    goto :goto_246

    .line 582
    :cond_245
    move-object v15, v2

    .line 583
    :goto_246
    add-int/lit8 v11, v11, 0x1

    .line 584
    .line 585
    move/from16 v1, p1

    .line 586
    .line 587
    move-object v2, v15

    .line 588
    goto :goto_1f8

    .line 589
    :cond_24c
    :goto_24c
    invoke-virtual {v0, v4}, Lkf0;->a(I)I

    .line 590
    .line 591
    .line 592
    move-result v1

    .line 593
    move v13, v1

    .line 594
    goto :goto_253

    .line 595
    :goto_252
    move v13, v2

    .line 596
    :goto_253
    iget v1, v0, Lkf0;->e:I

    .line 597
    .line 598
    add-int/lit8 v1, v1, 0x1

    .line 599
    .line 600
    iput v1, v0, Lkf0;->e:I

    .line 601
    .line 602
    iget v1, v0, Lkf0;->f:I

    .line 603
    .line 604
    iget-object v2, v0, Lkf0;->a:[J

    .line 605
    .line 606
    shr-int/lit8 v3, v13, 0x3

    .line 607
    .line 608
    aget-wide v4, v2, v3

    .line 609
    .line 610
    and-int/lit8 v6, v13, 0x7

    .line 611
    .line 612
    shl-int/lit8 v6, v6, 0x3

    .line 613
    .line 614
    shr-long v7, v4, v6

    .line 615
    .line 616
    and-long v7, v7, v26

    .line 617
    .line 618
    cmp-long v7, v7, v16

    .line 619
    .line 620
    if-nez v7, :cond_270

    .line 621
    .line 622
    move/from16 v7, v28

    .line 623
    .line 624
    goto :goto_272

    .line 625
    :cond_270
    move/from16 v7, v24

    .line 626
    .line 627
    :goto_272
    sub-int/2addr v1, v7

    .line 628
    iput v1, v0, Lkf0;->f:I

    .line 629
    .line 630
    iget v1, v0, Lkf0;->d:I

    .line 631
    .line 632
    shl-long v7, v26, v6

    .line 633
    .line 634
    not-long v7, v7

    .line 635
    and-long/2addr v4, v7

    .line 636
    shl-long v6, v33, v6

    .line 637
    .line 638
    or-long/2addr v4, v6

    .line 639
    aput-wide v4, v2, v3

    .line 640
    .line 641
    add-int/lit8 v3, v13, -0x7

    .line 642
    .line 643
    and-int/2addr v3, v1

    .line 644
    and-int/lit8 v1, v1, 0x7

    .line 645
    .line 646
    add-int/2addr v3, v1

    .line 647
    shr-int/lit8 v1, v3, 0x3

    .line 648
    .line 649
    aput-wide v4, v2, v1

    .line 650
    .line 651
    :goto_28a
    iget-object v1, v0, Lkf0;->b:[I

    .line 652
    .line 653
    aput p1, v1, v13

    .line 654
    .line 655
    iget-object v0, v0, Lkf0;->c:[Ljava/lang/Object;

    .line 656
    .line 657
    aput-object p2, v0, v13

    .line 658
    .line 659
    return-void

    .line 660
    :cond_293
    move/from16 v20, v7

    .line 661
    .line 662
    move/from16 v24, v15

    .line 663
    .line 664
    add-int/lit8 v8, v16, 0x8

    .line 665
    .line 666
    add-int/2addr v6, v8

    .line 667
    and-int/2addr v6, v5

    .line 668
    move/from16 v1, p1

    .line 669
    .line 670
    move/from16 v3, v21

    .line 671
    .line 672
    goto/16 :goto_18
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 29

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-ne v1, v0, :cond_8

    .line 7
    .line 8
    return v2

    .line 9
    :cond_8
    instance-of v3, v1, Lkf0;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    if-nez v3, :cond_e

    .line 13
    .line 14
    return v4

    .line 15
    :cond_e
    check-cast v1, Lkf0;

    .line 16
    .line 17
    iget v3, v1, Lkf0;->e:I

    .line 18
    .line 19
    iget v5, v0, Lkf0;->e:I

    .line 20
    .line 21
    if-eq v3, v5, :cond_17

    .line 22
    .line 23
    return v4

    .line 24
    :cond_17
    iget-object v3, v0, Lkf0;->b:[I

    .line 25
    .line 26
    iget-object v5, v0, Lkf0;->c:[Ljava/lang/Object;

    .line 27
    .line 28
    iget-object v0, v0, Lkf0;->a:[J

    .line 29
    .line 30
    array-length v6, v0

    .line 31
    add-int/lit8 v6, v6, -0x2

    .line 32
    .line 33
    if-ltz v6, :cond_146

    .line 34
    .line 35
    move v7, v4

    .line 36
    :goto_23
    aget-wide v8, v0, v7

    .line 37
    .line 38
    not-long v10, v8

    .line 39
    const/4 v12, 0x7

    .line 40
    shl-long/2addr v10, v12

    .line 41
    and-long/2addr v10, v8

    .line 42
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    and-long/2addr v10, v13

    .line 48
    cmp-long v10, v10, v13

    .line 49
    .line 50
    if-eqz v10, :cond_132

    .line 51
    .line 52
    sub-int v10, v7, v6

    .line 53
    .line 54
    not-int v10, v10

    .line 55
    ushr-int/lit8 v10, v10, 0x1f

    .line 56
    .line 57
    const/16 v11, 0x8

    .line 58
    .line 59
    rsub-int/lit8 v10, v10, 0x8

    .line 60
    .line 61
    move v15, v4

    .line 62
    :goto_3d
    if-ge v15, v10, :cond_127

    .line 63
    .line 64
    const-wide/16 v16, 0xff

    .line 65
    .line 66
    and-long v16, v8, v16

    .line 67
    .line 68
    const-wide/16 v18, 0x80

    .line 69
    .line 70
    cmp-long v16, v16, v18

    .line 71
    .line 72
    if-gez v16, :cond_105

    .line 73
    .line 74
    shl-int/lit8 v16, v7, 0x3

    .line 75
    .line 76
    add-int v16, v16, v15

    .line 77
    .line 78
    move/from16 v17, v2

    .line 79
    .line 80
    aget v2, v3, v16

    .line 81
    .line 82
    move/from16 v18, v4

    .line 83
    .line 84
    aget-object v4, v5, v16

    .line 85
    .line 86
    if-nez v4, :cond_ef

    .line 87
    .line 88
    invoke-virtual {v1, v2}, Lkf0;->b(I)Ljava/lang/Object;

    .line 89
    .line 90
    .line 91
    move-result-object v4

    .line 92
    if-nez v4, :cond_ee

    .line 93
    .line 94
    invoke-static {v2}, Ljava/lang/Integer;->hashCode(I)I

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    const v16, -0x3361d2af    # -8.293031E7f

    .line 99
    .line 100
    .line 101
    mul-int v4, v4, v16

    .line 102
    .line 103
    shl-int/lit8 v16, v4, 0x10

    .line 104
    .line 105
    xor-int v4, v4, v16

    .line 106
    .line 107
    move/from16 p0, v12

    .line 108
    .line 109
    and-int/lit8 v12, v4, 0x7f

    .line 110
    .line 111
    move-wide/from16 v19, v13

    .line 112
    .line 113
    iget v13, v1, Lkf0;->d:I

    .line 114
    .line 115
    ushr-int/lit8 v4, v4, 0x7

    .line 116
    .line 117
    and-int/2addr v4, v13

    .line 118
    move/from16 p1, v11

    .line 119
    .line 120
    move/from16 v14, v18

    .line 121
    .line 122
    :goto_79
    iget-object v11, v1, Lkf0;->a:[J

    .line 123
    .line 124
    shr-int/lit8 v16, v4, 0x3

    .line 125
    .line 126
    and-int/lit8 v21, v4, 0x7

    .line 127
    .line 128
    move-object/from16 v22, v0

    .line 129
    .line 130
    shl-int/lit8 v0, v21, 0x3

    .line 131
    .line 132
    aget-wide v23, v11, v16

    .line 133
    .line 134
    ushr-long v23, v23, v0

    .line 135
    .line 136
    add-int/lit8 v16, v16, 0x1

    .line 137
    .line 138
    aget-wide v25, v11, v16

    .line 139
    .line 140
    rsub-int/lit8 v11, v0, 0x40

    .line 141
    .line 142
    shl-long v25, v25, v11

    .line 143
    .line 144
    move-object v11, v3

    .line 145
    move/from16 v16, v4

    .line 146
    .line 147
    int-to-long v3, v0

    .line 148
    neg-long v3, v3

    .line 149
    const/16 v0, 0x3f

    .line 150
    .line 151
    shr-long/2addr v3, v0

    .line 152
    and-long v3, v25, v3

    .line 153
    .line 154
    or-long v3, v23, v3

    .line 155
    .line 156
    move-wide/from16 v23, v8

    .line 157
    .line 158
    int-to-long v8, v12

    .line 159
    const-wide v25, 0x101010101010101L

    .line 160
    .line 161
    .line 162
    .line 163
    .line 164
    mul-long v8, v8, v25

    .line 165
    .line 166
    xor-long/2addr v8, v3

    .line 167
    sub-long v25, v8, v25

    .line 168
    .line 169
    not-long v8, v8

    .line 170
    and-long v8, v25, v8

    .line 171
    .line 172
    and-long v8, v8, v19

    .line 173
    .line 174
    :goto_ad
    const-wide/16 v25, 0x0

    .line 175
    .line 176
    cmp-long v0, v8, v25

    .line 177
    .line 178
    if-eqz v0, :cond_ce

    .line 179
    .line 180
    invoke-static {v8, v9}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 181
    .line 182
    .line 183
    move-result v0

    .line 184
    shr-int/lit8 v0, v0, 0x3

    .line 185
    .line 186
    add-int v0, v16, v0

    .line 187
    .line 188
    and-int/2addr v0, v13

    .line 189
    move/from16 v21, v0

    .line 190
    .line 191
    iget-object v0, v1, Lkf0;->b:[I

    .line 192
    .line 193
    aget v0, v0, v21

    .line 194
    .line 195
    if-ne v0, v2, :cond_c7

    .line 196
    .line 197
    move/from16 v0, v21

    .line 198
    .line 199
    goto :goto_d9

    .line 200
    :cond_c7
    const-wide/16 v25, 0x1

    .line 201
    .line 202
    sub-long v25, v8, v25

    .line 203
    .line 204
    and-long v8, v8, v25

    .line 205
    .line 206
    goto :goto_ad

    .line 207
    :cond_ce
    not-long v8, v3

    .line 208
    const/4 v0, 0x6

    .line 209
    shl-long/2addr v8, v0

    .line 210
    and-long/2addr v3, v8

    .line 211
    and-long v3, v3, v19

    .line 212
    .line 213
    cmp-long v0, v3, v25

    .line 214
    .line 215
    if-eqz v0, :cond_e3

    .line 216
    .line 217
    const/4 v0, -0x1

    .line 218
    :goto_d9
    if-ltz v0, :cond_de

    .line 219
    .line 220
    move/from16 v0, v17

    .line 221
    .line 222
    goto :goto_e0

    .line 223
    :cond_de
    move/from16 v0, v18

    .line 224
    .line 225
    :goto_e0
    if-nez v0, :cond_114

    .line 226
    .line 227
    goto :goto_ee

    .line 228
    :cond_e3
    add-int/lit8 v14, v14, 0x8

    .line 229
    .line 230
    add-int v4, v16, v14

    .line 231
    .line 232
    and-int/2addr v4, v13

    .line 233
    move-object v3, v11

    .line 234
    move-object/from16 v0, v22

    .line 235
    .line 236
    move-wide/from16 v8, v23

    .line 237
    .line 238
    goto :goto_79

    .line 239
    :cond_ee
    :goto_ee
    return v18

    .line 240
    :cond_ef
    move-object/from16 v22, v0

    .line 241
    .line 242
    move-wide/from16 v23, v8

    .line 243
    .line 244
    move/from16 p1, v11

    .line 245
    .line 246
    move/from16 p0, v12

    .line 247
    .line 248
    move-wide/from16 v19, v13

    .line 249
    .line 250
    move-object v11, v3

    .line 251
    invoke-virtual {v1, v2}, Lkf0;->b(I)Ljava/lang/Object;

    .line 252
    .line 253
    .line 254
    move-result-object v0

    .line 255
    invoke-virtual {v4, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 256
    .line 257
    .line 258
    move-result v0

    .line 259
    if-nez v0, :cond_114

    .line 260
    .line 261
    return v18

    .line 262
    :cond_105
    move-object/from16 v22, v0

    .line 263
    .line 264
    move/from16 v17, v2

    .line 265
    .line 266
    move/from16 v18, v4

    .line 267
    .line 268
    move-wide/from16 v23, v8

    .line 269
    .line 270
    move/from16 p1, v11

    .line 271
    .line 272
    move/from16 p0, v12

    .line 273
    .line 274
    move-wide/from16 v19, v13

    .line 275
    .line 276
    move-object v11, v3

    .line 277
    :cond_114
    shr-long v8, v23, p1

    .line 278
    .line 279
    add-int/lit8 v15, v15, 0x1

    .line 280
    .line 281
    move/from16 v12, p0

    .line 282
    .line 283
    move-object v3, v11

    .line 284
    move/from16 v2, v17

    .line 285
    .line 286
    move/from16 v4, v18

    .line 287
    .line 288
    move-wide/from16 v13, v19

    .line 289
    .line 290
    move-object/from16 v0, v22

    .line 291
    .line 292
    move/from16 v11, p1

    .line 293
    .line 294
    goto/16 :goto_3d

    .line 295
    .line 296
    :cond_127
    move-object/from16 v22, v0

    .line 297
    .line 298
    move/from16 v17, v2

    .line 299
    .line 300
    move/from16 v18, v4

    .line 301
    .line 302
    move v0, v11

    .line 303
    move-object v11, v3

    .line 304
    if-ne v10, v0, :cond_148

    .line 305
    .line 306
    goto :goto_139

    .line 307
    :cond_132
    move-object/from16 v22, v0

    .line 308
    .line 309
    move/from16 v17, v2

    .line 310
    .line 311
    move-object v11, v3

    .line 312
    move/from16 v18, v4

    .line 313
    .line 314
    :goto_139
    if-eq v7, v6, :cond_148

    .line 315
    .line 316
    add-int/lit8 v7, v7, 0x1

    .line 317
    .line 318
    move-object v3, v11

    .line 319
    move/from16 v2, v17

    .line 320
    .line 321
    move/from16 v4, v18

    .line 322
    .line 323
    move-object/from16 v0, v22

    .line 324
    .line 325
    goto/16 :goto_23

    .line 326
    .line 327
    :cond_146
    move/from16 v17, v2

    .line 328
    .line 329
    :cond_148
    return v17
.end method

.method public final hashCode()I
    .registers 16

    .line 1
    iget-object v0, p0, Lkf0;->b:[I

    .line 2
    .line 3
    iget-object v1, p0, Lkf0;->c:[Ljava/lang/Object;

    .line 4
    .line 5
    iget-object p0, p0, Lkf0;->a:[J

    .line 6
    .line 7
    array-length v2, p0

    .line 8
    add-int/lit8 v2, v2, -0x2

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    if-ltz v2, :cond_56

    .line 12
    .line 13
    move v4, v3

    .line 14
    move v5, v4

    .line 15
    :goto_e
    aget-wide v6, p0, v4

    .line 16
    .line 17
    not-long v8, v6

    .line 18
    const/4 v10, 0x7

    .line 19
    shl-long/2addr v8, v10

    .line 20
    and-long/2addr v8, v6

    .line 21
    const-wide v10, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    and-long/2addr v8, v10

    .line 27
    cmp-long v8, v8, v10

    .line 28
    .line 29
    if-eqz v8, :cond_50

    .line 30
    .line 31
    sub-int v8, v4, v2

    .line 32
    .line 33
    not-int v8, v8

    .line 34
    ushr-int/lit8 v8, v8, 0x1f

    .line 35
    .line 36
    const/16 v9, 0x8

    .line 37
    .line 38
    rsub-int/lit8 v8, v8, 0x8

    .line 39
    .line 40
    move v10, v3

    .line 41
    :goto_28
    if-ge v10, v8, :cond_4c

    .line 42
    .line 43
    const-wide/16 v11, 0xff

    .line 44
    .line 45
    and-long/2addr v11, v6

    .line 46
    const-wide/16 v13, 0x80

    .line 47
    .line 48
    cmp-long v11, v11, v13

    .line 49
    .line 50
    if-gez v11, :cond_48

    .line 51
    .line 52
    shl-int/lit8 v11, v4, 0x3

    .line 53
    .line 54
    add-int/2addr v11, v10

    .line 55
    aget v12, v0, v11

    .line 56
    .line 57
    aget-object v11, v1, v11

    .line 58
    .line 59
    invoke-static {v12}, Ljava/lang/Integer;->hashCode(I)I

    .line 60
    .line 61
    .line 62
    move-result v12

    .line 63
    if-eqz v11, :cond_45

    .line 64
    .line 65
    invoke-virtual {v11}, Ljava/lang/Object;->hashCode()I

    .line 66
    .line 67
    .line 68
    move-result v11

    .line 69
    goto :goto_46

    .line 70
    :cond_45
    move v11, v3

    .line 71
    :goto_46
    xor-int/2addr v11, v12

    .line 72
    add-int/2addr v5, v11

    .line 73
    :cond_48
    shr-long/2addr v6, v9

    .line 74
    add-int/lit8 v10, v10, 0x1

    .line 75
    .line 76
    goto :goto_28

    .line 77
    :cond_4c
    if-ne v8, v9, :cond_4f

    .line 78
    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    return v5

    .line 81
    :cond_50
    :goto_50
    if-eq v4, v2, :cond_55

    .line 82
    .line 83
    add-int/lit8 v4, v4, 0x1

    .line 84
    .line 85
    goto :goto_e

    .line 86
    :cond_55
    return v5

    .line 87
    :cond_56
    return v3
.end method

.method public final toString()Ljava/lang/String;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lkf0;->e:I

    .line 4
    .line 5
    if-nez v1, :cond_9

    .line 6
    .line 7
    const-string v0, "{}"

    .line 8
    .line 9
    return-object v0

    .line 10
    :cond_9
    new-instance v1, Ljava/lang/StringBuilder;

    .line 11
    .line 12
    const-string v2, "{"

    .line 13
    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    iget-object v2, v0, Lkf0;->b:[I

    .line 18
    .line 19
    iget-object v3, v0, Lkf0;->c:[Ljava/lang/Object;

    .line 20
    .line 21
    iget-object v4, v0, Lkf0;->a:[J

    .line 22
    .line 23
    array-length v5, v4

    .line 24
    add-int/lit8 v5, v5, -0x2

    .line 25
    .line 26
    if-ltz v5, :cond_6f

    .line 27
    .line 28
    const/4 v6, 0x0

    .line 29
    move v7, v6

    .line 30
    move v8, v7

    .line 31
    :goto_1e
    aget-wide v9, v4, v7

    .line 32
    .line 33
    not-long v11, v9

    .line 34
    const/4 v13, 0x7

    .line 35
    shl-long/2addr v11, v13

    .line 36
    and-long/2addr v11, v9

    .line 37
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    and-long/2addr v11, v13

    .line 43
    cmp-long v11, v11, v13

    .line 44
    .line 45
    if-eqz v11, :cond_6a

    .line 46
    .line 47
    sub-int v11, v7, v5

    .line 48
    .line 49
    not-int v11, v11

    .line 50
    ushr-int/lit8 v11, v11, 0x1f

    .line 51
    .line 52
    const/16 v12, 0x8

    .line 53
    .line 54
    rsub-int/lit8 v11, v11, 0x8

    .line 55
    .line 56
    move v13, v6

    .line 57
    :goto_38
    if-ge v13, v11, :cond_68

    .line 58
    .line 59
    const-wide/16 v14, 0xff

    .line 60
    .line 61
    and-long/2addr v14, v9

    .line 62
    const-wide/16 v16, 0x80

    .line 63
    .line 64
    cmp-long v14, v14, v16

    .line 65
    .line 66
    if-gez v14, :cond_64

    .line 67
    .line 68
    shl-int/lit8 v14, v7, 0x3

    .line 69
    .line 70
    add-int/2addr v14, v13

    .line 71
    aget v15, v2, v14

    .line 72
    .line 73
    aget-object v14, v3, v14

    .line 74
    .line 75
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    const-string v15, "="

    .line 79
    .line 80
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    if-ne v14, v0, :cond_56

    .line 84
    .line 85
    const-string v14, "(this)"

    .line 86
    .line 87
    :cond_56
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 88
    .line 89
    .line 90
    add-int/lit8 v8, v8, 0x1

    .line 91
    .line 92
    iget v14, v0, Lkf0;->e:I

    .line 93
    .line 94
    if-ge v8, v14, :cond_64

    .line 95
    .line 96
    const-string v14, ", "

    .line 97
    .line 98
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    :cond_64
    shr-long/2addr v9, v12

    .line 102
    add-int/lit8 v13, v13, 0x1

    .line 103
    .line 104
    goto :goto_38

    .line 105
    :cond_68
    if-ne v11, v12, :cond_6f

    .line 106
    .line 107
    :cond_6a
    if-eq v7, v5, :cond_6f

    .line 108
    .line 109
    add-int/lit8 v7, v7, 0x1

    .line 110
    .line 111
    goto :goto_1e

    .line 112
    :cond_6f
    const/16 v0, 0x7d

    .line 113
    .line 114
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    return-object v0
.end method
