###### Class defpackage.i60 (i60)
.class public final Li60;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Ld8;


# direct methods
.method public constructor <init>(Lla;)V
    .registers 5

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 17
    new-instance v0, Ld8;

    const-string v1, "flutter/keyevent"

    sget-object v2, Li50;->a:Li50;

    invoke-direct {v0, p1, v1, v2}, Ld8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p0, Li60;->a:Ld8;

    return-void
.end method

.method public constructor <init>(Lrj;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ld8;

    .line 5
    .line 6
    const-string v1, "flutter/system"

    .line 7
    .line 8
    sget-object v2, Li50;->a:Li50;

    .line 9
    .line 10
    invoke-direct {v0, p1, v1, v2}, Ld8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Li60;->a:Ld8;

    .line 14
    .line 15
    return-void
.end method
