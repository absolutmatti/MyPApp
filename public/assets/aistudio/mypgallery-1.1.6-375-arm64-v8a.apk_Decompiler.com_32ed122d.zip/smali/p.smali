###### Class defpackage.p (p)
.class public abstract Lp;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lwd0;


# direct methods
.method public static addAll(Ljava/lang/Iterable;Ljava/util/Collection;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "TT;>;",
            "Ljava/util/Collection<",
            "-TT;>;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 200
    check-cast p1, Ljava/util/List;

    invoke-static {p0, p1}, Lp;->addAll(Ljava/lang/Iterable;Ljava/util/List;)V

    return-void
.end method

.method public static addAll(Ljava/lang/Iterable;Ljava/util/List;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Iterable<",
            "TT;>;",
            "Ljava/util/List<",
            "-TT;>;)V"
        }
    .end annotation

    .line 1
    sget-object v0, Ll40;->a:Ljava/nio/charset/Charset;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    instance-of v0, p0, Lt70;

    .line 7
    .line 8
    const-string v1, " is null."

    .line 9
    .line 10
    const-string v2, "Element at index "

    .line 11
    .line 12
    if-eqz v0, :cond_62

    .line 13
    .line 14
    check-cast p0, Lt70;

    .line 15
    .line 16
    invoke-interface {p0}, Lt70;->b()Ljava/util/List;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    move-object v0, p1

    .line 21
    check-cast v0, Lt70;

    .line 22
    .line 23
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    :goto_1e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v3

    .line 35
    if-eqz v3, :cond_c6

    .line 36
    .line 37
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    if-nez v3, :cond_52

    .line 42
    .line 43
    new-instance p0, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    sub-int/2addr v2, p1

    .line 53
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 57
    .line 58
    .line 59
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object p0

    .line 63
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 64
    .line 65
    .line 66
    move-result v1

    .line 67
    add-int/lit8 v1, v1, -0x1

    .line 68
    .line 69
    :goto_44
    if-lt v1, p1, :cond_4c

    .line 70
    .line 71
    invoke-interface {v0, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 72
    .line 73
    .line 74
    add-int/lit8 v1, v1, -0x1

    .line 75
    .line 76
    goto :goto_44

    .line 77
    :cond_4c
    new-instance p1, Ljava/lang/NullPointerException;

    .line 78
    .line 79
    invoke-direct {p1, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 80
    .line 81
    .line 82
    throw p1

    .line 83
    :cond_52
    instance-of v4, v3, Lqb;

    .line 84
    .line 85
    if-eqz v4, :cond_5c

    .line 86
    .line 87
    check-cast v3, Lqb;

    .line 88
    .line 89
    invoke-interface {v0, v3}, Lt70;->e(Lqb;)V

    .line 90
    .line 91
    .line 92
    goto :goto_1e

    .line 93
    :cond_5c
    check-cast v3, Ljava/lang/String;

    .line 94
    .line 95
    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 96
    .line 97
    .line 98
    goto :goto_1e

    .line 99
    :cond_62
    instance-of v0, p0, Lhm0;

    .line 100
    .line 101
    if-eqz v0, :cond_6c

    .line 102
    .line 103
    check-cast p0, Ljava/util/Collection;

    .line 104
    .line 105
    invoke-interface {p1, p0}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    .line 106
    .line 107
    .line 108
    return-void

    .line 109
    :cond_6c
    instance-of v0, p1, Ljava/util/ArrayList;

    .line 110
    .line 111
    if-eqz v0, :cond_86

    .line 112
    .line 113
    instance-of v0, p0, Ljava/util/Collection;

    .line 114
    .line 115
    if-eqz v0, :cond_86

    .line 116
    .line 117
    move-object v0, p1

    .line 118
    check-cast v0, Ljava/util/ArrayList;

    .line 119
    .line 120
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 121
    .line 122
    .line 123
    move-result v3

    .line 124
    move-object v4, p0

    .line 125
    check-cast v4, Ljava/util/Collection;

    .line 126
    .line 127
    invoke-interface {v4}, Ljava/util/Collection;->size()I

    .line 128
    .line 129
    .line 130
    move-result v4

    .line 131
    add-int/2addr v4, v3

    .line 132
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->ensureCapacity(I)V

    .line 133
    .line 134
    .line 135
    :cond_86
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 136
    .line 137
    .line 138
    move-result v0

    .line 139
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    :goto_8e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 144
    .line 145
    .line 146
    move-result v3

    .line 147
    if-eqz v3, :cond_c6

    .line 148
    .line 149
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    if-nez v3, :cond_c2

    .line 154
    .line 155
    new-instance p0, Ljava/lang/StringBuilder;

    .line 156
    .line 157
    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 158
    .line 159
    .line 160
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 161
    .line 162
    .line 163
    move-result v2

    .line 164
    sub-int/2addr v2, v0

    .line 165
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 172
    .line 173
    .line 174
    move-result-object p0

    .line 175
    invoke-interface {p1}, Ljava/util/List;->size()I

    .line 176
    .line 177
    .line 178
    move-result v1

    .line 179
    add-int/lit8 v1, v1, -0x1

    .line 180
    .line 181
    :goto_b4
    if-lt v1, v0, :cond_bc

    .line 182
    .line 183
    invoke-interface {p1, v1}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 184
    .line 185
    .line 186
    add-int/lit8 v1, v1, -0x1

    .line 187
    .line 188
    goto :goto_b4

    .line 189
    :cond_bc
    new-instance p1, Ljava/lang/NullPointerException;

    .line 190
    .line 191
    invoke-direct {p1, p0}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    .line 192
    .line 193
    .line 194
    throw p1

    .line 195
    :cond_c2
    invoke-interface {p1, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 196
    .line 197
    .line 198
    goto :goto_8e

    .line 199
    :cond_c6
    return-void
.end method

.method public static newUninitializedMessageException(Lxd0;)Lj61;
    .registers 1

    .line 1
    new-instance p0, Lj61;

    .line 2
    .line 3
    invoke-direct {p0}, Lj61;-><init>()V

    .line 4
    .line 5
    .line 6
    return-object p0
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "Reading "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 17
    .line 18
    .line 19
    const-string p0, " from a ByteString threw an IOException (should never happen)."

    .line 20
    .line 21
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    return-object p0
.end method

.method public abstract internalMergeFrom(Lr;)Lp;
.end method

.method public mergeDelimitedFrom(Ljava/io/InputStream;)Z
    .registers 3

    .line 24
    invoke-static {}, Lcs;->a()Lcs;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lp;->mergeDelimitedFrom(Ljava/io/InputStream;Lcs;)Z

    move-result p0

    return p0
.end method

.method public mergeDelimitedFrom(Ljava/io/InputStream;Lcs;)Z
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, -0x1

    .line 6
    if-ne v0, v1, :cond_9

    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    return p0

    .line 10
    :cond_9
    invoke-static {v0, p1}, Lwd;->s(ILjava/io/InputStream;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    new-instance v1, Lo;

    .line 15
    .line 16
    invoke-direct {v1, v0, p1}, Lo;-><init>(ILjava/io/InputStream;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0, v1, p2}, Lp;->mergeFrom(Ljava/io/InputStream;Lcs;)Lp;

    .line 20
    .line 21
    .line 22
    const/4 p0, 0x1

    .line 23
    return p0
.end method

.method public mergeFrom(Ljava/io/InputStream;)Lp;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            ")",
            "Lp;"
        }
    .end annotation

    .line 50
    invoke-static {p1}, Lwd;->g(Ljava/io/InputStream;)Lwd;

    move-result-object p1

    .line 51
    invoke-virtual {p0, p1}, Lp;->mergeFrom(Lwd;)Lp;

    const/4 v0, 0x0

    .line 52
    invoke-virtual {p1, v0}, Lwd;->a(I)V

    return-object p0
.end method

.method public mergeFrom(Ljava/io/InputStream;Lcs;)Lp;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            "Lcs;",
            ")",
            "Lp;"
        }
    .end annotation

    .line 53
    invoke-static {p1}, Lwd;->g(Ljava/io/InputStream;)Lwd;

    move-result-object p1

    .line 54
    invoke-virtual {p0, p1, p2}, Lp;->mergeFrom(Lwd;Lcs;)Lp;

    const/4 p2, 0x0

    .line 55
    invoke-virtual {p1, p2}, Lwd;->a(I)V

    return-object p0
.end method

.method public mergeFrom(Lqb;)Lp;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lqb;",
            ")",
            "Lp;"
        }
    .end annotation

    .line 38
    :try_start_0
    invoke-virtual {p1}, Lqb;->k()Lwd;

    move-result-object p1

    .line 39
    invoke-virtual {p0, p1}, Lp;->mergeFrom(Lwd;)Lp;

    const/4 v0, 0x0

    .line 40
    invoke-virtual {p1, v0}, Lwd;->a(I)V
    :try_end_b
    .catch La50; {:try_start_0 .. :try_end_b} :catch_16
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_b} :catch_c

    return-object p0

    :catch_c
    move-exception p1

    .line 41
    invoke-virtual {p0}, Lp;->a()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, p1}, Lm0;->n(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0

    :catch_16
    move-exception p0

    .line 42
    throw p0
.end method

.method public mergeFrom(Lqb;Lcs;)Lp;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lqb;",
            "Lcs;",
            ")",
            "Lp;"
        }
    .end annotation

    .line 43
    :try_start_0
    invoke-virtual {p1}, Lqb;->k()Lwd;

    move-result-object p1

    .line 44
    invoke-virtual {p0, p1, p2}, Lp;->mergeFrom(Lwd;Lcs;)Lp;

    const/4 p2, 0x0

    .line 45
    invoke-virtual {p1, p2}, Lwd;->a(I)V
    :try_end_b
    .catch La50; {:try_start_0 .. :try_end_b} :catch_16
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_b} :catch_c

    return-object p0

    :catch_c
    move-exception p1

    .line 46
    invoke-virtual {p0}, Lp;->a()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, p1}, Lm0;->n(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0

    :catch_16
    move-exception p0

    .line 47
    throw p0
.end method

.method public mergeFrom(Lwd;)Lp;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd;",
            ")",
            "Lp;"
        }
    .end annotation

    .line 37
    invoke-static {}, Lcs;->a()Lcs;

    move-result-object v0

    invoke-virtual {p0, p1, v0}, Lp;->mergeFrom(Lwd;Lcs;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public abstract mergeFrom(Lwd;Lcs;)Lp;
.end method

.method public mergeFrom(Lxd0;)Lp;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lxd0;",
            ")",
            "Lp;"
        }
    .end annotation

    .line 1
    invoke-interface {p0}, Lyd0;->getDefaultInstanceForType()Lxd0;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0, p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    if-eqz v0, :cond_15

    .line 14
    .line 15
    check-cast p1, Lr;

    .line 16
    .line 17
    invoke-virtual {p0, p1}, Lp;->internalMergeFrom(Lr;)Lp;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    :cond_15
    const-string p0, "mergeFrom(MessageLite) can only merge messages of the same type."

    .line 23
    .line 24
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const/4 p0, 0x0

    .line 28
    return-object p0
.end method

.method public mergeFrom([B)Lp;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B)",
            "Lp;"
        }
    .end annotation

    const/4 v0, 0x0

    .line 48
    array-length v1, p1

    invoke-virtual {p0, p1, v0, v1}, Lp;->mergeFrom([BII)Lp;

    move-result-object p0

    return-object p0
.end method

.method public abstract mergeFrom([BII)Lp;
.end method

.method public abstract mergeFrom([BIILcs;)Lp;
.end method

.method public mergeFrom([BLcs;)Lp;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([B",
            "Lcs;",
            ")",
            "Lp;"
        }
    .end annotation

    const/4 v0, 0x0

    .line 49
    array-length v1, p1

    invoke-virtual {p0, p1, v0, v1, p2}, Lp;->mergeFrom([BIILcs;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Ljava/io/InputStream;)Lwd0;
    .registers 2

    .line 33
    invoke-virtual {p0, p1}, Lp;->mergeFrom(Ljava/io/InputStream;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Ljava/io/InputStream;Lcs;)Lwd0;
    .registers 3

    .line 34
    invoke-virtual {p0, p1, p2}, Lp;->mergeFrom(Ljava/io/InputStream;Lcs;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Lqb;)Lwd0;
    .registers 2

    .line 29
    invoke-virtual {p0, p1}, Lp;->mergeFrom(Lqb;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Lqb;Lcs;)Lwd0;
    .registers 3

    .line 30
    invoke-virtual {p0, p1, p2}, Lp;->mergeFrom(Lqb;Lcs;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Lwd;)Lwd0;
    .registers 2

    .line 31
    invoke-virtual {p0, p1}, Lp;->mergeFrom(Lwd;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Lxd0;)Lwd0;
    .registers 2

    .line 32
    invoke-virtual {p0, p1}, Lp;->mergeFrom(Lxd0;)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom([B)Lwd0;
    .registers 2

    .line 35
    invoke-virtual {p0, p1}, Lp;->mergeFrom([B)Lp;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom([BLcs;)Lwd0;
    .registers 3

    .line 36
    invoke-virtual {p0, p1, p2}, Lp;->mergeFrom([BLcs;)Lp;

    move-result-object p0

    return-object p0
.end method
