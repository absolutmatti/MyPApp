###### Class defpackage.lb1 (lb1)
.class public final Llb1;
.super Lw4;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public final b()Z
    .registers 1

    .line 1
    invoke-super {p0}, Lx4;->b()Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    if-nez p0, :cond_7

    .line 6
    .line 7
    goto :goto_29

    .line 8
    :cond_7
    const-string p0, "MULTI_PROCESS"

    .line 9
    .line 10
    invoke-static {p0}, Lr30;->z(Ljava/lang/String;)Z

    .line 11
    .line 12
    .line 13
    move-result p0

    .line 14
    if-eqz p0, :cond_29

    .line 15
    .line 16
    sget-object p0, Ljb1;->a:Landroid/net/Uri;

    .line 17
    .line 18
    sget-object p0, Lmb1;->F:Lw4;

    .line 19
    .line 20
    invoke-virtual {p0}, Lx4;->b()Z

    .line 21
    .line 22
    .line 23
    move-result p0

    .line 24
    if-eqz p0, :cond_24

    .line 25
    .line 26
    sget-object p0, Lob1;->a:Lqb1;

    .line 27
    .line 28
    invoke-interface {p0}, Lqb1;->getStatics()Lorg/chromium/support_lib_boundary/StaticsBoundaryInterface;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-interface {p0}, Lorg/chromium/support_lib_boundary/StaticsBoundaryInterface;->isMultiProcessEnabled()Z

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    return p0

    .line 37
    :cond_24
    invoke-static {}, Lmb1;->a()Ljava/lang/UnsupportedOperationException;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    throw p0

    .line 42
    :cond_29
    :goto_29
    const/4 p0, 0x0

    .line 43
    return p0
.end method
