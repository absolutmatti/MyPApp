###### Class defpackage.fv (fv)
.class public final Lfv;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnPreDrawListener;


# instance fields
.field public final synthetic f:Lvw;

.field public final synthetic g:Lgv;


# direct methods
.method public constructor <init>(Lgv;Lvw;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lfv;->g:Lgv;

    .line 5
    .line 6
    iput-object p2, p0, Lfv;->f:Lvw;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onPreDraw()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lfv;->g:Lgv;

    .line 2
    .line 3
    iget-boolean v1, v0, Lgv;->h:Z

    .line 4
    .line 5
    if-eqz v1, :cond_16

    .line 6
    .line 7
    iget-object v1, v0, Lgv;->f:Lfv;

    .line 8
    .line 9
    if-eqz v1, :cond_16

    .line 10
    .line 11
    iget-object v1, p0, Lfv;->f:Lvw;

    .line 12
    .line 13
    invoke-virtual {v1}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 14
    .line 15
    .line 16
    move-result-object v1

    .line 17
    invoke-virtual {v1, p0}, Landroid/view/ViewTreeObserver;->removeOnPreDrawListener(Landroid/view/ViewTreeObserver$OnPreDrawListener;)V

    .line 18
    .line 19
    .line 20
    const/4 p0, 0x0

    .line 21
    iput-object p0, v0, Lgv;->f:Lfv;

    .line 22
    .line 23
    :cond_16
    iget-boolean p0, v0, Lgv;->h:Z

    .line 24
    .line 25
    return p0
.end method
