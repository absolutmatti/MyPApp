###### Class defpackage.p0 (p0)
.class public final Lp0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;


# instance fields
.field public final synthetic a:Landroid/view/accessibility/AccessibilityManager;

.field public final synthetic b:Lio/flutter/view/b;


# direct methods
.method public constructor <init>(Lio/flutter/view/b;Landroid/view/accessibility/AccessibilityManager;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lp0;->b:Lio/flutter/view/b;

    .line 5
    .line 6
    iput-object p2, p0, Lp0;->a:Landroid/view/accessibility/AccessibilityManager;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onTouchExplorationStateChanged(Z)V
    .registers 6

    .line 1
    iget-object v0, p0, Lp0;->b:Lio/flutter/view/b;

    .line 2
    .line 3
    iget-boolean v1, v0, Lio/flutter/view/b;->u:Z

    .line 4
    .line 5
    if-eqz v1, :cond_7

    .line 6
    .line 7
    goto :goto_41

    .line 8
    :cond_7
    const/4 v1, 0x0

    .line 9
    if-nez p1, :cond_1b

    .line 10
    .line 11
    invoke-virtual {v0, v1}, Lio/flutter/view/b;->k(Z)V

    .line 12
    .line 13
    .line 14
    iget-object v2, v0, Lio/flutter/view/b;->p:Ly0;

    .line 15
    .line 16
    if-eqz v2, :cond_1b

    .line 17
    .line 18
    iget v2, v2, Ly0;->b:I

    .line 19
    .line 20
    const/16 v3, 0x100

    .line 21
    .line 22
    invoke-virtual {v0, v2, v3}, Lio/flutter/view/b;->h(II)V

    .line 23
    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    iput-object v2, v0, Lio/flutter/view/b;->p:Ly0;

    .line 27
    .line 28
    :cond_1b
    iget-object v0, v0, Lio/flutter/view/b;->s:Lnw;

    .line 29
    .line 30
    if-eqz v0, :cond_41

    .line 31
    .line 32
    iget-object p0, p0, Lp0;->a:Landroid/view/accessibility/AccessibilityManager;

    .line 33
    .line 34
    invoke-virtual {p0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 35
    .line 36
    .line 37
    move-result p0

    .line 38
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast v0, Lvw;

    .line 41
    .line 42
    iget-object v2, v0, Lvw;->n:Ljv;

    .line 43
    .line 44
    iget-object v2, v2, Ljv;->a:Lio/flutter/embedding/engine/renderer/e;

    .line 45
    .line 46
    iget-object v2, v2, Lio/flutter/embedding/engine/renderer/e;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 47
    .line 48
    invoke-virtual {v2}, Lio/flutter/embedding/engine/FlutterJNI;->getIsSoftwareRenderingEnabled()Z

    .line 49
    .line 50
    .line 51
    move-result v2

    .line 52
    if-nez v2, :cond_3e

    .line 53
    .line 54
    if-nez p0, :cond_3a

    .line 55
    .line 56
    if-nez p1, :cond_3a

    .line 57
    .line 58
    const/4 v1, 0x1

    .line 59
    :cond_3a
    invoke-virtual {v0, v1}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 60
    .line 61
    .line 62
    return-void

    .line 63
    :cond_3e
    invoke-virtual {v0, v1}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 64
    .line 65
    .line 66
    :cond_41
    :goto_41
    return-void
.end method
