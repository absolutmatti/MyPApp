###### Class defpackage.uh1 (uh1)
.class public final Luh1;
.super Lth1;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final h:[B


# direct methods
.method public constructor <init>([B)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    const/16 v1, 0x19

    .line 3
    .line 4
    invoke-static {p1, v0, v1}, Ljava/util/Arrays;->copyOfRange([BII)[B

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-direct {p0, v0}, Lth1;-><init>([B)V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Luh1;->h:[B

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final g()[B
    .registers 1

    .line 1
    iget-object p0, p0, Luh1;->h:[B

    .line 2
    .line 3
    return-object p0
.end method
