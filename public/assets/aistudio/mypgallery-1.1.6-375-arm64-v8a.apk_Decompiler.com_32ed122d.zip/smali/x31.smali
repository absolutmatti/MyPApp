###### Class defpackage.x31 (x31)
.class public final Lx31;
.super Ljava/util/concurrent/CancellationException;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final transient f:Lp50;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ly31;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lx31;->f:Lp50;

    .line 5
    .line 6
    return-void
.end method
