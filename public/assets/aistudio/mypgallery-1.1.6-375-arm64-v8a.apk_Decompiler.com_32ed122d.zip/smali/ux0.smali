###### Class defpackage.ux0 (ux0)
.class public final Lux0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lwb1;


# static fields
.field public static volatile c:Lux0;

.field public static final d:Ljava/util/concurrent/locks/ReentrantLock;


# instance fields
.field public final a:Lwr;

.field public final b:Ljava/util/concurrent/CopyOnWriteArrayList;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lux0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(Lsx0;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lux0;->a:Lwr;

    .line 5
    .line 6
    new-instance v0, Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lux0;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 12
    .line 13
    if-eqz p1, :cond_17

    .line 14
    .line 15
    new-instance v0, Lns0;

    .line 16
    .line 17
    const/4 v1, 0x4

    .line 18
    invoke-direct {v0, v1, p0}, Lns0;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p1, v0}, Lsx0;->d(Lns0;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Lw8;Lsw;)V
    .registers 11

    .line 1
    instance-of v0, p1, Landroid/app/Activity;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_8

    .line 5
    .line 6
    check-cast p1, Landroid/app/Activity;

    .line 7
    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move-object p1, v1

    .line 10
    :goto_9
    sget-object v0, Luq;->f:Luq;

    .line 11
    .line 12
    if-eqz p1, :cond_b1

    .line 13
    .line 14
    sget-object v2, Lux0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    .line 15
    .line 16
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 17
    .line 18
    .line 19
    :try_start_12
    iget-object v3, p0, Lux0;->a:Lwr;

    .line 20
    .line 21
    if-nez v3, :cond_25

    .line 22
    .line 23
    new-instance p0, Lzc1;

    .line 24
    .line 25
    invoke-direct {p0, v0}, Lzc1;-><init>(Ljava/util/List;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p3, p0}, Lsw;->accept(Ljava/lang/Object;)V
    :try_end_1e
    .catchall {:try_start_12 .. :try_end_1e} :catchall_22

    .line 29
    .line 30
    .line 31
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :catchall_22
    move-exception p0

    .line 36
    goto/16 :goto_ad

    .line 37
    .line 38
    :cond_25
    iget-object p0, p0, Lux0;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 39
    .line 40
    const/4 v4, 0x0

    .line 41
    if-eqz p0, :cond_31

    .line 42
    .line 43
    :try_start_2a
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    .line 44
    .line 45
    .line 46
    move-result v5

    .line 47
    if-eqz v5, :cond_31

    .line 48
    .line 49
    goto :goto_4a

    .line 50
    :cond_31
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 51
    .line 52
    .line 53
    move-result-object v5

    .line 54
    :cond_35
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 55
    .line 56
    .line 57
    move-result v6

    .line 58
    if-eqz v6, :cond_4a

    .line 59
    .line 60
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v6

    .line 64
    check-cast v6, Ltx0;

    .line 65
    .line 66
    iget-object v6, v6, Ltx0;->a:Landroid/app/Activity;

    .line 67
    .line 68
    invoke-virtual {v6, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v6

    .line 72
    if-eqz v6, :cond_35

    .line 73
    .line 74
    const/4 v4, 0x1

    .line 75
    :cond_4a
    :goto_4a
    new-instance v5, Ltx0;

    .line 76
    .line 77
    invoke-direct {v5, p1, p2, p3}, Ltx0;-><init>(Landroid/app/Activity;Lw8;Lsw;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {p0, v5}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 81
    .line 82
    .line 83
    if-nez v4, :cond_7b

    .line 84
    .line 85
    check-cast v3, Lsx0;

    .line 86
    .line 87
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 88
    .line 89
    .line 90
    move-result-object p0

    .line 91
    if-eqz p0, :cond_64

    .line 92
    .line 93
    invoke-virtual {p0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 94
    .line 95
    .line 96
    move-result-object p0

    .line 97
    if-eqz p0, :cond_64

    .line 98
    .line 99
    iget-object v1, p0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    .line 100
    .line 101
    :cond_64
    if-eqz v1, :cond_6a

    .line 102
    .line 103
    invoke-virtual {v3, v1, p1}, Lsx0;->c(Landroid/os/IBinder;Landroid/app/Activity;)V

    .line 104
    .line 105
    .line 106
    goto :goto_a5

    .line 107
    :cond_6a
    new-instance p0, Lrx0;

    .line 108
    .line 109
    invoke-direct {p0, v3, p1}, Lrx0;-><init>(Lsx0;Landroid/app/Activity;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 113
    .line 114
    .line 115
    move-result-object p1

    .line 116
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 117
    .line 118
    .line 119
    move-result-object p1

    .line 120
    invoke-virtual {p1, p0}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    .line 121
    .line 122
    .line 123
    goto :goto_a5

    .line 124
    :cond_7b
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 125
    .line 126
    .line 127
    move-result-object p0

    .line 128
    :cond_7f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 129
    .line 130
    .line 131
    move-result p2

    .line 132
    if-eqz p2, :cond_95

    .line 133
    .line 134
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 135
    .line 136
    .line 137
    move-result-object p2

    .line 138
    move-object v3, p2

    .line 139
    check-cast v3, Ltx0;

    .line 140
    .line 141
    iget-object v3, v3, Ltx0;->a:Landroid/app/Activity;

    .line 142
    .line 143
    invoke-virtual {p1, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 144
    .line 145
    .line 146
    move-result v3

    .line 147
    if-eqz v3, :cond_7f

    .line 148
    .line 149
    goto :goto_96

    .line 150
    :cond_95
    move-object p2, v1

    .line 151
    :goto_96
    check-cast p2, Ltx0;

    .line 152
    .line 153
    if-eqz p2, :cond_9c

    .line 154
    .line 155
    iget-object v1, p2, Ltx0;->c:Lzc1;

    .line 156
    .line 157
    :cond_9c
    if-eqz v1, :cond_a5

    .line 158
    .line 159
    iput-object v1, v5, Ltx0;->c:Lzc1;

    .line 160
    .line 161
    iget-object p0, v5, Ltx0;->b:Lsw;

    .line 162
    .line 163
    invoke-virtual {p0, v1}, Lsw;->accept(Ljava/lang/Object;)V

    .line 164
    .line 165
    .line 166
    :cond_a5
    :goto_a5
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a7
    .catchall {:try_start_2a .. :try_end_a7} :catchall_22

    .line 167
    .line 168
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 169
    .line 170
    .line 171
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 172
    .line 173
    goto :goto_b1

    .line 174
    :goto_ad
    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 175
    .line 176
    .line 177
    throw p0

    .line 178
    :cond_b1
    :goto_b1
    if-nez v1, :cond_bb

    .line 179
    .line 180
    new-instance p0, Lzc1;

    .line 181
    .line 182
    invoke-direct {p0, v0}, Lzc1;-><init>(Ljava/util/List;)V

    .line 183
    .line 184
    .line 185
    invoke-virtual {p3, p0}, Lsw;->accept(Ljava/lang/Object;)V

    .line 186
    .line 187
    .line 188
    :cond_bb
    return-void
.end method

.method public final b(Lsw;)V
    .registers 8

    .line 1
    sget-object v0, Lux0;->d:Ljava/util/concurrent/locks/ReentrantLock;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lux0;->a:Lwr;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_28

    .line 5
    .line 6
    if-nez v1, :cond_9

    .line 7
    .line 8
    monitor-exit v0

    .line 9
    return-void

    .line 10
    :cond_9
    :try_start_9
    new-instance v1, Ljava/util/ArrayList;

    .line 11
    .line 12
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 13
    .line 14
    .line 15
    iget-object v2, p0, Lux0;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 16
    .line 17
    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    :cond_14
    :goto_14
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 22
    .line 23
    .line 24
    move-result v3

    .line 25
    if-eqz v3, :cond_2a

    .line 26
    .line 27
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    check-cast v3, Ltx0;

    .line 32
    .line 33
    iget-object v4, v3, Ltx0;->b:Lsw;

    .line 34
    .line 35
    if-ne v4, p1, :cond_14

    .line 36
    .line 37
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    goto :goto_14

    .line 41
    :catchall_28
    move-exception p0

    .line 42
    goto :goto_72

    .line 43
    :cond_2a
    iget-object p1, p0, Lux0;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 44
    .line 45
    invoke-virtual {p1, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->removeAll(Ljava/util/Collection;)Z

    .line 46
    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    const/4 v2, 0x0

    .line 53
    :cond_34
    :goto_34
    if-ge v2, p1, :cond_6e

    .line 54
    .line 55
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v3

    .line 59
    add-int/lit8 v2, v2, 0x1

    .line 60
    .line 61
    check-cast v3, Ltx0;

    .line 62
    .line 63
    iget-object v3, v3, Ltx0;->a:Landroid/app/Activity;

    .line 64
    .line 65
    iget-object v4, p0, Lux0;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 66
    .line 67
    if-eqz v4, :cond_4b

    .line 68
    .line 69
    invoke-virtual {v4}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    .line 70
    .line 71
    .line 72
    move-result v5

    .line 73
    if-eqz v5, :cond_4b

    .line 74
    .line 75
    goto :goto_64

    .line 76
    :cond_4b
    invoke-virtual {v4}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 77
    .line 78
    .line 79
    move-result-object v4

    .line 80
    :cond_4f
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 81
    .line 82
    .line 83
    move-result v5

    .line 84
    if-eqz v5, :cond_64

    .line 85
    .line 86
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object v5

    .line 90
    check-cast v5, Ltx0;

    .line 91
    .line 92
    iget-object v5, v5, Ltx0;->a:Landroid/app/Activity;

    .line 93
    .line 94
    invoke-virtual {v5, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    move-result v5

    .line 98
    if-eqz v5, :cond_4f

    .line 99
    .line 100
    goto :goto_34

    .line 101
    :cond_64
    :goto_64
    iget-object v4, p0, Lux0;->a:Lwr;

    .line 102
    .line 103
    if-eqz v4, :cond_34

    .line 104
    .line 105
    check-cast v4, Lsx0;

    .line 106
    .line 107
    invoke-virtual {v4, v3}, Lsx0;->b(Landroid/app/Activity;)V

    .line 108
    .line 109
    .line 110
    goto :goto_34

    .line 111
    :cond_6e
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_70
    .catchall {:try_start_9 .. :try_end_70} :catchall_28

    .line 112
    .line 113
    monitor-exit v0

    .line 114
    return-void

    .line 115
    :goto_72
    monitor-exit v0

    .line 116
    throw p0
.end method
