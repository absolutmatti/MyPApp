###### Class defpackage.xf (xf)
.class public final synthetic Lxf;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/Comparator;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Lxf;->a:I

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .registers 6

    .line 1
    iget p0, p0, Lxf;->a:I

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p0, :pswitch_data_36

    .line 5
    .line 6
    .line 7
    check-cast p1, [B

    .line 8
    .line 9
    check-cast p2, [B

    .line 10
    .line 11
    array-length p0, p1

    .line 12
    array-length v1, p2

    .line 13
    if-eq p0, v1, :cond_13

    .line 14
    .line 15
    array-length p0, p1

    .line 16
    array-length p1, p2

    .line 17
    sub-int v0, p0, p1

    .line 18
    .line 19
    goto :goto_23

    .line 20
    :cond_13
    move p0, v0

    .line 21
    :goto_14
    array-length v1, p1

    .line 22
    if-ge p0, v1, :cond_23

    .line 23
    .line 24
    aget-byte v1, p1, p0

    .line 25
    .line 26
    aget-byte v2, p2, p0

    .line 27
    .line 28
    if-eq v1, v2, :cond_20

    .line 29
    .line 30
    sub-int v0, v1, v2

    .line 31
    .line 32
    goto :goto_23

    .line 33
    :cond_20
    add-int/lit8 p0, p0, 0x1

    .line 34
    .line 35
    goto :goto_14

    .line 36
    :cond_23
    :goto_23
    return v0

    .line 37
    :pswitch_24
    check-cast p1, Lc50;

    .line 38
    .line 39
    check-cast p2, Lc50;

    .line 40
    .line 41
    iget p0, p1, Lc50;->b:I

    .line 42
    .line 43
    iget p1, p2, Lc50;->b:I

    .line 44
    .line 45
    if-ge p0, p1, :cond_30

    .line 46
    .line 47
    const/4 v0, -0x1

    .line 48
    goto :goto_34

    .line 49
    :cond_30
    if-ne p0, p1, :cond_33

    .line 50
    .line 51
    goto :goto_34

    .line 52
    :cond_33
    const/4 v0, 0x1

    .line 53
    :goto_34
    return v0

    .line 54
    nop

    .line 55
    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_24
    .end packed-switch
.end method
