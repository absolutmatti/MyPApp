###### Class defpackage.jt (jt)
.class public Ljt;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lfw;
.implements Lc3;


# instance fields
.field public f:Ldb0;

.field public g:Lew;


# virtual methods
.method public final onAttachedToActivity(Ld3;)V
    .registers 4

    .line 1
    new-instance v0, Ldb0;

    .line 2
    .line 3
    const/16 v1, 0x1c

    .line 4
    .line 5
    invoke-direct {v0, v1, p1}, Ldb0;-><init>(ILjava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    iput-object v0, p0, Ljt;->f:Ldb0;

    .line 9
    .line 10
    sget-object p1, Lnt;->b:Lmt;

    .line 11
    .line 12
    iget-object p0, p0, Ljt;->g:Lew;

    .line 13
    .line 14
    iget-object p0, p0, Lew;->c:Lla;

    .line 15
    .line 16
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    invoke-static {p0, v0}, Lmt;->a(Lla;Ldb0;)V

    .line 20
    .line 21
    .line 22
    return-void
.end method

.method public final onAttachedToEngine(Lew;)V
    .registers 2

    .line 1
    iput-object p1, p0, Ljt;->g:Lew;

    .line 2
    .line 3
    return-void
.end method

.method public final onDetachedFromActivity()V
    .registers 2

    .line 1
    iget-object p0, p0, Ljt;->f:Ldb0;

    .line 2
    .line 3
    if-eqz p0, :cond_7

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-object v0, p0, Ldb0;->g:Ljava/lang/Object;

    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public final onDetachedFromActivityForConfigChanges()V
    .registers 2

    .line 1
    iget-object p0, p0, Ljt;->f:Ldb0;

    .line 2
    .line 3
    if-eqz p0, :cond_7

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-object v0, p0, Ldb0;->g:Ljava/lang/Object;

    .line 7
    .line 8
    :cond_7
    return-void
.end method

.method public final onDetachedFromEngine(Lew;)V
    .registers 2

    .line 1
    const/4 p1, 0x0

    .line 2
    iput-object p1, p0, Ljt;->g:Lew;

    .line 3
    .line 4
    return-void
.end method

.method public final onReattachedToActivityForConfigChanges(Ld3;)V
    .registers 4

    .line 1
    iget-object v0, p0, Ljt;->f:Ldb0;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    iput-object p1, v0, Ldb0;->g:Ljava/lang/Object;

    .line 6
    .line 7
    return-void

    .line 8
    :cond_7
    new-instance v0, Ldb0;

    .line 9
    .line 10
    const/16 v1, 0x1c

    .line 11
    .line 12
    invoke-direct {v0, v1, p1}, Ldb0;-><init>(ILjava/lang/Object;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Ljt;->f:Ldb0;

    .line 16
    .line 17
    sget-object p1, Lnt;->b:Lmt;

    .line 18
    .line 19
    iget-object p0, p0, Ljt;->g:Lew;

    .line 20
    .line 21
    iget-object p0, p0, Lew;->c:Lla;

    .line 22
    .line 23
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    invoke-static {p0, v0}, Lmt;->a(Lla;Ldb0;)V

    .line 27
    .line 28
    .line 29
    return-void
.end method
