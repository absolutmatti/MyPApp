###### Class defpackage.oi0 (oi0)
.class public final Loi0;
.super Lxi0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final c:Loi0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Loi0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x3

    .line 5
    invoke-direct {v0, v1, v1, v2}, Lxi0;-><init>(III)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Loi0;->c:Loi0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Lcd;Lt8;Loy0;Lzf;)V
    .registers 5

    .line 1
    invoke-static {p3}, Lt51;->L(Loy0;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method
