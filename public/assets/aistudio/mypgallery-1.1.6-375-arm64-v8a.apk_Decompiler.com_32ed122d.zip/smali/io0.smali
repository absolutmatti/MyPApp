###### Class defpackage.io0 (io0)
.class public final Lio0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lia1;


# instance fields
.field public final f:Lgc;


# direct methods
.method public constructor <init>(Lgc;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lio0;->f:Lgc;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lgt0;I)V
    .registers 3

    .line 1
    iget-object p0, p0, Lio0;->f:Lgc;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lgc;->a(Lgt0;I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
