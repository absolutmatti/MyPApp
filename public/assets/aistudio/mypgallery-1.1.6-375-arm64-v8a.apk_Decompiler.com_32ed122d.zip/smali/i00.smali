###### Class defpackage.i00 (i00)
.class public abstract Li00;
.super Lp;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field private final defaultInstance:Lr00;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lr00;"
        }
    .end annotation
.end field

.field protected instance:Lr00;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lr00;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lr00;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li00;->defaultInstance:Lr00;

    .line 5
    .line 6
    invoke-virtual {p1}, Lr00;->isMutable()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_12

    .line 11
    .line 12
    invoke-virtual {p1}, Lr00;->newMutableInstance()Lr00;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    iput-object p1, p0, Li00;->instance:Lr00;

    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    const-string p0, "Default instance must be immutable."

    .line 20
    .line 21
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    const/4 p0, 0x0

    .line 25
    throw p0
.end method


# virtual methods
.method public final build()Lr00;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lr00;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Li00;->buildPartial()Lr00;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lr00;->isInitialized()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_b

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    invoke-static {p0}, Lp;->newUninitializedMessageException(Lxd0;)Lj61;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    throw p0
.end method

.method public bridge synthetic build()Lxd0;
    .registers 1

    .line 17
    invoke-virtual {p0}, Li00;->build()Lr00;

    move-result-object p0

    return-object p0
.end method

.method public buildPartial()Lr00;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lr00;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Li00;->instance:Lr00;

    .line 2
    .line 3
    invoke-virtual {v0}, Lr00;->isMutable()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget-object v1, p0, Li00;->instance:Lr00;

    .line 8
    .line 9
    if-nez v0, :cond_b

    .line 10
    .line 11
    return-object v1

    .line 12
    :cond_b
    invoke-virtual {v1}, Lr00;->makeImmutable()V

    .line 13
    .line 14
    .line 15
    iget-object p0, p0, Li00;->instance:Lr00;

    .line 16
    .line 17
    return-object p0
.end method

.method public bridge synthetic buildPartial()Lxd0;
    .registers 1

    .line 18
    invoke-virtual {p0}, Li00;->buildPartial()Lr00;

    move-result-object p0

    return-object p0
.end method

.method public final clear()Li00;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li00;"
        }
    .end annotation

    .line 1
    iget-object v0, p0, Li00;->defaultInstance:Lr00;

    .line 2
    .line 3
    invoke-virtual {v0}, Lr00;->isMutable()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_11

    .line 8
    .line 9
    iget-object v0, p0, Li00;->defaultInstance:Lr00;

    .line 10
    .line 11
    invoke-virtual {v0}, Lr00;->newMutableInstance()Lr00;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iput-object v0, p0, Li00;->instance:Lr00;

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_11
    const-string p0, "Default instance must be immutable."

    .line 19
    .line 20
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    const/4 p0, 0x0

    .line 24
    return-object p0
.end method

.method public bridge synthetic clear()Lwd0;
    .registers 1

    .line 25
    invoke-virtual {p0}, Li00;->clear()Li00;

    move-result-object p0

    return-object p0
.end method

.method public clone()Li00;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Li00;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Li00;->getDefaultInstanceForType()Lr00;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Lr00;->newBuilderForType()Li00;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {p0}, Li00;->buildPartial()Lr00;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    iput-object p0, v0, Li00;->instance:Lr00;

    .line 14
    .line 15
    return-object v0
.end method

.method public bridge synthetic clone()Ljava/lang/Object;
    .registers 1

    .line 17
    invoke-virtual {p0}, Li00;->clone()Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic clone()Lp;
    .registers 1

    .line 18
    invoke-virtual {p0}, Li00;->clone()Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic clone()Lwd0;
    .registers 1

    .line 16
    invoke-virtual {p0}, Li00;->clone()Li00;

    move-result-object p0

    return-object p0
.end method

.method public final copyOnWrite()V
    .registers 2

    .line 1
    iget-object v0, p0, Li00;->instance:Lr00;

    .line 2
    .line 3
    invoke-virtual {v0}, Lr00;->isMutable()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_b

    .line 8
    .line 9
    invoke-virtual {p0}, Li00;->copyOnWriteInternal()V

    .line 10
    .line 11
    .line 12
    :cond_b
    return-void
.end method

.method public copyOnWriteInternal()V
    .registers 5

    .line 1
    iget-object v0, p0, Li00;->defaultInstance:Lr00;

    .line 2
    .line 3
    invoke-virtual {v0}, Lr00;->newMutableInstance()Lr00;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    iget-object v1, p0, Li00;->instance:Lr00;

    .line 8
    .line 9
    sget-object v2, Lhn0;->c:Lhn0;

    .line 10
    .line 11
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    move-result-object v3

    .line 18
    invoke-virtual {v2, v3}, Lhn0;->a(Ljava/lang/Class;)Les0;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-interface {v2, v0, v1}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Li00;->instance:Lr00;

    .line 26
    .line 27
    return-void
.end method

.method public getDefaultInstanceForType()Lr00;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lr00;"
        }
    .end annotation

    .line 6
    iget-object p0, p0, Li00;->defaultInstance:Lr00;

    return-object p0
.end method

.method public bridge synthetic getDefaultInstanceForType()Lxd0;
    .registers 1

    .line 1
    invoke-virtual {p0}, Li00;->getDefaultInstanceForType()Lr00;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public internalMergeFrom(Lr00;)Li00;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lr00;",
            ")",
            "Li00;"
        }
    .end annotation

    .line 8
    invoke-virtual {p0, p1}, Li00;->mergeFrom(Lr00;)Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic internalMergeFrom(Lr;)Lp;
    .registers 2

    .line 1
    check-cast p1, Lr00;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Li00;->internalMergeFrom(Lr00;)Li00;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final isInitialized()Z
    .registers 2

    .line 1
    iget-object p0, p0, Li00;->instance:Lr00;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-static {p0, v0}, Lr00;->isInitialized(Lr00;Z)Z

    .line 5
    .line 6
    .line 7
    move-result p0

    .line 8
    return p0
.end method

.method public mergeFrom(Lr00;)Li00;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lr00;",
            ")",
            "Li00;"
        }
    .end annotation

    .line 57
    invoke-virtual {p0}, Li00;->getDefaultInstanceForType()Lr00;

    move-result-object v0

    invoke-virtual {v0, p1}, Lr00;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    return-object p0

    .line 58
    :cond_b
    invoke-virtual {p0}, Li00;->copyOnWrite()V

    .line 59
    iget-object v0, p0, Li00;->instance:Lr00;

    .line 60
    sget-object v1, Lhn0;->c:Lhn0;

    .line 61
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v1, v2}, Lhn0;->a(Ljava/lang/Class;)Les0;

    move-result-object v1

    .line 63
    invoke-interface {v1, v0, p1}, Les0;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    return-object p0
.end method

.method public mergeFrom(Lwd;Lcs;)Li00;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lwd;",
            "Lcs;",
            ")",
            "Li00;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Li00;->copyOnWrite()V

    .line 2
    .line 3
    .line 4
    :try_start_3
    sget-object v0, Lhn0;->c:Lhn0;

    .line 5
    .line 6
    iget-object v1, p0, Li00;->instance:Lr00;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    invoke-virtual {v0, v1}, Lhn0;->a(Ljava/lang/Class;)Les0;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    iget-object v1, p0, Li00;->instance:Lr00;

    .line 20
    .line 21
    iget-object v2, p1, Lwd;->b:Lcd;

    .line 22
    .line 23
    if-eqz v2, :cond_19

    .line 24
    .line 25
    goto :goto_1e

    .line 26
    :cond_19
    new-instance v2, Lcd;

    .line 27
    .line 28
    invoke-direct {v2, p1}, Lcd;-><init>(Lwd;)V

    .line 29
    .line 30
    .line 31
    :goto_1e
    invoke-interface {v0, v1, v2, p2}, Les0;->e(Ljava/lang/Object;Lcd;Lcs;)V
    :try_end_21
    .catch Ljava/lang/RuntimeException; {:try_start_3 .. :try_end_21} :catch_22

    .line 32
    .line 33
    .line 34
    return-object p0

    .line 35
    :catch_22
    move-exception p0

    .line 36
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 37
    .line 38
    .line 39
    move-result-object p1

    .line 40
    instance-of p1, p1, Ljava/io/IOException;

    .line 41
    .line 42
    if-eqz p1, :cond_32

    .line 43
    .line 44
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    check-cast p0, Ljava/io/IOException;

    .line 49
    .line 50
    throw p0

    .line 51
    :cond_32
    throw p0
.end method

.method public mergeFrom([BII)Li00;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BII)",
            "Li00;"
        }
    .end annotation

    .line 72
    invoke-static {}, Lcs;->a()Lcs;

    move-result-object v0

    invoke-virtual {p0, p1, p2, p3, v0}, Li00;->mergeFrom([BIILcs;)Li00;

    move-result-object p0

    return-object p0
.end method

.method public mergeFrom([BIILcs;)Li00;
    .registers 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "([BII",
            "Lcs;",
            ")",
            "Li00;"
        }
    .end annotation

    .line 64
    invoke-virtual {p0}, Li00;->copyOnWrite()V

    .line 65
    :try_start_3
    sget-object v0, Lhn0;->c:Lhn0;

    .line 66
    iget-object v1, p0, Li00;->instance:Lr00;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 67
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Lhn0;->a(Ljava/lang/Class;)Les0;

    move-result-object v2

    .line 68
    iget-object v3, p0, Li00;->instance:Lr00;

    add-int v6, p2, p3

    new-instance v7, Lz8;

    invoke-direct {v7, p4}, Lz8;-><init>(Lcs;)V

    move-object v4, p1

    move v5, p2

    invoke-interface/range {v2 .. v7}, Les0;->f(Ljava/lang/Object;[BIILz8;)V
    :try_end_20
    .catch La50; {:try_start_3 .. :try_end_20} :catch_2f
    .catch Ljava/lang/IndexOutOfBoundsException; {:try_start_3 .. :try_end_20} :catch_2a
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_20} :catch_21

    return-object p0

    :catch_21
    move-exception v0

    move-object p0, v0

    .line 69
    const-string p1, "Reading from byte array should not throw IOException."

    invoke-static {p1, p0}, Lm0;->n(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0

    .line 70
    :catch_2a
    invoke-static {}, La50;->g()La50;

    move-result-object p0

    throw p0

    :catch_2f
    move-exception v0

    move-object p0, v0

    .line 71
    throw p0
.end method

.method public bridge synthetic mergeFrom(Lwd;Lcs;)Lp;
    .registers 3

    .line 73
    invoke-virtual {p0, p1, p2}, Li00;->mergeFrom(Lwd;Lcs;)Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom([BII)Lp;
    .registers 4

    .line 52
    invoke-virtual {p0, p1, p2, p3}, Li00;->mergeFrom([BII)Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom([BIILcs;)Lp;
    .registers 5

    .line 53
    invoke-virtual {p0, p1, p2, p3, p4}, Li00;->mergeFrom([BIILcs;)Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom(Lwd;Lcs;)Lwd0;
    .registers 3

    .line 54
    invoke-virtual {p0, p1, p2}, Li00;->mergeFrom(Lwd;Lcs;)Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom([BII)Lwd0;
    .registers 4

    .line 55
    invoke-virtual {p0, p1, p2, p3}, Li00;->mergeFrom([BII)Li00;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic mergeFrom([BIILcs;)Lwd0;
    .registers 5

    .line 56
    invoke-virtual {p0, p1, p2, p3, p4}, Li00;->mergeFrom([BIILcs;)Li00;

    move-result-object p0

    return-object p0
.end method
