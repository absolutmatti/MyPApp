###### Class defpackage.wh1 (wh1)
.class public final Lwh1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:Landroid/database/Cursor;
