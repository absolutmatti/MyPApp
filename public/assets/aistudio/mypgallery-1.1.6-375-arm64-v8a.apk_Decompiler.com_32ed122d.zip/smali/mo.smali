###### Class defpackage.mo (mo)
.class public final Lmo;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroid/content/ServiceConnection;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lmo;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lmo;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .registers 4

    .line 1
    iget v0, p0, Lmo;->a:I

    .line 2
    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    packed-switch v0, :pswitch_data_38

    .line 10
    .line 11
    .line 12
    iget-object p1, p0, Lmo;->b:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p1, Ln01;

    .line 15
    .line 16
    new-instance v0, Landroid/os/Messenger;

    .line 17
    .line 18
    invoke-direct {v0, p2}, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V

    .line 19
    .line 20
    .line 21
    iput-object v0, p1, Ln01;->e:Landroid/os/Messenger;

    .line 22
    .line 23
    iget-object p0, p0, Lmo;->b:Ljava/lang/Object;

    .line 24
    .line 25
    check-cast p0, Ln01;

    .line 26
    .line 27
    iget-object p0, p0, Ln01;->f:Ljava/util/concurrent/CountDownLatch;

    .line 28
    .line 29
    invoke-virtual {p0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :pswitch_20
    iget-object p1, p0, Lmo;->b:Ljava/lang/Object;

    .line 34
    .line 35
    check-cast p1, Lno;

    .line 36
    .line 37
    new-instance v0, Landroid/os/Messenger;

    .line 38
    .line 39
    invoke-direct {v0, p2}, Landroid/os/Messenger;-><init>(Landroid/os/IBinder;)V

    .line 40
    .line 41
    .line 42
    iput-object v0, p1, Lno;->g:Landroid/os/Messenger;

    .line 43
    .line 44
    iget-object p0, p0, Lmo;->b:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p0, Lno;

    .line 47
    .line 48
    iget-object p0, p0, Lno;->i:Ljava/util/concurrent/CountDownLatch;

    .line 49
    .line 50
    if-eqz p0, :cond_36

    .line 51
    .line 52
    invoke-virtual {p0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 53
    .line 54
    .line 55
    :cond_36
    return-void

    .line 56
    nop

    .line 57
    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_20
    .end packed-switch
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .registers 4

    .line 1
    iget v0, p0, Lmo;->a:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    packed-switch v0, :pswitch_data_30

    .line 8
    .line 9
    .line 10
    iget-object p1, p0, Lmo;->b:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p1, Ln01;

    .line 13
    .line 14
    iput-object v1, p1, Ln01;->e:Landroid/os/Messenger;

    .line 15
    .line 16
    iget-object p1, p0, Lmo;->b:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p1, Ln01;

    .line 19
    .line 20
    const/16 v0, 0xb

    .line 21
    .line 22
    iput v0, p1, Ln01;->d:I

    .line 23
    .line 24
    iget-object p0, p0, Lmo;->b:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p0, Ln01;

    .line 27
    .line 28
    iget-object p0, p0, Ln01;->c:Ljava/util/concurrent/atomic/AtomicReference;

    .line 29
    .line 30
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    check-cast p0, Ljava/util/concurrent/CountDownLatch;

    .line 35
    .line 36
    if-eqz p0, :cond_28

    .line 37
    .line 38
    invoke-virtual {p0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 39
    .line 40
    .line 41
    :cond_28
    return-void

    .line 42
    :pswitch_29
    iget-object p0, p0, Lmo;->b:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p0, Lno;

    .line 45
    .line 46
    iput-object v1, p0, Lno;->g:Landroid/os/Messenger;

    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_29
    .end packed-switch
.end method
