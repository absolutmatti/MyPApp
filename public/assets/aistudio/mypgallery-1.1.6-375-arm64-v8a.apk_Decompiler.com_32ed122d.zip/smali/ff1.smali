###### Class defpackage.ff1 (ff1)
.class public final Lff1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Lne1;

.field public final b:Landroid/content/Context;

.field public final c:Ljava/lang/String;

.field public final d:Lq1;

.field public final e:Lig;

.field public final f:Lkr0;

.field public final g:Lrm0;

.field public final h:Landroidx/work/impl/WorkDatabase;

.field public final i:Lre1;

.field public final j:Lwm;

.field public final k:Ljava/util/ArrayList;

.field public final l:Ljava/lang/String;

.field public final m:Lr50;


# direct methods
.method public constructor <init>(Lzf;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lzf;->f:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast v0, Lne1;

    .line 7
    .line 8
    iput-object v0, p0, Lff1;->a:Lne1;

    .line 9
    .line 10
    iget-object v1, p1, Lzf;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v1, Landroid/content/Context;

    .line 13
    .line 14
    iput-object v1, p0, Lff1;->b:Landroid/content/Context;

    .line 15
    .line 16
    iget-object v0, v0, Lne1;->a:Ljava/lang/String;

    .line 17
    .line 18
    iput-object v0, p0, Lff1;->c:Ljava/lang/String;

    .line 19
    .line 20
    iget-object v1, p1, Lzf;->c:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v1, Lq1;

    .line 23
    .line 24
    iput-object v1, p0, Lff1;->d:Lq1;

    .line 25
    .line 26
    iget-object v1, p1, Lzf;->a:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast v1, Lig;

    .line 29
    .line 30
    iput-object v1, p0, Lff1;->e:Lig;

    .line 31
    .line 32
    iget-object v1, v1, Lig;->d:Lkr0;

    .line 33
    .line 34
    iput-object v1, p0, Lff1;->f:Lkr0;

    .line 35
    .line 36
    iget-object v1, p1, Lzf;->d:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v1, Lrm0;

    .line 39
    .line 40
    iput-object v1, p0, Lff1;->g:Lrm0;

    .line 41
    .line 42
    iget-object v1, p1, Lzf;->e:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast v1, Landroidx/work/impl/WorkDatabase;

    .line 45
    .line 46
    iput-object v1, p0, Lff1;->h:Landroidx/work/impl/WorkDatabase;

    .line 47
    .line 48
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->v()Lre1;

    .line 49
    .line 50
    .line 51
    move-result-object v2

    .line 52
    iput-object v2, p0, Lff1;->i:Lre1;

    .line 53
    .line 54
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->q()Lwm;

    .line 55
    .line 56
    .line 57
    move-result-object v1

    .line 58
    iput-object v1, p0, Lff1;->j:Lwm;

    .line 59
    .line 60
    iget-object p1, p1, Lzf;->b:Ljava/lang/Object;

    .line 61
    .line 62
    move-object v1, p1

    .line 63
    check-cast v1, Ljava/util/ArrayList;

    .line 64
    .line 65
    iput-object v1, p0, Lff1;->k:Ljava/util/ArrayList;

    .line 66
    .line 67
    new-instance p1, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    const-string v2, "Work [ id="

    .line 70
    .line 71
    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    const-string v0, ", tags={ "

    .line 78
    .line 79
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 80
    .line 81
    .line 82
    const/4 v5, 0x0

    .line 83
    const/16 v6, 0x3e

    .line 84
    .line 85
    const-string v2, ","

    .line 86
    .line 87
    const/4 v3, 0x0

    .line 88
    const/4 v4, 0x0

    .line 89
    invoke-static/range {v1 .. v6}, Lfe;->V(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lqz;I)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    const-string v1, " } ]"

    .line 94
    .line 95
    invoke-static {p1, v0, v1}, Lzi0;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object p1

    .line 99
    iput-object p1, p0, Lff1;->l:Ljava/lang/String;

    .line 100
    .line 101
    invoke-static {}, Lge1;->a()Lr50;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    iput-object p1, p0, Lff1;->m:Lr50;

    .line 106
    .line 107
    return-void
.end method

.method public static final a(Lff1;Lsh;)Ljava/lang/Object;
    .registers 20

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v0, p1

    .line 4
    .line 5
    iget-object v6, v1, Lff1;->l:Ljava/lang/String;

    .line 6
    .line 7
    iget-object v2, v1, Lff1;->d:Lq1;

    .line 8
    .line 9
    iget-object v3, v1, Lff1;->c:Ljava/lang/String;

    .line 10
    .line 11
    iget-object v4, v1, Lff1;->h:Landroidx/work/impl/WorkDatabase;

    .line 12
    .line 13
    iget-object v5, v1, Lff1;->e:Lig;

    .line 14
    .line 15
    iget-object v7, v5, Lig;->m:Ls10;

    .line 16
    .line 17
    iget-object v8, v1, Lff1;->a:Lne1;

    .line 18
    .line 19
    instance-of v9, v0, Lef1;

    .line 20
    .line 21
    if-eqz v9, :cond_25

    .line 22
    .line 23
    move-object v9, v0

    .line 24
    check-cast v9, Lef1;

    .line 25
    .line 26
    iget v10, v9, Lef1;->k:I

    .line 27
    .line 28
    const/high16 v11, -0x80000000

    .line 29
    .line 30
    and-int v12, v10, v11

    .line 31
    .line 32
    if-eqz v12, :cond_25

    .line 33
    .line 34
    sub-int/2addr v10, v11

    .line 35
    iput v10, v9, Lef1;->k:I

    .line 36
    .line 37
    goto :goto_2a

    .line 38
    :cond_25
    new-instance v9, Lef1;

    .line 39
    .line 40
    invoke-direct {v9, v1, v0}, Lef1;-><init>(Lff1;Lsh;)V

    .line 41
    .line 42
    .line 43
    :goto_2a
    iget-object v0, v9, Lef1;->i:Ljava/lang/Object;

    .line 44
    .line 45
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object v10

    .line 49
    iget v11, v9, Lef1;->k:I

    .line 50
    .line 51
    const/4 v12, 0x1

    .line 52
    if-eqz v11, :cond_4e

    .line 53
    .line 54
    if-ne v11, v12, :cond_47

    .line 55
    .line 56
    :try_start_37
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V
    :try_end_3a
    .catch Ljava/util/concurrent/CancellationException; {:try_start_37 .. :try_end_3a} :catch_43
    .catchall {:try_start_37 .. :try_end_3a} :catchall_3e

    .line 57
    .line 58
    .line 59
    move-object/from16 v17, v6

    .line 60
    .line 61
    goto/16 :goto_1c1

    .line 62
    .line 63
    :catchall_3e
    move-exception v0

    .line 64
    move-object/from16 v17, v6

    .line 65
    .line 66
    goto/16 :goto_1d2

    .line 67
    .line 68
    :catch_43
    move-exception v0

    .line 69
    move-object v4, v6

    .line 70
    goto/16 :goto_1f4

    .line 71
    .line 72
    :cond_47
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 73
    .line 74
    invoke-static {v0}, Lm0;->g(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    const/4 v0, 0x0

    .line 78
    return-object v0

    .line 79
    :cond_4e
    invoke-static {v0}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    invoke-static {}, Lrl;->L()Z

    .line 86
    .line 87
    .line 88
    move-result v7

    .line 89
    iget-object v11, v8, Lne1;->x:Ljava/lang/String;

    .line 90
    .line 91
    iget-object v13, v8, Lne1;->c:Ljava/lang/String;

    .line 92
    .line 93
    iget-object v14, v8, Lne1;->d:Ljava/lang/String;

    .line 94
    .line 95
    if-eqz v7, :cond_69

    .line 96
    .line 97
    if-eqz v11, :cond_69

    .line 98
    .line 99
    invoke-virtual {v8}, Lne1;->hashCode()I

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    invoke-static {v0, v11}, Lrl;->p(ILjava/lang/String;)V

    .line 104
    .line 105
    .line 106
    :cond_69
    new-instance v0, Lwe1;

    .line 107
    .line 108
    const/4 v15, 0x0

    .line 109
    invoke-direct {v0, v1, v15}, Lwe1;-><init>(Lff1;I)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {v4, v0}, Lgq0;->n(Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    .line 113
    .line 114
    .line 115
    move-result-object v0

    .line 116
    check-cast v0, Ljava/lang/Boolean;

    .line 117
    .line 118
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 119
    .line 120
    .line 121
    move-result v0

    .line 122
    if-eqz v0, :cond_81

    .line 123
    .line 124
    new-instance v0, Laf1;

    .line 125
    .line 126
    invoke-direct {v0}, Laf1;-><init>()V

    .line 127
    .line 128
    .line 129
    return-object v0

    .line 130
    :cond_81
    invoke-virtual {v8}, Lne1;->b()Z

    .line 131
    .line 132
    .line 133
    move-result v0

    .line 134
    const/4 v12, 0x0

    .line 135
    if-eqz v0, :cond_8e

    .line 136
    .line 137
    iget-object v0, v8, Lne1;->e:Lak;

    .line 138
    .line 139
    move-object/from16 v17, v6

    .line 140
    .line 141
    goto/16 :goto_12d

    .line 142
    .line 143
    :cond_8e
    iget-object v0, v5, Lig;->f:Lmp;

    .line 144
    .line 145
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    .line 150
    .line 151
    sget-object v0, Ll30;->a:Ljava/lang/String;

    .line 152
    .line 153
    :try_start_98
    invoke-static {v14}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 154
    .line 155
    .line 156
    move-result-object v0

    .line 157
    invoke-virtual {v0, v12}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 158
    .line 159
    .line 160
    move-result-object v0

    .line 161
    invoke-virtual {v0, v12}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 162
    .line 163
    .line 164
    move-result-object v0

    .line 165
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    check-cast v0, Landroidx/work/OverwritingInputMerger;
    :try_end_a9
    .catch Ljava/lang/Exception; {:try_start_98 .. :try_end_a9} :catch_ac

    .line 169
    .line 170
    move-object/from16 v17, v6

    .line 171
    .line 172
    goto :goto_bf

    .line 173
    :catch_ac
    move-exception v0

    .line 174
    invoke-static {}, Lta0;->g()Lta0;

    .line 175
    .line 176
    .line 177
    move-result-object v12

    .line 178
    sget-object v15, Ll30;->a:Ljava/lang/String;

    .line 179
    .line 180
    move-object/from16 v17, v6

    .line 181
    .line 182
    const-string v6, "Trouble instantiating "

    .line 183
    .line 184
    invoke-virtual {v6, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 185
    .line 186
    .line 187
    move-result-object v6

    .line 188
    invoke-virtual {v12, v15, v6, v0}, Lta0;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 189
    .line 190
    .line 191
    const/4 v0, 0x0

    .line 192
    :goto_bf
    if-nez v0, :cond_d7

    .line 193
    .line 194
    sget-object v0, Lhf1;->a:Ljava/lang/String;

    .line 195
    .line 196
    invoke-static {}, Lta0;->g()Lta0;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    const-string v2, "Could not create Input Merger "

    .line 201
    .line 202
    invoke-virtual {v2, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 203
    .line 204
    .line 205
    move-result-object v2

    .line 206
    invoke-virtual {v1, v0, v2}, Lta0;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 207
    .line 208
    .line 209
    new-instance v10, Lye1;

    .line 210
    .line 211
    invoke-direct {v10}, Lye1;-><init>()V

    .line 212
    .line 213
    .line 214
    goto/16 :goto_230

    .line 215
    .line 216
    :cond_d7
    iget-object v0, v8, Lne1;->e:Lak;

    .line 217
    .line 218
    invoke-static {v0}, Llf1;->y(Ljava/lang/Object;)Ljava/util/List;

    .line 219
    .line 220
    .line 221
    move-result-object v0

    .line 222
    iget-object v6, v1, Lff1;->i:Lre1;

    .line 223
    .line 224
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 225
    .line 226
    .line 227
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 228
    .line 229
    .line 230
    iget-object v6, v6, Lre1;->a:Lgq0;

    .line 231
    .line 232
    new-instance v8, Lum;

    .line 233
    .line 234
    const/16 v12, 0xc

    .line 235
    .line 236
    invoke-direct {v8, v3, v12}, Lum;-><init>(Ljava/lang/String;I)V

    .line 237
    .line 238
    .line 239
    const/4 v12, 0x0

    .line 240
    const/4 v14, 0x1

    .line 241
    invoke-static {v6, v14, v12, v8}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v6

    .line 245
    check-cast v6, Ljava/util/List;

    .line 246
    .line 247
    invoke-static {v6, v0}, Lfe;->X(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    new-instance v6, Lzj;

    .line 252
    .line 253
    invoke-direct {v6, v12}, Lzj;-><init>(I)V

    .line 254
    .line 255
    .line 256
    new-instance v8, Ljava/util/LinkedHashMap;

    .line 257
    .line 258
    invoke-direct {v8}, Ljava/util/LinkedHashMap;-><init>()V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 262
    .line 263
    .line 264
    move-result v14

    .line 265
    move v15, v12

    .line 266
    :goto_109
    if-ge v15, v14, :cond_120

    .line 267
    .line 268
    invoke-virtual {v0, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v12

    .line 272
    add-int/lit8 v15, v15, 0x1

    .line 273
    .line 274
    check-cast v12, Lak;

    .line 275
    .line 276
    iget-object v12, v12, Lak;->a:Ljava/util/HashMap;

    .line 277
    .line 278
    invoke-static {v12}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    .line 279
    .line 280
    .line 281
    move-result-object v12

    .line 282
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 283
    .line 284
    .line 285
    invoke-interface {v8, v12}, Ljava/util/Map;->putAll(Ljava/util/Map;)V

    .line 286
    .line 287
    .line 288
    goto :goto_109

    .line 289
    :cond_120
    invoke-virtual {v6, v8}, Lzj;->c(Ljava/util/HashMap;)V

    .line 290
    .line 291
    .line 292
    new-instance v0, Lak;

    .line 293
    .line 294
    iget-object v6, v6, Lzj;->a:Ljava/util/LinkedHashMap;

    .line 295
    .line 296
    invoke-direct {v0, v6}, Lak;-><init>(Ljava/util/LinkedHashMap;)V

    .line 297
    .line 298
    .line 299
    invoke-static {v0}, Lge1;->P(Lak;)[B

    .line 300
    .line 301
    .line 302
    :goto_12d
    new-instance v6, Landroidx/work/WorkerParameters;

    .line 303
    .line 304
    invoke-static {v3}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    .line 305
    .line 306
    .line 307
    move-result-object v3

    .line 308
    iget-object v8, v1, Lff1;->k:Ljava/util/ArrayList;

    .line 309
    .line 310
    iget-object v12, v5, Lig;->a:Ljava/util/concurrent/ExecutorService;

    .line 311
    .line 312
    iget-object v14, v5, Lig;->b:Lam;

    .line 313
    .line 314
    new-instance v15, Lke1;

    .line 315
    .line 316
    new-instance v15, Lbe1;

    .line 317
    .line 318
    move-object/from16 v16, v10

    .line 319
    .line 320
    iget-object v10, v1, Lff1;->g:Lrm0;

    .line 321
    .line 322
    invoke-direct {v15, v4, v10, v2}, Lbe1;-><init>(Landroidx/work/impl/WorkDatabase;Lrm0;Lq1;)V

    .line 323
    .line 324
    .line 325
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 326
    .line 327
    .line 328
    iput-object v3, v6, Landroidx/work/WorkerParameters;->a:Ljava/util/UUID;

    .line 329
    .line 330
    iput-object v0, v6, Landroidx/work/WorkerParameters;->b:Lak;

    .line 331
    .line 332
    new-instance v0, Ljava/util/HashSet;

    .line 333
    .line 334
    invoke-direct {v0, v8}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 335
    .line 336
    .line 337
    iput-object v12, v6, Landroidx/work/WorkerParameters;->c:Ljava/util/concurrent/ExecutorService;

    .line 338
    .line 339
    iput-object v14, v6, Landroidx/work/WorkerParameters;->d:Lyh;

    .line 340
    .line 341
    :try_start_154
    iget-object v0, v5, Lig;->e:Liq0;

    .line 342
    .line 343
    iget-object v3, v1, Lff1;->b:Landroid/content/Context;

    .line 344
    .line 345
    invoke-virtual {v0, v3, v13, v6}, Liq0;->h(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Lda0;

    .line 346
    .line 347
    .line 348
    move-result-object v0
    :try_end_15c
    .catchall {:try_start_154 .. :try_end_15c} :catchall_214

    .line 349
    const/4 v14, 0x1

    .line 350
    iput-boolean v14, v0, Lda0;->d:Z

    .line 351
    .line 352
    iget-object v3, v9, Lsh;->g:Lyh;

    .line 353
    .line 354
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 355
    .line 356
    .line 357
    sget-object v5, Liq0;->j:Liq0;

    .line 358
    .line 359
    invoke-interface {v3, v5}, Lyh;->q(Lxh;)Lwh;

    .line 360
    .line 361
    .line 362
    move-result-object v3

    .line 363
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 364
    .line 365
    .line 366
    check-cast v3, Lp50;

    .line 367
    .line 368
    new-instance v5, Lxe1;

    .line 369
    .line 370
    invoke-direct {v5, v0, v7, v11, v1}, Lxe1;-><init>(Lda0;ZLjava/lang/String;Lff1;)V

    .line 371
    .line 372
    .line 373
    invoke-interface {v3, v5}, Lp50;->t(Lqz;)Lwn;

    .line 374
    .line 375
    .line 376
    new-instance v5, Lwe1;

    .line 377
    .line 378
    invoke-direct {v5, v1, v14}, Lwe1;-><init>(Lff1;I)V

    .line 379
    .line 380
    .line 381
    invoke-virtual {v4, v5}, Lgq0;->n(Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    .line 382
    .line 383
    .line 384
    move-result-object v4

    .line 385
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 386
    .line 387
    .line 388
    check-cast v4, Ljava/lang/Boolean;

    .line 389
    .line 390
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 391
    .line 392
    .line 393
    move-result v4

    .line 394
    if-nez v4, :cond_192

    .line 395
    .line 396
    new-instance v10, Laf1;

    .line 397
    .line 398
    invoke-direct {v10}, Laf1;-><init>()V

    .line 399
    .line 400
    .line 401
    goto/16 :goto_230

    .line 402
    .line 403
    :cond_192
    invoke-interface {v3}, Lp50;->isCancelled()Z

    .line 404
    .line 405
    .line 406
    move-result v3

    .line 407
    if-eqz v3, :cond_19f

    .line 408
    .line 409
    new-instance v10, Laf1;

    .line 410
    .line 411
    invoke-direct {v10}, Laf1;-><init>()V

    .line 412
    .line 413
    .line 414
    goto/16 :goto_230

    .line 415
    .line 416
    :cond_19f
    iget-object v2, v2, Lq1;->i:Ljava/lang/Object;

    .line 417
    .line 418
    check-cast v2, Lkp0;

    .line 419
    .line 420
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 421
    .line 422
    .line 423
    invoke-static {v2}, Lrl;->E(Ljava/util/concurrent/Executor;)Lbi;

    .line 424
    .line 425
    .line 426
    move-result-object v6

    .line 427
    move-object v2, v0

    .line 428
    :try_start_1ab
    new-instance v0, Lpc;

    .line 429
    .line 430
    const/16 v5, 0xe

    .line 431
    .line 432
    move-object v3, v15

    .line 433
    const/4 v4, 0x0

    .line 434
    invoke-direct/range {v0 .. v5}, Lpc;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 435
    .line 436
    .line 437
    const/4 v14, 0x1

    .line 438
    iput v14, v9, Lef1;->k:I

    .line 439
    .line 440
    invoke-static {v6, v0, v9}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 441
    .line 442
    .line 443
    move-result-object v0

    .line 444
    move-object/from16 v1, v16

    .line 445
    .line 446
    if-ne v0, v1, :cond_1c1

    .line 447
    .line 448
    move-object v10, v1

    .line 449
    goto :goto_230

    .line 450
    :cond_1c1
    :goto_1c1
    check-cast v0, Lca0;

    .line 451
    .line 452
    new-instance v10, Lze1;

    .line 453
    .line 454
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 455
    .line 456
    .line 457
    invoke-direct {v10, v0}, Lze1;-><init>(Lca0;)V
    :try_end_1cb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1ab .. :try_end_1cb} :catch_1ce
    .catchall {:try_start_1ab .. :try_end_1cb} :catchall_1cc

    .line 458
    .line 459
    .line 460
    goto :goto_230

    .line 461
    :catchall_1cc
    move-exception v0

    .line 462
    goto :goto_1d2

    .line 463
    :catch_1ce
    move-exception v0

    .line 464
    move-object/from16 v4, v17

    .line 465
    .line 466
    goto :goto_1f4

    .line 467
    :goto_1d2
    sget-object v1, Lhf1;->a:Ljava/lang/String;

    .line 468
    .line 469
    invoke-static {}, Lta0;->g()Lta0;

    .line 470
    .line 471
    .line 472
    move-result-object v2

    .line 473
    new-instance v3, Ljava/lang/StringBuilder;

    .line 474
    .line 475
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 476
    .line 477
    .line 478
    move-object/from16 v4, v17

    .line 479
    .line 480
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 481
    .line 482
    .line 483
    const-string v4, " failed because it threw an exception/error"

    .line 484
    .line 485
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 486
    .line 487
    .line 488
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 489
    .line 490
    .line 491
    move-result-object v3

    .line 492
    invoke-virtual {v2, v1, v3, v0}, Lta0;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 493
    .line 494
    .line 495
    new-instance v10, Lye1;

    .line 496
    .line 497
    invoke-direct {v10}, Lye1;-><init>()V

    .line 498
    .line 499
    .line 500
    goto :goto_230

    .line 501
    :goto_1f4
    sget-object v1, Lhf1;->a:Ljava/lang/String;

    .line 502
    .line 503
    invoke-static {}, Lta0;->g()Lta0;

    .line 504
    .line 505
    .line 506
    move-result-object v2

    .line 507
    new-instance v3, Ljava/lang/StringBuilder;

    .line 508
    .line 509
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 510
    .line 511
    .line 512
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 513
    .line 514
    .line 515
    const-string v4, " was cancelled"

    .line 516
    .line 517
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 518
    .line 519
    .line 520
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 521
    .line 522
    .line 523
    move-result-object v3

    .line 524
    iget v2, v2, Lta0;->a:I

    .line 525
    .line 526
    const/4 v4, 0x4

    .line 527
    if-gt v2, v4, :cond_213

    .line 528
    .line 529
    invoke-static {v1, v3, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 530
    .line 531
    .line 532
    :cond_213
    throw v0

    .line 533
    :catchall_214
    sget-object v0, Lhf1;->a:Ljava/lang/String;

    .line 534
    .line 535
    invoke-static {}, Lta0;->g()Lta0;

    .line 536
    .line 537
    .line 538
    move-result-object v1

    .line 539
    new-instance v2, Ljava/lang/StringBuilder;

    .line 540
    .line 541
    const-string v3, "Could not create Worker "

    .line 542
    .line 543
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 544
    .line 545
    .line 546
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 547
    .line 548
    .line 549
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 550
    .line 551
    .line 552
    move-result-object v2

    .line 553
    invoke-virtual {v1, v0, v2}, Lta0;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 554
    .line 555
    .line 556
    new-instance v10, Lye1;

    .line 557
    .line 558
    invoke-direct {v10}, Lye1;-><init>()V

    .line 559
    .line 560
    .line 561
    :goto_230
    return-object v10
.end method


# virtual methods
.method public final b(I)V
    .registers 7

    .line 1
    iget-object v0, p0, Lff1;->i:Lre1;

    .line 2
    .line 3
    sget-object v1, Lde1;->f:Lde1;

    .line 4
    .line 5
    iget-object v2, p0, Lff1;->c:Ljava/lang/String;

    .line 6
    .line 7
    invoke-virtual {v0, v1, v2}, Lre1;->f(Lde1;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Lff1;->f:Lkr0;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 16
    .line 17
    .line 18
    move-result-wide v3

    .line 19
    invoke-virtual {v0, v3, v4, v2}, Lre1;->e(JLjava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object p0, p0, Lff1;->a:Lne1;

    .line 23
    .line 24
    iget p0, p0, Lne1;->v:I

    .line 25
    .line 26
    invoke-virtual {v0, p0, v2}, Lre1;->d(ILjava/lang/String;)V

    .line 27
    .line 28
    .line 29
    const-wide/16 v3, -0x1

    .line 30
    .line 31
    invoke-virtual {v0, v3, v4, v2}, Lre1;->c(JLjava/lang/String;)V

    .line 32
    .line 33
    .line 34
    invoke-virtual {v0, p1, v2}, Lre1;->g(ILjava/lang/String;)V

    .line 35
    .line 36
    .line 37
    return-void
.end method

.method public final c()V
    .registers 7

    .line 1
    iget-object v0, p0, Lff1;->f:Lkr0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    iget-object v2, p0, Lff1;->i:Lre1;

    .line 11
    .line 12
    iget-object v3, p0, Lff1;->c:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v2, v0, v1, v3}, Lre1;->e(JLjava/lang/String;)V

    .line 15
    .line 16
    .line 17
    sget-object v0, Lde1;->f:Lde1;

    .line 18
    .line 19
    invoke-virtual {v2, v0, v3}, Lre1;->f(Lde1;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    iget-object v0, v2, Lre1;->a:Lgq0;

    .line 23
    .line 24
    new-instance v1, Lum;

    .line 25
    .line 26
    const/16 v4, 0xa

    .line 27
    .line 28
    invoke-direct {v1, v3, v4}, Lum;-><init>(Ljava/lang/String;I)V

    .line 29
    .line 30
    .line 31
    const/4 v4, 0x0

    .line 32
    const/4 v5, 0x1

    .line 33
    invoke-static {v0, v4, v5, v1}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    check-cast v1, Ljava/lang/Number;

    .line 38
    .line 39
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 40
    .line 41
    .line 42
    iget-object p0, p0, Lff1;->a:Lne1;

    .line 43
    .line 44
    iget p0, p0, Lne1;->v:I

    .line 45
    .line 46
    invoke-virtual {v2, p0, v3}, Lre1;->d(ILjava/lang/String;)V

    .line 47
    .line 48
    .line 49
    new-instance p0, Lum;

    .line 50
    .line 51
    const/16 v1, 0xb

    .line 52
    .line 53
    invoke-direct {p0, v3, v1}, Lum;-><init>(Ljava/lang/String;I)V

    .line 54
    .line 55
    .line 56
    invoke-static {v0, v4, v5, p0}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    const-wide/16 v0, -0x1

    .line 60
    .line 61
    invoke-virtual {v2, v0, v1, v3}, Lre1;->c(JLjava/lang/String;)V

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public final d(Lca0;)V
    .registers 8

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lff1;->c:Ljava/lang/String;

    .line 5
    .line 6
    filled-new-array {v0}, [Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-static {v1}, Llf1;->C([Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    :goto_d
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    iget-object v3, p0, Lff1;->i:Lre1;

    .line 19
    .line 20
    if-nez v2, :cond_32

    .line 21
    .line 22
    invoke-static {v1}, Lke;->O(Ljava/util/AbstractList;)Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    check-cast v2, Ljava/lang/String;

    .line 27
    .line 28
    invoke-virtual {v3, v2}, Lre1;->a(Ljava/lang/String;)Lde1;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    sget-object v5, Lde1;->k:Lde1;

    .line 33
    .line 34
    if-eq v4, v5, :cond_28

    .line 35
    .line 36
    sget-object v4, Lde1;->i:Lde1;

    .line 37
    .line 38
    invoke-virtual {v3, v4, v2}, Lre1;->f(Lde1;Ljava/lang/String;)V

    .line 39
    .line 40
    .line 41
    :cond_28
    iget-object v3, p0, Lff1;->j:Lwm;

    .line 42
    .line 43
    invoke-virtual {v3, v2}, Lwm;->a(Ljava/lang/String;)Ljava/util/List;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 48
    .line 49
    .line 50
    goto :goto_d

    .line 51
    :cond_32
    check-cast p1, Laa0;

    .line 52
    .line 53
    iget-object p1, p1, Laa0;->a:Lak;

    .line 54
    .line 55
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    .line 57
    .line 58
    iget-object p0, p0, Lff1;->a:Lne1;

    .line 59
    .line 60
    iget p0, p0, Lne1;->v:I

    .line 61
    .line 62
    invoke-virtual {v3, p0, v0}, Lre1;->d(ILjava/lang/String;)V

    .line 63
    .line 64
    .line 65
    iget-object p0, v3, Lre1;->a:Lgq0;

    .line 66
    .line 67
    new-instance v1, Ltm;

    .line 68
    .line 69
    const/16 v2, 0x8

    .line 70
    .line 71
    invoke-direct {v1, p1, v2, v0}, Ltm;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 72
    .line 73
    .line 74
    const/4 p1, 0x0

    .line 75
    const/4 v0, 0x1

    .line 76
    invoke-static {p0, p1, v0, v1}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    return-void
.end method

###### Class defpackage.we1 (we1)
.class public final synthetic Lwe1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lff1;


# direct methods
.method public synthetic constructor <init>(Lff1;I)V
    .registers 3

    .line 1
    iput p2, p0, Lwe1;->a:I

    .line 2
    .line 3
    iput-object p1, p0, Lwe1;->b:Lff1;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Lwe1;->a:I

    .line 2
    .line 3
    sget-object v1, Lde1;->f:Lde1;

    .line 4
    .line 5
    iget-object p0, p0, Lwe1;->b:Lff1;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_9e

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Lff1;->i:Lre1;

    .line 11
    .line 12
    iget-object p0, p0, Lff1;->c:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v0, p0}, Lre1;->a(Ljava/lang/String;)Lde1;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    const/4 v3, 0x0

    .line 19
    if-ne v2, v1, :cond_32

    .line 20
    .line 21
    sget-object v1, Lde1;->g:Lde1;

    .line 22
    .line 23
    invoke-virtual {v0, v1, p0}, Lre1;->f(Lde1;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    iget-object v1, v0, Lre1;->a:Lgq0;

    .line 27
    .line 28
    new-instance v2, Lum;

    .line 29
    .line 30
    const/16 v4, 0xd

    .line 31
    .line 32
    invoke-direct {v2, p0, v4}, Lum;-><init>(Ljava/lang/String;I)V

    .line 33
    .line 34
    .line 35
    const/4 v4, 0x1

    .line 36
    invoke-static {v1, v3, v4, v2}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 37
    .line 38
    .line 39
    move-result-object v1

    .line 40
    check-cast v1, Ljava/lang/Number;

    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    .line 43
    .line 44
    .line 45
    const/16 v1, -0x100

    .line 46
    .line 47
    invoke-virtual {v0, v1, p0}, Lre1;->g(ILjava/lang/String;)V

    .line 48
    .line 49
    .line 50
    move v3, v4

    .line 51
    :cond_32
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    return-object p0

    .line 56
    :pswitch_37
    iget-object v0, p0, Lff1;->a:Lne1;

    .line 57
    .line 58
    iget-object v2, v0, Lne1;->b:Lde1;

    .line 59
    .line 60
    iget-object v3, v0, Lne1;->c:Ljava/lang/String;

    .line 61
    .line 62
    if-eq v2, v1, :cond_5c

    .line 63
    .line 64
    sget-object p0, Lhf1;->a:Ljava/lang/String;

    .line 65
    .line 66
    invoke-static {}, Lta0;->g()Lta0;

    .line 67
    .line 68
    .line 69
    move-result-object v0

    .line 70
    new-instance v1, Ljava/lang/StringBuilder;

    .line 71
    .line 72
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    const-string v2, " is not in ENQUEUED state. Nothing more to do"

    .line 79
    .line 80
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    invoke-virtual {v0, p0, v1}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 88
    .line 89
    .line 90
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 91
    .line 92
    goto :goto_9c

    .line 93
    :cond_5c
    invoke-virtual {v0}, Lne1;->b()Z

    .line 94
    .line 95
    .line 96
    move-result v2

    .line 97
    if-nez v2, :cond_6a

    .line 98
    .line 99
    iget-object v2, v0, Lne1;->b:Lde1;

    .line 100
    .line 101
    if-ne v2, v1, :cond_9a

    .line 102
    .line 103
    iget v1, v0, Lne1;->k:I

    .line 104
    .line 105
    if-lez v1, :cond_9a

    .line 106
    .line 107
    :cond_6a
    iget-object p0, p0, Lff1;->f:Lkr0;

    .line 108
    .line 109
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 113
    .line 114
    .line 115
    move-result-wide v1

    .line 116
    invoke-virtual {v0}, Lne1;->a()J

    .line 117
    .line 118
    .line 119
    move-result-wide v4

    .line 120
    cmp-long p0, v1, v4

    .line 121
    .line 122
    if-gez p0, :cond_9a

    .line 123
    .line 124
    invoke-static {}, Lta0;->g()Lta0;

    .line 125
    .line 126
    .line 127
    move-result-object p0

    .line 128
    sget-object v0, Lhf1;->a:Ljava/lang/String;

    .line 129
    .line 130
    new-instance v1, Ljava/lang/StringBuilder;

    .line 131
    .line 132
    const-string v2, "Delaying execution for "

    .line 133
    .line 134
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 138
    .line 139
    .line 140
    const-string v2, " because it is being executed before schedule."

    .line 141
    .line 142
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 143
    .line 144
    .line 145
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 146
    .line 147
    .line 148
    move-result-object v1

    .line 149
    invoke-virtual {p0, v0, v1}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 153
    .line 154
    goto :goto_9c

    .line 155
    :cond_9a
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 156
    .line 157
    :goto_9c
    return-object p0

    .line 158
    nop

    .line 159
    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_37
    .end packed-switch
.end method

###### Class defpackage.xe1 (xe1)
.class public final synthetic Lxe1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lqz;


# instance fields
.field public final synthetic f:Lda0;

.field public final synthetic g:Z

.field public final synthetic h:Ljava/lang/String;

.field public final synthetic i:Lff1;


# direct methods
.method public synthetic constructor <init>(Lda0;ZLjava/lang/String;Lff1;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lxe1;->f:Lda0;

    .line 5
    .line 6
    iput-boolean p2, p0, Lxe1;->g:Z

    .line 7
    .line 8
    iput-object p3, p0, Lxe1;->h:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lxe1;->i:Lff1;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    check-cast p1, Ljava/lang/Throwable;

    .line 2
    .line 3
    instance-of v0, p1, Lve1;

    .line 4
    .line 5
    if-eqz v0, :cond_13

    .line 6
    .line 7
    check-cast p1, Lve1;

    .line 8
    .line 9
    iget p1, p1, Lve1;->f:I

    .line 10
    .line 11
    iget-object v0, p0, Lxe1;->f:Lda0;

    .line 12
    .line 13
    iget-object v0, v0, Lda0;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 14
    .line 15
    const/16 v1, -0x100

    .line 16
    .line 17
    invoke-virtual {v0, v1, p1}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    .line 18
    .line 19
    .line 20
    :cond_13
    iget-boolean p1, p0, Lxe1;->g:Z

    .line 21
    .line 22
    if-eqz p1, :cond_2d

    .line 23
    .line 24
    iget-object p1, p0, Lxe1;->h:Ljava/lang/String;

    .line 25
    .line 26
    if-eqz p1, :cond_2d

    .line 27
    .line 28
    iget-object p0, p0, Lxe1;->i:Lff1;

    .line 29
    .line 30
    iget-object v0, p0, Lff1;->e:Lig;

    .line 31
    .line 32
    iget-object v0, v0, Lig;->m:Ls10;

    .line 33
    .line 34
    iget-object p0, p0, Lff1;->a:Lne1;

    .line 35
    .line 36
    invoke-virtual {p0}, Lne1;->hashCode()I

    .line 37
    .line 38
    .line 39
    move-result p0

    .line 40
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    invoke-static {p0, p1}, Lrl;->B(ILjava/lang/String;)V

    .line 44
    .line 45
    .line 46
    :cond_2d
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 47
    .line 48
    return-object p0
.end method
