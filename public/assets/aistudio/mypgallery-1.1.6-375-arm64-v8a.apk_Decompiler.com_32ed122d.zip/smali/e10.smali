###### Class defpackage.e10 (e10)
.class public final Le10;
.super Lsh;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:Lf10;

.field public k:I


# direct methods
.method public constructor <init>(Lf10;Lsh;)V
    .registers 3

    .line 1
    iput-object p1, p0, Le10;->j:Lf10;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lsh;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Le10;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Le10;->k:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Le10;->k:I

    .line 9
    .line 10
    iget-object p1, p0, Le10;->j:Lf10;

    .line 11
    .line 12
    invoke-static {p1, p0}, Lf10;->a(Lf10;Lsh;)Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method
