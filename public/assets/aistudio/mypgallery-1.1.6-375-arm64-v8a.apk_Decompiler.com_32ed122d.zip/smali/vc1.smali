###### Class defpackage.vc1 (vc1)
.class public final Lvc1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final b:Lvc1;


# instance fields
.field public final a:Lsc1;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x22

    .line 4
    .line 5
    if-lt v0, v1, :cond_b

    .line 6
    .line 7
    sget-object v0, Lrc1;->s:Lvc1;

    .line 8
    .line 9
    sput-object v0, Lvc1;->b:Lvc1;

    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    const/16 v1, 0x1e

    .line 13
    .line 14
    if-lt v0, v1, :cond_14

    .line 15
    .line 16
    sget-object v0, Lpc1;->r:Lvc1;

    .line 17
    .line 18
    sput-object v0, Lvc1;->b:Lvc1;

    .line 19
    .line 20
    return-void

    .line 21
    :cond_14
    sget-object v0, Lsc1;->b:Lvc1;

    .line 22
    .line 23
    sput-object v0, Lvc1;->b:Lvc1;

    .line 24
    .line 25
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 62
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 63
    new-instance v0, Lsc1;

    invoke-direct {v0, p0}, Lsc1;-><init>(Lvc1;)V

    iput-object v0, p0, Lvc1;->a:Lsc1;

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsets;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v1, 0x22

    .line 7
    .line 8
    if-lt v0, v1, :cond_11

    .line 9
    .line 10
    new-instance v0, Lrc1;

    .line 11
    .line 12
    invoke-direct {v0, p0, p1}, Lrc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lvc1;->a:Lsc1;

    .line 16
    .line 17
    return-void

    .line 18
    :cond_11
    const/16 v1, 0x1f

    .line 19
    .line 20
    if-lt v0, v1, :cond_1d

    .line 21
    .line 22
    new-instance v0, Lqc1;

    .line 23
    .line 24
    invoke-direct {v0, p0, p1}, Lqc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 25
    .line 26
    .line 27
    iput-object v0, p0, Lvc1;->a:Lsc1;

    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    const/16 v1, 0x1e

    .line 31
    .line 32
    if-lt v0, v1, :cond_29

    .line 33
    .line 34
    new-instance v0, Lpc1;

    .line 35
    .line 36
    invoke-direct {v0, p0, p1}, Lpc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 37
    .line 38
    .line 39
    iput-object v0, p0, Lvc1;->a:Lsc1;

    .line 40
    .line 41
    return-void

    .line 42
    :cond_29
    const/16 v1, 0x1d

    .line 43
    .line 44
    if-lt v0, v1, :cond_35

    .line 45
    .line 46
    new-instance v0, Loc1;

    .line 47
    .line 48
    invoke-direct {v0, p0, p1}, Loc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 49
    .line 50
    .line 51
    iput-object v0, p0, Lvc1;->a:Lsc1;

    .line 52
    .line 53
    return-void

    .line 54
    :cond_35
    new-instance v0, Lnc1;

    .line 55
    .line 56
    invoke-direct {v0, p0, p1}, Lnc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 57
    .line 58
    .line 59
    iput-object v0, p0, Lvc1;->a:Lsc1;

    .line 60
    .line 61
    return-void
.end method

.method public static a(Lo30;IIII)Lo30;
    .registers 10

    .line 1
    iget v0, p0, Lo30;->a:I

    .line 2
    .line 3
    sub-int/2addr v0, p1

    .line 4
    const/4 v1, 0x0

    .line 5
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iget v2, p0, Lo30;->b:I

    .line 10
    .line 11
    sub-int/2addr v2, p2

    .line 12
    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    iget v3, p0, Lo30;->c:I

    .line 17
    .line 18
    sub-int/2addr v3, p3

    .line 19
    invoke-static {v1, v3}, Ljava/lang/Math;->max(II)I

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    iget v4, p0, Lo30;->d:I

    .line 24
    .line 25
    sub-int/2addr v4, p4

    .line 26
    invoke-static {v1, v4}, Ljava/lang/Math;->max(II)I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-ne v0, p1, :cond_26

    .line 31
    .line 32
    if-ne v2, p2, :cond_26

    .line 33
    .line 34
    if-ne v3, p3, :cond_26

    .line 35
    .line 36
    if-ne v1, p4, :cond_26

    .line 37
    .line 38
    return-object p0

    .line 39
    :cond_26
    invoke-static {v0, v2, v3, v1}, Lo30;->a(IIII)Lo30;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    return-object p0
.end method

.method public static c(Landroid/view/WindowInsets;Landroid/view/View;)Lvc1;
    .registers 4

    .line 1
    new-instance v0, Lvc1;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-direct {v0, p0}, Lvc1;-><init>(Landroid/view/WindowInsets;)V

    .line 7
    .line 8
    .line 9
    if-eqz p1, :cond_29

    .line 10
    .line 11
    invoke-virtual {p1}, Landroid/view/View;->isAttachedToWindow()Z

    .line 12
    .line 13
    .line 14
    move-result p0

    .line 15
    if-eqz p0, :cond_29

    .line 16
    .line 17
    sget-object p0, Lj91;->a:Ljava/util/WeakHashMap;

    .line 18
    .line 19
    invoke-static {p1}, Le91;->a(Landroid/view/View;)Lvc1;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    iget-object v1, v0, Lvc1;->a:Lsc1;

    .line 24
    .line 25
    invoke-virtual {v1, p0}, Lsc1;->p(Lvc1;)V

    .line 26
    .line 27
    .line 28
    invoke-virtual {p1}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    invoke-virtual {v1, p0}, Lsc1;->d(Landroid/view/View;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p1}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 36
    .line 37
    .line 38
    move-result p0

    .line 39
    invoke-virtual {v1, p0}, Lsc1;->r(I)V

    .line 40
    .line 41
    .line 42
    :cond_29
    return-object v0
.end method


# virtual methods
.method public final b()Landroid/view/WindowInsets;
    .registers 2

    .line 1
    iget-object p0, p0, Lvc1;->a:Lsc1;

    .line 2
    .line 3
    instance-of v0, p0, Llc1;

    .line 4
    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    check-cast p0, Llc1;

    .line 8
    .line 9
    iget-object p0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    const/4 p0, 0x0

    .line 13
    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .line 1
    if-ne p0, p1, :cond_4

    .line 2
    .line 3
    const/4 p0, 0x1

    .line 4
    return p0

    .line 5
    :cond_4
    instance-of v0, p1, Lvc1;

    .line 6
    .line 7
    if-nez v0, :cond_a

    .line 8
    .line 9
    const/4 p0, 0x0

    .line 10
    return p0

    .line 11
    :cond_a
    check-cast p1, Lvc1;

    .line 12
    .line 13
    iget-object p0, p0, Lvc1;->a:Lsc1;

    .line 14
    .line 15
    iget-object p1, p1, Lvc1;->a:Lsc1;

    .line 16
    .line 17
    invoke-static {p0, p1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p0

    .line 21
    return p0
.end method

.method public final hashCode()I
    .registers 1

    .line 1
    iget-object p0, p0, Lvc1;->a:Lsc1;

    .line 2
    .line 3
    if-nez p0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x0

    .line 6
    return p0

    .line 7
    :cond_6
    invoke-virtual {p0}, Lsc1;->hashCode()I

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0
.end method
