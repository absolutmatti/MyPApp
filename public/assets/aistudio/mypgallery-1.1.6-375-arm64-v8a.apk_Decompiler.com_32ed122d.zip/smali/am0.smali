###### Class defpackage.am0 (am0)
.class public abstract Lam0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Lmb0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    sget-object v0, Lod1;->h:Lgd1;

    .line 2
    .line 3
    sget-object v1, Lod1;->j:Lkd1;

    .line 4
    .line 5
    invoke-static {}, Lfm0;->v()Lfm0;

    .line 6
    .line 7
    .line 8
    move-result-object v2

    .line 9
    new-instance v3, Lmb0;

    .line 10
    .line 11
    invoke-direct {v3, v0, v1, v2}, Lmb0;-><init>(Lod1;Lod1;Lfm0;)V

    .line 12
    .line 13
    .line 14
    sput-object v3, Lam0;->a:Lmb0;

    .line 15
    .line 16
    return-void
.end method
