###### Class defpackage.qi (qi)
.class public final Lqi;
.super Landroid/database/ContentObserver;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lbl0;)V
    .registers 4

    .line 1
    const/4 v0, 0x3

    .line 2
    iput v0, p0, Lqi;->a:I

    .line 3
    .line 4
    new-instance v0, Landroid/os/Handler;

    .line 5
    .line 6
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 11
    .line 12
    .line 13
    invoke-direct {p0, v0}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lqi;->b:Ljava/lang/Object;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>(Le11;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lqi;->a:I

    .line 20
    iput-object p1, p0, Lqi;->b:Ljava/lang/Object;

    .line 21
    new-instance p1, Landroid/os/Handler;

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    invoke-direct {p0, p1}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Landroid/os/Handler;I)V
    .registers 4

    .line 19
    iput p3, p0, Lqi;->a:I

    iput-object p1, p0, Lqi;->b:Ljava/lang/Object;

    invoke-direct {p0, p2}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    return-void
.end method


# virtual methods
.method public deliverSelfNotifications()Z
    .registers 2

    .line 1
    iget v0, p0, Lqi;->a:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_e

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Landroid/database/ContentObserver;->deliverSelfNotifications()Z

    .line 7
    .line 8
    .line 9
    move-result p0

    .line 10
    return p0

    .line 11
    :pswitch_a
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :pswitch_c
    const/4 p0, 0x1

    .line 14
    return p0

    .line 15
    :pswitch_data_e
    .packed-switch 0x0
        :pswitch_c
        :pswitch_a
    .end packed-switch
.end method

.method public final onChange(Z)V
    .registers 5

    .line 1
    iget v0, p0, Lqi;->a:I

    .line 2
    .line 3
    iget-object v1, p0, Lqi;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_b2

    .line 6
    .line 7
    .line 8
    check-cast v1, Lbl0;

    .line 9
    .line 10
    iget-object p0, v1, Lbl0;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, Lda1;

    .line 13
    .line 14
    iget-object p1, v1, Lbl0;->f:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast p1, Landroid/media/AudioManager;

    .line 17
    .line 18
    invoke-static {p1}, Ln40;->G(Landroid/media/AudioManager;)D

    .line 19
    .line 20
    .line 21
    move-result-wide v0

    .line 22
    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 27
    .line 28
    invoke-virtual {p0, p1, v0}, Lda1;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    return-void

    .line 32
    :pswitch_1f
    invoke-super {p0, p1}, Landroid/database/ContentObserver;->onChange(Z)V

    .line 33
    .line 34
    .line 35
    check-cast v1, Lms0;

    .line 36
    .line 37
    iget-object p0, v1, Lms0;->g:Landroid/content/Context;

    .line 38
    .line 39
    if-eqz p0, :cond_89

    .line 40
    .line 41
    :try_start_28
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    const-string p1, "screen_brightness"

    .line 46
    .line 47
    invoke-static {p0, p1}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    .line 48
    .line 49
    .line 50
    move-result p0

    .line 51
    int-to-float p0, p0

    .line 52
    iget-object p1, v1, Lms0;->n:Lnw;

    .line 53
    .line 54
    sget-object v0, Lms0;->s:[Ld60;

    .line 55
    .line 56
    const/4 v2, 0x0

    .line 57
    aget-object v2, v0, v2

    .line 58
    .line 59
    invoke-virtual {p1, v1, v2}, Lnw;->m(Ljava/lang/Object;Ld60;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object p1

    .line 63
    check-cast p1, Ljava/lang/Number;

    .line 64
    .line 65
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 66
    .line 67
    .line 68
    move-result p1

    .line 69
    div-float/2addr p0, p1

    .line 70
    iget-object p1, v1, Lms0;->o:Lnw;

    .line 71
    .line 72
    const/4 v2, 0x1

    .line 73
    aget-object v0, v0, v2

    .line 74
    .line 75
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 76
    .line 77
    .line 78
    move-result-object p0

    .line 79
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    .line 84
    .line 85
    iput-object p0, p1, Lnw;->g:Ljava/lang/Object;

    .line 86
    .line 87
    iget-object p0, v1, Lms0;->j:Lnw;

    .line 88
    .line 89
    if-eqz p0, :cond_6b

    .line 90
    .line 91
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast p0, Ldr;

    .line 94
    .line 95
    if-eqz p0, :cond_6b

    .line 96
    .line 97
    invoke-virtual {v1}, Lms0;->b()F

    .line 98
    .line 99
    .line 100
    move-result p1

    .line 101
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    invoke-virtual {p0, p1}, Ldr;->a(Ljava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    :cond_6b
    iget-object p0, v1, Lms0;->p:Ljava/lang/Float;

    .line 109
    .line 110
    if-nez p0, :cond_89

    .line 111
    .line 112
    iget-object p0, v1, Lms0;->l:Lnw;

    .line 113
    .line 114
    if-eqz p0, :cond_89

    .line 115
    .line 116
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 117
    .line 118
    check-cast p0, Ldr;

    .line 119
    .line 120
    if-eqz p0, :cond_89

    .line 121
    .line 122
    invoke-virtual {v1}, Lms0;->b()F

    .line 123
    .line 124
    .line 125
    move-result p1

    .line 126
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 127
    .line 128
    .line 129
    move-result-object p1

    .line 130
    invoke-virtual {p0, p1}, Ldr;->a(Ljava/lang/Object;)V
    :try_end_84
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_28 .. :try_end_84} :catch_85

    .line 131
    .line 132
    .line 133
    goto :goto_89

    .line 134
    :catch_85
    move-exception p0

    .line 135
    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    .line 136
    .line 137
    .line 138
    :cond_89
    :goto_89
    return-void

    .line 139
    :pswitch_8a
    invoke-super {p0, p1}, Landroid/database/ContentObserver;->onChange(Z)V

    .line 140
    .line 141
    .line 142
    check-cast v1, Lvw;

    .line 143
    .line 144
    iget-object p0, v1, Lvw;->n:Ljv;

    .line 145
    .line 146
    if-nez p0, :cond_94

    .line 147
    .line 148
    goto :goto_97

    .line 149
    :cond_94
    invoke-virtual {v1}, Lvw;->d()V

    .line 150
    .line 151
    .line 152
    :goto_97
    return-void

    .line 153
    :pswitch_98
    check-cast v1, Le11;

    .line 154
    .line 155
    iget-boolean p0, v1, Lsi;->g:Z

    .line 156
    .line 157
    if-eqz p0, :cond_b0

    .line 158
    .line 159
    iget-object p0, v1, Lsi;->h:Landroid/database/Cursor;

    .line 160
    .line 161
    if-eqz p0, :cond_b0

    .line 162
    .line 163
    invoke-interface {p0}, Landroid/database/Cursor;->isClosed()Z

    .line 164
    .line 165
    .line 166
    move-result p0

    .line 167
    if-nez p0, :cond_b0

    .line 168
    .line 169
    iget-object p0, v1, Lsi;->h:Landroid/database/Cursor;

    .line 170
    .line 171
    invoke-interface {p0}, Landroid/database/Cursor;->requery()Z

    .line 172
    .line 173
    .line 174
    move-result p0

    .line 175
    iput-boolean p0, v1, Lsi;->f:Z

    .line 176
    .line 177
    :cond_b0
    return-void

    .line 178
    nop

    .line 179
    :pswitch_data_b2
    .packed-switch 0x0
        :pswitch_98
        :pswitch_8a
        :pswitch_1f
    .end packed-switch
.end method
