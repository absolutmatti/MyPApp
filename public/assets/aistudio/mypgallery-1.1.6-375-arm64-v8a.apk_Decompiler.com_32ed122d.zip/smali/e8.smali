###### Class defpackage.e8 (e8)
.class public abstract Le8;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# direct methods
.method public static a()I
    .registers 1

    .line 1
    const/16 v0, 0x200

    .line 2
    .line 3
    return v0
.end method
