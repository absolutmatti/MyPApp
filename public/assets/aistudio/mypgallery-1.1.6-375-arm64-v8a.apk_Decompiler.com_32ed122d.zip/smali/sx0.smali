###### Class defpackage.sx0 (sx0)
.class public final Lsx0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lwr;


# instance fields
.field public final a:Landroidx/window/sidecar/SidecarInterface;

.field public final b:Lox0;

.field public final c:Ljava/util/LinkedHashMap;

.field public final d:Ljava/util/LinkedHashMap;

.field public e:Ld8;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-static {p1}, Lqx0;->a(Landroid/content/Context;)Landroidx/window/sidecar/SidecarInterface;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    new-instance v0, Lox0;

    .line 9
    .line 10
    invoke-direct {v0}, Lox0;-><init>()V

    .line 11
    .line 12
    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 17
    .line 18
    iput-object v0, p0, Lsx0;->b:Lox0;

    .line 19
    .line 20
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 21
    .line 22
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object p1, p0, Lsx0;->c:Ljava/util/LinkedHashMap;

    .line 26
    .line 27
    new-instance p1, Ljava/util/LinkedHashMap;

    .line 28
    .line 29
    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, Lsx0;->d:Ljava/util/LinkedHashMap;

    .line 33
    .line 34
    return-void
.end method


# virtual methods
.method public final a(Landroid/app/Activity;)Lzc1;
    .registers 4

    .line 1
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 v0, 0x0

    .line 6
    if-eqz p1, :cond_10

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 9
    .line 10
    .line 11
    move-result-object p1

    .line 12
    if-eqz p1, :cond_10

    .line 13
    .line 14
    iget-object p1, p1, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    .line 15
    .line 16
    goto :goto_11

    .line 17
    :cond_10
    move-object p1, v0

    .line 18
    :goto_11
    if-nez p1, :cond_1b

    .line 19
    .line 20
    new-instance p0, Lzc1;

    .line 21
    .line 22
    sget-object p1, Luq;->f:Luq;

    .line 23
    .line 24
    invoke-direct {p0, p1}, Lzc1;-><init>(Ljava/util/List;)V

    .line 25
    .line 26
    .line 27
    return-object p0

    .line 28
    :cond_1b
    iget-object v1, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 29
    .line 30
    if-eqz v1, :cond_23

    .line 31
    .line 32
    invoke-interface {v1, p1}, Landroidx/window/sidecar/SidecarInterface;->getWindowLayoutInfo(Landroid/os/IBinder;)Landroidx/window/sidecar/SidecarWindowLayoutInfo;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    :cond_23
    iget-object p1, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 37
    .line 38
    if-eqz p1, :cond_2d

    .line 39
    .line 40
    invoke-interface {p1}, Landroidx/window/sidecar/SidecarInterface;->getDeviceState()Landroidx/window/sidecar/SidecarDeviceState;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    if-nez p1, :cond_32

    .line 45
    .line 46
    :cond_2d
    new-instance p1, Landroidx/window/sidecar/SidecarDeviceState;

    .line 47
    .line 48
    invoke-direct {p1}, Landroidx/window/sidecar/SidecarDeviceState;-><init>()V

    .line 49
    .line 50
    .line 51
    :cond_32
    iget-object p0, p0, Lsx0;->b:Lox0;

    .line 52
    .line 53
    invoke-virtual {p0, v0, p1}, Lox0;->c(Landroidx/window/sidecar/SidecarWindowLayoutInfo;Landroidx/window/sidecar/SidecarDeviceState;)Lzc1;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    return-object p0
.end method

.method public final b(Landroid/app/Activity;)V
    .registers 7

    .line 1
    invoke-virtual {p1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_10

    .line 7
    .line 8
    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    if-eqz v0, :cond_10

    .line 13
    .line 14
    iget-object v0, v0, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    .line 15
    .line 16
    goto :goto_11

    .line 17
    :cond_10
    move-object v0, v1

    .line 18
    :goto_11
    if-nez v0, :cond_14

    .line 19
    .line 20
    goto :goto_68

    .line 21
    :cond_14
    iget-object v2, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 22
    .line 23
    if-eqz v2, :cond_1b

    .line 24
    .line 25
    invoke-interface {v2, v0}, Landroidx/window/sidecar/SidecarInterface;->onWindowLayoutChangeListenerRemoved(Landroid/os/IBinder;)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    iget-object v2, p0, Lsx0;->d:Ljava/util/LinkedHashMap;

    .line 29
    .line 30
    invoke-virtual {v2, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v3

    .line 34
    check-cast v3, Lch;

    .line 35
    .line 36
    if-nez v3, :cond_26

    .line 37
    .line 38
    goto :goto_33

    .line 39
    :cond_26
    instance-of v4, p1, Luh0;

    .line 40
    .line 41
    if-eqz v4, :cond_30

    .line 42
    .line 43
    move-object v4, p1

    .line 44
    check-cast v4, Luh0;

    .line 45
    .line 46
    invoke-interface {v4, v3}, Luh0;->removeOnConfigurationChangedListener(Lch;)V

    .line 47
    .line 48
    .line 49
    :cond_30
    invoke-interface {v2, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    :goto_33
    iget-object v2, p0, Lsx0;->e:Ld8;

    .line 53
    .line 54
    if-eqz v2, :cond_50

    .line 55
    .line 56
    iget-object v3, v2, Ld8;->g:Ljava/lang/Object;

    .line 57
    .line 58
    check-cast v3, Ljava/util/concurrent/locks/ReentrantLock;

    .line 59
    .line 60
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 61
    .line 62
    .line 63
    :try_start_3e
    iget-object v2, v2, Ld8;->h:Ljava/lang/Object;

    .line 64
    .line 65
    check-cast v2, Ljava/util/WeakHashMap;

    .line 66
    .line 67
    invoke-virtual {v2, p1, v1}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_47
    .catchall {:try_start_3e .. :try_end_47} :catchall_4b

    .line 71
    .line 72
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 73
    .line 74
    .line 75
    goto :goto_50

    .line 76
    :catchall_4b
    move-exception p0

    .line 77
    invoke-virtual {v3}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 78
    .line 79
    .line 80
    throw p0

    .line 81
    :cond_50
    :goto_50
    iget-object p1, p0, Lsx0;->c:Ljava/util/LinkedHashMap;

    .line 82
    .line 83
    invoke-interface {p1}, Ljava/util/Map;->size()I

    .line 84
    .line 85
    .line 86
    move-result v1

    .line 87
    const/4 v2, 0x1

    .line 88
    if-ne v1, v2, :cond_5b

    .line 89
    .line 90
    move v1, v2

    .line 91
    goto :goto_5c

    .line 92
    :cond_5b
    const/4 v1, 0x0

    .line 93
    :goto_5c
    invoke-interface {p1, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    if-eqz v1, :cond_68

    .line 97
    .line 98
    iget-object p0, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 99
    .line 100
    if-eqz p0, :cond_68

    .line 101
    .line 102
    invoke-interface {p0, v2}, Landroidx/window/sidecar/SidecarInterface;->onDeviceStateListenersChanged(Z)V

    .line 103
    .line 104
    .line 105
    :cond_68
    :goto_68
    return-void
.end method

.method public final c(Landroid/os/IBinder;Landroid/app/Activity;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lsx0;->c:Ljava/util/LinkedHashMap;

    .line 2
    .line 3
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 7
    .line 8
    if-eqz v1, :cond_c

    .line 9
    .line 10
    invoke-interface {v1, p1}, Landroidx/window/sidecar/SidecarInterface;->onWindowLayoutChangeListenerAdded(Landroid/os/IBinder;)V

    .line 11
    .line 12
    .line 13
    :cond_c
    invoke-interface {v0}, Ljava/util/Map;->size()I

    .line 14
    .line 15
    .line 16
    move-result p1

    .line 17
    const/4 v0, 0x1

    .line 18
    if-ne p1, v0, :cond_1b

    .line 19
    .line 20
    iget-object p1, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 21
    .line 22
    if-eqz p1, :cond_1b

    .line 23
    .line 24
    const/4 v0, 0x0

    .line 25
    invoke-interface {p1, v0}, Landroidx/window/sidecar/SidecarInterface;->onDeviceStateListenersChanged(Z)V

    .line 26
    .line 27
    .line 28
    :cond_1b
    iget-object p1, p0, Lsx0;->e:Ld8;

    .line 29
    .line 30
    if-eqz p1, :cond_26

    .line 31
    .line 32
    invoke-virtual {p0, p2}, Lsx0;->a(Landroid/app/Activity;)Lzc1;

    .line 33
    .line 34
    .line 35
    move-result-object v0

    .line 36
    invoke-virtual {p1, p2, v0}, Ld8;->t(Landroid/app/Activity;Lzc1;)V

    .line 37
    .line 38
    .line 39
    :cond_26
    iget-object p1, p0, Lsx0;->d:Ljava/util/LinkedHashMap;

    .line 40
    .line 41
    invoke-virtual {p1, p2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    if-nez v0, :cond_3f

    .line 46
    .line 47
    instance-of v0, p2, Luh0;

    .line 48
    .line 49
    if-eqz v0, :cond_3f

    .line 50
    .line 51
    new-instance v0, Lpx0;

    .line 52
    .line 53
    invoke-direct {v0, p0, p2}, Lpx0;-><init>(Lsx0;Landroid/app/Activity;)V

    .line 54
    .line 55
    .line 56
    invoke-interface {p1, p2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    check-cast p2, Luh0;

    .line 60
    .line 61
    invoke-interface {p2, v0}, Luh0;->addOnConfigurationChangedListener(Lch;)V

    .line 62
    .line 63
    .line 64
    :cond_3f
    return-void
.end method

.method public final d(Lns0;)V
    .registers 4

    .line 1
    new-instance v0, Ld8;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    iput-object p1, v0, Ld8;->f:Ljava/lang/Object;

    .line 7
    .line 8
    new-instance p1, Ljava/util/concurrent/locks/ReentrantLock;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, v0, Ld8;->g:Ljava/lang/Object;

    .line 14
    .line 15
    new-instance p1, Ljava/util/WeakHashMap;

    .line 16
    .line 17
    invoke-direct {p1}, Ljava/util/WeakHashMap;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, v0, Ld8;->h:Ljava/lang/Object;

    .line 21
    .line 22
    iput-object v0, p0, Lsx0;->e:Ld8;

    .line 23
    .line 24
    iget-object p1, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 25
    .line 26
    if-eqz p1, :cond_2e

    .line 27
    .line 28
    new-instance v0, Landroidx/window/layout/adapter/sidecar/DistinctElementSidecarCallback;

    .line 29
    .line 30
    new-instance v1, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;

    .line 31
    .line 32
    invoke-direct {v1, p0}, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;-><init>(Lsx0;)V

    .line 33
    .line 34
    .line 35
    check-cast v1, Landroidx/window/sidecar/SidecarInterface$SidecarCallback;

    .line 36
    .line 37
    iget-object p0, p0, Lsx0;->b:Lox0;

    .line 38
    .line 39
    invoke-direct {v0, p0, v1}, Landroidx/window/layout/adapter/sidecar/DistinctElementSidecarCallback;-><init>(Lox0;Landroidx/window/sidecar/SidecarInterface$SidecarCallback;)V

    .line 40
    .line 41
    .line 42
    check-cast v0, Landroidx/window/sidecar/SidecarInterface$SidecarCallback;

    .line 43
    .line 44
    invoke-interface {p1, v0}, Landroidx/window/sidecar/SidecarInterface;->setSidecarCallback(Landroidx/window/sidecar/SidecarInterface$SidecarCallback;)V

    .line 45
    .line 46
    .line 47
    :cond_2e
    return-void
.end method

.method public final e()Z
    .registers 11

    .line 1
    const-string v0, "Illegal return type for \'onWindowLayoutChangeListenerRemoved\': "

    .line 2
    .line 3
    const-string v1, "Illegal return type for \'onWindowLayoutChangeListenerAdded\': "

    .line 4
    .line 5
    const-string v2, "Illegal return type for \'getWindowLayoutInfo\': "

    .line 6
    .line 7
    const-string v3, "Illegal return type for \'setSidecarCallback\': "

    .line 8
    .line 9
    :try_start_8
    iget-object v4, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 10
    .line 11
    const/4 v5, 0x0

    .line 12
    if-eqz v4, :cond_20

    .line 13
    .line 14
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    if-eqz v4, :cond_20

    .line 19
    .line 20
    const-string v6, "setSidecarCallback"

    .line 21
    .line 22
    const-class v7, Landroidx/window/sidecar/SidecarInterface$SidecarCallback;

    .line 23
    .line 24
    filled-new-array {v7}, [Ljava/lang/Class;

    .line 25
    .line 26
    .line 27
    move-result-object v7

    .line 28
    invoke-virtual {v4, v6, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 29
    .line 30
    .line 31
    move-result-object v4

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move-object v4, v5

    .line 34
    :goto_21
    if-eqz v4, :cond_28

    .line 35
    .line 36
    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    move-result-object v4

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move-object v4, v5

    .line 42
    :goto_29
    sget-object v6, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    .line 43
    .line 44
    invoke-static {v4, v6}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    move-result v7

    .line 48
    if-eqz v7, :cond_182

    .line 49
    .line 50
    iget-object v3, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 51
    .line 52
    if-eqz v3, :cond_38

    .line 53
    .line 54
    invoke-interface {v3}, Landroidx/window/sidecar/SidecarInterface;->getDeviceState()Landroidx/window/sidecar/SidecarDeviceState;

    .line 55
    .line 56
    .line 57
    :cond_38
    iget-object v3, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 58
    .line 59
    const/4 v4, 0x1

    .line 60
    if-eqz v3, :cond_40

    .line 61
    .line 62
    invoke-interface {v3, v4}, Landroidx/window/sidecar/SidecarInterface;->onDeviceStateListenersChanged(Z)V

    .line 63
    .line 64
    .line 65
    :cond_40
    iget-object v3, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;
    :try_end_42
    .catchall {:try_start_8 .. :try_end_42} :catchall_194

    .line 66
    .line 67
    const-class v7, Landroid/os/IBinder;

    .line 68
    .line 69
    if-eqz v3, :cond_57

    .line 70
    .line 71
    :try_start_46
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    if-eqz v3, :cond_57

    .line 76
    .line 77
    const-string v8, "getWindowLayoutInfo"

    .line 78
    .line 79
    filled-new-array {v7}, [Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    move-result-object v9

    .line 83
    invoke-virtual {v3, v8, v9}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    goto :goto_58

    .line 88
    :cond_57
    move-object v3, v5

    .line 89
    :goto_58
    if-eqz v3, :cond_5f

    .line 90
    .line 91
    invoke-virtual {v3}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    goto :goto_60

    .line 96
    :cond_5f
    move-object v3, v5

    .line 97
    :goto_60
    const-class v8, Landroidx/window/sidecar/SidecarWindowLayoutInfo;

    .line 98
    .line 99
    invoke-static {v3, v8}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 100
    .line 101
    .line 102
    move-result v8

    .line 103
    if-eqz v8, :cond_170

    .line 104
    .line 105
    iget-object v2, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 106
    .line 107
    if-eqz v2, :cond_7d

    .line 108
    .line 109
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    .line 111
    .line 112
    move-result-object v2

    .line 113
    if-eqz v2, :cond_7d

    .line 114
    .line 115
    const-string v3, "onWindowLayoutChangeListenerAdded"

    .line 116
    .line 117
    filled-new-array {v7}, [Ljava/lang/Class;

    .line 118
    .line 119
    .line 120
    move-result-object v8

    .line 121
    invoke-virtual {v2, v3, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    goto :goto_7e

    .line 126
    :cond_7d
    move-object v2, v5

    .line 127
    :goto_7e
    if-eqz v2, :cond_85

    .line 128
    .line 129
    invoke-virtual {v2}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    goto :goto_86

    .line 134
    :cond_85
    move-object v2, v5

    .line 135
    :goto_86
    invoke-static {v2, v6}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 136
    .line 137
    .line 138
    move-result v3

    .line 139
    if-eqz v3, :cond_15e

    .line 140
    .line 141
    iget-object p0, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 142
    .line 143
    if-eqz p0, :cond_a1

    .line 144
    .line 145
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    .line 147
    .line 148
    move-result-object p0

    .line 149
    if-eqz p0, :cond_a1

    .line 150
    .line 151
    const-string v1, "onWindowLayoutChangeListenerRemoved"

    .line 152
    .line 153
    filled-new-array {v7}, [Ljava/lang/Class;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-virtual {p0, v1, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    goto :goto_a2

    .line 162
    :cond_a1
    move-object p0, v5

    .line 163
    :goto_a2
    if-eqz p0, :cond_a9

    .line 164
    .line 165
    invoke-virtual {p0}, Ljava/lang/reflect/Method;->getReturnType()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    move-result-object p0

    .line 169
    goto :goto_aa

    .line 170
    :cond_a9
    move-object p0, v5

    .line 171
    :goto_aa
    invoke-static {p0, v6}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 172
    .line 173
    .line 174
    move-result v1

    .line 175
    if-eqz v1, :cond_14c

    .line 176
    .line 177
    new-instance p0, Landroidx/window/sidecar/SidecarDeviceState;

    .line 178
    .line 179
    invoke-direct {p0}, Landroidx/window/sidecar/SidecarDeviceState;-><init>()V
    :try_end_b5
    .catchall {:try_start_46 .. :try_end_b5} :catchall_194

    .line 180
    .line 181
    .line 182
    const/4 v0, 0x3

    .line 183
    :try_start_b6
    iput v0, p0, Landroidx/window/sidecar/SidecarDeviceState;->posture:I
    :try_end_b8
    .catch Ljava/lang/NoSuchFieldError; {:try_start_b6 .. :try_end_b8} :catch_b9
    .catchall {:try_start_b6 .. :try_end_b8} :catchall_194

    .line 184
    .line 185
    goto :goto_e9

    .line 186
    :catch_b9
    :try_start_b9
    const-class v1, Landroidx/window/sidecar/SidecarDeviceState;

    .line 187
    .line 188
    const-string v2, "setPosture"

    .line 189
    .line 190
    sget-object v3, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    .line 191
    .line 192
    filled-new-array {v3}, [Ljava/lang/Class;

    .line 193
    .line 194
    .line 195
    move-result-object v3

    .line 196
    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 197
    .line 198
    .line 199
    move-result-object v1

    .line 200
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 201
    .line 202
    .line 203
    move-result-object v2

    .line 204
    filled-new-array {v2}, [Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v2

    .line 208
    invoke-virtual {v1, p0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    const-class v1, Landroidx/window/sidecar/SidecarDeviceState;

    .line 212
    .line 213
    const-string v2, "getPosture"

    .line 214
    .line 215
    invoke-virtual {v1, v2, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    invoke-virtual {v1, p0, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 220
    .line 221
    .line 222
    move-result-object p0

    .line 223
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 224
    .line 225
    .line 226
    check-cast p0, Ljava/lang/Integer;

    .line 227
    .line 228
    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    .line 229
    .line 230
    .line 231
    move-result p0

    .line 232
    if-ne p0, v0, :cond_144

    .line 233
    .line 234
    :goto_e9
    new-instance p0, Landroidx/window/sidecar/SidecarDisplayFeature;

    .line 235
    .line 236
    invoke-direct {p0}, Landroidx/window/sidecar/SidecarDisplayFeature;-><init>()V

    .line 237
    .line 238
    .line 239
    invoke-virtual {p0}, Landroidx/window/sidecar/SidecarDisplayFeature;->getRect()Landroid/graphics/Rect;

    .line 240
    .line 241
    .line 242
    move-result-object v0

    .line 243
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 244
    .line 245
    .line 246
    invoke-virtual {p0, v0}, Landroidx/window/sidecar/SidecarDisplayFeature;->setRect(Landroid/graphics/Rect;)V

    .line 247
    .line 248
    .line 249
    invoke-virtual {p0}, Landroidx/window/sidecar/SidecarDisplayFeature;->getType()I

    .line 250
    .line 251
    .line 252
    invoke-virtual {p0, v4}, Landroidx/window/sidecar/SidecarDisplayFeature;->setType(I)V

    .line 253
    .line 254
    .line 255
    new-instance v0, Landroidx/window/sidecar/SidecarWindowLayoutInfo;

    .line 256
    .line 257
    invoke-direct {v0}, Landroidx/window/sidecar/SidecarWindowLayoutInfo;-><init>()V
    :try_end_103
    .catchall {:try_start_b9 .. :try_end_103} :catchall_194

    .line 258
    .line 259
    .line 260
    :try_start_103
    iget-object p0, v0, Landroidx/window/sidecar/SidecarWindowLayoutInfo;->displayFeatures:Ljava/util/List;
    :try_end_105
    .catch Ljava/lang/NoSuchFieldError; {:try_start_103 .. :try_end_105} :catch_107
    .catchall {:try_start_103 .. :try_end_105} :catchall_194

    .line 261
    .line 262
    goto/16 :goto_195

    .line 263
    .line 264
    :catch_107
    :try_start_107
    new-instance v1, Ljava/util/ArrayList;

    .line 265
    .line 266
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 267
    .line 268
    .line 269
    invoke-interface {v1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 270
    .line 271
    .line 272
    const-class p0, Landroidx/window/sidecar/SidecarWindowLayoutInfo;

    .line 273
    .line 274
    const-string v2, "setDisplayFeatures"

    .line 275
    .line 276
    const-class v3, Ljava/util/List;

    .line 277
    .line 278
    filled-new-array {v3}, [Ljava/lang/Class;

    .line 279
    .line 280
    .line 281
    move-result-object v3

    .line 282
    invoke-virtual {p0, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 283
    .line 284
    .line 285
    move-result-object p0

    .line 286
    filled-new-array {v1}, [Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v2

    .line 290
    invoke-virtual {p0, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    const-class p0, Landroidx/window/sidecar/SidecarWindowLayoutInfo;

    .line 294
    .line 295
    const-string v2, "getDisplayFeatures"

    .line 296
    .line 297
    invoke-virtual {p0, v2, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 298
    .line 299
    .line 300
    move-result-object p0

    .line 301
    invoke-virtual {p0, v0, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 302
    .line 303
    .line 304
    move-result-object p0

    .line 305
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 306
    .line 307
    .line 308
    check-cast p0, Ljava/util/List;

    .line 309
    .line 310
    invoke-virtual {v1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 311
    .line 312
    .line 313
    move-result p0

    .line 314
    if-eqz p0, :cond_13c

    .line 315
    .line 316
    goto :goto_195

    .line 317
    :cond_13c
    new-instance p0, Ljava/lang/Exception;

    .line 318
    .line 319
    const-string v0, "Invalid display feature getter/setter"

    .line 320
    .line 321
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 322
    .line 323
    .line 324
    throw p0

    .line 325
    :cond_144
    new-instance p0, Ljava/lang/Exception;

    .line 326
    .line 327
    const-string v0, "Invalid device posture getter/setter"

    .line 328
    .line 329
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    throw p0

    .line 333
    :cond_14c
    new-instance v1, Ljava/lang/NoSuchMethodException;

    .line 334
    .line 335
    new-instance v2, Ljava/lang/StringBuilder;

    .line 336
    .line 337
    invoke-direct {v2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 338
    .line 339
    .line 340
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 341
    .line 342
    .line 343
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 344
    .line 345
    .line 346
    move-result-object p0

    .line 347
    invoke-direct {v1, p0}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    .line 348
    .line 349
    .line 350
    throw v1

    .line 351
    :cond_15e
    new-instance p0, Ljava/lang/NoSuchMethodException;

    .line 352
    .line 353
    new-instance v0, Ljava/lang/StringBuilder;

    .line 354
    .line 355
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 356
    .line 357
    .line 358
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 359
    .line 360
    .line 361
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 362
    .line 363
    .line 364
    move-result-object v0

    .line 365
    invoke-direct {p0, v0}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    .line 366
    .line 367
    .line 368
    throw p0

    .line 369
    :cond_170
    new-instance p0, Ljava/lang/NoSuchMethodException;

    .line 370
    .line 371
    new-instance v0, Ljava/lang/StringBuilder;

    .line 372
    .line 373
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 374
    .line 375
    .line 376
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 377
    .line 378
    .line 379
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 380
    .line 381
    .line 382
    move-result-object v0

    .line 383
    invoke-direct {p0, v0}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    .line 384
    .line 385
    .line 386
    throw p0

    .line 387
    :cond_182
    new-instance p0, Ljava/lang/NoSuchMethodException;

    .line 388
    .line 389
    new-instance v0, Ljava/lang/StringBuilder;

    .line 390
    .line 391
    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 392
    .line 393
    .line 394
    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 395
    .line 396
    .line 397
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 398
    .line 399
    .line 400
    move-result-object v0

    .line 401
    invoke-direct {p0, v0}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    .line 402
    .line 403
    .line 404
    throw p0
    :try_end_194
    .catchall {:try_start_107 .. :try_end_194} :catchall_194

    .line 405
    :catchall_194
    const/4 v4, 0x0

    .line 406
    :goto_195
    return v4
.end method

###### Class androidx.window.layout.adapter.sidecar.SidecarCompat$TranslatingCallback (androidx.window.layout.adapter.sidecar.SidecarCompat$TranslatingCallback)
.class public final Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroidx/window/sidecar/SidecarInterface$SidecarCallback;


# instance fields
.field public final synthetic a:Lsx0;


# direct methods
.method public constructor <init>(Lsx0;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;->a:Lsx0;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public onDeviceStateChanged(Landroidx/window/sidecar/SidecarDeviceState;)V
    .registers 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;->a:Lsx0;

    .line 5
    .line 6
    iget-object v0, v0, Lsx0;->c:Ljava/util/LinkedHashMap;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 9
    .line 10
    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/lang/Iterable;

    .line 13
    .line 14
    iget-object p0, p0, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;->a:Lsx0;

    .line 15
    .line 16
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object v0

    .line 20
    :cond_13
    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_4a

    .line 25
    .line 26
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Landroid/app/Activity;

    .line 31
    .line 32
    const/4 v2, 0x0

    .line 33
    if-eqz v1, :cond_31

    .line 34
    .line 35
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 36
    .line 37
    .line 38
    move-result-object v3

    .line 39
    if-eqz v3, :cond_31

    .line 40
    .line 41
    invoke-virtual {v3}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    .line 42
    .line 43
    .line 44
    move-result-object v3

    .line 45
    if-eqz v3, :cond_31

    .line 46
    .line 47
    iget-object v3, v3, Landroid/view/WindowManager$LayoutParams;->token:Landroid/os/IBinder;

    .line 48
    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move-object v3, v2

    .line 51
    :goto_32
    if-eqz v3, :cond_3c

    .line 52
    .line 53
    iget-object v4, p0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 54
    .line 55
    if-eqz v4, :cond_3c

    .line 56
    .line 57
    invoke-interface {v4, v3}, Landroidx/window/sidecar/SidecarInterface;->getWindowLayoutInfo(Landroid/os/IBinder;)Landroidx/window/sidecar/SidecarWindowLayoutInfo;

    .line 58
    .line 59
    .line 60
    move-result-object v2

    .line 61
    :cond_3c
    iget-object v3, p0, Lsx0;->e:Ld8;

    .line 62
    .line 63
    if-eqz v3, :cond_13

    .line 64
    .line 65
    iget-object v4, p0, Lsx0;->b:Lox0;

    .line 66
    .line 67
    invoke-virtual {v4, v2, p1}, Lox0;->c(Landroidx/window/sidecar/SidecarWindowLayoutInfo;Landroidx/window/sidecar/SidecarDeviceState;)Lzc1;

    .line 68
    .line 69
    .line 70
    move-result-object v2

    .line 71
    invoke-virtual {v3, v1, v2}, Ld8;->t(Landroid/app/Activity;Lzc1;)V

    .line 72
    .line 73
    .line 74
    goto :goto_13

    .line 75
    :cond_4a
    return-void
.end method

.method public onWindowLayoutChanged(Landroid/os/IBinder;Landroidx/window/sidecar/SidecarWindowLayoutInfo;)V
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;->a:Lsx0;

    .line 8
    .line 9
    iget-object v0, v0, Lsx0;->c:Ljava/util/LinkedHashMap;

    .line 10
    .line 11
    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    check-cast p1, Landroid/app/Activity;

    .line 16
    .line 17
    if-nez p1, :cond_1a

    .line 18
    .line 19
    const-string p0, "SidecarCompat"

    .line 20
    .line 21
    const-string p1, "Unable to resolve activity from window token. Missing a call to #onWindowLayoutChangeListenerAdded()?"

    .line 22
    .line 23
    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 24
    .line 25
    .line 26
    return-void

    .line 27
    :cond_1a
    iget-object v0, p0, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;->a:Lsx0;

    .line 28
    .line 29
    iget-object v1, v0, Lsx0;->b:Lox0;

    .line 30
    .line 31
    iget-object v0, v0, Lsx0;->a:Landroidx/window/sidecar/SidecarInterface;

    .line 32
    .line 33
    if-eqz v0, :cond_28

    .line 34
    .line 35
    invoke-interface {v0}, Landroidx/window/sidecar/SidecarInterface;->getDeviceState()Landroidx/window/sidecar/SidecarDeviceState;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    if-nez v0, :cond_2d

    .line 40
    .line 41
    :cond_28
    new-instance v0, Landroidx/window/sidecar/SidecarDeviceState;

    .line 42
    .line 43
    invoke-direct {v0}, Landroidx/window/sidecar/SidecarDeviceState;-><init>()V

    .line 44
    .line 45
    .line 46
    :cond_2d
    invoke-virtual {v1, p2, v0}, Lox0;->c(Landroidx/window/sidecar/SidecarWindowLayoutInfo;Landroidx/window/sidecar/SidecarDeviceState;)Lzc1;

    .line 47
    .line 48
    .line 49
    move-result-object p2

    .line 50
    iget-object p0, p0, Landroidx/window/layout/adapter/sidecar/SidecarCompat$TranslatingCallback;->a:Lsx0;

    .line 51
    .line 52
    iget-object p0, p0, Lsx0;->e:Ld8;

    .line 53
    .line 54
    if-eqz p0, :cond_3a

    .line 55
    .line 56
    invoke-virtual {p0, p1, p2}, Ld8;->t(Landroid/app/Activity;Lzc1;)V

    .line 57
    .line 58
    .line 59
    :cond_3a
    return-void
.end method

###### Class defpackage.px0 (px0)
.class public final synthetic Lpx0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lch;


# instance fields
.field public final synthetic a:Lsx0;

.field public final synthetic b:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Lsx0;Landroid/app/Activity;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lpx0;->a:Lsx0;

    .line 5
    .line 6
    iput-object p2, p0, Lpx0;->b:Landroid/app/Activity;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final accept(Ljava/lang/Object;)V
    .registers 3

    .line 1
    check-cast p1, Landroid/content/res/Configuration;

    .line 2
    .line 3
    iget-object p1, p0, Lpx0;->a:Lsx0;

    .line 4
    .line 5
    iget-object v0, p1, Lsx0;->e:Ld8;

    .line 6
    .line 7
    if-eqz v0, :cond_11

    .line 8
    .line 9
    iget-object p0, p0, Lpx0;->b:Landroid/app/Activity;

    .line 10
    .line 11
    invoke-virtual {p1, p0}, Lsx0;->a(Landroid/app/Activity;)Lzc1;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    invoke-virtual {v0, p0, p1}, Ld8;->t(Landroid/app/Activity;Lzc1;)V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method
