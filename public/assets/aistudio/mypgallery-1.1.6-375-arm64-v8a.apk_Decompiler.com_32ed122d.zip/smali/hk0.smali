###### Class defpackage.hk0 (hk0)
.class public final Lhk0;
.super Ltv;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public m:Lc1;


# virtual methods
.method public final onHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 4

    .line 1
    iget-object v0, p0, Lhk0;->m:Lc1;

    .line 2
    .line 3
    if-eqz v0, :cond_12

    .line 4
    .line 5
    iget-object v0, v0, Lc1;->a:Lio/flutter/view/b;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    if-nez v0, :cond_b

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    goto :goto_f

    .line 12
    :cond_b
    invoke-virtual {v0, p1, v1}, Lio/flutter/view/b;->f(Landroid/view/MotionEvent;Z)Z

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    :goto_f
    if-eqz v0, :cond_12

    .line 17
    .line 18
    return v1

    .line 19
    :cond_12
    invoke-super {p0, p1}, Landroid/view/View;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    return p0
.end method
