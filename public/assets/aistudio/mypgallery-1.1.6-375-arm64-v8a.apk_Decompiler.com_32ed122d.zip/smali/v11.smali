###### Class defpackage.v11 (v11)
.class public final Lv11;
.super Lw11;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final i:Llz;


# direct methods
.method public constructor <init>(Lez;Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    invoke-direct {p0, p1, p2}, Lw11;-><init>(Lez;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    invoke-virtual {p1, p2}, Lez;->g(Ljava/lang/String;)Llz;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    iput-object p1, p0, Lv11;->i:Llz;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public final b(I)V
    .registers 2

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lv11;->i:Llz;

    .line 5
    .line 6
    invoke-interface {p0, p1}, Lt11;->b(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final c(IJ)V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lv11;->i:Llz;

    .line 5
    .line 6
    invoke-interface {p0, p1, p2, p3}, Lt11;->c(IJ)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final close()V
    .registers 2

    .line 1
    iget-object v0, p0, Lv11;->i:Llz;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/io/Closeable;->close()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, Lw11;->h:Z

    .line 8
    .line 9
    return-void
.end method

.method public final e(I[B)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lv11;->i:Llz;

    .line 5
    .line 6
    invoke-interface {p0, p1, p2}, Lt11;->e(I[B)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final f(I)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    const/16 p0, 0x15

    .line 5
    .line 6
    const-string p1, "no row"

    .line 7
    .line 8
    invoke-static {p0, p1}, Lhh1;->H(ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final getBlob(I)[B
    .registers 2

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    const/16 p0, 0x15

    .line 5
    .line 6
    const-string p1, "no row"

    .line 7
    .line 8
    invoke-static {p0, p1}, Lhh1;->H(ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final getColumnCount()I
    .registers 1

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    const/4 p0, 0x0

    .line 5
    return p0
.end method

.method public final getColumnName(I)Ljava/lang/String;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    const/16 p0, 0x15

    .line 5
    .line 6
    const-string p1, "no row"

    .line 7
    .line 8
    invoke-static {p0, p1}, Lhh1;->H(ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final getLong(I)J
    .registers 2

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    const/16 p0, 0x15

    .line 5
    .line 6
    const-string p1, "no row"

    .line 7
    .line 8
    invoke-static {p0, p1}, Lhh1;->H(ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final isNull(I)Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    const/16 p0, 0x15

    .line 5
    .line 6
    const-string p1, "no row"

    .line 7
    .line 8
    invoke-static {p0, p1}, Lhh1;->H(ILjava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    throw p0
.end method

.method public final reset()V
    .registers 1

    .line 1
    return-void
.end method

.method public final s(ILjava/lang/String;)V
    .registers 3

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lw11;->a()V

    .line 5
    .line 6
    .line 7
    iget-object p0, p0, Lv11;->i:Llz;

    .line 8
    .line 9
    invoke-interface {p0, p1, p2}, Lt11;->i(ILjava/lang/String;)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public final v()Z
    .registers 1

    .line 1
    invoke-virtual {p0}, Lw11;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lv11;->i:Llz;

    .line 5
    .line 6
    iget-object p0, p0, Llz;->g:Landroid/database/sqlite/SQLiteStatement;

    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    .line 9
    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    return p0
.end method
