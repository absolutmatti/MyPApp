###### Class defpackage.nw (nw)
.class public Lnw;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lre0;
.implements Lbj0;
.implements Lvm0;
.implements Ler;


# instance fields
.field public final synthetic f:I

.field public g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 1
    iput p1, p0, Lnw;->f:I

    .line 2
    .line 3
    sparse-switch p1, :sswitch_data_28

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    iput-object p1, p0, Lnw;->g:Ljava/lang/Object;

    .line 11
    .line 12
    return-void

    .line 13
    :sswitch_c
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 14
    .line 15
    .line 16
    sget-object p1, Lvr0;->a:[J

    .line 17
    .line 18
    new-instance p1, Lrf0;

    .line 19
    .line 20
    const/4 v0, 0x6

    .line 21
    invoke-direct {p1, v0}, Lrf0;-><init>(I)V

    .line 22
    .line 23
    .line 24
    iput-object p1, p0, Lnw;->g:Ljava/lang/Object;

    .line 25
    .line 26
    return-void

    .line 27
    :sswitch_1a
    new-instance p1, Landroid/util/SparseArray;

    .line 28
    .line 29
    const/16 v0, 0xa

    .line 30
    .line 31
    invoke-direct {p1, v0}, Landroid/util/SparseArray;-><init>(I)V

    .line 32
    .line 33
    .line 34
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object p1, p0, Lnw;->g:Ljava/lang/Object;

    .line 38
    .line 39
    return-void

    .line 40
    nop

    .line 41
    :sswitch_data_28
    .sparse-switch
        0x6 -> :sswitch_1a
        0x1c -> :sswitch_c
    .end sparse-switch
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 52
    iput p1, p0, Lnw;->f:I

    iput-object p2, p0, Lnw;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    .line 41
    iput p1, p0, Lnw;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lla;)V
    .registers 6

    const/4 v0, 0x7

    iput v0, p0, Lnw;->f:I

    .line 47
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 48
    new-instance v0, Lu6;

    invoke-direct {v0, p0}, Lu6;-><init>(Lnw;)V

    .line 49
    new-instance p0, Lte0;

    sget-object v1, Lzz0;->f:Lzz0;

    const/4 v2, 0x0

    .line 50
    const-string v3, "flutter/keyboard"

    invoke-direct {p0, p1, v3, v1, v2}, Lte0;-><init>(Lla;Ljava/lang/String;Lue0;Lmp;)V

    .line 51
    invoke-virtual {p0, v0}, Lte0;->b(Lre0;)V

    return-void
.end method

.method public constructor <init>(Lrj;)V
    .registers 6

    const/16 v0, 0xe

    iput v0, p0, Lnw;->f:I

    .line 42
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    new-instance v0, Lnw;

    const/16 v1, 0xd

    invoke-direct {v0, v1, p0}, Lnw;-><init>(ILjava/lang/Object;)V

    .line 44
    new-instance p0, Lte0;

    sget-object v1, Lzz0;->f:Lzz0;

    const/4 v2, 0x0

    .line 45
    const-string v3, "flutter/mousecursor"

    invoke-direct {p0, p1, v3, v1, v2}, Lte0;-><init>(Lla;Ljava/lang/String;Lue0;Lmp;)V

    .line 46
    invoke-virtual {p0, v0}, Lte0;->b(Lre0;)V

    return-void
.end method

.method public static n(I)Z
    .registers 2

    .line 1
    const/16 v0, 0x30

    .line 2
    .line 3
    if-gt v0, p0, :cond_8

    .line 4
    .line 5
    const/16 v0, 0x39

    .line 6
    .line 7
    if-le p0, v0, :cond_13

    .line 8
    .line 9
    :cond_8
    const/16 v0, 0x23

    .line 10
    .line 11
    if-eq p0, v0, :cond_13

    .line 12
    .line 13
    const/16 v0, 0x2a

    .line 14
    .line 15
    if-ne p0, v0, :cond_11

    .line 16
    .line 17
    goto :goto_13

    .line 18
    :cond_11
    const/4 p0, 0x0

    .line 19
    return p0

    .line 20
    :cond_13
    :goto_13
    const/4 p0, 0x1

    .line 21
    return p0
.end method

.method private final o(Loe0;Lse0;)V
    .registers 38

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p0

    .line 4
    .line 5
    iget-object v1, v1, Lnw;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lu6;

    .line 8
    .line 9
    iget-object v2, v1, Lu6;->h:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lwk0;

    .line 12
    .line 13
    if-nez v2, :cond_10

    .line 14
    .line 15
    goto/16 :goto_3ff

    .line 16
    .line 17
    :cond_10
    iget-object v2, v0, Loe0;->a:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v0, v0, Loe0;->b:Ljava/lang/Object;

    .line 20
    .line 21
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    .line 23
    .line 24
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 25
    .line 26
    .line 27
    move-result v3

    .line 28
    const/4 v7, 0x4

    .line 29
    const/4 v8, 0x3

    .line 30
    const/4 v9, 0x2

    .line 31
    const/4 v10, 0x1

    .line 32
    const/4 v11, 0x0

    .line 33
    const/4 v12, -0x1

    .line 34
    sparse-switch v3, :sswitch_data_400

    .line 35
    .line 36
    .line 37
    goto/16 :goto_7d

    .line 38
    .line 39
    :sswitch_26
    const-string v3, "dispose"

    .line 40
    .line 41
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    if-nez v2, :cond_2f

    .line 46
    .line 47
    goto :goto_7d

    .line 48
    :cond_2f
    const/4 v12, 0x7

    .line 49
    goto :goto_7d

    .line 50
    :sswitch_31
    const-string v3, "setDirection"

    .line 51
    .line 52
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v2

    .line 56
    if-nez v2, :cond_3a

    .line 57
    .line 58
    goto :goto_7d

    .line 59
    :cond_3a
    const/4 v12, 0x6

    .line 60
    goto :goto_7d

    .line 61
    :sswitch_3c
    const-string v3, "touch"

    .line 62
    .line 63
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-nez v2, :cond_45

    .line 68
    .line 69
    goto :goto_7d

    .line 70
    :cond_45
    const/4 v12, 0x5

    .line 71
    goto :goto_7d

    .line 72
    :sswitch_47
    const-string v3, "synchronizeToNativeViewHierarchy"

    .line 73
    .line 74
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 75
    .line 76
    .line 77
    move-result v2

    .line 78
    if-nez v2, :cond_50

    .line 79
    .line 80
    goto :goto_7d

    .line 81
    :cond_50
    move v12, v7

    .line 82
    goto :goto_7d

    .line 83
    :sswitch_52
    const-string v3, "clearFocus"

    .line 84
    .line 85
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 86
    .line 87
    .line 88
    move-result v2

    .line 89
    if-nez v2, :cond_5b

    .line 90
    .line 91
    goto :goto_7d

    .line 92
    :cond_5b
    move v12, v8

    .line 93
    goto :goto_7d

    .line 94
    :sswitch_5d
    const-string v3, "resize"

    .line 95
    .line 96
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 97
    .line 98
    .line 99
    move-result v2

    .line 100
    if-nez v2, :cond_66

    .line 101
    .line 102
    goto :goto_7d

    .line 103
    :cond_66
    move v12, v9

    .line 104
    goto :goto_7d

    .line 105
    :sswitch_68
    const-string v3, "offset"

    .line 106
    .line 107
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 108
    .line 109
    .line 110
    move-result v2

    .line 111
    if-nez v2, :cond_71

    .line 112
    .line 113
    goto :goto_7d

    .line 114
    :cond_71
    move v12, v10

    .line 115
    goto :goto_7d

    .line 116
    :sswitch_73
    const-string v3, "create"

    .line 117
    .line 118
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 119
    .line 120
    .line 121
    move-result v2

    .line 122
    if-nez v2, :cond_7c

    .line 123
    .line 124
    goto :goto_7d

    .line 125
    :cond_7c
    move v12, v11

    .line 126
    :goto_7d
    const-string v2, "left"

    .line 127
    .line 128
    const-string v3, "top"

    .line 129
    .line 130
    const-string v13, "height"

    .line 131
    .line 132
    const-string v14, "width"

    .line 133
    .line 134
    const-string v15, "direction"

    .line 135
    .line 136
    const-string v4, "id"

    .line 137
    .line 138
    const-string v5, "error"

    .line 139
    .line 140
    const/4 v6, 0x0

    .line 141
    packed-switch v12, :pswitch_data_422

    .line 142
    .line 143
    .line 144
    move-object/from16 v0, p2

    .line 145
    .line 146
    check-cast v0, Lqe0;

    .line 147
    .line 148
    invoke-virtual {v0}, Lqe0;->notImplemented()V

    .line 149
    .line 150
    .line 151
    return-void

    .line 152
    :pswitch_97
    check-cast v0, Ljava/util/Map;

    .line 153
    .line 154
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object v0

    .line 158
    check-cast v0, Ljava/lang/Integer;

    .line 159
    .line 160
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 161
    .line 162
    .line 163
    move-result v0

    .line 164
    :try_start_a3
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 165
    .line 166
    check-cast v1, Lwk0;

    .line 167
    .line 168
    invoke-interface {v1, v0}, Lwk0;->n(I)V

    .line 169
    .line 170
    .line 171
    move-object/from16 v0, p2

    .line 172
    .line 173
    check-cast v0, Lqe0;

    .line 174
    .line 175
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_b1
    .catch Ljava/lang/IllegalStateException; {:try_start_a3 .. :try_end_b1} :catch_b3

    .line 176
    .line 177
    .line 178
    goto/16 :goto_3ff

    .line 179
    .line 180
    :catch_b3
    move-exception v0

    .line 181
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    move-object/from16 v1, p2

    .line 186
    .line 187
    check-cast v1, Lqe0;

    .line 188
    .line 189
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 190
    .line 191
    .line 192
    goto/16 :goto_3ff

    .line 193
    .line 194
    :pswitch_c1
    check-cast v0, Ljava/util/Map;

    .line 195
    .line 196
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v2

    .line 200
    check-cast v2, Ljava/lang/Integer;

    .line 201
    .line 202
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 203
    .line 204
    .line 205
    move-result v2

    .line 206
    invoke-interface {v0, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    .line 208
    .line 209
    move-result-object v0

    .line 210
    check-cast v0, Ljava/lang/Integer;

    .line 211
    .line 212
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 213
    .line 214
    .line 215
    move-result v0

    .line 216
    :try_start_d7
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast v1, Lwk0;

    .line 219
    .line 220
    invoke-interface {v1, v2, v0}, Lwk0;->e(II)V

    .line 221
    .line 222
    .line 223
    move-object/from16 v0, p2

    .line 224
    .line 225
    check-cast v0, Lqe0;

    .line 226
    .line 227
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_e5
    .catch Ljava/lang/IllegalStateException; {:try_start_d7 .. :try_end_e5} :catch_e7

    .line 228
    .line 229
    .line 230
    goto/16 :goto_3ff

    .line 231
    .line 232
    :catch_e7
    move-exception v0

    .line 233
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 234
    .line 235
    .line 236
    move-result-object v0

    .line 237
    move-object/from16 v1, p2

    .line 238
    .line 239
    check-cast v1, Lqe0;

    .line 240
    .line 241
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 242
    .line 243
    .line 244
    goto/16 :goto_3ff

    .line 245
    .line 246
    :pswitch_f5
    check-cast v0, Ljava/util/List;

    .line 247
    .line 248
    new-instance v17, Lsk0;

    .line 249
    .line 250
    invoke-interface {v0, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 251
    .line 252
    .line 253
    move-result-object v2

    .line 254
    check-cast v2, Ljava/lang/Integer;

    .line 255
    .line 256
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 257
    .line 258
    .line 259
    move-result v18

    .line 260
    invoke-interface {v0, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    move-result-object v2

    .line 264
    move-object/from16 v19, v2

    .line 265
    .line 266
    check-cast v19, Ljava/lang/Number;

    .line 267
    .line 268
    invoke-interface {v0, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 269
    .line 270
    .line 271
    move-result-object v2

    .line 272
    move-object/from16 v20, v2

    .line 273
    .line 274
    check-cast v20, Ljava/lang/Number;

    .line 275
    .line 276
    invoke-interface {v0, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 277
    .line 278
    .line 279
    move-result-object v2

    .line 280
    check-cast v2, Ljava/lang/Integer;

    .line 281
    .line 282
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 283
    .line 284
    .line 285
    move-result v21

    .line 286
    invoke-interface {v0, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v2

    .line 290
    check-cast v2, Ljava/lang/Integer;

    .line 291
    .line 292
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 293
    .line 294
    .line 295
    move-result v22

    .line 296
    const/4 v2, 0x5

    .line 297
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v23

    .line 301
    const/4 v2, 0x6

    .line 302
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object v24

    .line 306
    const/4 v2, 0x7

    .line 307
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 308
    .line 309
    .line 310
    move-result-object v2

    .line 311
    check-cast v2, Ljava/lang/Integer;

    .line 312
    .line 313
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 314
    .line 315
    .line 316
    move-result v25

    .line 317
    const/16 v2, 0x8

    .line 318
    .line 319
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 320
    .line 321
    .line 322
    move-result-object v2

    .line 323
    check-cast v2, Ljava/lang/Integer;

    .line 324
    .line 325
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 326
    .line 327
    .line 328
    move-result v26

    .line 329
    const/16 v2, 0x9

    .line 330
    .line 331
    invoke-interface {v0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 332
    .line 333
    .line 334
    move-result-object v2

    .line 335
    check-cast v2, Ljava/lang/Double;

    .line 336
    .line 337
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 338
    .line 339
    .line 340
    move-result-wide v2

    .line 341
    double-to-float v2, v2

    .line 342
    const/16 v3, 0xa

    .line 343
    .line 344
    invoke-interface {v0, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 345
    .line 346
    .line 347
    move-result-object v3

    .line 348
    check-cast v3, Ljava/lang/Double;

    .line 349
    .line 350
    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    .line 351
    .line 352
    .line 353
    move-result-wide v3

    .line 354
    double-to-float v3, v3

    .line 355
    const/16 v4, 0xb

    .line 356
    .line 357
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 358
    .line 359
    .line 360
    move-result-object v4

    .line 361
    check-cast v4, Ljava/lang/Integer;

    .line 362
    .line 363
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 364
    .line 365
    .line 366
    move-result v29

    .line 367
    const/16 v4, 0xc

    .line 368
    .line 369
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 370
    .line 371
    .line 372
    move-result-object v4

    .line 373
    check-cast v4, Ljava/lang/Integer;

    .line 374
    .line 375
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 376
    .line 377
    .line 378
    move-result v30

    .line 379
    const/16 v4, 0xd

    .line 380
    .line 381
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 382
    .line 383
    .line 384
    move-result-object v4

    .line 385
    check-cast v4, Ljava/lang/Integer;

    .line 386
    .line 387
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 388
    .line 389
    .line 390
    move-result v31

    .line 391
    const/16 v4, 0xe

    .line 392
    .line 393
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    move-result-object v4

    .line 397
    check-cast v4, Ljava/lang/Integer;

    .line 398
    .line 399
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 400
    .line 401
    .line 402
    move-result v32

    .line 403
    const/16 v4, 0xf

    .line 404
    .line 405
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 406
    .line 407
    .line 408
    move-result-object v0

    .line 409
    check-cast v0, Ljava/lang/Number;

    .line 410
    .line 411
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 412
    .line 413
    .line 414
    move-result-wide v33

    .line 415
    move/from16 v27, v2

    .line 416
    .line 417
    move/from16 v28, v3

    .line 418
    .line 419
    invoke-direct/range {v17 .. v34}, Lsk0;-><init>(ILjava/lang/Number;Ljava/lang/Number;IILjava/lang/Object;Ljava/lang/Object;IIFFIIIIJ)V

    .line 420
    .line 421
    .line 422
    move-object/from16 v0, v17

    .line 423
    .line 424
    :try_start_1a7
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 425
    .line 426
    check-cast v1, Lwk0;

    .line 427
    .line 428
    invoke-interface {v1, v0}, Lwk0;->l(Lsk0;)V

    .line 429
    .line 430
    .line 431
    move-object/from16 v0, p2

    .line 432
    .line 433
    check-cast v0, Lqe0;

    .line 434
    .line 435
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_1b5
    .catch Ljava/lang/IllegalStateException; {:try_start_1a7 .. :try_end_1b5} :catch_1b7

    .line 436
    .line 437
    .line 438
    goto/16 :goto_3ff

    .line 439
    .line 440
    :catch_1b7
    move-exception v0

    .line 441
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 442
    .line 443
    .line 444
    move-result-object v0

    .line 445
    move-object/from16 v1, p2

    .line 446
    .line 447
    check-cast v1, Lqe0;

    .line 448
    .line 449
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 450
    .line 451
    .line 452
    goto/16 :goto_3ff

    .line 453
    .line 454
    :pswitch_1c5
    check-cast v0, Ljava/lang/Boolean;

    .line 455
    .line 456
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 457
    .line 458
    .line 459
    move-result v0

    .line 460
    :try_start_1cb
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 461
    .line 462
    check-cast v1, Lwk0;

    .line 463
    .line 464
    invoke-interface {v1, v0}, Lwk0;->b(Z)V

    .line 465
    .line 466
    .line 467
    move-object/from16 v0, p2

    .line 468
    .line 469
    check-cast v0, Lqe0;

    .line 470
    .line 471
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_1d9
    .catch Ljava/lang/IllegalStateException; {:try_start_1cb .. :try_end_1d9} :catch_1db

    .line 472
    .line 473
    .line 474
    goto/16 :goto_3ff

    .line 475
    .line 476
    :catch_1db
    move-exception v0

    .line 477
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 478
    .line 479
    .line 480
    move-result-object v0

    .line 481
    move-object/from16 v1, p2

    .line 482
    .line 483
    check-cast v1, Lqe0;

    .line 484
    .line 485
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 486
    .line 487
    .line 488
    goto/16 :goto_3ff

    .line 489
    .line 490
    :pswitch_1e9
    check-cast v0, Ljava/lang/Integer;

    .line 491
    .line 492
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 493
    .line 494
    .line 495
    move-result v0

    .line 496
    :try_start_1ef
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 497
    .line 498
    check-cast v1, Lwk0;

    .line 499
    .line 500
    invoke-interface {v1, v0}, Lwk0;->j(I)V

    .line 501
    .line 502
    .line 503
    move-object/from16 v0, p2

    .line 504
    .line 505
    check-cast v0, Lqe0;

    .line 506
    .line 507
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_1fd
    .catch Ljava/lang/IllegalStateException; {:try_start_1ef .. :try_end_1fd} :catch_1ff

    .line 508
    .line 509
    .line 510
    goto/16 :goto_3ff

    .line 511
    .line 512
    :catch_1ff
    move-exception v0

    .line 513
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 514
    .line 515
    .line 516
    move-result-object v0

    .line 517
    move-object/from16 v1, p2

    .line 518
    .line 519
    check-cast v1, Lqe0;

    .line 520
    .line 521
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 522
    .line 523
    .line 524
    goto/16 :goto_3ff

    .line 525
    .line 526
    :pswitch_20d
    check-cast v0, Ljava/util/Map;

    .line 527
    .line 528
    new-instance v7, Lvk0;

    .line 529
    .line 530
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 531
    .line 532
    .line 533
    move-result-object v2

    .line 534
    check-cast v2, Ljava/lang/Integer;

    .line 535
    .line 536
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 537
    .line 538
    .line 539
    move-result v8

    .line 540
    invoke-interface {v0, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 541
    .line 542
    .line 543
    move-result-object v2

    .line 544
    check-cast v2, Ljava/lang/Double;

    .line 545
    .line 546
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 547
    .line 548
    .line 549
    move-result-wide v9

    .line 550
    invoke-interface {v0, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 551
    .line 552
    .line 553
    move-result-object v0

    .line 554
    check-cast v0, Ljava/lang/Double;

    .line 555
    .line 556
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 557
    .line 558
    .line 559
    move-result-wide v11

    .line 560
    invoke-direct/range {v7 .. v12}, Lvk0;-><init>(IDD)V

    .line 561
    .line 562
    .line 563
    :try_start_232
    iget-object v0, v1, Lu6;->h:Ljava/lang/Object;

    .line 564
    .line 565
    check-cast v0, Lwk0;

    .line 566
    .line 567
    new-instance v1, Lho;

    .line 568
    .line 569
    move-object/from16 v2, p2

    .line 570
    .line 571
    check-cast v2, Lqe0;

    .line 572
    .line 573
    invoke-direct {v1, v2}, Lho;-><init>(Ljava/lang/Object;)V

    .line 574
    .line 575
    .line 576
    invoke-interface {v0, v7, v1}, Lwk0;->h(Lvk0;Lho;)V
    :try_end_242
    .catch Ljava/lang/IllegalStateException; {:try_start_232 .. :try_end_242} :catch_244

    .line 577
    .line 578
    .line 579
    goto/16 :goto_3ff

    .line 580
    .line 581
    :catch_244
    move-exception v0

    .line 582
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 583
    .line 584
    .line 585
    move-result-object v0

    .line 586
    move-object/from16 v1, p2

    .line 587
    .line 588
    check-cast v1, Lqe0;

    .line 589
    .line 590
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 591
    .line 592
    .line 593
    goto/16 :goto_3ff

    .line 594
    .line 595
    :pswitch_252
    check-cast v0, Ljava/util/Map;

    .line 596
    .line 597
    :try_start_254
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 598
    .line 599
    move-object v7, v1

    .line 600
    check-cast v7, Lwk0;

    .line 601
    .line 602
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 603
    .line 604
    .line 605
    move-result-object v1

    .line 606
    check-cast v1, Ljava/lang/Integer;

    .line 607
    .line 608
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 609
    .line 610
    .line 611
    move-result v8

    .line 612
    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 613
    .line 614
    .line 615
    move-result-object v1

    .line 616
    check-cast v1, Ljava/lang/Double;

    .line 617
    .line 618
    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    .line 619
    .line 620
    .line 621
    move-result-wide v9

    .line 622
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 623
    .line 624
    .line 625
    move-result-object v0

    .line 626
    check-cast v0, Ljava/lang/Double;

    .line 627
    .line 628
    invoke-virtual {v0}, Ljava/lang/Double;->doubleValue()D

    .line 629
    .line 630
    .line 631
    move-result-wide v11

    .line 632
    invoke-interface/range {v7 .. v12}, Lwk0;->d(IDD)V

    .line 633
    .line 634
    .line 635
    move-object/from16 v0, p2

    .line 636
    .line 637
    check-cast v0, Lqe0;

    .line 638
    .line 639
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_281
    .catch Ljava/lang/IllegalStateException; {:try_start_254 .. :try_end_281} :catch_283

    .line 640
    .line 641
    .line 642
    goto/16 :goto_3ff

    .line 643
    .line 644
    :catch_283
    move-exception v0

    .line 645
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 646
    .line 647
    .line 648
    move-result-object v0

    .line 649
    move-object/from16 v1, p2

    .line 650
    .line 651
    check-cast v1, Lqe0;

    .line 652
    .line 653
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 654
    .line 655
    .line 656
    goto/16 :goto_3ff

    .line 657
    .line 658
    :pswitch_291
    const-string v7, "hybridFallback"

    .line 659
    .line 660
    check-cast v0, Ljava/util/Map;

    .line 661
    .line 662
    const-string v8, "hybrid"

    .line 663
    .line 664
    invoke-interface {v0, v8}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 665
    .line 666
    .line 667
    move-result v12

    .line 668
    if-eqz v12, :cond_2ab

    .line 669
    .line 670
    invoke-interface {v0, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 671
    .line 672
    .line 673
    move-result-object v8

    .line 674
    check-cast v8, Ljava/lang/Boolean;

    .line 675
    .line 676
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 677
    .line 678
    .line 679
    move-result v8

    .line 680
    if-eqz v8, :cond_2ab

    .line 681
    .line 682
    move v8, v10

    .line 683
    goto :goto_2ac

    .line 684
    :cond_2ab
    move v8, v11

    .line 685
    :goto_2ac
    const-string v12, "params"

    .line 686
    .line 687
    invoke-interface {v0, v12}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 688
    .line 689
    .line 690
    move-result v16

    .line 691
    if-eqz v16, :cond_2c1

    .line 692
    .line 693
    invoke-interface {v0, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 694
    .line 695
    .line 696
    move-result-object v12

    .line 697
    check-cast v12, [B

    .line 698
    .line 699
    invoke-static {v12}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 700
    .line 701
    .line 702
    move-result-object v12

    .line 703
    move-object/from16 v29, v12

    .line 704
    .line 705
    goto :goto_2c3

    .line 706
    :cond_2c1
    move-object/from16 v29, v6

    .line 707
    .line 708
    :goto_2c3
    :try_start_2c3
    iget-object v12, v1, Lu6;->h:Ljava/lang/Object;

    .line 709
    .line 710
    check-cast v12, Lwk0;

    .line 711
    .line 712
    invoke-interface {v12}, Lwk0;->p()Z

    .line 713
    .line 714
    .line 715
    move-result v12
    :try_end_2cb
    .catch Ljava/lang/IllegalStateException; {:try_start_2c3 .. :try_end_2cb} :catch_30c

    .line 716
    const-string v9, "viewType"

    .line 717
    .line 718
    if-eqz v12, :cond_30f

    .line 719
    .line 720
    :try_start_2cf
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 721
    .line 722
    .line 723
    move-result-object v2

    .line 724
    check-cast v2, Ljava/lang/Integer;

    .line 725
    .line 726
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 727
    .line 728
    .line 729
    move-result v17

    .line 730
    invoke-interface {v0, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 731
    .line 732
    .line 733
    move-result-object v2

    .line 734
    move-object/from16 v18, v2

    .line 735
    .line 736
    check-cast v18, Ljava/lang/String;

    .line 737
    .line 738
    invoke-interface {v0, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 739
    .line 740
    .line 741
    move-result-object v0

    .line 742
    check-cast v0, Ljava/lang/Integer;

    .line 743
    .line 744
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 745
    .line 746
    .line 747
    move-result v27

    .line 748
    new-instance v16, Lok0;

    .line 749
    .line 750
    const-wide/16 v25, 0x0

    .line 751
    .line 752
    const/16 v28, 0x0

    .line 753
    .line 754
    const-wide/16 v19, 0x0

    .line 755
    .line 756
    const-wide/16 v21, 0x0

    .line 757
    .line 758
    const-wide/16 v23, 0x0

    .line 759
    .line 760
    invoke-direct/range {v16 .. v29}, Lok0;-><init>(ILjava/lang/String;DDDDIILjava/nio/ByteBuffer;)V

    .line 761
    .line 762
    .line 763
    move-object/from16 v0, v16

    .line 764
    .line 765
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 766
    .line 767
    check-cast v1, Lwk0;

    .line 768
    .line 769
    invoke-interface {v1, v0}, Lwk0;->f(Lok0;)V

    .line 770
    .line 771
    .line 772
    move-object/from16 v0, p2

    .line 773
    .line 774
    check-cast v0, Lqe0;

    .line 775
    .line 776
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 777
    .line 778
    .line 779
    goto/16 :goto_3ff

    .line 780
    .line 781
    :catch_30c
    move-exception v0

    .line 782
    goto/16 :goto_3f4

    .line 783
    .line 784
    :cond_30f
    if-eqz v8, :cond_34e

    .line 785
    .line 786
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 787
    .line 788
    .line 789
    move-result-object v2

    .line 790
    check-cast v2, Ljava/lang/Integer;

    .line 791
    .line 792
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 793
    .line 794
    .line 795
    move-result v17

    .line 796
    invoke-interface {v0, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 797
    .line 798
    .line 799
    move-result-object v2

    .line 800
    move-object/from16 v18, v2

    .line 801
    .line 802
    check-cast v18, Ljava/lang/String;

    .line 803
    .line 804
    invoke-interface {v0, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 805
    .line 806
    .line 807
    move-result-object v0

    .line 808
    check-cast v0, Ljava/lang/Integer;

    .line 809
    .line 810
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 811
    .line 812
    .line 813
    move-result v27

    .line 814
    new-instance v16, Lok0;

    .line 815
    .line 816
    const-wide/16 v25, 0x0

    .line 817
    .line 818
    const/16 v28, 0x3

    .line 819
    .line 820
    const-wide/16 v19, 0x0

    .line 821
    .line 822
    const-wide/16 v21, 0x0

    .line 823
    .line 824
    const-wide/16 v23, 0x0

    .line 825
    .line 826
    invoke-direct/range {v16 .. v29}, Lok0;-><init>(ILjava/lang/String;DDDDIILjava/nio/ByteBuffer;)V

    .line 827
    .line 828
    .line 829
    move-object/from16 v0, v16

    .line 830
    .line 831
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 832
    .line 833
    check-cast v1, Lwk0;

    .line 834
    .line 835
    invoke-interface {v1, v0}, Lwk0;->a(Lok0;)V

    .line 836
    .line 837
    .line 838
    move-object/from16 v0, p2

    .line 839
    .line 840
    check-cast v0, Lqe0;

    .line 841
    .line 842
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 843
    .line 844
    .line 845
    goto/16 :goto_3ff

    .line 846
    .line 847
    :cond_34e
    invoke-interface {v0, v7}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 848
    .line 849
    .line 850
    move-result v8

    .line 851
    if-eqz v8, :cond_361

    .line 852
    .line 853
    invoke-interface {v0, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 854
    .line 855
    .line 856
    move-result-object v7

    .line 857
    check-cast v7, Ljava/lang/Boolean;

    .line 858
    .line 859
    invoke-virtual {v7}, Ljava/lang/Boolean;->booleanValue()Z

    .line 860
    .line 861
    .line 862
    move-result v7

    .line 863
    if-eqz v7, :cond_361

    .line 864
    .line 865
    move v11, v10

    .line 866
    :cond_361
    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 867
    .line 868
    .line 869
    move-result-object v4

    .line 870
    check-cast v4, Ljava/lang/Integer;

    .line 871
    .line 872
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 873
    .line 874
    .line 875
    move-result v17

    .line 876
    invoke-interface {v0, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 877
    .line 878
    .line 879
    move-result-object v4

    .line 880
    move-object/from16 v18, v4

    .line 881
    .line 882
    check-cast v18, Ljava/lang/String;

    .line 883
    .line 884
    invoke-interface {v0, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 885
    .line 886
    .line 887
    move-result v4

    .line 888
    const-wide/16 v7, 0x0

    .line 889
    .line 890
    if-eqz v4, :cond_388

    .line 891
    .line 892
    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 893
    .line 894
    .line 895
    move-result-object v3

    .line 896
    check-cast v3, Ljava/lang/Double;

    .line 897
    .line 898
    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    .line 899
    .line 900
    .line 901
    move-result-wide v3

    .line 902
    move-wide/from16 v19, v3

    .line 903
    .line 904
    goto :goto_38a

    .line 905
    :cond_388
    move-wide/from16 v19, v7

    .line 906
    .line 907
    :goto_38a
    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 908
    .line 909
    .line 910
    move-result v3

    .line 911
    if-eqz v3, :cond_39a

    .line 912
    .line 913
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 914
    .line 915
    .line 916
    move-result-object v2

    .line 917
    check-cast v2, Ljava/lang/Double;

    .line 918
    .line 919
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 920
    .line 921
    .line 922
    move-result-wide v7

    .line 923
    :cond_39a
    move-wide/from16 v21, v7

    .line 924
    .line 925
    invoke-interface {v0, v14}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 926
    .line 927
    .line 928
    move-result-object v2

    .line 929
    check-cast v2, Ljava/lang/Double;

    .line 930
    .line 931
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 932
    .line 933
    .line 934
    move-result-wide v23

    .line 935
    invoke-interface {v0, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 936
    .line 937
    .line 938
    move-result-object v2

    .line 939
    check-cast v2, Ljava/lang/Double;

    .line 940
    .line 941
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 942
    .line 943
    .line 944
    move-result-wide v25

    .line 945
    invoke-interface {v0, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 946
    .line 947
    .line 948
    move-result-object v0

    .line 949
    check-cast v0, Ljava/lang/Integer;

    .line 950
    .line 951
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 952
    .line 953
    .line 954
    move-result v27

    .line 955
    new-instance v16, Lok0;

    .line 956
    .line 957
    if-eqz v11, :cond_3c1

    .line 958
    .line 959
    const/16 v28, 0x2

    .line 960
    .line 961
    goto :goto_3c3

    .line 962
    :cond_3c1
    move/from16 v28, v10

    .line 963
    .line 964
    :goto_3c3
    invoke-direct/range {v16 .. v29}, Lok0;-><init>(ILjava/lang/String;DDDDIILjava/nio/ByteBuffer;)V

    .line 965
    .line 966
    .line 967
    move-object/from16 v0, v16

    .line 968
    .line 969
    iget-object v1, v1, Lu6;->h:Ljava/lang/Object;

    .line 970
    .line 971
    check-cast v1, Lwk0;

    .line 972
    .line 973
    invoke-interface {v1, v0}, Lwk0;->m(Lok0;)J

    .line 974
    .line 975
    .line 976
    move-result-wide v0

    .line 977
    const-wide/16 v2, -0x2

    .line 978
    .line 979
    cmp-long v2, v0, v2

    .line 980
    .line 981
    if-nez v2, :cond_3e8

    .line 982
    .line 983
    if-eqz v11, :cond_3e0

    .line 984
    .line 985
    move-object/from16 v0, p2

    .line 986
    .line 987
    check-cast v0, Lqe0;

    .line 988
    .line 989
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 990
    .line 991
    .line 992
    goto :goto_3ff

    .line 993
    :cond_3e0
    new-instance v0, Ljava/lang/AssertionError;

    .line 994
    .line 995
    const-string v1, "Platform view attempted to fall back to hybrid mode when not requested."

    .line 996
    .line 997
    invoke-direct {v0, v1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 998
    .line 999
    .line 1000
    throw v0

    .line 1001
    :cond_3e8
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1002
    .line 1003
    .line 1004
    move-result-object v0

    .line 1005
    move-object/from16 v1, p2

    .line 1006
    .line 1007
    check-cast v1, Lqe0;

    .line 1008
    .line 1009
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_3f3
    .catch Ljava/lang/IllegalStateException; {:try_start_2cf .. :try_end_3f3} :catch_30c

    .line 1010
    .line 1011
    .line 1012
    goto :goto_3ff

    .line 1013
    :goto_3f4
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 1014
    .line 1015
    .line 1016
    move-result-object v0

    .line 1017
    move-object/from16 v1, p2

    .line 1018
    .line 1019
    check-cast v1, Lqe0;

    .line 1020
    .line 1021
    invoke-virtual {v1, v5, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1022
    .line 1023
    .line 1024
    :goto_3ff
    return-void

    .line 1025
    :sswitch_data_400
    .sparse-switch
        -0x509a5f04 -> :sswitch_73
        -0x3cc89b6d -> :sswitch_68
        -0x37b2634c -> :sswitch_5d
        -0x2d106975 -> :sswitch_52
        -0x126acbb2 -> :sswitch_47
        0x696df3f -> :sswitch_3c
        0x2261393d -> :sswitch_31
        0x63a5261f -> :sswitch_26
    .end sparse-switch

    .line 1026
    .line 1027
    .line 1028
    .line 1029
    .line 1030
    .line 1031
    .line 1032
    .line 1033
    .line 1034
    .line 1035
    .line 1036
    .line 1037
    .line 1038
    .line 1039
    .line 1040
    .line 1041
    .line 1042
    .line 1043
    .line 1044
    .line 1045
    .line 1046
    .line 1047
    .line 1048
    .line 1049
    .line 1050
    .line 1051
    .line 1052
    .line 1053
    .line 1054
    .line 1055
    .line 1056
    .line 1057
    .line 1058
    .line 1059
    :pswitch_data_422
    .packed-switch 0x0
        :pswitch_291
        :pswitch_252
        :pswitch_20d
        :pswitch_1e9
        :pswitch_1c5
        :pswitch_f5
        :pswitch_c1
        :pswitch_97
    .end packed-switch
.end method

.method private final p(Loe0;Lse0;)V
    .registers 8

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lbl0;

    .line 4
    .line 5
    iget-object v0, p0, Lbl0;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v0, Lom0;

    .line 8
    .line 9
    if-nez v0, :cond_b

    .line 10
    .line 11
    goto :goto_75

    .line 12
    :cond_b
    iget-object v0, p1, Loe0;->a:Ljava/lang/String;

    .line 13
    .line 14
    iget-object p1, p1, Loe0;->b:Ljava/lang/Object;

    .line 15
    .line 16
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const-string v1, "ProcessText.processTextAction"

    .line 20
    .line 21
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v1

    .line 25
    const/4 v2, 0x0

    .line 26
    const-string v3, "error"

    .line 27
    .line 28
    if-nez v1, :cond_45

    .line 29
    .line 30
    const-string p1, "ProcessText.queryTextActions"

    .line 31
    .line 32
    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    move-result p1

    .line 36
    if-nez p1, :cond_2b

    .line 37
    .line 38
    check-cast p2, Lqe0;

    .line 39
    .line 40
    invoke-virtual {p2}, Lqe0;->notImplemented()V

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :cond_2b
    :try_start_2b
    iget-object p0, p0, Lbl0;->g:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p0, Lom0;

    .line 47
    .line 48
    invoke-virtual {p0}, Lom0;->b()Ljava/util/HashMap;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    move-object p1, p2

    .line 53
    check-cast p1, Lqe0;

    .line 54
    .line 55
    invoke-virtual {p1, p0}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_39
    .catch Ljava/lang/IllegalStateException; {:try_start_2b .. :try_end_39} :catch_3a

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :catch_3a
    move-exception p0

    .line 60
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    check-cast p2, Lqe0;

    .line 65
    .line 66
    invoke-virtual {p2, v3, p0, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    goto :goto_75

    .line 70
    :cond_45
    :try_start_45
    check-cast p1, Ljava/util/ArrayList;

    .line 71
    .line 72
    const/4 v0, 0x0

    .line 73
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v0

    .line 77
    check-cast v0, Ljava/lang/String;

    .line 78
    .line 79
    const/4 v1, 0x1

    .line 80
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v1

    .line 84
    check-cast v1, Ljava/lang/String;

    .line 85
    .line 86
    const/4 v4, 0x2

    .line 87
    invoke-virtual {p1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 88
    .line 89
    .line 90
    move-result-object p1

    .line 91
    check-cast p1, Ljava/lang/Boolean;

    .line 92
    .line 93
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    iget-object p0, p0, Lbl0;->g:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast p0, Lom0;

    .line 100
    .line 101
    move-object v4, p2

    .line 102
    check-cast v4, Lqe0;

    .line 103
    .line 104
    invoke-virtual {p0, v0, v1, p1, v4}, Lom0;->a(Ljava/lang/String;Ljava/lang/String;ZLqe0;)V
    :try_end_6a
    .catch Ljava/lang/IllegalStateException; {:try_start_45 .. :try_end_6a} :catch_6b

    .line 105
    .line 106
    .line 107
    return-void

    .line 108
    :catch_6b
    move-exception p0

    .line 109
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p0

    .line 113
    check-cast p2, Lqe0;

    .line 114
    .line 115
    invoke-virtual {p2, v3, p0, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 116
    .line 117
    .line 118
    :goto_75
    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .registers 10

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lu6;

    .line 4
    .line 5
    iget-object p0, p0, Lu6;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Lvw;

    .line 8
    .line 9
    const/16 v0, 0x3e8

    .line 10
    .line 11
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    sget-object v1, Lu6;->m:Lkv;

    .line 16
    .line 17
    if-nez v1, :cond_13e

    .line 18
    .line 19
    new-instance v1, Lkv;

    .line 20
    .line 21
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 22
    .line 23
    .line 24
    const/16 v2, 0x3f2

    .line 25
    .line 26
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 27
    .line 28
    .line 29
    move-result-object v2

    .line 30
    const-string v3, "alias"

    .line 31
    .line 32
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    const/16 v2, 0x3f5

    .line 36
    .line 37
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 38
    .line 39
    .line 40
    move-result-object v2

    .line 41
    const-string v3, "allScroll"

    .line 42
    .line 43
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    const-string v3, "basic"

    .line 47
    .line 48
    invoke-virtual {v1, v3, v0}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    const/16 v3, 0x3ee

    .line 52
    .line 53
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    const-string v4, "cell"

    .line 58
    .line 59
    invoke-virtual {v1, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    const/16 v3, 0x3ea

    .line 63
    .line 64
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 65
    .line 66
    .line 67
    move-result-object v3

    .line 68
    const-string v4, "click"

    .line 69
    .line 70
    invoke-virtual {v1, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    const/16 v3, 0x3e9

    .line 74
    .line 75
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    const-string v4, "contextMenu"

    .line 80
    .line 81
    invoke-virtual {v1, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    const/16 v3, 0x3f3

    .line 85
    .line 86
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 87
    .line 88
    .line 89
    move-result-object v3

    .line 90
    const-string v4, "copy"

    .line 91
    .line 92
    invoke-virtual {v1, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 93
    .line 94
    .line 95
    const/16 v3, 0x3f4

    .line 96
    .line 97
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    const-string v4, "forbidden"

    .line 102
    .line 103
    invoke-virtual {v1, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    const/16 v4, 0x3fc

    .line 107
    .line 108
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    .line 110
    .line 111
    move-result-object v4

    .line 112
    const-string v5, "grab"

    .line 113
    .line 114
    invoke-virtual {v1, v5, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    const/16 v4, 0x3fd

    .line 118
    .line 119
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 120
    .line 121
    .line 122
    move-result-object v4

    .line 123
    const-string v5, "grabbing"

    .line 124
    .line 125
    invoke-virtual {v1, v5, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    const/16 v4, 0x3eb

    .line 129
    .line 130
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 131
    .line 132
    .line 133
    move-result-object v4

    .line 134
    const-string v5, "help"

    .line 135
    .line 136
    invoke-virtual {v1, v5, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 137
    .line 138
    .line 139
    const-string v4, "move"

    .line 140
    .line 141
    invoke-virtual {v1, v4, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    const/4 v2, 0x0

    .line 145
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    const-string v4, "none"

    .line 150
    .line 151
    invoke-virtual {v1, v4, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    const-string v2, "noDrop"

    .line 155
    .line 156
    invoke-virtual {v1, v2, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 157
    .line 158
    .line 159
    const/16 v2, 0x3ef

    .line 160
    .line 161
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 162
    .line 163
    .line 164
    move-result-object v2

    .line 165
    const-string v3, "precise"

    .line 166
    .line 167
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 168
    .line 169
    .line 170
    const/16 v2, 0x3f0

    .line 171
    .line 172
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 173
    .line 174
    .line 175
    move-result-object v2

    .line 176
    const-string v3, "text"

    .line 177
    .line 178
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 179
    .line 180
    .line 181
    const/16 v2, 0x3f6

    .line 182
    .line 183
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 184
    .line 185
    .line 186
    move-result-object v2

    .line 187
    const-string v3, "resizeColumn"

    .line 188
    .line 189
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 190
    .line 191
    .line 192
    const/16 v3, 0x3f7

    .line 193
    .line 194
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    const-string v4, "resizeDown"

    .line 199
    .line 200
    invoke-virtual {v1, v4, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 201
    .line 202
    .line 203
    const/16 v4, 0x3f8

    .line 204
    .line 205
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    .line 207
    .line 208
    move-result-object v4

    .line 209
    const-string v5, "resizeUpLeft"

    .line 210
    .line 211
    invoke-virtual {v1, v5, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    const/16 v6, 0x3f9

    .line 215
    .line 216
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 217
    .line 218
    .line 219
    move-result-object v6

    .line 220
    const-string v7, "resizeDownRight"

    .line 221
    .line 222
    invoke-virtual {v1, v7, v6}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    const-string v7, "resizeLeft"

    .line 226
    .line 227
    invoke-virtual {v1, v7, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 228
    .line 229
    .line 230
    const-string v7, "resizeLeftRight"

    .line 231
    .line 232
    invoke-virtual {v1, v7, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    const-string v7, "resizeRight"

    .line 236
    .line 237
    invoke-virtual {v1, v7, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 238
    .line 239
    .line 240
    const-string v2, "resizeRow"

    .line 241
    .line 242
    invoke-virtual {v1, v2, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    const-string v2, "resizeUp"

    .line 246
    .line 247
    invoke-virtual {v1, v2, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    const-string v2, "resizeUpDown"

    .line 251
    .line 252
    invoke-virtual {v1, v2, v3}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 253
    .line 254
    .line 255
    invoke-virtual {v1, v5, v6}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 256
    .line 257
    .line 258
    const-string v2, "resizeUpRight"

    .line 259
    .line 260
    invoke-virtual {v1, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 261
    .line 262
    .line 263
    const-string v2, "resizeUpLeftDownRight"

    .line 264
    .line 265
    invoke-virtual {v1, v2, v6}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 266
    .line 267
    .line 268
    const-string v2, "resizeUpRightDownLeft"

    .line 269
    .line 270
    invoke-virtual {v1, v2, v4}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 271
    .line 272
    .line 273
    const/16 v2, 0x3f1

    .line 274
    .line 275
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 276
    .line 277
    .line 278
    move-result-object v2

    .line 279
    const-string v3, "verticalText"

    .line 280
    .line 281
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    const/16 v2, 0x3ec

    .line 285
    .line 286
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 287
    .line 288
    .line 289
    move-result-object v2

    .line 290
    const-string v3, "wait"

    .line 291
    .line 292
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 293
    .line 294
    .line 295
    const/16 v2, 0x3fa

    .line 296
    .line 297
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 298
    .line 299
    .line 300
    move-result-object v2

    .line 301
    const-string v3, "zoomIn"

    .line 302
    .line 303
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 304
    .line 305
    .line 306
    const/16 v2, 0x3fb

    .line 307
    .line 308
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    const-string v3, "zoomOut"

    .line 313
    .line 314
    invoke-virtual {v1, v3, v2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 315
    .line 316
    .line 317
    sput-object v1, Lu6;->m:Lkv;

    .line 318
    .line 319
    :cond_13e
    sget-object v1, Lu6;->m:Lkv;

    .line 320
    .line 321
    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->getOrDefault(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 322
    .line 323
    .line 324
    move-result-object p1

    .line 325
    check-cast p1, Ljava/lang/Integer;

    .line 326
    .line 327
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 328
    .line 329
    .line 330
    move-result p1

    .line 331
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 332
    .line 333
    .line 334
    move-result-object v0

    .line 335
    invoke-static {v0, p1}, Landroid/view/PointerIcon;->getSystemIcon(Landroid/content/Context;I)Landroid/view/PointerIcon;

    .line 336
    .line 337
    .line 338
    move-result-object p1

    .line 339
    invoke-virtual {p0, p1}, Landroid/view/View;->setPointerIcon(Landroid/view/PointerIcon;)V

    .line 340
    .line 341
    .line 342
    return-void
.end method

.method public b(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lse0;

    .line 4
    .line 5
    const-string v0, "sqlite_error"

    .line 6
    .line 7
    invoke-interface {p0, v0, p2, p1}, Lse0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public c()V
    .registers 2

    .line 1
    const-string p0, "DIAGNOSTIC_PROFILE_IS_COMPRESSED"

    .line 2
    .line 3
    const-string v0, "ProfileInstaller"

    .line 4
    .line 5
    invoke-static {v0, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public d(ILjava/lang/Object;)V
    .registers 6

    .line 1
    packed-switch p1, :pswitch_data_40

    .line 2
    .line 3
    .line 4
    :pswitch_3
    const-string v0, ""

    .line 5
    .line 6
    goto :goto_23

    .line 7
    :pswitch_6
    const-string v0, "RESULT_DELETE_SKIP_FILE_SUCCESS"

    .line 8
    .line 9
    goto :goto_23

    .line 10
    :pswitch_9
    const-string v0, "RESULT_INSTALL_SKIP_FILE_SUCCESS"

    .line 11
    .line 12
    goto :goto_23

    .line 13
    :pswitch_c
    const-string v0, "RESULT_PARSE_EXCEPTION"

    .line 14
    .line 15
    goto :goto_23

    .line 16
    :pswitch_f
    const-string v0, "RESULT_IO_EXCEPTION"

    .line 17
    .line 18
    goto :goto_23

    .line 19
    :pswitch_12
    const-string v0, "RESULT_BASELINE_PROFILE_NOT_FOUND"

    .line 20
    .line 21
    goto :goto_23

    .line 22
    :pswitch_15
    const-string v0, "RESULT_DESIRED_FORMAT_UNSUPPORTED"

    .line 23
    .line 24
    goto :goto_23

    .line 25
    :pswitch_18
    const-string v0, "RESULT_NOT_WRITABLE"

    .line 26
    .line 27
    goto :goto_23

    .line 28
    :pswitch_1b
    const-string v0, "RESULT_UNSUPPORTED_ART_VERSION"

    .line 29
    .line 30
    goto :goto_23

    .line 31
    :pswitch_1e
    const-string v0, "RESULT_ALREADY_INSTALLED"

    .line 32
    .line 33
    goto :goto_23

    .line 34
    :pswitch_21
    const-string v0, "RESULT_INSTALL_SUCCESS"

    .line 35
    .line 36
    :goto_23
    const/4 v1, 0x6

    .line 37
    const-string v2, "ProfileInstaller"

    .line 38
    .line 39
    if-eq p1, v1, :cond_33

    .line 40
    .line 41
    const/4 v1, 0x7

    .line 42
    if-eq p1, v1, :cond_33

    .line 43
    .line 44
    const/16 v1, 0x8

    .line 45
    .line 46
    if-eq p1, v1, :cond_33

    .line 47
    .line 48
    invoke-static {v2, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 49
    .line 50
    .line 51
    goto :goto_38

    .line 52
    :cond_33
    check-cast p2, Ljava/lang/Throwable;

    .line 53
    .line 54
    invoke-static {v2, v0, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 55
    .line 56
    .line 57
    :goto_38
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p0, Landroidx/profileinstaller/ProfileInstallReceiver;

    .line 60
    .line 61
    invoke-virtual {p0, p1}, Landroid/content/BroadcastReceiver;->setResultCode(I)V

    .line 62
    .line 63
    .line 64
    return-void

    .line 65
    :pswitch_data_40
    .packed-switch 0x1
        :pswitch_21
        :pswitch_1e
        :pswitch_1b
        :pswitch_18
        :pswitch_15
        :pswitch_12
        :pswitch_f
        :pswitch_c
        :pswitch_3
        :pswitch_9
        :pswitch_6
    .end packed-switch
.end method

.method public e(Lko0;Ljava/lang/Object;)V
    .registers 7

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lrf0;

    .line 4
    .line 5
    invoke-virtual {p0, p2}, Lrf0;->c(Ljava/lang/Object;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-gez v0, :cond_c

    .line 10
    .line 11
    const/4 v1, 0x1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 v1, 0x0

    .line 14
    :goto_d
    if-eqz v1, :cond_11

    .line 15
    .line 16
    const/4 v2, 0x0

    .line 17
    goto :goto_15

    .line 18
    :cond_11
    iget-object v2, p0, Lrf0;->c:[Ljava/lang/Object;

    .line 19
    .line 20
    aget-object v2, v2, v0

    .line 21
    .line 22
    :goto_15
    if-nez v2, :cond_18

    .line 23
    .line 24
    goto :goto_33

    .line 25
    :cond_18
    instance-of v3, v2, Lvf0;

    .line 26
    .line 27
    if-eqz v3, :cond_23

    .line 28
    .line 29
    move-object v3, v2

    .line 30
    check-cast v3, Lvf0;

    .line 31
    .line 32
    invoke-virtual {v3, p1}, Lvf0;->a(Ljava/lang/Object;)Z

    .line 33
    .line 34
    .line 35
    goto :goto_32

    .line 36
    :cond_23
    if-eq v2, p1, :cond_32

    .line 37
    .line 38
    new-instance v3, Lvf0;

    .line 39
    .line 40
    invoke-direct {v3}, Lvf0;-><init>()V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v3, v2}, Lvf0;->a(Ljava/lang/Object;)Z

    .line 44
    .line 45
    .line 46
    invoke-virtual {v3, p1}, Lvf0;->a(Ljava/lang/Object;)Z

    .line 47
    .line 48
    .line 49
    move-object p1, v3

    .line 50
    goto :goto_33

    .line 51
    :cond_32
    :goto_32
    move-object p1, v2

    .line 52
    :goto_33
    if-eqz v1, :cond_3f

    .line 53
    .line 54
    not-int v0, v0

    .line 55
    iget-object v1, p0, Lrf0;->b:[Ljava/lang/Object;

    .line 56
    .line 57
    aput-object p2, v1, v0

    .line 58
    .line 59
    iget-object p0, p0, Lrf0;->c:[Ljava/lang/Object;

    .line 60
    .line 61
    aput-object p1, p0, v0

    .line 62
    .line 63
    return-void

    .line 64
    :cond_3f
    iget-object p0, p0, Lrf0;->c:[Ljava/lang/Object;

    .line 65
    .line 66
    aput-object p1, p0, v0

    .line 67
    .line 68
    return-void
.end method

.method public f(I)V
    .registers 4

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lal0;

    .line 4
    .line 5
    iget-object p0, p0, Lal0;->n:Landroid/util/SparseArray;

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Lnk0;

    .line 12
    .line 13
    const-string v0, "PlatformViewsController2"

    .line 14
    .line 15
    if-nez p0, :cond_22

    .line 16
    .line 17
    new-instance p0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string v1, "Clearing focus on an unknown view with id: "

    .line 20
    .line 21
    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_22
    invoke-interface {p0}, Lnk0;->getView()Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    if-nez p0, :cond_3a

    .line 40
    .line 41
    new-instance p0, Ljava/lang/StringBuilder;

    .line 42
    .line 43
    const-string v1, "Clearing focus on a null view with id: "

    .line 44
    .line 45
    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    invoke-virtual {p0}, Landroid/view/View;->clearFocus()V

    .line 60
    .line 61
    .line 62
    return-void
.end method

.method public g(Lok0;)V
    .registers 6

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lal0;

    .line 4
    .line 5
    iget-object v0, p0, Lal0;->f:Lqv;

    .line 6
    .line 7
    iget-object v1, p1, Lok0;->b:Ljava/lang/String;

    .line 8
    .line 9
    iget v2, p1, Lok0;->a:I

    .line 10
    .line 11
    iget-object v3, p1, Lok0;->i:Ljava/nio/ByteBuffer;

    .line 12
    .line 13
    iget-object v0, v0, Lqv;->a:Ljava/util/HashMap;

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    check-cast v0, Lpk0;

    .line 20
    .line 21
    if-eqz v0, :cond_47

    .line 22
    .line 23
    if-eqz v3, :cond_21

    .line 24
    .line 25
    invoke-virtual {v0}, Lpk0;->getCreateArgsCodec()Lsd0;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    invoke-interface {v1, v3}, Lsd0;->b(Ljava/nio/ByteBuffer;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v1

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v1, 0x0

    .line 35
    :goto_22
    iget-object v3, p0, Lal0;->h:Ldv;

    .line 36
    .line 37
    invoke-virtual {v0, v3, v2, v1}, Lpk0;->create(Landroid/content/Context;ILjava/lang/Object;)Lnk0;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    invoke-interface {v0}, Lnk0;->getView()Landroid/view/View;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    if-eqz v1, :cond_41

    .line 46
    .line 47
    iget p1, p1, Lok0;->g:I

    .line 48
    .line 49
    invoke-virtual {v1, p1}, Landroid/view/View;->setLayoutDirection(I)V

    .line 50
    .line 51
    .line 52
    iget-object p1, p0, Lal0;->n:Landroid/util/SparseArray;

    .line 53
    .line 54
    invoke-virtual {p1, v2, v0}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p0, p0, Lal0;->i:Lvw;

    .line 58
    .line 59
    if-nez p0, :cond_3d

    .line 60
    .line 61
    return-void

    .line 62
    :cond_3d
    invoke-interface {v0, p0}, Lnk0;->onFlutterViewAttached(Landroid/view/View;)V

    .line 63
    .line 64
    .line 65
    return-void

    .line 66
    :cond_41
    const-string p0, "PlatformView#getView() returned null, but an Android view reference was expected."

    .line 67
    .line 68
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 69
    .line 70
    .line 71
    return-void

    .line 72
    :cond_47
    const-string p0, "Trying to create a platform view of unregistered type: "

    .line 73
    .line 74
    invoke-static {v1, p0}, Lm0;->u(Ljava/lang/Object;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    return-void
.end method

.method public h(Ljava/lang/Object;Ldr;)V
    .registers 3

    .line 1
    iput-object p2, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    return-void
.end method

.method public i(Ljava/nio/ByteBuffer;Lke0;)Landroid/graphics/Bitmap;
    .registers 3

    .line 1
    invoke-static {p1}, Landroid/graphics/ImageDecoder;->createSource(Ljava/nio/ByteBuffer;)Landroid/graphics/ImageDecoder$Source;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    :try_start_4
    new-instance p2, Lx20;

    .line 6
    .line 7
    invoke-direct {p2, p0}, Lx20;-><init>(Lnw;)V

    .line 8
    .line 9
    .line 10
    invoke-static {p1, p2}, Landroid/graphics/ImageDecoder;->decodeBitmap(Landroid/graphics/ImageDecoder$Source;Landroid/graphics/ImageDecoder$OnHeaderDecodedListener;)Landroid/graphics/Bitmap;

    .line 11
    .line 12
    .line 13
    move-result-object p0
    :try_end_d
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_d} :catch_e

    .line 14
    return-object p0

    .line 15
    :catch_e
    move-exception p0

    .line 16
    const-string p1, "FlutterImageDecoderImplDefault"

    .line 17
    .line 18
    const-string p2, "Failed to decode image"

    .line 19
    .line 20
    invoke-static {p1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 21
    .line 22
    .line 23
    const/4 p0, 0x0

    .line 24
    return-object p0
.end method

.method public j(I)V
    .registers 7

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lal0;

    .line 4
    .line 5
    iget-object v0, p0, Lal0;->o:Landroid/util/SparseArray;

    .line 6
    .line 7
    iget-object v1, p0, Lal0;->u:Ljava/util/HashSet;

    .line 8
    .line 9
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 10
    .line 11
    .line 12
    move-result-object v2

    .line 13
    invoke-virtual {v1, v2}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    iget-object p0, p0, Lal0;->n:Landroid/util/SparseArray;

    .line 17
    .line 18
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    check-cast v1, Lnk0;

    .line 23
    .line 24
    const-string v2, "PlatformViewsController2"

    .line 25
    .line 26
    if-nez v1, :cond_2d

    .line 27
    .line 28
    new-instance p0, Ljava/lang/StringBuilder;

    .line 29
    .line 30
    const-string v0, "Disposing unknown platform view with id: "

    .line 31
    .line 32
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    invoke-static {v2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 43
    .line 44
    .line 45
    return-void

    .line 46
    :cond_2d
    invoke-interface {v1}, Lnk0;->getView()Landroid/view/View;

    .line 47
    .line 48
    .line 49
    move-result-object v3

    .line 50
    if-eqz v3, :cond_42

    .line 51
    .line 52
    invoke-interface {v1}, Lnk0;->getView()Landroid/view/View;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    check-cast v4, Landroid/view/ViewGroup;

    .line 61
    .line 62
    if-eqz v4, :cond_42

    .line 63
    .line 64
    invoke-virtual {v4, v3}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 65
    .line 66
    .line 67
    :cond_42
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->remove(I)V

    .line 68
    .line 69
    .line 70
    :try_start_45
    invoke-interface {v1}, Lnk0;->dispose()V
    :try_end_48
    .catch Ljava/lang/RuntimeException; {:try_start_45 .. :try_end_48} :catch_49

    .line 71
    .line 72
    .line 73
    goto :goto_4f

    .line 74
    :catch_49
    move-exception p0

    .line 75
    const-string v1, "Disposing platform view threw an exception"

    .line 76
    .line 77
    invoke-static {v2, v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 78
    .line 79
    .line 80
    :goto_4f
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    check-cast p0, Lcw;

    .line 85
    .line 86
    if-eqz p0, :cond_6b

    .line 87
    .line 88
    invoke-virtual {p0}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 89
    .line 90
    .line 91
    invoke-virtual {p0}, Lcw;->a()V

    .line 92
    .line 93
    .line 94
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 95
    .line 96
    .line 97
    move-result-object v1

    .line 98
    check-cast v1, Landroid/view/ViewGroup;

    .line 99
    .line 100
    if-eqz v1, :cond_68

    .line 101
    .line 102
    invoke-virtual {v1, p0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 103
    .line 104
    .line 105
    :cond_68
    invoke-virtual {v0, p1}, Landroid/util/SparseArray;->remove(I)V

    .line 106
    .line 107
    .line 108
    :cond_6b
    return-void
.end method

.method public k(Lbk0;)Ljava/lang/CharSequence;
    .registers 9

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lkk0;

    .line 4
    .line 5
    const-string v0, "PlatformPlugin"

    .line 6
    .line 7
    const-string v1, "Clipboard item contains a Uri with scheme \'"

    .line 8
    .line 9
    iget-object p0, p0, Lkk0;->a:Landroid/app/Activity;

    .line 10
    .line 11
    const-string v2, "clipboard"

    .line 12
    .line 13
    invoke-virtual {p0, v2}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    check-cast v2, Landroid/content/ClipboardManager;

    .line 18
    .line 19
    invoke-virtual {v2}, Landroid/content/ClipboardManager;->hasPrimaryClip()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    const/4 v4, 0x0

    .line 24
    if-nez v3, :cond_1a

    .line 25
    .line 26
    goto :goto_28

    .line 27
    :cond_1a
    :try_start_1a
    invoke-virtual {v2}, Landroid/content/ClipboardManager;->getPrimaryClip()Landroid/content/ClipData;

    .line 28
    .line 29
    .line 30
    move-result-object v2

    .line 31
    if-nez v2, :cond_21

    .line 32
    .line 33
    goto :goto_28

    .line 34
    :cond_21
    if-eqz p1, :cond_2d

    .line 35
    .line 36
    sget-object v3, Lbk0;->f:Lbk0;

    .line 37
    .line 38
    if-ne p1, v3, :cond_28

    .line 39
    .line 40
    goto :goto_2d

    .line 41
    :cond_28
    :goto_28
    return-object v4

    .line 42
    :catch_29
    move-exception p0

    .line 43
    goto :goto_82

    .line 44
    :catch_2b
    move-exception p0

    .line 45
    goto :goto_8e

    .line 46
    :cond_2d
    :goto_2d
    const/4 p1, 0x0

    .line 47
    invoke-virtual {v2, p1}, Landroid/content/ClipData;->getItemAt(I)Landroid/content/ClipData$Item;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    invoke-virtual {p1}, Landroid/content/ClipData$Item;->getText()Ljava/lang/CharSequence;

    .line 52
    .line 53
    .line 54
    move-result-object v2
    :try_end_36
    .catch Ljava/lang/SecurityException; {:try_start_1a .. :try_end_36} :catch_2b
    .catch Ljava/io/FileNotFoundException; {:try_start_1a .. :try_end_36} :catch_88
    .catch Ljava/io/IOException; {:try_start_1a .. :try_end_36} :catch_29

    .line 55
    if-nez v2, :cond_81

    .line 56
    .line 57
    :try_start_38
    invoke-virtual {p1}, Landroid/content/ClipData$Item;->getUri()Landroid/net/Uri;

    .line 58
    .line 59
    .line 60
    move-result-object v3

    .line 61
    if-nez v3, :cond_47

    .line 62
    .line 63
    const-string p0, "Clipboard item contained no textual content nor a URI to retrieve it from."

    .line 64
    .line 65
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 66
    .line 67
    .line 68
    return-object v4

    .line 69
    :catch_44
    move-exception p0

    .line 70
    move-object v4, v2

    .line 71
    goto :goto_82

    .line 72
    :cond_47
    invoke-virtual {v3}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object v5

    .line 76
    const-string v6, "content"

    .line 77
    .line 78
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v6

    .line 82
    if-nez v6, :cond_68

    .line 83
    .line 84
    new-instance p0, Ljava/lang/StringBuilder;

    .line 85
    .line 86
    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {p0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 90
    .line 91
    .line 92
    const-string p1, "\'that is unhandled."

    .line 93
    .line 94
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object p0

    .line 101
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 102
    .line 103
    .line 104
    return-object v4

    .line 105
    :cond_68
    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    const-string v5, "text/*"

    .line 110
    .line 111
    invoke-virtual {v1, v3, v5, v4}, Landroid/content/ContentResolver;->openTypedAssetFileDescriptor(Landroid/net/Uri;Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/res/AssetFileDescriptor;

    .line 112
    .line 113
    .line 114
    move-result-object v1

    .line 115
    invoke-virtual {p1, p0}, Landroid/content/ClipData$Item;->coerceToText(Landroid/content/Context;)Ljava/lang/CharSequence;

    .line 116
    .line 117
    .line 118
    move-result-object p0
    :try_end_76
    .catch Ljava/lang/SecurityException; {:try_start_38 .. :try_end_76} :catch_2b
    .catch Ljava/io/FileNotFoundException; {:try_start_38 .. :try_end_76} :catch_88
    .catch Ljava/io/IOException; {:try_start_38 .. :try_end_76} :catch_44

    .line 119
    if-eqz v1, :cond_80

    .line 120
    .line 121
    :try_start_78
    invoke-virtual {v1}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_7b
    .catch Ljava/lang/SecurityException; {:try_start_78 .. :try_end_7b} :catch_2b
    .catch Ljava/io/FileNotFoundException; {:try_start_78 .. :try_end_7b} :catch_88
    .catch Ljava/io/IOException; {:try_start_78 .. :try_end_7b} :catch_7c

    .line 122
    .line 123
    .line 124
    return-object p0

    .line 125
    :catch_7c
    move-exception p1

    .line 126
    move-object v4, p0

    .line 127
    move-object p0, p1

    .line 128
    goto :goto_82

    .line 129
    :cond_80
    return-object p0

    .line 130
    :cond_81
    return-object v2

    .line 131
    :goto_82
    const-string p1, "Failed to close AssetFileDescriptor while trying to read text from URI."

    .line 132
    .line 133
    invoke-static {v0, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 134
    .line 135
    .line 136
    goto :goto_93

    .line 137
    :catch_88
    const-string p0, "Clipboard text was unable to be received from content URI."

    .line 138
    .line 139
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 140
    .line 141
    .line 142
    goto :goto_93

    .line 143
    :goto_8e
    const-string p1, "Attempted to get clipboard data that requires additional permission(s).\nSee the exception details for which permission(s) are required, and consider adding them to your Android Manifest as described in:\nhttps://developer.android.com/guide/topics/permissions/overview"

    .line 144
    .line 145
    invoke-static {v0, p1, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 146
    .line 147
    .line 148
    :goto_93
    return-object v4
.end method

.method public l(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lma0;

    .line 4
    .line 5
    iget-object p0, p0, Lma0;->b:Landroid/content/Context;

    .line 6
    .line 7
    if-eqz p2, :cond_21

    .line 8
    .line 9
    invoke-static {p2}, Lma0;->a(Ljava/lang/String;)Ljava/util/Locale;

    .line 10
    .line 11
    .line 12
    move-result-object p2

    .line 13
    new-instance v0, Landroid/content/res/Configuration;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-direct {v0, v1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 24
    .line 25
    .line 26
    invoke-virtual {v0, p2}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {p0, v0}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    .line 30
    .line 31
    .line 32
    move-result-object p2

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    move-object p2, p0

    .line 35
    :goto_22
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    const-string v1, "string"

    .line 44
    .line 45
    invoke-virtual {v0, p1, v1, p0}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 46
    .line 47
    .line 48
    move-result p0

    .line 49
    if-eqz p0, :cond_3b

    .line 50
    .line 51
    invoke-virtual {p2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 52
    .line 53
    .line 54
    move-result-object p1

    .line 55
    invoke-virtual {p1, p0}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    .line 56
    .line 57
    .line 58
    move-result-object p0

    .line 59
    return-object p0

    .line 60
    :cond_3b
    const/4 p0, 0x0

    .line 61
    return-object p0
.end method

.method public m(Ljava/lang/Object;Ld60;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 5
    .line 6
    check-cast p0, Ljava/lang/Float;

    .line 7
    .line 8
    if-eqz p0, :cond_a

    .line 9
    .line 10
    return-object p0

    .line 11
    :cond_a
    new-instance p0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string p1, "Property "

    .line 14
    .line 15
    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    check-cast p2, Lsb;

    .line 19
    .line 20
    iget-object p1, p2, Lsb;->i:Ljava/lang/String;

    .line 21
    .line 22
    const-string p2, " should be initialized before get."

    .line 23
    .line 24
    invoke-static {p0, p1, p2}, Lzi0;->q(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 25
    .line 26
    .line 27
    move-result-object p0

    .line 28
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    const/4 p0, 0x0

    .line 32
    return-object p0
.end method

.method public onCancel()V
    .registers 2

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-object v0, p0, Lnw;->g:Ljava/lang/Object;

    .line 3
    .line 4
    return-void
.end method

.method public onMethodCall(Loe0;Lse0;)V
    .registers 33

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    iget v2, v0, Lnw;->f:I

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    const-string v4, "error"

    .line 9
    .line 10
    const/4 v5, 0x1

    .line 11
    const/4 v6, 0x0

    .line 12
    sparse-switch v2, :sswitch_data_69c

    .line 13
    .line 14
    .line 15
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v0, Lr5;

    .line 18
    .line 19
    iget-object v2, v1, Loe0;->a:Ljava/lang/String;

    .line 20
    .line 21
    iget-object v1, v1, Loe0;->b:Ljava/lang/Object;

    .line 22
    .line 23
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    const-string v3, "get"

    .line 27
    .line 28
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-nez v3, :cond_3d

    .line 33
    .line 34
    const-string v3, "put"

    .line 35
    .line 36
    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    if-nez v2, :cond_31

    .line 41
    .line 42
    move-object/from16 v0, p2

    .line 43
    .line 44
    check-cast v0, Lqe0;

    .line 45
    .line 46
    invoke-virtual {v0}, Lqe0;->notImplemented()V

    .line 47
    .line 48
    .line 49
    goto :goto_5e

    .line 50
    :cond_31
    check-cast v1, [B

    .line 51
    .line 52
    iput-object v1, v0, Lr5;->f:Ljava/lang/Object;

    .line 53
    .line 54
    move-object/from16 v0, p2

    .line 55
    .line 56
    check-cast v0, Lqe0;

    .line 57
    .line 58
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 59
    .line 60
    .line 61
    goto :goto_5e

    .line 62
    :cond_3d
    iput-boolean v5, v0, Lr5;->e:Z

    .line 63
    .line 64
    iget-boolean v1, v0, Lr5;->d:Z

    .line 65
    .line 66
    if-nez v1, :cond_4f

    .line 67
    .line 68
    iget-boolean v1, v0, Lr5;->c:Z

    .line 69
    .line 70
    if-nez v1, :cond_48

    .line 71
    .line 72
    goto :goto_4f

    .line 73
    :cond_48
    move-object/from16 v1, p2

    .line 74
    .line 75
    check-cast v1, Lqe0;

    .line 76
    .line 77
    iput-object v1, v0, Lr5;->b:Ljava/lang/Object;

    .line 78
    .line 79
    goto :goto_5e

    .line 80
    :cond_4f
    :goto_4f
    iget-object v0, v0, Lr5;->f:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v0, [B

    .line 83
    .line 84
    invoke-static {v0}, Lr5;->d([B)Ljava/util/HashMap;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    move-object/from16 v1, p2

    .line 89
    .line 90
    check-cast v1, Lqe0;

    .line 91
    .line 92
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 93
    .line 94
    .line 95
    :goto_5e
    return-void

    .line 96
    :sswitch_5f
    invoke-direct/range {p0 .. p2}, Lnw;->p(Loe0;Lse0;)V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :sswitch_63
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 101
    .line 102
    check-cast v0, Lu6;

    .line 103
    .line 104
    iget-object v2, v0, Lu6;->h:Ljava/lang/Object;

    .line 105
    .line 106
    check-cast v2, Lnw;

    .line 107
    .line 108
    if-nez v2, :cond_6f

    .line 109
    .line 110
    goto/16 :goto_29d

    .line 111
    .line 112
    :cond_6f
    iget-object v2, v1, Loe0;->a:Ljava/lang/String;

    .line 113
    .line 114
    iget-object v1, v1, Loe0;->b:Ljava/lang/Object;

    .line 115
    .line 116
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    .line 118
    .line 119
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    .line 120
    .line 121
    .line 122
    move-result v7

    .line 123
    const/4 v8, 0x5

    .line 124
    const/4 v9, 0x4

    .line 125
    const/4 v10, 0x3

    .line 126
    const/4 v11, 0x2

    .line 127
    const/4 v12, -0x1

    .line 128
    sparse-switch v7, :sswitch_data_6b6

    .line 129
    .line 130
    .line 131
    goto :goto_c4

    .line 132
    :sswitch_83
    const-string v7, "dispose"

    .line 133
    .line 134
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 135
    .line 136
    .line 137
    move-result v2

    .line 138
    if-nez v2, :cond_8c

    .line 139
    .line 140
    goto :goto_c4

    .line 141
    :cond_8c
    move v12, v8

    .line 142
    goto :goto_c4

    .line 143
    :sswitch_8e
    const-string v7, "isSurfaceControlEnabled"

    .line 144
    .line 145
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    if-nez v2, :cond_97

    .line 150
    .line 151
    goto :goto_c4

    .line 152
    :cond_97
    move v12, v9

    .line 153
    goto :goto_c4

    .line 154
    :sswitch_99
    const-string v7, "setDirection"

    .line 155
    .line 156
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    move-result v2

    .line 160
    if-nez v2, :cond_a2

    .line 161
    .line 162
    goto :goto_c4

    .line 163
    :cond_a2
    move v12, v10

    .line 164
    goto :goto_c4

    .line 165
    :sswitch_a4
    const-string v7, "touch"

    .line 166
    .line 167
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 168
    .line 169
    .line 170
    move-result v2

    .line 171
    if-nez v2, :cond_ad

    .line 172
    .line 173
    goto :goto_c4

    .line 174
    :cond_ad
    move v12, v11

    .line 175
    goto :goto_c4

    .line 176
    :sswitch_af
    const-string v7, "clearFocus"

    .line 177
    .line 178
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 179
    .line 180
    .line 181
    move-result v2

    .line 182
    if-nez v2, :cond_b8

    .line 183
    .line 184
    goto :goto_c4

    .line 185
    :cond_b8
    move v12, v5

    .line 186
    goto :goto_c4

    .line 187
    :sswitch_ba
    const-string v7, "create"

    .line 188
    .line 189
    invoke-virtual {v2, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 190
    .line 191
    .line 192
    move-result v2

    .line 193
    if-nez v2, :cond_c3

    .line 194
    .line 195
    goto :goto_c4

    .line 196
    :cond_c3
    move v12, v3

    .line 197
    :goto_c4
    const-string v2, "direction"

    .line 198
    .line 199
    const-string v7, "id"

    .line 200
    .line 201
    packed-switch v12, :pswitch_data_6d0

    .line 202
    .line 203
    .line 204
    move-object/from16 v0, p2

    .line 205
    .line 206
    check-cast v0, Lqe0;

    .line 207
    .line 208
    invoke-virtual {v0}, Lqe0;->notImplemented()V

    .line 209
    .line 210
    .line 211
    goto/16 :goto_29d

    .line 212
    .line 213
    :pswitch_d4
    check-cast v1, Ljava/util/Map;

    .line 214
    .line 215
    invoke-interface {v1, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 216
    .line 217
    .line 218
    move-result-object v1

    .line 219
    check-cast v1, Ljava/lang/Integer;

    .line 220
    .line 221
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 222
    .line 223
    .line 224
    move-result v1

    .line 225
    :try_start_e0
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v0, Lnw;

    .line 228
    .line 229
    invoke-virtual {v0, v1}, Lnw;->j(I)V

    .line 230
    .line 231
    .line 232
    move-object/from16 v0, p2

    .line 233
    .line 234
    check-cast v0, Lqe0;

    .line 235
    .line 236
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_ee
    .catch Ljava/lang/IllegalStateException; {:try_start_e0 .. :try_end_ee} :catch_f0

    .line 237
    .line 238
    .line 239
    goto/16 :goto_29d

    .line 240
    .line 241
    :catch_f0
    move-exception v0

    .line 242
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    move-object/from16 v1, p2

    .line 247
    .line 248
    check-cast v1, Lqe0;

    .line 249
    .line 250
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 251
    .line 252
    .line 253
    goto/16 :goto_29d

    .line 254
    .line 255
    :pswitch_fe
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 256
    .line 257
    check-cast v0, Lnw;

    .line 258
    .line 259
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 260
    .line 261
    check-cast v0, Lal0;

    .line 262
    .line 263
    iget-object v0, v0, Lal0;->j:Lio/flutter/embedding/engine/FlutterJNI;

    .line 264
    .line 265
    if-nez v0, :cond_10b

    .line 266
    .line 267
    goto :goto_10f

    .line 268
    :cond_10b
    invoke-virtual {v0}, Lio/flutter/embedding/engine/FlutterJNI;->IsSurfaceControlEnabled()Z

    .line 269
    .line 270
    .line 271
    move-result v3

    .line 272
    :goto_10f
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 273
    .line 274
    .line 275
    move-result-object v0

    .line 276
    move-object/from16 v1, p2

    .line 277
    .line 278
    check-cast v1, Lqe0;

    .line 279
    .line 280
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 281
    .line 282
    .line 283
    goto/16 :goto_29d

    .line 284
    .line 285
    :pswitch_11c
    check-cast v1, Ljava/util/Map;

    .line 286
    .line 287
    invoke-interface {v1, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 288
    .line 289
    .line 290
    move-result-object v3

    .line 291
    check-cast v3, Ljava/lang/Integer;

    .line 292
    .line 293
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 294
    .line 295
    .line 296
    move-result v3

    .line 297
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v1

    .line 301
    check-cast v1, Ljava/lang/Integer;

    .line 302
    .line 303
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 304
    .line 305
    .line 306
    move-result v1

    .line 307
    :try_start_132
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast v0, Lnw;

    .line 310
    .line 311
    invoke-virtual {v0, v3, v1}, Lnw;->s(II)V

    .line 312
    .line 313
    .line 314
    move-object/from16 v0, p2

    .line 315
    .line 316
    check-cast v0, Lqe0;

    .line 317
    .line 318
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_140
    .catch Ljava/lang/IllegalStateException; {:try_start_132 .. :try_end_140} :catch_142

    .line 319
    .line 320
    .line 321
    goto/16 :goto_29d

    .line 322
    .line 323
    :catch_142
    move-exception v0

    .line 324
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 325
    .line 326
    .line 327
    move-result-object v0

    .line 328
    move-object/from16 v1, p2

    .line 329
    .line 330
    check-cast v1, Lqe0;

    .line 331
    .line 332
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 333
    .line 334
    .line 335
    goto/16 :goto_29d

    .line 336
    .line 337
    :pswitch_150
    check-cast v1, Ljava/util/List;

    .line 338
    .line 339
    new-instance v12, Lsk0;

    .line 340
    .line 341
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 342
    .line 343
    .line 344
    move-result-object v2

    .line 345
    check-cast v2, Ljava/lang/Integer;

    .line 346
    .line 347
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 348
    .line 349
    .line 350
    move-result v13

    .line 351
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 352
    .line 353
    .line 354
    move-result-object v2

    .line 355
    move-object v14, v2

    .line 356
    check-cast v14, Ljava/lang/Number;

    .line 357
    .line 358
    invoke-interface {v1, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 359
    .line 360
    .line 361
    move-result-object v2

    .line 362
    move-object v15, v2

    .line 363
    check-cast v15, Ljava/lang/Number;

    .line 364
    .line 365
    invoke-interface {v1, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 366
    .line 367
    .line 368
    move-result-object v2

    .line 369
    check-cast v2, Ljava/lang/Integer;

    .line 370
    .line 371
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 372
    .line 373
    .line 374
    move-result v16

    .line 375
    invoke-interface {v1, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 376
    .line 377
    .line 378
    move-result-object v2

    .line 379
    check-cast v2, Ljava/lang/Integer;

    .line 380
    .line 381
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 382
    .line 383
    .line 384
    move-result v17

    .line 385
    invoke-interface {v1, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 386
    .line 387
    .line 388
    move-result-object v18

    .line 389
    const/4 v2, 0x6

    .line 390
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 391
    .line 392
    .line 393
    move-result-object v19

    .line 394
    const/4 v2, 0x7

    .line 395
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 396
    .line 397
    .line 398
    move-result-object v2

    .line 399
    check-cast v2, Ljava/lang/Integer;

    .line 400
    .line 401
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 402
    .line 403
    .line 404
    move-result v20

    .line 405
    const/16 v2, 0x8

    .line 406
    .line 407
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 408
    .line 409
    .line 410
    move-result-object v2

    .line 411
    check-cast v2, Ljava/lang/Integer;

    .line 412
    .line 413
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 414
    .line 415
    .line 416
    move-result v21

    .line 417
    const/16 v2, 0x9

    .line 418
    .line 419
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 420
    .line 421
    .line 422
    move-result-object v2

    .line 423
    check-cast v2, Ljava/lang/Double;

    .line 424
    .line 425
    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    .line 426
    .line 427
    .line 428
    move-result-wide v2

    .line 429
    double-to-float v2, v2

    .line 430
    const/16 v3, 0xa

    .line 431
    .line 432
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 433
    .line 434
    .line 435
    move-result-object v3

    .line 436
    check-cast v3, Ljava/lang/Double;

    .line 437
    .line 438
    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    .line 439
    .line 440
    .line 441
    move-result-wide v7

    .line 442
    double-to-float v3, v7

    .line 443
    const/16 v5, 0xb

    .line 444
    .line 445
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 446
    .line 447
    .line 448
    move-result-object v5

    .line 449
    check-cast v5, Ljava/lang/Integer;

    .line 450
    .line 451
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 452
    .line 453
    .line 454
    move-result v24

    .line 455
    const/16 v5, 0xc

    .line 456
    .line 457
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 458
    .line 459
    .line 460
    move-result-object v5

    .line 461
    check-cast v5, Ljava/lang/Integer;

    .line 462
    .line 463
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 464
    .line 465
    .line 466
    move-result v25

    .line 467
    const/16 v5, 0xd

    .line 468
    .line 469
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 470
    .line 471
    .line 472
    move-result-object v5

    .line 473
    check-cast v5, Ljava/lang/Integer;

    .line 474
    .line 475
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 476
    .line 477
    .line 478
    move-result v26

    .line 479
    const/16 v5, 0xe

    .line 480
    .line 481
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 482
    .line 483
    .line 484
    move-result-object v5

    .line 485
    check-cast v5, Ljava/lang/Integer;

    .line 486
    .line 487
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 488
    .line 489
    .line 490
    move-result v27

    .line 491
    const/16 v5, 0xf

    .line 492
    .line 493
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 494
    .line 495
    .line 496
    move-result-object v1

    .line 497
    check-cast v1, Ljava/lang/Number;

    .line 498
    .line 499
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 500
    .line 501
    .line 502
    move-result-wide v28

    .line 503
    move/from16 v22, v2

    .line 504
    .line 505
    move/from16 v23, v3

    .line 506
    .line 507
    invoke-direct/range {v12 .. v29}, Lsk0;-><init>(ILjava/lang/Number;Ljava/lang/Number;IILjava/lang/Object;Ljava/lang/Object;IIFFIIIIJ)V

    .line 508
    .line 509
    .line 510
    :try_start_1fd
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 511
    .line 512
    check-cast v0, Lnw;

    .line 513
    .line 514
    invoke-virtual {v0, v12}, Lnw;->q(Lsk0;)V

    .line 515
    .line 516
    .line 517
    move-object/from16 v0, p2

    .line 518
    .line 519
    check-cast v0, Lqe0;

    .line 520
    .line 521
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_20b
    .catch Ljava/lang/IllegalStateException; {:try_start_1fd .. :try_end_20b} :catch_20d

    .line 522
    .line 523
    .line 524
    goto/16 :goto_29d

    .line 525
    .line 526
    :catch_20d
    move-exception v0

    .line 527
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 528
    .line 529
    .line 530
    move-result-object v0

    .line 531
    move-object/from16 v1, p2

    .line 532
    .line 533
    check-cast v1, Lqe0;

    .line 534
    .line 535
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 536
    .line 537
    .line 538
    goto/16 :goto_29d

    .line 539
    .line 540
    :pswitch_21b
    check-cast v1, Ljava/lang/Integer;

    .line 541
    .line 542
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 543
    .line 544
    .line 545
    move-result v1

    .line 546
    :try_start_221
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 547
    .line 548
    check-cast v0, Lnw;

    .line 549
    .line 550
    invoke-virtual {v0, v1}, Lnw;->f(I)V

    .line 551
    .line 552
    .line 553
    move-object/from16 v0, p2

    .line 554
    .line 555
    check-cast v0, Lqe0;

    .line 556
    .line 557
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_22f
    .catch Ljava/lang/IllegalStateException; {:try_start_221 .. :try_end_22f} :catch_230

    .line 558
    .line 559
    .line 560
    goto :goto_29d

    .line 561
    :catch_230
    move-exception v0

    .line 562
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 563
    .line 564
    .line 565
    move-result-object v0

    .line 566
    move-object/from16 v1, p2

    .line 567
    .line 568
    check-cast v1, Lqe0;

    .line 569
    .line 570
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 571
    .line 572
    .line 573
    goto :goto_29d

    .line 574
    :pswitch_23d
    check-cast v1, Ljava/util/Map;

    .line 575
    .line 576
    const-string v3, "params"

    .line 577
    .line 578
    invoke-interface {v1, v3}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 579
    .line 580
    .line 581
    move-result v5

    .line 582
    if-eqz v5, :cond_254

    .line 583
    .line 584
    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 585
    .line 586
    .line 587
    move-result-object v3

    .line 588
    check-cast v3, [B

    .line 589
    .line 590
    invoke-static {v3}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    .line 591
    .line 592
    .line 593
    move-result-object v3

    .line 594
    move-object/from16 v21, v3

    .line 595
    .line 596
    goto :goto_256

    .line 597
    :cond_254
    move-object/from16 v21, v6

    .line 598
    .line 599
    :goto_256
    :try_start_256
    invoke-interface {v1, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 600
    .line 601
    .line 602
    move-result-object v3

    .line 603
    check-cast v3, Ljava/lang/Integer;

    .line 604
    .line 605
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 606
    .line 607
    .line 608
    move-result v9

    .line 609
    const-string v3, "viewType"

    .line 610
    .line 611
    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 612
    .line 613
    .line 614
    move-result-object v3

    .line 615
    move-object v10, v3

    .line 616
    check-cast v10, Ljava/lang/String;

    .line 617
    .line 618
    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 619
    .line 620
    .line 621
    move-result-object v1

    .line 622
    check-cast v1, Ljava/lang/Integer;

    .line 623
    .line 624
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 625
    .line 626
    .line 627
    move-result v19

    .line 628
    new-instance v8, Lok0;

    .line 629
    .line 630
    const-wide/16 v17, 0x0

    .line 631
    .line 632
    const/16 v20, 0x0

    .line 633
    .line 634
    const-wide/16 v11, 0x0

    .line 635
    .line 636
    const-wide/16 v13, 0x0

    .line 637
    .line 638
    const-wide/16 v15, 0x0

    .line 639
    .line 640
    invoke-direct/range {v8 .. v21}, Lok0;-><init>(ILjava/lang/String;DDDDIILjava/nio/ByteBuffer;)V

    .line 641
    .line 642
    .line 643
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 644
    .line 645
    check-cast v0, Lnw;

    .line 646
    .line 647
    invoke-virtual {v0, v8}, Lnw;->g(Lok0;)V

    .line 648
    .line 649
    .line 650
    move-object/from16 v0, p2

    .line 651
    .line 652
    check-cast v0, Lqe0;

    .line 653
    .line 654
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_290
    .catch Ljava/lang/IllegalStateException; {:try_start_256 .. :try_end_290} :catch_291

    .line 655
    .line 656
    .line 657
    goto :goto_29d

    .line 658
    :catch_291
    move-exception v0

    .line 659
    invoke-static {v0}, Landroid/util/Log;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    .line 660
    .line 661
    .line 662
    move-result-object v0

    .line 663
    move-object/from16 v1, p2

    .line 664
    .line 665
    check-cast v1, Lqe0;

    .line 666
    .line 667
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 668
    .line 669
    .line 670
    :goto_29d
    return-void

    .line 671
    :sswitch_29e
    invoke-direct/range {p0 .. p2}, Lnw;->o(Loe0;Lse0;)V

    .line 672
    .line 673
    .line 674
    return-void

    .line 675
    :sswitch_2a2
    const-string v2, "No such clipboard content format: "

    .line 676
    .line 677
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 678
    .line 679
    check-cast v0, Lu6;

    .line 680
    .line 681
    iget-object v7, v0, Lu6;->h:Ljava/lang/Object;

    .line 682
    .line 683
    check-cast v7, Lnw;

    .line 684
    .line 685
    if-nez v7, :cond_2b0

    .line 686
    .line 687
    goto/16 :goto_5d2

    .line 688
    .line 689
    :cond_2b0
    iget-object v7, v1, Loe0;->a:Ljava/lang/String;

    .line 690
    .line 691
    iget-object v1, v1, Loe0;->b:Ljava/lang/Object;

    .line 692
    .line 693
    :try_start_2b4
    invoke-virtual {v7}, Ljava/lang/String;->hashCode()I

    .line 694
    .line 695
    .line 696
    move-result v8
    :try_end_2b8
    .catch Lorg/json/JSONException; {:try_start_2b4 .. :try_end_2b8} :catch_2f5

    .line 697
    const-string v9, "text"

    .line 698
    .line 699
    const-string v10, "clipboard"

    .line 700
    .line 701
    sparse-switch v8, :sswitch_data_6e0

    .line 702
    .line 703
    .line 704
    goto/16 :goto_5b1

    .line 705
    .line 706
    :sswitch_2c1
    :try_start_2c1
    const-string v2, "SystemChrome.setPreferredOrientations"

    .line 707
    .line 708
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 709
    .line 710
    .line 711
    move-result v2
    :try_end_2c7
    .catch Lorg/json/JSONException; {:try_start_2c1 .. :try_end_2c7} :catch_2f5

    .line 712
    if-eqz v2, :cond_5b1

    .line 713
    .line 714
    :try_start_2c9
    check-cast v1, Lorg/json/JSONArray;

    .line 715
    .line 716
    invoke-static {v0, v1}, Lu6;->h(Lu6;Lorg/json/JSONArray;)I

    .line 717
    .line 718
    .line 719
    move-result v1

    .line 720
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 721
    .line 722
    check-cast v0, Lnw;

    .line 723
    .line 724
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 725
    .line 726
    check-cast v0, Lkk0;

    .line 727
    .line 728
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 729
    .line 730
    invoke-virtual {v0, v1}, Landroid/app/Activity;->setRequestedOrientation(I)V

    .line 731
    .line 732
    .line 733
    move-object/from16 v0, p2

    .line 734
    .line 735
    check-cast v0, Lqe0;

    .line 736
    .line 737
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_2e3
    .catch Lorg/json/JSONException; {:try_start_2c9 .. :try_end_2e3} :catch_2e7
    .catch Ljava/lang/NoSuchFieldException; {:try_start_2c9 .. :try_end_2e3} :catch_2e5

    .line 738
    .line 739
    .line 740
    goto/16 :goto_5d2

    .line 741
    .line 742
    :catch_2e5
    move-exception v0

    .line 743
    goto :goto_2e8

    .line 744
    :catch_2e7
    move-exception v0

    .line 745
    :goto_2e8
    :try_start_2e8
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 746
    .line 747
    .line 748
    move-result-object v0

    .line 749
    move-object/from16 v1, p2

    .line 750
    .line 751
    check-cast v1, Lqe0;

    .line 752
    .line 753
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 754
    .line 755
    .line 756
    goto/16 :goto_5d2

    .line 757
    .line 758
    :catch_2f5
    move-exception v0

    .line 759
    goto/16 :goto_5b9

    .line 760
    .line 761
    :sswitch_2f8
    const-string v2, "SystemChrome.setEnabledSystemUIOverlays"

    .line 762
    .line 763
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 764
    .line 765
    .line 766
    move-result v2
    :try_end_2fe
    .catch Lorg/json/JSONException; {:try_start_2e8 .. :try_end_2fe} :catch_2f5

    .line 767
    if-eqz v2, :cond_5b1

    .line 768
    .line 769
    :try_start_300
    check-cast v1, Lorg/json/JSONArray;

    .line 770
    .line 771
    invoke-static {v0, v1}, Lu6;->i(Lu6;Lorg/json/JSONArray;)Ljava/util/ArrayList;

    .line 772
    .line 773
    .line 774
    move-result-object v1

    .line 775
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 776
    .line 777
    check-cast v0, Lnw;

    .line 778
    .line 779
    invoke-virtual {v0, v1}, Lnw;->t(Ljava/util/ArrayList;)V

    .line 780
    .line 781
    .line 782
    move-object/from16 v0, p2

    .line 783
    .line 784
    check-cast v0, Lqe0;

    .line 785
    .line 786
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_314
    .catch Lorg/json/JSONException; {:try_start_300 .. :try_end_314} :catch_318
    .catch Ljava/lang/NoSuchFieldException; {:try_start_300 .. :try_end_314} :catch_316

    .line 787
    .line 788
    .line 789
    goto/16 :goto_5d2

    .line 790
    .line 791
    :catch_316
    move-exception v0

    .line 792
    goto :goto_319

    .line 793
    :catch_318
    move-exception v0

    .line 794
    :goto_319
    :try_start_319
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 795
    .line 796
    .line 797
    move-result-object v0

    .line 798
    move-object/from16 v1, p2

    .line 799
    .line 800
    check-cast v1, Lqe0;

    .line 801
    .line 802
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 803
    .line 804
    .line 805
    goto/16 :goto_5d2

    .line 806
    .line 807
    :sswitch_326
    const-string v3, "Clipboard.getData"

    .line 808
    .line 809
    invoke-virtual {v7, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 810
    .line 811
    .line 812
    move-result v3

    .line 813
    if-eqz v3, :cond_5b1

    .line 814
    .line 815
    check-cast v1, Ljava/lang/String;
    :try_end_330
    .catch Lorg/json/JSONException; {:try_start_319 .. :try_end_330} :catch_2f5

    .line 816
    .line 817
    if-eqz v1, :cond_342

    .line 818
    .line 819
    :try_start_332
    invoke-static {v1}, Lbk0;->a(Ljava/lang/String;)Lbk0;

    .line 820
    .line 821
    .line 822
    move-result-object v1
    :try_end_336
    .catch Ljava/lang/NoSuchFieldException; {:try_start_332 .. :try_end_336} :catch_337
    .catch Lorg/json/JSONException; {:try_start_332 .. :try_end_336} :catch_2f5

    .line 823
    goto :goto_343

    .line 824
    :catch_337
    :try_start_337
    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 825
    .line 826
    .line 827
    move-result-object v1

    .line 828
    move-object/from16 v2, p2

    .line 829
    .line 830
    check-cast v2, Lqe0;

    .line 831
    .line 832
    invoke-virtual {v2, v4, v1, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 833
    .line 834
    .line 835
    :cond_342
    move-object v1, v6

    .line 836
    :goto_343
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 837
    .line 838
    check-cast v0, Lnw;

    .line 839
    .line 840
    invoke-virtual {v0, v1}, Lnw;->k(Lbk0;)Ljava/lang/CharSequence;

    .line 841
    .line 842
    .line 843
    move-result-object v0

    .line 844
    if-eqz v0, :cond_35e

    .line 845
    .line 846
    new-instance v1, Lorg/json/JSONObject;

    .line 847
    .line 848
    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    .line 849
    .line 850
    .line 851
    invoke-virtual {v1, v9, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    .line 852
    .line 853
    .line 854
    move-object/from16 v0, p2

    .line 855
    .line 856
    check-cast v0, Lqe0;

    .line 857
    .line 858
    invoke-virtual {v0, v1}, Lqe0;->success(Ljava/lang/Object;)V

    .line 859
    .line 860
    .line 861
    goto/16 :goto_5d2

    .line 862
    .line 863
    :cond_35e
    move-object/from16 v0, p2

    .line 864
    .line 865
    check-cast v0, Lqe0;

    .line 866
    .line 867
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 868
    .line 869
    .line 870
    goto/16 :goto_5d2

    .line 871
    .line 872
    :sswitch_367
    const-string v2, "SystemChrome.setSystemUIOverlayStyle"

    .line 873
    .line 874
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 875
    .line 876
    .line 877
    move-result v2
    :try_end_36d
    .catch Lorg/json/JSONException; {:try_start_337 .. :try_end_36d} :catch_2f5

    .line 878
    if-eqz v2, :cond_5b1

    .line 879
    .line 880
    :try_start_36f
    check-cast v1, Lorg/json/JSONObject;

    .line 881
    .line 882
    invoke-static {v0, v1}, Lu6;->k(Lu6;Lorg/json/JSONObject;)Ldk0;

    .line 883
    .line 884
    .line 885
    move-result-object v1

    .line 886
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 887
    .line 888
    check-cast v0, Lnw;

    .line 889
    .line 890
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 891
    .line 892
    check-cast v0, Lkk0;

    .line 893
    .line 894
    invoke-virtual {v0, v1}, Lkk0;->a(Ldk0;)V

    .line 895
    .line 896
    .line 897
    move-object/from16 v0, p2

    .line 898
    .line 899
    check-cast v0, Lqe0;

    .line 900
    .line 901
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_387
    .catch Lorg/json/JSONException; {:try_start_36f .. :try_end_387} :catch_38b
    .catch Ljava/lang/NoSuchFieldException; {:try_start_36f .. :try_end_387} :catch_389

    .line 902
    .line 903
    .line 904
    goto/16 :goto_5d2

    .line 905
    .line 906
    :catch_389
    move-exception v0

    .line 907
    goto :goto_38c

    .line 908
    :catch_38b
    move-exception v0

    .line 909
    :goto_38c
    :try_start_38c
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 910
    .line 911
    .line 912
    move-result-object v0

    .line 913
    move-object/from16 v1, p2

    .line 914
    .line 915
    check-cast v1, Lqe0;

    .line 916
    .line 917
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 918
    .line 919
    .line 920
    goto/16 :goto_5d2

    .line 921
    .line 922
    :sswitch_399
    const-string v2, "SystemChrome.setEnabledSystemUIMode"

    .line 923
    .line 924
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 925
    .line 926
    .line 927
    move-result v2
    :try_end_39f
    .catch Lorg/json/JSONException; {:try_start_38c .. :try_end_39f} :catch_2f5

    .line 928
    if-eqz v2, :cond_5b1

    .line 929
    .line 930
    :try_start_3a1
    check-cast v1, Ljava/lang/String;

    .line 931
    .line 932
    invoke-static {v0, v1}, Lu6;->j(Lu6;Ljava/lang/String;)I

    .line 933
    .line 934
    .line 935
    move-result v1

    .line 936
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 937
    .line 938
    check-cast v0, Lnw;

    .line 939
    .line 940
    invoke-virtual {v0, v1}, Lnw;->u(I)V

    .line 941
    .line 942
    .line 943
    move-object/from16 v0, p2

    .line 944
    .line 945
    check-cast v0, Lqe0;

    .line 946
    .line 947
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_3b5
    .catch Lorg/json/JSONException; {:try_start_3a1 .. :try_end_3b5} :catch_3b9
    .catch Ljava/lang/NoSuchFieldException; {:try_start_3a1 .. :try_end_3b5} :catch_3b7

    .line 948
    .line 949
    .line 950
    goto/16 :goto_5d2

    .line 951
    .line 952
    :catch_3b7
    move-exception v0

    .line 953
    goto :goto_3ba

    .line 954
    :catch_3b9
    move-exception v0

    .line 955
    :goto_3ba
    :try_start_3ba
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 956
    .line 957
    .line 958
    move-result-object v0

    .line 959
    move-object/from16 v1, p2

    .line 960
    .line 961
    check-cast v1, Lqe0;

    .line 962
    .line 963
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 964
    .line 965
    .line 966
    goto/16 :goto_5d2

    .line 967
    .line 968
    :sswitch_3c7
    const-string v1, "Clipboard.hasStrings"

    .line 969
    .line 970
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 971
    .line 972
    .line 973
    move-result v1

    .line 974
    if-eqz v1, :cond_5b1

    .line 975
    .line 976
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 977
    .line 978
    check-cast v0, Lnw;

    .line 979
    .line 980
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 981
    .line 982
    check-cast v0, Lkk0;

    .line 983
    .line 984
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 985
    .line 986
    invoke-virtual {v0, v10}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 987
    .line 988
    .line 989
    move-result-object v0

    .line 990
    check-cast v0, Landroid/content/ClipboardManager;

    .line 991
    .line 992
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->hasPrimaryClip()Z

    .line 993
    .line 994
    .line 995
    move-result v1

    .line 996
    if-nez v1, :cond_3e6

    .line 997
    .line 998
    goto :goto_3f3

    .line 999
    :cond_3e6
    invoke-virtual {v0}, Landroid/content/ClipboardManager;->getPrimaryClipDescription()Landroid/content/ClipDescription;

    .line 1000
    .line 1001
    .line 1002
    move-result-object v0

    .line 1003
    if-nez v0, :cond_3ed

    .line 1004
    .line 1005
    goto :goto_3f3

    .line 1006
    :cond_3ed
    const-string v1, "text/*"

    .line 1007
    .line 1008
    invoke-virtual {v0, v1}, Landroid/content/ClipDescription;->hasMimeType(Ljava/lang/String;)Z

    .line 1009
    .line 1010
    .line 1011
    move-result v3

    .line 1012
    :goto_3f3
    new-instance v0, Lorg/json/JSONObject;

    .line 1013
    .line 1014
    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    .line 1015
    .line 1016
    .line 1017
    const-string v1, "value"

    .line 1018
    .line 1019
    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;

    .line 1020
    .line 1021
    .line 1022
    move-object/from16 v1, p2

    .line 1023
    .line 1024
    check-cast v1, Lqe0;

    .line 1025
    .line 1026
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1027
    .line 1028
    .line 1029
    goto/16 :goto_5d2

    .line 1030
    .line 1031
    :sswitch_406
    const-string v1, "SystemChrome.restoreSystemUIOverlays"

    .line 1032
    .line 1033
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1034
    .line 1035
    .line 1036
    move-result v1

    .line 1037
    if-eqz v1, :cond_5b1

    .line 1038
    .line 1039
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1040
    .line 1041
    check-cast v0, Lnw;

    .line 1042
    .line 1043
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1044
    .line 1045
    check-cast v0, Lkk0;

    .line 1046
    .line 1047
    invoke-virtual {v0}, Lkk0;->b()V

    .line 1048
    .line 1049
    .line 1050
    move-object/from16 v0, p2

    .line 1051
    .line 1052
    check-cast v0, Lqe0;

    .line 1053
    .line 1054
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1055
    .line 1056
    .line 1057
    goto/16 :goto_5d2

    .line 1058
    .line 1059
    :sswitch_422
    const-string v2, "SystemSound.play"

    .line 1060
    .line 1061
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1062
    .line 1063
    .line 1064
    move-result v2
    :try_end_428
    .catch Lorg/json/JSONException; {:try_start_3ba .. :try_end_428} :catch_2f5

    .line 1065
    if-eqz v2, :cond_5b1

    .line 1066
    .line 1067
    :try_start_42a
    check-cast v1, Ljava/lang/String;

    .line 1068
    .line 1069
    invoke-static {v1}, Lck0;->a(Ljava/lang/String;)I

    .line 1070
    .line 1071
    .line 1072
    move-result v1

    .line 1073
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1074
    .line 1075
    check-cast v0, Lnw;

    .line 1076
    .line 1077
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1078
    .line 1079
    check-cast v0, Lkk0;

    .line 1080
    .line 1081
    if-ne v1, v5, :cond_447

    .line 1082
    .line 1083
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 1084
    .line 1085
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 1086
    .line 1087
    .line 1088
    move-result-object v0

    .line 1089
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 1090
    .line 1091
    .line 1092
    move-result-object v0

    .line 1093
    invoke-virtual {v0, v3}, Landroid/view/View;->playSoundEffect(I)V

    .line 1094
    .line 1095
    .line 1096
    :cond_447
    move-object/from16 v0, p2

    .line 1097
    .line 1098
    check-cast v0, Lqe0;

    .line 1099
    .line 1100
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_44e
    .catch Ljava/lang/NoSuchFieldException; {:try_start_42a .. :try_end_44e} :catch_450
    .catch Lorg/json/JSONException; {:try_start_42a .. :try_end_44e} :catch_2f5

    .line 1101
    .line 1102
    .line 1103
    goto/16 :goto_5d2

    .line 1104
    .line 1105
    :catch_450
    move-exception v0

    .line 1106
    :try_start_451
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1107
    .line 1108
    .line 1109
    move-result-object v0

    .line 1110
    move-object/from16 v1, p2

    .line 1111
    .line 1112
    check-cast v1, Lqe0;

    .line 1113
    .line 1114
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1115
    .line 1116
    .line 1117
    goto/16 :goto_5d2

    .line 1118
    .line 1119
    :sswitch_45e
    const-string v2, "HapticFeedback.vibrate"

    .line 1120
    .line 1121
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1122
    .line 1123
    .line 1124
    move-result v2
    :try_end_464
    .catch Lorg/json/JSONException; {:try_start_451 .. :try_end_464} :catch_2f5

    .line 1125
    if-eqz v2, :cond_5b1

    .line 1126
    .line 1127
    :try_start_466
    check-cast v1, Ljava/lang/String;

    .line 1128
    .line 1129
    invoke-static {v1}, Lzi0;->c(Ljava/lang/String;)I

    .line 1130
    .line 1131
    .line 1132
    move-result v1

    .line 1133
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1134
    .line 1135
    check-cast v0, Lnw;

    .line 1136
    .line 1137
    invoke-virtual {v0, v1}, Lnw;->v(I)V

    .line 1138
    .line 1139
    .line 1140
    move-object/from16 v0, p2

    .line 1141
    .line 1142
    check-cast v0, Lqe0;

    .line 1143
    .line 1144
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_47a
    .catch Ljava/lang/NoSuchFieldException; {:try_start_466 .. :try_end_47a} :catch_47c
    .catch Lorg/json/JSONException; {:try_start_466 .. :try_end_47a} :catch_2f5

    .line 1145
    .line 1146
    .line 1147
    goto/16 :goto_5d2

    .line 1148
    .line 1149
    :catch_47c
    move-exception v0

    .line 1150
    :try_start_47d
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1151
    .line 1152
    .line 1153
    move-result-object v0

    .line 1154
    move-object/from16 v1, p2

    .line 1155
    .line 1156
    check-cast v1, Lqe0;

    .line 1157
    .line 1158
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1159
    .line 1160
    .line 1161
    goto/16 :goto_5d2

    .line 1162
    .line 1163
    :sswitch_48a
    const-string v2, "SystemChrome.setApplicationSwitcherDescription"

    .line 1164
    .line 1165
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1166
    .line 1167
    .line 1168
    move-result v2
    :try_end_490
    .catch Lorg/json/JSONException; {:try_start_47d .. :try_end_490} :catch_2f5

    .line 1169
    if-eqz v2, :cond_5b1

    .line 1170
    .line 1171
    :try_start_492
    check-cast v1, Lorg/json/JSONObject;

    .line 1172
    .line 1173
    const-string v2, "primaryColor"

    .line 1174
    .line 1175
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    .line 1176
    .line 1177
    .line 1178
    move-result v2

    .line 1179
    if-eqz v2, :cond_49f

    .line 1180
    .line 1181
    const/high16 v5, -0x1000000

    .line 1182
    .line 1183
    or-int/2addr v2, v5

    .line 1184
    :cond_49f
    const-string v5, "label"

    .line 1185
    .line 1186
    invoke-virtual {v1, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1187
    .line 1188
    .line 1189
    move-result-object v1

    .line 1190
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1191
    .line 1192
    check-cast v0, Lnw;

    .line 1193
    .line 1194
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1195
    .line 1196
    check-cast v0, Lkk0;

    .line 1197
    .line 1198
    new-instance v5, Landroid/app/ActivityManager$TaskDescription;

    .line 1199
    .line 1200
    invoke-direct {v5, v1, v3, v2}, Landroid/app/ActivityManager$TaskDescription;-><init>(Ljava/lang/String;II)V

    .line 1201
    .line 1202
    .line 1203
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 1204
    .line 1205
    invoke-virtual {v0, v5}, Landroid/app/Activity;->setTaskDescription(Landroid/app/ActivityManager$TaskDescription;)V

    .line 1206
    .line 1207
    .line 1208
    move-object/from16 v0, p2

    .line 1209
    .line 1210
    check-cast v0, Lqe0;

    .line 1211
    .line 1212
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_4be
    .catch Lorg/json/JSONException; {:try_start_492 .. :try_end_4be} :catch_4c0

    .line 1213
    .line 1214
    .line 1215
    goto/16 :goto_5d2

    .line 1216
    .line 1217
    :catch_4c0
    move-exception v0

    .line 1218
    :try_start_4c1
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1219
    .line 1220
    .line 1221
    move-result-object v0

    .line 1222
    move-object/from16 v1, p2

    .line 1223
    .line 1224
    check-cast v1, Lqe0;

    .line 1225
    .line 1226
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1227
    .line 1228
    .line 1229
    goto/16 :goto_5d2

    .line 1230
    .line 1231
    :sswitch_4ce
    const-string v1, "SystemChrome.setSystemUIChangeListener"

    .line 1232
    .line 1233
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1234
    .line 1235
    .line 1236
    move-result v1

    .line 1237
    if-eqz v1, :cond_5b1

    .line 1238
    .line 1239
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1240
    .line 1241
    check-cast v0, Lnw;

    .line 1242
    .line 1243
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1244
    .line 1245
    check-cast v0, Lkk0;

    .line 1246
    .line 1247
    iget-object v1, v0, Lkk0;->a:Landroid/app/Activity;

    .line 1248
    .line 1249
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 1250
    .line 1251
    .line 1252
    move-result-object v1

    .line 1253
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 1254
    .line 1255
    .line 1256
    move-result-object v1

    .line 1257
    new-instance v2, Ljk0;

    .line 1258
    .line 1259
    invoke-direct {v2, v0, v1}, Ljk0;-><init>(Lkk0;Landroid/view/View;)V

    .line 1260
    .line 1261
    .line 1262
    invoke-virtual {v1, v2}, Landroid/view/View;->setOnSystemUiVisibilityChangeListener(Landroid/view/View$OnSystemUiVisibilityChangeListener;)V

    .line 1263
    .line 1264
    .line 1265
    move-object/from16 v0, p2

    .line 1266
    .line 1267
    check-cast v0, Lqe0;

    .line 1268
    .line 1269
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1270
    .line 1271
    .line 1272
    goto/16 :goto_5d2

    .line 1273
    .line 1274
    :sswitch_4f9
    const-string v2, "Clipboard.setData"

    .line 1275
    .line 1276
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1277
    .line 1278
    .line 1279
    move-result v2

    .line 1280
    if-eqz v2, :cond_5b1

    .line 1281
    .line 1282
    check-cast v1, Lorg/json/JSONObject;

    .line 1283
    .line 1284
    invoke-virtual {v1, v9}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1285
    .line 1286
    .line 1287
    move-result-object v1

    .line 1288
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1289
    .line 1290
    check-cast v0, Lnw;

    .line 1291
    .line 1292
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1293
    .line 1294
    check-cast v0, Lkk0;

    .line 1295
    .line 1296
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 1297
    .line 1298
    invoke-virtual {v0, v10}, Landroid/app/Activity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 1299
    .line 1300
    .line 1301
    move-result-object v0

    .line 1302
    check-cast v0, Landroid/content/ClipboardManager;

    .line 1303
    .line 1304
    const-string v2, "text label?"

    .line 1305
    .line 1306
    invoke-static {v2, v1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    .line 1307
    .line 1308
    .line 1309
    move-result-object v1

    .line 1310
    invoke-virtual {v0, v1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    .line 1311
    .line 1312
    .line 1313
    move-object/from16 v0, p2

    .line 1314
    .line 1315
    check-cast v0, Lqe0;

    .line 1316
    .line 1317
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1318
    .line 1319
    .line 1320
    goto/16 :goto_5d2

    .line 1321
    .line 1322
    :sswitch_529
    const-string v1, "SystemNavigator.pop"

    .line 1323
    .line 1324
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1325
    .line 1326
    .line 1327
    move-result v1

    .line 1328
    if-eqz v1, :cond_5b1

    .line 1329
    .line 1330
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1331
    .line 1332
    check-cast v0, Lnw;

    .line 1333
    .line 1334
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1335
    .line 1336
    check-cast v0, Lkk0;

    .line 1337
    .line 1338
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 1339
    .line 1340
    instance-of v1, v0, Lth0;

    .line 1341
    .line 1342
    if-eqz v1, :cond_549

    .line 1343
    .line 1344
    check-cast v0, Lth0;

    .line 1345
    .line 1346
    invoke-interface {v0}, Lth0;->getOnBackPressedDispatcher()Lsh0;

    .line 1347
    .line 1348
    .line 1349
    move-result-object v0

    .line 1350
    invoke-virtual {v0}, Lsh0;->b()V

    .line 1351
    .line 1352
    .line 1353
    goto :goto_54c

    .line 1354
    :cond_549
    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    .line 1355
    .line 1356
    .line 1357
    :goto_54c
    move-object/from16 v0, p2

    .line 1358
    .line 1359
    check-cast v0, Lqe0;

    .line 1360
    .line 1361
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1362
    .line 1363
    .line 1364
    goto/16 :goto_5d2

    .line 1365
    .line 1366
    :sswitch_555
    const-string v2, "Share.invoke"

    .line 1367
    .line 1368
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1369
    .line 1370
    .line 1371
    move-result v2

    .line 1372
    if-eqz v2, :cond_5b1

    .line 1373
    .line 1374
    check-cast v1, Ljava/lang/String;

    .line 1375
    .line 1376
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1377
    .line 1378
    check-cast v0, Lnw;

    .line 1379
    .line 1380
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1381
    .line 1382
    check-cast v0, Lkk0;

    .line 1383
    .line 1384
    new-instance v2, Landroid/content/Intent;

    .line 1385
    .line 1386
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 1387
    .line 1388
    .line 1389
    const-string v3, "android.intent.action.SEND"

    .line 1390
    .line 1391
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 1392
    .line 1393
    .line 1394
    const-string v3, "text/plain"

    .line 1395
    .line 1396
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 1397
    .line 1398
    .line 1399
    const-string v3, "android.intent.extra.TEXT"

    .line 1400
    .line 1401
    invoke-virtual {v2, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 1402
    .line 1403
    .line 1404
    iget-object v0, v0, Lkk0;->a:Landroid/app/Activity;

    .line 1405
    .line 1406
    invoke-static {v2, v6}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    .line 1407
    .line 1408
    .line 1409
    move-result-object v1

    .line 1410
    invoke-virtual {v0, v1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    .line 1411
    .line 1412
    .line 1413
    move-object/from16 v0, p2

    .line 1414
    .line 1415
    check-cast v0, Lqe0;

    .line 1416
    .line 1417
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1418
    .line 1419
    .line 1420
    goto :goto_5d2

    .line 1421
    :sswitch_58c
    const-string v2, "SystemNavigator.setFrameworkHandlesBack"

    .line 1422
    .line 1423
    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1424
    .line 1425
    .line 1426
    move-result v2

    .line 1427
    if-eqz v2, :cond_5b1

    .line 1428
    .line 1429
    check-cast v1, Ljava/lang/Boolean;

    .line 1430
    .line 1431
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 1432
    .line 1433
    .line 1434
    move-result v1

    .line 1435
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1436
    .line 1437
    check-cast v0, Lnw;

    .line 1438
    .line 1439
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1440
    .line 1441
    check-cast v0, Lkk0;

    .line 1442
    .line 1443
    iget-object v0, v0, Lkk0;->c:Ldv;

    .line 1444
    .line 1445
    if-eqz v0, :cond_5a9

    .line 1446
    .line 1447
    invoke-virtual {v0, v1}, Ldv;->g(Z)V

    .line 1448
    .line 1449
    .line 1450
    :cond_5a9
    move-object/from16 v0, p2

    .line 1451
    .line 1452
    check-cast v0, Lqe0;

    .line 1453
    .line 1454
    invoke-virtual {v0, v6}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1455
    .line 1456
    .line 1457
    goto :goto_5d2

    .line 1458
    :cond_5b1
    :goto_5b1
    move-object/from16 v0, p2

    .line 1459
    .line 1460
    check-cast v0, Lqe0;

    .line 1461
    .line 1462
    invoke-virtual {v0}, Lqe0;->notImplemented()V
    :try_end_5b8
    .catch Lorg/json/JSONException; {:try_start_4c1 .. :try_end_5b8} :catch_2f5

    .line 1463
    .line 1464
    .line 1465
    goto :goto_5d2

    .line 1466
    :goto_5b9
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1467
    .line 1468
    const-string v2, "JSON error: "

    .line 1469
    .line 1470
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1471
    .line 1472
    .line 1473
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1474
    .line 1475
    .line 1476
    move-result-object v0

    .line 1477
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1478
    .line 1479
    .line 1480
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1481
    .line 1482
    .line 1483
    move-result-object v0

    .line 1484
    move-object/from16 v1, p2

    .line 1485
    .line 1486
    check-cast v1, Lqe0;

    .line 1487
    .line 1488
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1489
    .line 1490
    .line 1491
    :goto_5d2
    return-void

    .line 1492
    :sswitch_5d3
    const-string v2, "Error when setting cursors: "

    .line 1493
    .line 1494
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1495
    .line 1496
    check-cast v0, Lnw;

    .line 1497
    .line 1498
    iget-object v3, v0, Lnw;->g:Ljava/lang/Object;

    .line 1499
    .line 1500
    check-cast v3, Lnw;

    .line 1501
    .line 1502
    if-nez v3, :cond_5e0

    .line 1503
    .line 1504
    goto :goto_645

    .line 1505
    :cond_5e0
    iget-object v3, v1, Loe0;->a:Ljava/lang/String;

    .line 1506
    .line 1507
    :try_start_5e2
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    .line 1508
    .line 1509
    .line 1510
    move-result v5

    .line 1511
    const v7, -0x4de8d908

    .line 1512
    .line 1513
    .line 1514
    if-eq v5, v7, :cond_5ec

    .line 1515
    .line 1516
    goto :goto_645

    .line 1517
    :cond_5ec
    const-string v5, "activateSystemCursor"

    .line 1518
    .line 1519
    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1520
    .line 1521
    .line 1522
    move-result v3

    .line 1523
    if-eqz v3, :cond_645

    .line 1524
    .line 1525
    iget-object v1, v1, Loe0;->b:Ljava/lang/Object;

    .line 1526
    .line 1527
    check-cast v1, Ljava/util/HashMap;

    .line 1528
    .line 1529
    const-string v3, "kind"

    .line 1530
    .line 1531
    invoke-virtual {v1, v3}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1532
    .line 1533
    .line 1534
    move-result-object v1

    .line 1535
    check-cast v1, Ljava/lang/String;
    :try_end_600
    .catch Ljava/lang/Exception; {:try_start_5e2 .. :try_end_600} :catch_611

    .line 1536
    .line 1537
    :try_start_600
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1538
    .line 1539
    check-cast v0, Lnw;

    .line 1540
    .line 1541
    invoke-virtual {v0, v1}, Lnw;->a(Ljava/lang/String;)V
    :try_end_607
    .catch Ljava/lang/Exception; {:try_start_600 .. :try_end_607} :catch_613

    .line 1542
    .line 1543
    .line 1544
    :try_start_607
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 1545
    .line 1546
    move-object/from16 v1, p2

    .line 1547
    .line 1548
    check-cast v1, Lqe0;

    .line 1549
    .line 1550
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 1551
    .line 1552
    .line 1553
    goto :goto_645

    .line 1554
    :catch_611
    move-exception v0

    .line 1555
    goto :goto_62c

    .line 1556
    :catch_613
    move-exception v0

    .line 1557
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1558
    .line 1559
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1560
    .line 1561
    .line 1562
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1563
    .line 1564
    .line 1565
    move-result-object v0

    .line 1566
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1567
    .line 1568
    .line 1569
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1570
    .line 1571
    .line 1572
    move-result-object v0

    .line 1573
    move-object/from16 v1, p2

    .line 1574
    .line 1575
    check-cast v1, Lqe0;

    .line 1576
    .line 1577
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V
    :try_end_62b
    .catch Ljava/lang/Exception; {:try_start_607 .. :try_end_62b} :catch_611

    .line 1578
    .line 1579
    .line 1580
    goto :goto_645

    .line 1581
    :goto_62c
    new-instance v1, Ljava/lang/StringBuilder;

    .line 1582
    .line 1583
    const-string v2, "Unhandled error: "

    .line 1584
    .line 1585
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1586
    .line 1587
    .line 1588
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1589
    .line 1590
    .line 1591
    move-result-object v0

    .line 1592
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1593
    .line 1594
    .line 1595
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1596
    .line 1597
    .line 1598
    move-result-object v0

    .line 1599
    move-object/from16 v1, p2

    .line 1600
    .line 1601
    check-cast v1, Lqe0;

    .line 1602
    .line 1603
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1604
    .line 1605
    .line 1606
    :cond_645
    :goto_645
    return-void

    .line 1607
    :sswitch_646
    const-string v2, "locale"

    .line 1608
    .line 1609
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 1610
    .line 1611
    check-cast v0, Lu6;

    .line 1612
    .line 1613
    iget-object v3, v0, Lu6;->h:Ljava/lang/Object;

    .line 1614
    .line 1615
    check-cast v3, Lnw;

    .line 1616
    .line 1617
    if-nez v3, :cond_653

    .line 1618
    .line 1619
    goto :goto_69b

    .line 1620
    :cond_653
    iget-object v3, v1, Loe0;->a:Ljava/lang/String;

    .line 1621
    .line 1622
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1623
    .line 1624
    .line 1625
    const-string v5, "Localization.getStringResource"

    .line 1626
    .line 1627
    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 1628
    .line 1629
    .line 1630
    move-result v3

    .line 1631
    if-nez v3, :cond_668

    .line 1632
    .line 1633
    move-object/from16 v0, p2

    .line 1634
    .line 1635
    check-cast v0, Lqe0;

    .line 1636
    .line 1637
    invoke-virtual {v0}, Lqe0;->notImplemented()V

    .line 1638
    .line 1639
    .line 1640
    goto :goto_69b

    .line 1641
    :cond_668
    iget-object v1, v1, Loe0;->b:Ljava/lang/Object;

    .line 1642
    .line 1643
    check-cast v1, Lorg/json/JSONObject;

    .line 1644
    .line 1645
    :try_start_66c
    const-string v3, "key"

    .line 1646
    .line 1647
    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1648
    .line 1649
    .line 1650
    move-result-object v3

    .line 1651
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    .line 1652
    .line 1653
    .line 1654
    move-result v5

    .line 1655
    if-eqz v5, :cond_67f

    .line 1656
    .line 1657
    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    .line 1658
    .line 1659
    .line 1660
    move-result-object v1

    .line 1661
    goto :goto_680

    .line 1662
    :catch_67d
    move-exception v0

    .line 1663
    goto :goto_690

    .line 1664
    :cond_67f
    move-object v1, v6

    .line 1665
    :goto_680
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 1666
    .line 1667
    check-cast v0, Lnw;

    .line 1668
    .line 1669
    invoke-virtual {v0, v3, v1}, Lnw;->l(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1670
    .line 1671
    .line 1672
    move-result-object v0

    .line 1673
    move-object/from16 v1, p2

    .line 1674
    .line 1675
    check-cast v1, Lqe0;

    .line 1676
    .line 1677
    invoke-virtual {v1, v0}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_68f
    .catch Lorg/json/JSONException; {:try_start_66c .. :try_end_68f} :catch_67d

    .line 1678
    .line 1679
    .line 1680
    goto :goto_69b

    .line 1681
    :goto_690
    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 1682
    .line 1683
    .line 1684
    move-result-object v0

    .line 1685
    move-object/from16 v1, p2

    .line 1686
    .line 1687
    check-cast v1, Lqe0;

    .line 1688
    .line 1689
    invoke-virtual {v1, v4, v0, v6}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 1690
    .line 1691
    .line 1692
    :goto_69b
    return-void

    .line 1693
    :sswitch_data_69c
    .sparse-switch
        0x8 -> :sswitch_646
        0xd -> :sswitch_5d3
        0x12 -> :sswitch_2a2
        0x14 -> :sswitch_29e
        0x15 -> :sswitch_63
        0x18 -> :sswitch_5f
    .end sparse-switch

    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    :sswitch_data_6b6
    .sparse-switch
        -0x509a5f04 -> :sswitch_ba
        -0x2d106975 -> :sswitch_af
        0x696df3f -> :sswitch_a4
        0x2261393d -> :sswitch_99
        0x2cc8f227 -> :sswitch_8e
        0x63a5261f -> :sswitch_83
    .end sparse-switch

    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    :pswitch_data_6d0
    .packed-switch 0x0
        :pswitch_23d
        :pswitch_21b
        :pswitch_150
        :pswitch_11c
        :pswitch_fe
        :pswitch_d4
    .end packed-switch

    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    :sswitch_data_6e0
    .sparse-switch
        -0x59804db0 -> :sswitch_58c
        -0x3789da79 -> :sswitch_555
        -0x2dad73d5 -> :sswitch_529
        -0x2af4a94c -> :sswitch_4f9
        -0x2267c49c -> :sswitch_4ce
        -0x20b0f718 -> :sswitch_48a
        -0xebc6f23 -> :sswitch_45e
        -0xcd4cf9e -> :sswitch_422
        0xe6a45af -> :sswitch_406
        0x3436a200 -> :sswitch_3c7
        0x4341194a -> :sswitch_399
        0x52e10221 -> :sswitch_367
        0x5a408fa8 -> :sswitch_326
        0x63cbfa4a -> :sswitch_2f8
        0x7e576127 -> :sswitch_2c1
    .end sparse-switch
.end method

.method public q(Lsk0;)V
    .registers 28

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    iget v1, v0, Lsk0;->a:I

    .line 4
    .line 5
    move-object/from16 v2, p0

    .line 6
    .line 7
    iget-object v2, v2, Lnw;->g:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v2, Lal0;

    .line 10
    .line 11
    iget-object v3, v2, Lal0;->h:Ldv;

    .line 12
    .line 13
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    .line 22
    .line 23
    iget-object v4, v2, Lal0;->n:Landroid/util/SparseArray;

    .line 24
    .line 25
    invoke-virtual {v4, v1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v4

    .line 29
    check-cast v4, Lnk0;

    .line 30
    .line 31
    const-string v5, "PlatformViewsController2"

    .line 32
    .line 33
    if-nez v4, :cond_34

    .line 34
    .line 35
    new-instance v0, Ljava/lang/StringBuilder;

    .line 36
    .line 37
    const-string v2, "Sending touch to an unknown view with id: "

    .line 38
    .line 39
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 40
    .line 41
    .line 42
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-static {v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 50
    .line 51
    .line 52
    return-void

    .line 53
    :cond_34
    invoke-interface {v4}, Lnk0;->getView()Landroid/view/View;

    .line 54
    .line 55
    .line 56
    move-result-object v4

    .line 57
    if-nez v4, :cond_4c

    .line 58
    .line 59
    new-instance v0, Ljava/lang/StringBuilder;

    .line 60
    .line 61
    const-string v2, "Sending touch to a null view with id: "

    .line 62
    .line 63
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v0

    .line 73
    invoke-static {v5, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 74
    .line 75
    .line 76
    return-void

    .line 77
    :cond_4c
    iget-wide v5, v0, Lsk0;->p:J

    .line 78
    .line 79
    iget v1, v0, Lsk0;->e:I

    .line 80
    .line 81
    new-instance v7, Lze0;

    .line 82
    .line 83
    invoke-direct {v7, v5, v6}, Lze0;-><init>(J)V

    .line 84
    .line 85
    .line 86
    iget-object v2, v2, Lal0;->p:Lu6;

    .line 87
    .line 88
    invoke-virtual {v2, v7}, Lu6;->H(Lze0;)Landroid/view/MotionEvent;

    .line 89
    .line 90
    .line 91
    move-result-object v2

    .line 92
    iget-object v5, v0, Lsk0;->g:Ljava/lang/Object;

    .line 93
    .line 94
    check-cast v5, Ljava/util/List;

    .line 95
    .line 96
    new-instance v6, Ljava/util/ArrayList;

    .line 97
    .line 98
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 99
    .line 100
    .line 101
    invoke-interface {v5}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 102
    .line 103
    .line 104
    move-result-object v5

    .line 105
    :goto_68
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 106
    .line 107
    .line 108
    move-result v7

    .line 109
    const/4 v8, 0x1

    .line 110
    const/4 v9, 0x0

    .line 111
    if-eqz v7, :cond_104

    .line 112
    .line 113
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object v7

    .line 117
    check-cast v7, Ljava/util/List;

    .line 118
    .line 119
    new-instance v10, Landroid/view/MotionEvent$PointerCoords;

    .line 120
    .line 121
    invoke-direct {v10}, Landroid/view/MotionEvent$PointerCoords;-><init>()V

    .line 122
    .line 123
    .line 124
    invoke-interface {v7, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v9

    .line 128
    check-cast v9, Ljava/lang/Double;

    .line 129
    .line 130
    invoke-virtual {v9}, Ljava/lang/Double;->doubleValue()D

    .line 131
    .line 132
    .line 133
    move-result-wide v11

    .line 134
    double-to-float v9, v11

    .line 135
    iput v9, v10, Landroid/view/MotionEvent$PointerCoords;->orientation:F

    .line 136
    .line 137
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v8

    .line 141
    check-cast v8, Ljava/lang/Double;

    .line 142
    .line 143
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 144
    .line 145
    .line 146
    move-result-wide v8

    .line 147
    double-to-float v8, v8

    .line 148
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->pressure:F

    .line 149
    .line 150
    const/4 v8, 0x2

    .line 151
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 152
    .line 153
    .line 154
    move-result-object v8

    .line 155
    check-cast v8, Ljava/lang/Double;

    .line 156
    .line 157
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 158
    .line 159
    .line 160
    move-result-wide v8

    .line 161
    double-to-float v8, v8

    .line 162
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->size:F

    .line 163
    .line 164
    const/4 v8, 0x3

    .line 165
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 166
    .line 167
    .line 168
    move-result-object v8

    .line 169
    check-cast v8, Ljava/lang/Double;

    .line 170
    .line 171
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 172
    .line 173
    .line 174
    move-result-wide v8

    .line 175
    float-to-double v11, v3

    .line 176
    mul-double/2addr v8, v11

    .line 177
    double-to-float v8, v8

    .line 178
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->toolMajor:F

    .line 179
    .line 180
    const/4 v8, 0x4

    .line 181
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 182
    .line 183
    .line 184
    move-result-object v8

    .line 185
    check-cast v8, Ljava/lang/Double;

    .line 186
    .line 187
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 188
    .line 189
    .line 190
    move-result-wide v8

    .line 191
    mul-double/2addr v8, v11

    .line 192
    double-to-float v8, v8

    .line 193
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->toolMinor:F

    .line 194
    .line 195
    const/4 v8, 0x5

    .line 196
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 197
    .line 198
    .line 199
    move-result-object v8

    .line 200
    check-cast v8, Ljava/lang/Double;

    .line 201
    .line 202
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 203
    .line 204
    .line 205
    move-result-wide v8

    .line 206
    mul-double/2addr v8, v11

    .line 207
    double-to-float v8, v8

    .line 208
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->touchMajor:F

    .line 209
    .line 210
    const/4 v8, 0x6

    .line 211
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 212
    .line 213
    .line 214
    move-result-object v8

    .line 215
    check-cast v8, Ljava/lang/Double;

    .line 216
    .line 217
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 218
    .line 219
    .line 220
    move-result-wide v8

    .line 221
    mul-double/2addr v8, v11

    .line 222
    double-to-float v8, v8

    .line 223
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->touchMinor:F

    .line 224
    .line 225
    const/4 v8, 0x7

    .line 226
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 227
    .line 228
    .line 229
    move-result-object v8

    .line 230
    check-cast v8, Ljava/lang/Double;

    .line 231
    .line 232
    invoke-virtual {v8}, Ljava/lang/Double;->doubleValue()D

    .line 233
    .line 234
    .line 235
    move-result-wide v8

    .line 236
    mul-double/2addr v8, v11

    .line 237
    double-to-float v8, v8

    .line 238
    iput v8, v10, Landroid/view/MotionEvent$PointerCoords;->x:F

    .line 239
    .line 240
    const/16 v8, 0x8

    .line 241
    .line 242
    invoke-interface {v7, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 243
    .line 244
    .line 245
    move-result-object v7

    .line 246
    check-cast v7, Ljava/lang/Double;

    .line 247
    .line 248
    invoke-virtual {v7}, Ljava/lang/Double;->doubleValue()D

    .line 249
    .line 250
    .line 251
    move-result-wide v7

    .line 252
    mul-double/2addr v7, v11

    .line 253
    double-to-float v7, v7

    .line 254
    iput v7, v10, Landroid/view/MotionEvent$PointerCoords;->y:F

    .line 255
    .line 256
    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 257
    .line 258
    .line 259
    goto/16 :goto_68

    .line 260
    .line 261
    :cond_104
    new-array v3, v1, [Landroid/view/MotionEvent$PointerCoords;

    .line 262
    .line 263
    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    move-result-object v3

    .line 267
    check-cast v3, [Landroid/view/MotionEvent$PointerCoords;

    .line 268
    .line 269
    if-eqz v2, :cond_12a

    .line 270
    .line 271
    array-length v0, v3

    .line 272
    if-ge v0, v8, :cond_113

    .line 273
    .line 274
    goto/16 :goto_1a4

    .line 275
    .line 276
    :cond_113
    aget-object v0, v3, v9

    .line 277
    .line 278
    iget v0, v0, Landroid/view/MotionEvent$PointerCoords;->x:F

    .line 279
    .line 280
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getX()F

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    sub-float/2addr v0, v1

    .line 285
    aget-object v1, v3, v9

    .line 286
    .line 287
    iget v1, v1, Landroid/view/MotionEvent$PointerCoords;->y:F

    .line 288
    .line 289
    invoke-virtual {v2}, Landroid/view/MotionEvent;->getY()F

    .line 290
    .line 291
    .line 292
    move-result v3

    .line 293
    sub-float/2addr v1, v3

    .line 294
    invoke-virtual {v2, v0, v1}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    .line 295
    .line 296
    .line 297
    goto/16 :goto_1a4

    .line 298
    .line 299
    :cond_12a
    iget-object v2, v0, Lsk0;->f:Ljava/lang/Object;

    .line 300
    .line 301
    check-cast v2, Ljava/util/List;

    .line 302
    .line 303
    new-instance v5, Ljava/util/ArrayList;

    .line 304
    .line 305
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 306
    .line 307
    .line 308
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 309
    .line 310
    .line 311
    move-result-object v2

    .line 312
    :goto_137
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 313
    .line 314
    .line 315
    move-result v6

    .line 316
    if-eqz v6, :cond_164

    .line 317
    .line 318
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 319
    .line 320
    .line 321
    move-result-object v6

    .line 322
    check-cast v6, Ljava/util/List;

    .line 323
    .line 324
    new-instance v7, Landroid/view/MotionEvent$PointerProperties;

    .line 325
    .line 326
    invoke-direct {v7}, Landroid/view/MotionEvent$PointerProperties;-><init>()V

    .line 327
    .line 328
    .line 329
    invoke-interface {v6, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 330
    .line 331
    .line 332
    move-result-object v10

    .line 333
    check-cast v10, Ljava/lang/Integer;

    .line 334
    .line 335
    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    .line 336
    .line 337
    .line 338
    move-result v10

    .line 339
    iput v10, v7, Landroid/view/MotionEvent$PointerProperties;->id:I

    .line 340
    .line 341
    invoke-interface {v6, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 342
    .line 343
    .line 344
    move-result-object v6

    .line 345
    check-cast v6, Ljava/lang/Integer;

    .line 346
    .line 347
    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    .line 348
    .line 349
    .line 350
    move-result v6

    .line 351
    iput v6, v7, Landroid/view/MotionEvent$PointerProperties;->toolType:I

    .line 352
    .line 353
    invoke-virtual {v5, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 354
    .line 355
    .line 356
    goto :goto_137

    .line 357
    :cond_164
    new-array v1, v1, [Landroid/view/MotionEvent$PointerProperties;

    .line 358
    .line 359
    invoke-virtual {v5, v1}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    move-result-object v1

    .line 363
    move-object/from16 v16, v1

    .line 364
    .line 365
    check-cast v16, [Landroid/view/MotionEvent$PointerProperties;

    .line 366
    .line 367
    iget-object v1, v0, Lsk0;->b:Ljava/lang/Number;

    .line 368
    .line 369
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 370
    .line 371
    .line 372
    move-result-wide v10

    .line 373
    iget-object v1, v0, Lsk0;->c:Ljava/lang/Number;

    .line 374
    .line 375
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 376
    .line 377
    .line 378
    move-result-wide v12

    .line 379
    iget v14, v0, Lsk0;->d:I

    .line 380
    .line 381
    iget v15, v0, Lsk0;->e:I

    .line 382
    .line 383
    iget v1, v0, Lsk0;->h:I

    .line 384
    .line 385
    iget v2, v0, Lsk0;->i:I

    .line 386
    .line 387
    iget v5, v0, Lsk0;->j:F

    .line 388
    .line 389
    iget v6, v0, Lsk0;->k:F

    .line 390
    .line 391
    iget v7, v0, Lsk0;->l:I

    .line 392
    .line 393
    iget v8, v0, Lsk0;->m:I

    .line 394
    .line 395
    iget v9, v0, Lsk0;->n:I

    .line 396
    .line 397
    iget v0, v0, Lsk0;->o:I

    .line 398
    .line 399
    move/from16 v25, v0

    .line 400
    .line 401
    move/from16 v18, v1

    .line 402
    .line 403
    move/from16 v19, v2

    .line 404
    .line 405
    move-object/from16 v17, v3

    .line 406
    .line 407
    move/from16 v20, v5

    .line 408
    .line 409
    move/from16 v21, v6

    .line 410
    .line 411
    move/from16 v22, v7

    .line 412
    .line 413
    move/from16 v23, v8

    .line 414
    .line 415
    move/from16 v24, v9

    .line 416
    .line 417
    invoke-static/range {v10 .. v25}, Landroid/view/MotionEvent;->obtain(JJII[Landroid/view/MotionEvent$PointerProperties;[Landroid/view/MotionEvent$PointerCoords;IIFFIIII)Landroid/view/MotionEvent;

    .line 418
    .line 419
    .line 420
    move-result-object v2

    .line 421
    :goto_1a4
    invoke-virtual {v4, v2}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z

    .line 422
    .line 423
    .line 424
    return-void
.end method

.method public r(Ljava/lang/Object;Ljava/lang/Object;)Z
    .registers 5

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lrf0;

    .line 4
    .line 5
    invoke-virtual {p0, p1}, Lrf0;->d(Ljava/lang/Object;)Ljava/lang/Object;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    if-nez v0, :cond_b

    .line 10
    .line 11
    goto :goto_2c

    .line 12
    :cond_b
    instance-of v1, v0, Lvf0;

    .line 13
    .line 14
    if-eqz v1, :cond_21

    .line 15
    .line 16
    check-cast v0, Lvf0;

    .line 17
    .line 18
    invoke-virtual {v0, p2}, Lvf0;->j(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result p2

    .line 22
    if-eqz p2, :cond_20

    .line 23
    .line 24
    invoke-virtual {v0}, Lvf0;->g()Z

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-eqz v0, :cond_20

    .line 29
    .line 30
    invoke-virtual {p0, p1}, Lrf0;->f(Ljava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    :cond_20
    return p2

    .line 34
    :cond_21
    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 35
    .line 36
    .line 37
    move-result p2

    .line 38
    if-eqz p2, :cond_2c

    .line 39
    .line 40
    invoke-virtual {p0, p1}, Lrf0;->f(Ljava/lang/Object;)V

    .line 41
    .line 42
    .line 43
    const/4 p0, 0x1

    .line 44
    return p0

    .line 45
    :cond_2c
    :goto_2c
    const/4 p0, 0x0

    .line 46
    return p0
.end method

.method public s(II)V
    .registers 4

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lal0;

    .line 4
    .line 5
    iget-object p0, p0, Lal0;->n:Landroid/util/SparseArray;

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Lnk0;

    .line 12
    .line 13
    const-string v0, "PlatformViewsController2"

    .line 14
    .line 15
    if-nez p0, :cond_22

    .line 16
    .line 17
    new-instance p0, Ljava/lang/StringBuilder;

    .line 18
    .line 19
    const-string p2, "Setting direction to an unknown view with id: "

    .line 20
    .line 21
    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 32
    .line 33
    .line 34
    return-void

    .line 35
    :cond_22
    invoke-interface {p0}, Lnk0;->getView()Landroid/view/View;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    if-nez p0, :cond_3a

    .line 40
    .line 41
    new-instance p0, Ljava/lang/StringBuilder;

    .line 42
    .line 43
    const-string p2, "Setting direction to a null view with id: "

    .line 44
    .line 45
    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object p0

    .line 55
    invoke-static {v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :cond_3a
    invoke-virtual {p0, p2}, Landroid/view/View;->setLayoutDirection(I)V

    .line 60
    .line 61
    .line 62
    return-void
.end method

.method public success(Ljava/lang/Object;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lse0;

    .line 4
    .line 5
    invoke-interface {p0, p1}, Lse0;->success(Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public t(Ljava/util/ArrayList;)V
    .registers 6

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lkk0;

    .line 4
    .line 5
    iget-boolean v0, p0, Lkk0;->f:Z

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x1

    .line 9
    if-eqz v0, :cond_15

    .line 10
    .line 11
    iput-boolean v1, p0, Lkk0;->f:Z

    .line 12
    .line 13
    iget-object v0, p0, Lkk0;->a:Landroid/app/Activity;

    .line 14
    .line 15
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-static {v0, v2}, Lt51;->O(Landroid/view/Window;Z)V

    .line 20
    .line 21
    .line 22
    :cond_15
    invoke-virtual {p1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_1e

    .line 27
    .line 28
    const/16 v0, 0x1706

    .line 29
    .line 30
    goto :goto_20

    .line 31
    :cond_1e
    const/16 v0, 0x706

    .line 32
    .line 33
    :goto_20
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 34
    .line 35
    .line 36
    move-result v3

    .line 37
    if-ge v1, v3, :cond_3d

    .line 38
    .line 39
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v3

    .line 43
    check-cast v3, Lek0;

    .line 44
    .line 45
    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    .line 46
    .line 47
    .line 48
    move-result v3

    .line 49
    if-eqz v3, :cond_38

    .line 50
    .line 51
    if-eq v3, v2, :cond_35

    .line 52
    .line 53
    goto :goto_3a

    .line 54
    :cond_35
    and-int/lit16 v0, v0, -0x203

    .line 55
    .line 56
    goto :goto_3a

    .line 57
    :cond_38
    and-int/lit8 v0, v0, -0x5

    .line 58
    .line 59
    :goto_3a
    add-int/lit8 v1, v1, 0x1

    .line 60
    .line 61
    goto :goto_20

    .line 62
    :cond_3d
    iput v0, p0, Lkk0;->e:I

    .line 63
    .line 64
    invoke-virtual {p0}, Lkk0;->b()V

    .line 65
    .line 66
    .line 67
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    .line 1
    iget v0, p0, Lnw;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_3a

    .line 4
    .line 5
    .line 6
    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    return-object p0

    .line 11
    :pswitch_a
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "NotNullProperty("

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lnw;->g:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v1, Ljava/lang/Float;

    .line 21
    .line 22
    if-eqz v1, :cond_2a

    .line 23
    .line 24
    new-instance v1, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string v2, "value="

    .line 27
    .line 28
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 32
    .line 33
    check-cast p0, Ljava/lang/Float;

    .line 34
    .line 35
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 36
    .line 37
    .line 38
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 39
    .line 40
    .line 41
    move-result-object p0

    .line 42
    goto :goto_2c

    .line 43
    :cond_2a
    const-string p0, "value not initialized yet"

    .line 44
    .line 45
    :goto_2c
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    const/16 p0, 0x29

    .line 49
    .line 50
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 51
    .line 52
    .line 53
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    return-object p0

    .line 58
    nop

    .line 59
    :pswitch_data_3a
    .packed-switch 0x11
        :pswitch_a
    .end packed-switch
.end method

.method public u(I)V
    .registers 7

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lkk0;

    .line 4
    .line 5
    iget-object v0, p0, Lkk0;->a:Landroid/app/Activity;

    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x1

    .line 9
    const/4 v3, 0x4

    .line 10
    if-eq p1, v3, :cond_18

    .line 11
    .line 12
    iget-boolean v4, p0, Lkk0;->f:Z

    .line 13
    .line 14
    if-eqz v4, :cond_18

    .line 15
    .line 16
    iput-boolean v1, p0, Lkk0;->f:Z

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    invoke-static {v4, v2}, Lt51;->O(Landroid/view/Window;Z)V

    .line 23
    .line 24
    .line 25
    :cond_18
    if-ne p1, v2, :cond_1d

    .line 26
    .line 27
    const/16 p1, 0x706

    .line 28
    .line 29
    goto :goto_28

    .line 30
    :cond_1d
    const/4 v4, 0x2

    .line 31
    if-ne p1, v4, :cond_23

    .line 32
    .line 33
    const/16 p1, 0xf06

    .line 34
    .line 35
    goto :goto_28

    .line 36
    :cond_23
    const/4 v4, 0x3

    .line 37
    if-ne p1, v4, :cond_2e

    .line 38
    .line 39
    const/16 p1, 0x1706

    .line 40
    .line 41
    :goto_28
    iput p1, p0, Lkk0;->e:I

    .line 42
    .line 43
    invoke-virtual {p0}, Lkk0;->b()V

    .line 44
    .line 45
    .line 46
    return-void

    .line 47
    :cond_2e
    if-ne p1, v3, :cond_51

    .line 48
    .line 49
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 50
    .line 51
    const/16 v3, 0x1d

    .line 52
    .line 53
    if-lt p1, v3, :cond_51

    .line 54
    .line 55
    iput-boolean v2, p0, Lkk0;->f:Z

    .line 56
    .line 57
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 58
    .line 59
    .line 60
    move-result-object p1

    .line 61
    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-virtual {p1, v1}, Landroid/view/View;->setSystemUiVisibility(I)V

    .line 66
    .line 67
    .line 68
    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 69
    .line 70
    .line 71
    move-result-object p1

    .line 72
    invoke-static {p1, v1}, Lt51;->O(Landroid/view/Window;Z)V

    .line 73
    .line 74
    .line 75
    iget-object p1, p0, Lkk0;->d:Ldk0;

    .line 76
    .line 77
    if-eqz p1, :cond_51

    .line 78
    .line 79
    invoke-virtual {p0, p1}, Lkk0;->a(Ldk0;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    return-void
.end method

.method public v(I)V
    .registers 4

    .line 1
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lkk0;

    .line 4
    .line 5
    iget-object p0, p0, Lkk0;->a:Landroid/app/Activity;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-virtual {p0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    invoke-static {p1}, Lzi0;->y(I)I

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    const/4 v0, 0x3

    .line 20
    const/16 v1, 0x1e

    .line 21
    .line 22
    packed-switch p1, :pswitch_data_4e

    .line 23
    .line 24
    .line 25
    goto :goto_34

    .line 26
    :pswitch_19
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 27
    .line 28
    if-lt p1, v1, :cond_34

    .line 29
    .line 30
    const/16 p1, 0x11

    .line 31
    .line 32
    invoke-virtual {p0, p1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :pswitch_23
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 37
    .line 38
    if-lt p1, v1, :cond_34

    .line 39
    .line 40
    invoke-virtual {p0, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 41
    .line 42
    .line 43
    return-void

    .line 44
    :pswitch_2b
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 45
    .line 46
    if-lt p1, v1, :cond_34

    .line 47
    .line 48
    const/16 p1, 0x10

    .line 49
    .line 50
    invoke-virtual {p0, p1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 51
    .line 52
    .line 53
    :cond_34
    :goto_34
    return-void

    .line 54
    :pswitch_35
    const/4 p1, 0x4

    .line 55
    invoke-virtual {p0, p1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 56
    .line 57
    .line 58
    return-void

    .line 59
    :pswitch_3a
    const/4 p1, 0x6

    .line 60
    invoke-virtual {p0, p1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 61
    .line 62
    .line 63
    return-void

    .line 64
    :pswitch_3f
    invoke-virtual {p0, v0}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :pswitch_43
    const/4 p1, 0x1

    .line 69
    invoke-virtual {p0, p1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 70
    .line 71
    .line 72
    return-void

    .line 73
    :pswitch_48
    const/4 p1, 0x0

    .line 74
    invoke-virtual {p0, p1}, Landroid/view/View;->performHapticFeedback(I)Z

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    nop

    .line 79
    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_48
        :pswitch_43
        :pswitch_3f
        :pswitch_3a
        :pswitch_35
        :pswitch_2b
        :pswitch_23
        :pswitch_19
    .end packed-switch
.end method

###### Class defpackage.x20 (x20)
.class public final synthetic Lx20;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroid/graphics/ImageDecoder$OnHeaderDecodedListener;


# instance fields
.field public final synthetic a:Lnw;


# direct methods
.method public synthetic constructor <init>(Lnw;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lx20;->a:Lnw;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onHeaderDecoded(Landroid/graphics/ImageDecoder;Landroid/graphics/ImageDecoder$ImageInfo;Landroid/graphics/ImageDecoder$Source;)V
    .registers 6

    .line 1
    sget-object p3, Landroid/graphics/ColorSpace$Named;->SRGB:Landroid/graphics/ColorSpace$Named;

    .line 2
    .line 3
    invoke-static {p3}, Landroid/graphics/ColorSpace;->get(Landroid/graphics/ColorSpace$Named;)Landroid/graphics/ColorSpace;

    .line 4
    .line 5
    .line 6
    move-result-object p3

    .line 7
    invoke-virtual {p1, p3}, Landroid/graphics/ImageDecoder;->setTargetColorSpace(Landroid/graphics/ColorSpace;)V

    .line 8
    .line 9
    .line 10
    const/4 p3, 0x1

    .line 11
    invoke-virtual {p1, p3}, Landroid/graphics/ImageDecoder;->setAllocator(I)V

    .line 12
    .line 13
    .line 14
    iget-object p0, p0, Lx20;->a:Lnw;

    .line 15
    .line 16
    iget-object p0, p0, Lnw;->g:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p0, Lvv;

    .line 19
    .line 20
    if-eqz p0, :cond_26

    .line 21
    .line 22
    invoke-virtual {p2}, Landroid/graphics/ImageDecoder$ImageInfo;->getSize()Landroid/util/Size;

    .line 23
    .line 24
    .line 25
    move-result-object p1

    .line 26
    invoke-virtual {p1}, Landroid/util/Size;->getWidth()I

    .line 27
    .line 28
    .line 29
    move-result p2

    .line 30
    invoke-virtual {p1}, Landroid/util/Size;->getHeight()I

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    iget-wide v0, p0, Lvv;->a:J

    .line 35
    .line 36
    invoke-static {v0, v1, p2, p1}, Lio/flutter/embedding/engine/FlutterJNI;->b(JII)V

    .line 37
    .line 38
    .line 39
    :cond_26
    return-void
.end method
