###### Class defpackage.fh1 (fh1)
.class public final Lfh1;
.super Lsg1;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final synthetic a:Lcom/google/android/gms/common/internal/a;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/internal/a;Landroid/os/Looper;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lfh1;->a:Lcom/google/android/gms/common/internal/a;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p2, p1}, Lsg1;-><init>(Landroid/os/Looper;I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final handleMessage(Landroid/os/Message;)V
    .registers 11

    .line 1
    iget-object p0, p0, Lfh1;->a:Lcom/google/android/gms/common/internal/a;

    .line 2
    .line 3
    iget-object v0, p0, Lcom/google/android/gms/common/internal/a;->v:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    iget v1, p1, Landroid/os/Message;->arg1:I

    .line 10
    .line 11
    iget v2, p1, Landroid/os/Message;->what:I

    .line 12
    .line 13
    const/4 v3, 0x7

    .line 14
    const/4 v4, 0x2

    .line 15
    const/4 v5, 0x1

    .line 16
    const/4 v6, 0x0

    .line 17
    if-eq v0, v1, :cond_36

    .line 18
    .line 19
    if-eq v2, v4, :cond_1a

    .line 20
    .line 21
    if-eq v2, v5, :cond_1a

    .line 22
    .line 23
    if-ne v2, v3, :cond_19

    .line 24
    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    return-void

    .line 27
    :cond_1a
    :goto_1a
    iget-object p0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 28
    .line 29
    check-cast p0, Lug1;

    .line 30
    .line 31
    if-eqz p0, :cond_1d2

    .line 32
    .line 33
    monitor-enter p0

    .line 34
    :try_start_21
    iput-object v6, p0, Lug1;->a:Ljava/lang/Boolean;

    .line 35
    .line 36
    monitor-exit p0
    :try_end_24
    .catchall {:try_start_21 .. :try_end_24} :catchall_33

    .line 37
    iget-object p1, p0, Lug1;->c:Lcom/google/android/gms/common/internal/a;

    .line 38
    .line 39
    iget-object v0, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 40
    .line 41
    monitor-enter v0

    .line 42
    :try_start_29
    iget-object p1, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 43
    .line 44
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 45
    .line 46
    .line 47
    monitor-exit v0

    .line 48
    return-void

    .line 49
    :catchall_30
    move-exception p0

    .line 50
    monitor-exit v0
    :try_end_32
    .catchall {:try_start_29 .. :try_end_32} :catchall_30

    .line 51
    throw p0

    .line 52
    :catchall_33
    move-exception p1

    .line 53
    :try_start_34
    monitor-exit p0
    :try_end_35
    .catchall {:try_start_34 .. :try_end_35} :catchall_33

    .line 54
    throw p1

    .line 55
    :cond_36
    const/4 v0, 0x4

    .line 56
    const/4 v1, 0x5

    .line 57
    if-eq v2, v5, :cond_41

    .line 58
    .line 59
    if-eq v2, v3, :cond_41

    .line 60
    .line 61
    if-ne v2, v0, :cond_3f

    .line 62
    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    if-ne v2, v1, :cond_47

    .line 65
    .line 66
    :cond_41
    :goto_41
    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/a;->e()Z

    .line 67
    .line 68
    .line 69
    move-result v2

    .line 70
    if-eqz v2, :cond_1b6

    .line 71
    .line 72
    :cond_47
    iget v2, p1, Landroid/os/Message;->what:I

    .line 73
    .line 74
    const/16 v7, 0x8

    .line 75
    .line 76
    const/4 v8, 0x3

    .line 77
    if-ne v2, v0, :cond_91

    .line 78
    .line 79
    new-instance v0, Lrg;

    .line 80
    .line 81
    iget p1, p1, Landroid/os/Message;->arg2:I

    .line 82
    .line 83
    invoke-direct {v0, p1, v6, v6}, Lrg;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    .line 84
    .line 85
    .line 86
    iput-object v0, p0, Lcom/google/android/gms/common/internal/a;->s:Lrg;

    .line 87
    .line 88
    iget-boolean p1, p0, Lcom/google/android/gms/common/internal/a;->t:Z

    .line 89
    .line 90
    if-eqz p1, :cond_5c

    .line 91
    .line 92
    goto :goto_7e

    .line 93
    :cond_5c
    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/a;->r()Ljava/lang/String;

    .line 94
    .line 95
    .line 96
    move-result-object p1

    .line 97
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 98
    .line 99
    .line 100
    move-result p1

    .line 101
    if-eqz p1, :cond_67

    .line 102
    .line 103
    goto :goto_7e

    .line 104
    :cond_67
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 105
    .line 106
    .line 107
    move-result p1

    .line 108
    if-eqz p1, :cond_6e

    .line 109
    .line 110
    goto :goto_7e

    .line 111
    :cond_6e
    :try_start_6e
    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/a;->r()Ljava/lang/String;

    .line 112
    .line 113
    .line 114
    move-result-object p1

    .line 115
    invoke-static {p1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_75
    .catch Ljava/lang/ClassNotFoundException; {:try_start_6e .. :try_end_75} :catch_7e

    .line 116
    .line 117
    .line 118
    iget-boolean p1, p0, Lcom/google/android/gms/common/internal/a;->t:Z

    .line 119
    .line 120
    if-eqz p1, :cond_7a

    .line 121
    .line 122
    goto :goto_7e

    .line 123
    :cond_7a
    invoke-virtual {p0, v8, v6}, Lcom/google/android/gms/common/internal/a;->v(ILandroid/os/IInterface;)V

    .line 124
    .line 125
    .line 126
    return-void

    .line 127
    :catch_7e
    :goto_7e
    iget-object p1, p0, Lcom/google/android/gms/common/internal/a;->s:Lrg;

    .line 128
    .line 129
    if-eqz p1, :cond_83

    .line 130
    .line 131
    goto :goto_88

    .line 132
    :cond_83
    new-instance p1, Lrg;

    .line 133
    .line 134
    invoke-direct {p1, v7, v6, v6}, Lrg;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    :goto_88
    iget-object p0, p0, Lcom/google/android/gms/common/internal/a;->i:Lz9;

    .line 138
    .line 139
    invoke-interface {p0, p1}, Lz9;->g(Lrg;)V

    .line 140
    .line 141
    .line 142
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 143
    .line 144
    .line 145
    return-void

    .line 146
    :cond_91
    if-ne v2, v1, :cond_a6

    .line 147
    .line 148
    iget-object p1, p0, Lcom/google/android/gms/common/internal/a;->s:Lrg;

    .line 149
    .line 150
    if-eqz p1, :cond_98

    .line 151
    .line 152
    goto :goto_9d

    .line 153
    :cond_98
    new-instance p1, Lrg;

    .line 154
    .line 155
    invoke-direct {p1, v7, v6, v6}, Lrg;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    .line 156
    .line 157
    .line 158
    :goto_9d
    iget-object p0, p0, Lcom/google/android/gms/common/internal/a;->i:Lz9;

    .line 159
    .line 160
    invoke-interface {p0, p1}, Lz9;->g(Lrg;)V

    .line 161
    .line 162
    .line 163
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 164
    .line 165
    .line 166
    return-void

    .line 167
    :cond_a6
    if-ne v2, v8, :cond_c2

    .line 168
    .line 169
    iget-object v0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 170
    .line 171
    instance-of v1, v0, Landroid/app/PendingIntent;

    .line 172
    .line 173
    if-eqz v1, :cond_b1

    .line 174
    .line 175
    check-cast v0, Landroid/app/PendingIntent;

    .line 176
    .line 177
    goto :goto_b2

    .line 178
    :cond_b1
    move-object v0, v6

    .line 179
    :goto_b2
    new-instance v1, Lrg;

    .line 180
    .line 181
    iget p1, p1, Landroid/os/Message;->arg2:I

    .line 182
    .line 183
    invoke-direct {v1, p1, v0, v6}, Lrg;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    .line 184
    .line 185
    .line 186
    iget-object p0, p0, Lcom/google/android/gms/common/internal/a;->i:Lz9;

    .line 187
    .line 188
    invoke-interface {p0, v1}, Lz9;->g(Lrg;)V

    .line 189
    .line 190
    .line 191
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 192
    .line 193
    .line 194
    return-void

    .line 195
    :cond_c2
    const/4 v0, 0x6

    .line 196
    if-ne v2, v0, :cond_dc

    .line 197
    .line 198
    invoke-virtual {p0, v1, v6}, Lcom/google/android/gms/common/internal/a;->v(ILandroid/os/IInterface;)V

    .line 199
    .line 200
    .line 201
    iget-object v0, p0, Lcom/google/android/gms/common/internal/a;->n:Lns0;

    .line 202
    .line 203
    if-eqz v0, :cond_d5

    .line 204
    .line 205
    iget p1, p1, Landroid/os/Message;->arg2:I

    .line 206
    .line 207
    iget-object v0, v0, Lns0;->g:Ljava/lang/Object;

    .line 208
    .line 209
    check-cast v0, Lm10;

    .line 210
    .line 211
    invoke-interface {v0, p1}, Lm10;->a(I)V

    .line 212
    .line 213
    .line 214
    :cond_d5
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 215
    .line 216
    .line 217
    invoke-virtual {p0, v1, v5, v6}, Lcom/google/android/gms/common/internal/a;->u(IILandroid/os/IInterface;)Z

    .line 218
    .line 219
    .line 220
    return-void

    .line 221
    :cond_dc
    if-ne v2, v4, :cond_101

    .line 222
    .line 223
    invoke-virtual {p0}, Lcom/google/android/gms/common/internal/a;->a()Z

    .line 224
    .line 225
    .line 226
    move-result p0

    .line 227
    if-eqz p0, :cond_e5

    .line 228
    .line 229
    goto :goto_101

    .line 230
    :cond_e5
    iget-object p0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 231
    .line 232
    check-cast p0, Lug1;

    .line 233
    .line 234
    if-eqz p0, :cond_1d2

    .line 235
    .line 236
    monitor-enter p0

    .line 237
    :try_start_ec
    iput-object v6, p0, Lug1;->a:Ljava/lang/Boolean;

    .line 238
    .line 239
    monitor-exit p0
    :try_end_ef
    .catchall {:try_start_ec .. :try_end_ef} :catchall_fe

    .line 240
    iget-object p1, p0, Lug1;->c:Lcom/google/android/gms/common/internal/a;

    .line 241
    .line 242
    iget-object v0, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 243
    .line 244
    monitor-enter v0

    .line 245
    :try_start_f4
    iget-object p1, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 246
    .line 247
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 248
    .line 249
    .line 250
    monitor-exit v0

    .line 251
    return-void

    .line 252
    :catchall_fb
    move-exception p0

    .line 253
    monitor-exit v0
    :try_end_fd
    .catchall {:try_start_f4 .. :try_end_fd} :catchall_fb

    .line 254
    throw p0

    .line 255
    :catchall_fe
    move-exception p1

    .line 256
    :try_start_ff
    monitor-exit p0
    :try_end_100
    .catchall {:try_start_ff .. :try_end_100} :catchall_fe

    .line 257
    throw p1

    .line 258
    :cond_101
    :goto_101
    iget p0, p1, Landroid/os/Message;->what:I

    .line 259
    .line 260
    if-eq p0, v4, :cond_130

    .line 261
    .line 262
    if-eq p0, v5, :cond_130

    .line 263
    .line 264
    if-ne p0, v3, :cond_10a

    .line 265
    .line 266
    goto :goto_130

    .line 267
    :cond_10a
    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 268
    .line 269
    .line 270
    move-result-object p1

    .line 271
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    .line 272
    .line 273
    .line 274
    move-result p1

    .line 275
    new-instance v0, Ljava/lang/StringBuilder;

    .line 276
    .line 277
    add-int/lit8 p1, p1, 0x22

    .line 278
    .line 279
    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 280
    .line 281
    .line 282
    const-string p1, "Don\'t know how to handle message: "

    .line 283
    .line 284
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 285
    .line 286
    .line 287
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 288
    .line 289
    .line 290
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object p0

    .line 294
    new-instance p1, Ljava/lang/Exception;

    .line 295
    .line 296
    invoke-direct {p1}, Ljava/lang/Exception;-><init>()V

    .line 297
    .line 298
    .line 299
    const-string v0, "GmsClient"

    .line 300
    .line 301
    invoke-static {v0, p0, p1}, Landroid/util/Log;->wtf(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 302
    .line 303
    .line 304
    return-void

    .line 305
    :cond_130
    :goto_130
    iget-object p0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 306
    .line 307
    check-cast p0, Lug1;

    .line 308
    .line 309
    const-string p1, " being reused. This is not safe."

    .line 310
    .line 311
    const-string v0, "Callback proxy "

    .line 312
    .line 313
    monitor-enter p0

    .line 314
    :try_start_139
    iget-object v1, p0, Lug1;->a:Ljava/lang/Boolean;

    .line 315
    .line 316
    iget-boolean v2, p0, Lug1;->b:Z

    .line 317
    .line 318
    if-eqz v2, :cond_163

    .line 319
    .line 320
    const-string v2, "GmsClient"

    .line 321
    .line 322
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 323
    .line 324
    .line 325
    move-result-object v3

    .line 326
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 327
    .line 328
    .line 329
    move-result v4

    .line 330
    add-int/lit8 v4, v4, 0x2f

    .line 331
    .line 332
    new-instance v8, Ljava/lang/StringBuilder;

    .line 333
    .line 334
    invoke-direct {v8, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 338
    .line 339
    .line 340
    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 341
    .line 342
    .line 343
    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object p1

    .line 350
    invoke-static {v2, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 351
    .line 352
    .line 353
    goto :goto_163

    .line 354
    :catchall_161
    move-exception p1

    .line 355
    goto :goto_1b4

    .line 356
    :cond_163
    :goto_163
    monitor-exit p0
    :try_end_164
    .catchall {:try_start_139 .. :try_end_164} :catchall_161

    .line 357
    if-eqz v1, :cond_197

    .line 358
    .line 359
    iget-object p1, p0, Lug1;->f:Lcom/google/android/gms/common/internal/a;

    .line 360
    .line 361
    iget v0, p0, Lug1;->d:I

    .line 362
    .line 363
    if-nez v0, :cond_17e

    .line 364
    .line 365
    invoke-virtual {p0}, Lug1;->a()Z

    .line 366
    .line 367
    .line 368
    move-result v0

    .line 369
    if-nez v0, :cond_197

    .line 370
    .line 371
    invoke-virtual {p1, v5, v6}, Lcom/google/android/gms/common/internal/a;->v(ILandroid/os/IInterface;)V

    .line 372
    .line 373
    .line 374
    new-instance p1, Lrg;

    .line 375
    .line 376
    invoke-direct {p1, v7, v6, v6}, Lrg;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    invoke-virtual {p0, p1}, Lug1;->b(Lrg;)V

    .line 380
    .line 381
    .line 382
    goto :goto_197

    .line 383
    :cond_17e
    invoke-virtual {p1, v5, v6}, Lcom/google/android/gms/common/internal/a;->v(ILandroid/os/IInterface;)V

    .line 384
    .line 385
    .line 386
    iget-object p1, p0, Lug1;->e:Landroid/os/Bundle;

    .line 387
    .line 388
    if-eqz p1, :cond_18e

    .line 389
    .line 390
    const-string v1, "pendingIntent"

    .line 391
    .line 392
    invoke-virtual {p1, v1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    .line 393
    .line 394
    .line 395
    move-result-object p1

    .line 396
    check-cast p1, Landroid/app/PendingIntent;

    .line 397
    .line 398
    goto :goto_18f

    .line 399
    :cond_18e
    move-object p1, v6

    .line 400
    :goto_18f
    new-instance v1, Lrg;

    .line 401
    .line 402
    invoke-direct {v1, v0, p1, v6}, Lrg;-><init>(ILandroid/app/PendingIntent;Ljava/lang/String;)V

    .line 403
    .line 404
    .line 405
    invoke-virtual {p0, v1}, Lug1;->b(Lrg;)V

    .line 406
    .line 407
    .line 408
    :cond_197
    :goto_197
    monitor-enter p0

    .line 409
    :try_start_198
    iput-boolean v5, p0, Lug1;->b:Z

    .line 410
    .line 411
    monitor-exit p0
    :try_end_19b
    .catchall {:try_start_198 .. :try_end_19b} :catchall_1b1

    .line 412
    monitor-enter p0

    .line 413
    :try_start_19c
    iput-object v6, p0, Lug1;->a:Ljava/lang/Boolean;

    .line 414
    .line 415
    monitor-exit p0
    :try_end_19f
    .catchall {:try_start_19c .. :try_end_19f} :catchall_1ae

    .line 416
    iget-object p1, p0, Lug1;->c:Lcom/google/android/gms/common/internal/a;

    .line 417
    .line 418
    iget-object v0, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 419
    .line 420
    monitor-enter v0

    .line 421
    :try_start_1a4
    iget-object p1, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 422
    .line 423
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 424
    .line 425
    .line 426
    monitor-exit v0

    .line 427
    return-void

    .line 428
    :catchall_1ab
    move-exception p0

    .line 429
    monitor-exit v0
    :try_end_1ad
    .catchall {:try_start_1a4 .. :try_end_1ad} :catchall_1ab

    .line 430
    throw p0

    .line 431
    :catchall_1ae
    move-exception p1

    .line 432
    :try_start_1af
    monitor-exit p0
    :try_end_1b0
    .catchall {:try_start_1af .. :try_end_1b0} :catchall_1ae

    .line 433
    throw p1

    .line 434
    :catchall_1b1
    move-exception p1

    .line 435
    :try_start_1b2
    monitor-exit p0
    :try_end_1b3
    .catchall {:try_start_1b2 .. :try_end_1b3} :catchall_1b1

    .line 436
    throw p1

    .line 437
    :goto_1b4
    :try_start_1b4
    monitor-exit p0
    :try_end_1b5
    .catchall {:try_start_1b4 .. :try_end_1b5} :catchall_161

    .line 438
    throw p1

    .line 439
    :cond_1b6
    iget-object p0, p1, Landroid/os/Message;->obj:Ljava/lang/Object;

    .line 440
    .line 441
    check-cast p0, Lug1;

    .line 442
    .line 443
    if-eqz p0, :cond_1d2

    .line 444
    .line 445
    monitor-enter p0

    .line 446
    :try_start_1bd
    iput-object v6, p0, Lug1;->a:Ljava/lang/Boolean;

    .line 447
    .line 448
    monitor-exit p0
    :try_end_1c0
    .catchall {:try_start_1bd .. :try_end_1c0} :catchall_1cf

    .line 449
    iget-object p1, p0, Lug1;->c:Lcom/google/android/gms/common/internal/a;

    .line 450
    .line 451
    iget-object v0, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 452
    .line 453
    monitor-enter v0

    .line 454
    :try_start_1c5
    iget-object p1, p1, Lcom/google/android/gms/common/internal/a;->k:Ljava/util/ArrayList;

    .line 455
    .line 456
    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 457
    .line 458
    .line 459
    monitor-exit v0

    .line 460
    return-void

    .line 461
    :catchall_1cc
    move-exception p0

    .line 462
    monitor-exit v0
    :try_end_1ce
    .catchall {:try_start_1c5 .. :try_end_1ce} :catchall_1cc

    .line 463
    throw p0

    .line 464
    :catchall_1cf
    move-exception p1

    .line 465
    :try_start_1d0
    monitor-exit p0
    :try_end_1d1
    .catchall {:try_start_1d0 .. :try_end_1d1} :catchall_1cf

    .line 466
    throw p1

    .line 467
    :cond_1d2
    return-void
.end method
