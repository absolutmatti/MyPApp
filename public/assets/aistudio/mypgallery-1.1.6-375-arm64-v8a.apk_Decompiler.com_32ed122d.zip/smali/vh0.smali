###### Class defpackage.vh0 (vh0)
.class public interface abstract Lvh0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract b(Lne1;Lbh;)V
.end method
