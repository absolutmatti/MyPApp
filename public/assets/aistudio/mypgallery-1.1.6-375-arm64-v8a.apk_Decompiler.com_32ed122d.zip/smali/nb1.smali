###### Class defpackage.nb1 (nb1)
.class public abstract Lnb1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Lns0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lns0;

    .line 2
    .line 3
    sget-object v1, Lob1;->a:Lqb1;

    .line 4
    .line 5
    invoke-interface {v1}, Lqb1;->getWebkitToCompatConverter()Lorg/chromium/support_lib_boundary/WebkitToCompatConverterBoundaryInterface;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/16 v2, 0x14

    .line 10
    .line 11
    invoke-direct {v0, v2, v1}, Lns0;-><init>(ILjava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    sput-object v0, Lnb1;->a:Lns0;

    .line 15
    .line 16
    return-void
.end method
