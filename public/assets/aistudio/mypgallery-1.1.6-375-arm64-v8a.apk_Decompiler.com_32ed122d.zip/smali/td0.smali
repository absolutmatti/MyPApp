###### Class defpackage.td0 (td0)
.class public interface abstract Ltd0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract a(Ljava/lang/Class;)Lco0;
.end method

.method public abstract b(Ljava/lang/Class;)Z
.end method
