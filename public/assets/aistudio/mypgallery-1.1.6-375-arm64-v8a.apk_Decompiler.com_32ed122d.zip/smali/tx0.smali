###### Class defpackage.tx0 (tx0)
.class public final Ltx0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Landroid/app/Activity;

.field public final b:Lsw;

.field public c:Lzc1;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Lw8;Lsw;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ltx0;->a:Landroid/app/Activity;

    .line 5
    .line 6
    iput-object p3, p0, Ltx0;->b:Lsw;

    .line 7
    .line 8
    return-void
.end method
