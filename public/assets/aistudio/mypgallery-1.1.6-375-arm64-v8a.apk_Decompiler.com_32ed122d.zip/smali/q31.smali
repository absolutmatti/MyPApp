###### Class defpackage.q31 (q31)
.class public final Lq31;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lwh;


# instance fields
.field public final f:Ljava/lang/Object;

.field public final g:Ljava/lang/ThreadLocal;

.field public final h:Ls31;


# direct methods
.method public constructor <init>(Lnl0;Ljava/lang/ThreadLocal;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lq31;->f:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Lq31;->g:Ljava/lang/ThreadLocal;

    .line 7
    .line 8
    new-instance p1, Ls31;

    .line 9
    .line 10
    invoke-direct {p1, p2}, Ls31;-><init>(Ljava/lang/ThreadLocal;)V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lq31;->h:Ls31;

    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final getKey()Lxh;
    .registers 1

    .line 1
    iget-object p0, p0, Lq31;->h:Ls31;

    .line 2
    .line 3
    return-object p0
.end method

.method public final k(Ljava/lang/Object;Lsz;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p2, p1, p0}, Lsz;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final n(Lyh;)Lyh;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lsa;->M(Lwh;Lyh;)Lyh;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final q(Lxh;)Lwh;
    .registers 3

    .line 1
    iget-object v0, p0, Lq31;->h:Ls31;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ls31;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eqz p1, :cond_9

    .line 8
    .line 9
    return-object p0

    .line 10
    :cond_9
    const/4 p0, 0x0

    .line 11
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "ThreadLocal(value="

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lq31;->f:Ljava/lang/Object;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", threadLocal = "

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object p0, p0, Lq31;->g:Ljava/lang/ThreadLocal;

    .line 19
    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const/16 p0, 0x29

    .line 24
    .line 25
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method

.method public final u(Lxh;)Lyh;
    .registers 3

    .line 1
    iget-object v0, p0, Lq31;->h:Ls31;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Ls31;->equals(Ljava/lang/Object;)Z

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    if-eqz p1, :cond_a

    .line 8
    .line 9
    sget-object p0, Lsq;->f:Lsq;

    .line 10
    .line 11
    :cond_a
    return-object p0
.end method
