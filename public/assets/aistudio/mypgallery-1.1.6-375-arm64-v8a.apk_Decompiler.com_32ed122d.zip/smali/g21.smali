###### Class defpackage.g21 (g21)
.class public interface abstract Lg21;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract canChildScrollUp(Lj21;Landroid/view/View;)Z
.end method
