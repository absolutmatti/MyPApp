###### Class defpackage.mg (mg)
.class public interface abstract Lmg;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/AutoCloseable;


# virtual methods
.method public abstract o(ZLsz;Lsh;)Ljava/lang/Object;
.end method
