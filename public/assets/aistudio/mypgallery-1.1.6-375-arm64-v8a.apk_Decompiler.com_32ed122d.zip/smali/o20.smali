###### Class defpackage.o20 (o20)
.class public abstract Lo20;
.super Landroid/os/Binder;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lp20;


# static fields
.field public static final synthetic f:I
