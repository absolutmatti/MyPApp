###### Class defpackage.z9 (z9)
.class public interface abstract Lz9;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract g(Lrg;)V
.end method
