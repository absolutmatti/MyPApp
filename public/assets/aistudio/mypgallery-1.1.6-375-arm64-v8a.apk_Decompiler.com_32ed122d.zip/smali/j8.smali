###### Class defpackage.j8 (j8)
.class public final synthetic Lj8;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    .line 1
    iput p4, p0, Lj8;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lj8;->g:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Lj8;->h:Ljava/lang/Object;

    .line 6
    .line 7
    iput-object p3, p0, Lj8;->i:Ljava/lang/Object;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lj8;->f:I

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    const/4 v3, 0x1

    .line 7
    const/4 v4, 0x0

    .line 8
    packed-switch v1, :pswitch_data_4a8

    .line 9
    .line 10
    .line 11
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 14
    .line 15
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v2, Lwb;

    .line 18
    .line 19
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v0, Loz;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 24
    .line 25
    .line 26
    move-result v1

    .line 27
    if-eqz v1, :cond_1d

    .line 28
    .line 29
    goto :goto_29

    .line 30
    :cond_1d
    :try_start_1d
    invoke-interface {v0}, Loz;->a()Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    invoke-virtual {v2, v0}, Lwb;->a(Ljava/lang/Object;)V
    :try_end_24
    .catchall {:try_start_1d .. :try_end_24} :catchall_25

    .line 35
    .line 36
    .line 37
    goto :goto_29

    .line 38
    :catchall_25
    move-exception v0

    .line 39
    invoke-virtual {v2, v0}, Lwb;->b(Ljava/lang/Throwable;)V

    .line 40
    .line 41
    .line 42
    :goto_29
    return-void

    .line 43
    :pswitch_2a
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 44
    .line 45
    check-cast v1, Lbl0;

    .line 46
    .line 47
    iget-object v0, v0, Lj8;->h:Ljava/lang/Object;

    .line 48
    .line 49
    check-cast v0, La01;

    .line 50
    .line 51
    iget-object v1, v1, Lbl0;->f:Ljava/lang/Object;

    .line 52
    .line 53
    move-object v9, v1

    .line 54
    check-cast v9, Lrm0;

    .line 55
    .line 56
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 57
    .line 58
    .line 59
    const-string v1, "Work "

    .line 60
    .line 61
    iget-object v13, v0, La01;->a:Lce1;

    .line 62
    .line 63
    iget-object v14, v13, Lce1;->a:Ljava/lang/String;

    .line 64
    .line 65
    new-instance v12, Ljava/util/ArrayList;

    .line 66
    .line 67
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 68
    .line 69
    .line 70
    iget-object v5, v9, Lrm0;->e:Landroidx/work/impl/WorkDatabase;

    .line 71
    .line 72
    new-instance v6, Lqm0;

    .line 73
    .line 74
    invoke-direct {v6, v9, v12, v14}, Lqm0;-><init>(Lrm0;Ljava/util/ArrayList;Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v5, v6}, Lgq0;->n(Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v5

    .line 81
    move-object v11, v5

    .line 82
    check-cast v11, Lne1;

    .line 83
    .line 84
    const/16 v5, 0xc

    .line 85
    .line 86
    if-nez v11, :cond_7e

    .line 87
    .line 88
    invoke-static {}, Lta0;->g()Lta0;

    .line 89
    .line 90
    .line 91
    move-result-object v0

    .line 92
    sget-object v1, Lrm0;->l:Ljava/lang/String;

    .line 93
    .line 94
    new-instance v2, Ljava/lang/StringBuilder;

    .line 95
    .line 96
    const-string v3, "Didn\'t find WorkSpec for id "

    .line 97
    .line 98
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 99
    .line 100
    .line 101
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v2

    .line 108
    invoke-virtual {v0, v1, v2}, Lta0;->j(Ljava/lang/String;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    iget-object v0, v9, Lrm0;->d:Lq1;

    .line 112
    .line 113
    iget-object v0, v0, Lq1;->i:Ljava/lang/Object;

    .line 114
    .line 115
    check-cast v0, Lkp0;

    .line 116
    .line 117
    new-instance v1, Lg8;

    .line 118
    .line 119
    invoke-direct {v1, v9, v5, v13}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0, v1}, Lkp0;->execute(Ljava/lang/Runnable;)V

    .line 123
    .line 124
    .line 125
    goto/16 :goto_163

    .line 126
    .line 127
    :cond_7e
    iget-object v15, v9, Lrm0;->k:Ljava/lang/Object;

    .line 128
    .line 129
    monitor-enter v15

    .line 130
    :try_start_81
    iget-object v6, v9, Lrm0;->k:Ljava/lang/Object;

    .line 131
    .line 132
    monitor-enter v6
    :try_end_84
    .catchall {:try_start_81 .. :try_end_84} :catchall_c6

    .line 133
    :try_start_84
    invoke-virtual {v9, v14}, Lrm0;->c(Ljava/lang/String;)Lff1;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    if-eqz v7, :cond_8b

    .line 138
    .line 139
    move v4, v3

    .line 140
    :cond_8b
    monitor-exit v6
    :try_end_8c
    .catchall {:try_start_84 .. :try_end_8c} :catchall_164

    .line 141
    if-eqz v4, :cond_da

    .line 142
    .line 143
    :try_start_8e
    iget-object v2, v9, Lrm0;->h:Ljava/util/HashMap;

    .line 144
    .line 145
    invoke-virtual {v2, v14}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    check-cast v2, Ljava/util/Set;

    .line 150
    .line 151
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 152
    .line 153
    .line 154
    move-result-object v3

    .line 155
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v3

    .line 159
    check-cast v3, La01;

    .line 160
    .line 161
    iget-object v3, v3, La01;->a:Lce1;

    .line 162
    .line 163
    iget v3, v3, Lce1;->b:I

    .line 164
    .line 165
    iget v4, v13, Lce1;->b:I

    .line 166
    .line 167
    if-ne v3, v4, :cond_c9

    .line 168
    .line 169
    invoke-interface {v2, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 170
    .line 171
    .line 172
    invoke-static {}, Lta0;->g()Lta0;

    .line 173
    .line 174
    .line 175
    move-result-object v0

    .line 176
    sget-object v2, Lrm0;->l:Ljava/lang/String;

    .line 177
    .line 178
    new-instance v3, Ljava/lang/StringBuilder;

    .line 179
    .line 180
    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 181
    .line 182
    .line 183
    invoke-virtual {v3, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 184
    .line 185
    .line 186
    const-string v1, " is already enqueued for processing"

    .line 187
    .line 188
    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 189
    .line 190
    .line 191
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 192
    .line 193
    .line 194
    move-result-object v1

    .line 195
    invoke-virtual {v0, v2, v1}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 196
    .line 197
    .line 198
    goto :goto_d7

    .line 199
    :catchall_c6
    move-exception v0

    .line 200
    goto/16 :goto_167

    .line 201
    .line 202
    :cond_c9
    iget-object v0, v9, Lrm0;->d:Lq1;

    .line 203
    .line 204
    iget-object v0, v0, Lq1;->i:Ljava/lang/Object;

    .line 205
    .line 206
    check-cast v0, Lkp0;

    .line 207
    .line 208
    new-instance v1, Lg8;

    .line 209
    .line 210
    invoke-direct {v1, v9, v5, v13}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {v0, v1}, Lkp0;->execute(Ljava/lang/Runnable;)V

    .line 214
    .line 215
    .line 216
    :goto_d7
    monitor-exit v15

    .line 217
    goto/16 :goto_163

    .line 218
    .line 219
    :cond_da
    iget v1, v11, Lne1;->t:I

    .line 220
    .line 221
    iget v4, v13, Lce1;->b:I

    .line 222
    .line 223
    if-eq v1, v4, :cond_f0

    .line 224
    .line 225
    iget-object v0, v9, Lrm0;->d:Lq1;

    .line 226
    .line 227
    iget-object v0, v0, Lq1;->i:Ljava/lang/Object;

    .line 228
    .line 229
    check-cast v0, Lkp0;

    .line 230
    .line 231
    new-instance v1, Lg8;

    .line 232
    .line 233
    invoke-direct {v1, v9, v5, v13}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    invoke-virtual {v0, v1}, Lkp0;->execute(Ljava/lang/Runnable;)V

    .line 237
    .line 238
    .line 239
    monitor-exit v15

    .line 240
    goto :goto_163

    .line 241
    :cond_f0
    new-instance v5, Lzf;

    .line 242
    .line 243
    iget-object v6, v9, Lrm0;->b:Landroid/content/Context;

    .line 244
    .line 245
    iget-object v7, v9, Lrm0;->c:Lig;

    .line 246
    .line 247
    iget-object v8, v9, Lrm0;->d:Lq1;

    .line 248
    .line 249
    iget-object v10, v9, Lrm0;->e:Landroidx/work/impl/WorkDatabase;

    .line 250
    .line 251
    invoke-direct/range {v5 .. v12}, Lzf;-><init>(Landroid/content/Context;Lig;Lq1;Lrm0;Landroidx/work/impl/WorkDatabase;Lne1;Ljava/util/ArrayList;)V

    .line 252
    .line 253
    .line 254
    new-instance v1, Lff1;

    .line 255
    .line 256
    invoke-direct {v1, v5}, Lff1;-><init>(Lzf;)V

    .line 257
    .line 258
    .line 259
    iget-object v4, v1, Lff1;->d:Lq1;

    .line 260
    .line 261
    iget-object v4, v4, Lq1;->g:Ljava/lang/Object;

    .line 262
    .line 263
    check-cast v4, Lbi;

    .line 264
    .line 265
    invoke-static {}, Lge1;->a()Lr50;

    .line 266
    .line 267
    .line 268
    move-result-object v5

    .line 269
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 270
    .line 271
    .line 272
    invoke-static {v4, v5}, Lsa;->M(Lwh;Lyh;)Lyh;

    .line 273
    .line 274
    .line 275
    move-result-object v4

    .line 276
    new-instance v5, Ldf1;

    .line 277
    .line 278
    invoke-direct {v5, v1, v2, v3}, Ldf1;-><init>(Lff1;Lkotlin/coroutines/Continuation;I)V

    .line 279
    .line 280
    .line 281
    invoke-static {v4, v5}, Ln40;->K(Lyh;Lsz;)Lzb;

    .line 282
    .line 283
    .line 284
    move-result-object v2

    .line 285
    new-instance v3, Lj8;

    .line 286
    .line 287
    const/4 v4, 0x6

    .line 288
    invoke-direct {v3, v9, v2, v1, v4}, Lj8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 289
    .line 290
    .line 291
    iget-object v4, v9, Lrm0;->d:Lq1;

    .line 292
    .line 293
    iget-object v4, v4, Lq1;->i:Ljava/lang/Object;

    .line 294
    .line 295
    check-cast v4, Lkp0;

    .line 296
    .line 297
    iget-object v2, v2, Lzb;->g:Lyb;

    .line 298
    .line 299
    invoke-virtual {v2, v3, v4}, Lf0;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 300
    .line 301
    .line 302
    iget-object v2, v9, Lrm0;->g:Ljava/util/HashMap;

    .line 303
    .line 304
    invoke-virtual {v2, v14, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 305
    .line 306
    .line 307
    new-instance v1, Ljava/util/HashSet;

    .line 308
    .line 309
    invoke-direct {v1}, Ljava/util/HashSet;-><init>()V

    .line 310
    .line 311
    .line 312
    invoke-virtual {v1, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 313
    .line 314
    .line 315
    iget-object v0, v9, Lrm0;->h:Ljava/util/HashMap;

    .line 316
    .line 317
    invoke-virtual {v0, v14, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 318
    .line 319
    .line 320
    monitor-exit v15
    :try_end_140
    .catchall {:try_start_8e .. :try_end_140} :catchall_c6

    .line 321
    invoke-static {}, Lta0;->g()Lta0;

    .line 322
    .line 323
    .line 324
    move-result-object v0

    .line 325
    sget-object v1, Lrm0;->l:Ljava/lang/String;

    .line 326
    .line 327
    new-instance v2, Ljava/lang/StringBuilder;

    .line 328
    .line 329
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 330
    .line 331
    .line 332
    const-class v3, Lrm0;

    .line 333
    .line 334
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 335
    .line 336
    .line 337
    move-result-object v3

    .line 338
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 339
    .line 340
    .line 341
    const-string v3, ": processing "

    .line 342
    .line 343
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-virtual {v2, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 347
    .line 348
    .line 349
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 350
    .line 351
    .line 352
    move-result-object v2

    .line 353
    invoke-virtual {v0, v1, v2}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 354
    .line 355
    .line 356
    :goto_163
    return-void

    .line 357
    :catchall_164
    move-exception v0

    .line 358
    :try_start_165
    monitor-exit v6
    :try_end_166
    .catchall {:try_start_165 .. :try_end_166} :catchall_164

    .line 359
    :try_start_166
    throw v0

    .line 360
    :goto_167
    monitor-exit v15
    :try_end_168
    .catchall {:try_start_166 .. :try_end_168} :catchall_c6

    .line 361
    throw v0

    .line 362
    :pswitch_169
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 363
    .line 364
    check-cast v1, Lrm0;

    .line 365
    .line 366
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 367
    .line 368
    check-cast v2, Lzb;

    .line 369
    .line 370
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 371
    .line 372
    check-cast v0, Lff1;

    .line 373
    .line 374
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 375
    .line 376
    .line 377
    :try_start_178
    iget-object v2, v2, Lzb;->g:Lyb;

    .line 378
    .line 379
    invoke-virtual {v2}, Lf0;->get()Ljava/lang/Object;

    .line 380
    .line 381
    .line 382
    move-result-object v2

    .line 383
    check-cast v2, Ljava/lang/Boolean;

    .line 384
    .line 385
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 386
    .line 387
    .line 388
    move-result v3
    :try_end_184
    .catch Ljava/lang/InterruptedException; {:try_start_178 .. :try_end_184} :catch_184
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_178 .. :try_end_184} :catch_184

    .line 389
    :catch_184
    iget-object v5, v1, Lrm0;->k:Ljava/lang/Object;

    .line 390
    .line 391
    monitor-enter v5

    .line 392
    :try_start_187
    iget-object v2, v0, Lff1;->a:Lne1;

    .line 393
    .line 394
    invoke-static {v2}, Lhh1;->p(Lne1;)Lce1;

    .line 395
    .line 396
    .line 397
    move-result-object v2

    .line 398
    iget-object v6, v2, Lce1;->a:Ljava/lang/String;

    .line 399
    .line 400
    invoke-virtual {v1, v6}, Lrm0;->c(Ljava/lang/String;)Lff1;

    .line 401
    .line 402
    .line 403
    move-result-object v7

    .line 404
    if-ne v7, v0, :cond_19b

    .line 405
    .line 406
    invoke-virtual {v1, v6}, Lrm0;->b(Ljava/lang/String;)Lff1;

    .line 407
    .line 408
    .line 409
    goto :goto_19b

    .line 410
    :catchall_199
    move-exception v0

    .line 411
    goto :goto_1dc

    .line 412
    :cond_19b
    :goto_19b
    invoke-static {}, Lta0;->g()Lta0;

    .line 413
    .line 414
    .line 415
    move-result-object v0

    .line 416
    sget-object v7, Lrm0;->l:Ljava/lang/String;

    .line 417
    .line 418
    new-instance v8, Ljava/lang/StringBuilder;

    .line 419
    .line 420
    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    .line 421
    .line 422
    .line 423
    const-class v9, Lrm0;

    .line 424
    .line 425
    invoke-virtual {v9}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 426
    .line 427
    .line 428
    move-result-object v9

    .line 429
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 430
    .line 431
    .line 432
    const-string v9, " "

    .line 433
    .line 434
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 435
    .line 436
    .line 437
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 438
    .line 439
    .line 440
    const-string v6, " executed; reschedule = "

    .line 441
    .line 442
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 443
    .line 444
    .line 445
    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 446
    .line 447
    .line 448
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object v6

    .line 452
    invoke-virtual {v0, v7, v6}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 453
    .line 454
    .line 455
    iget-object v0, v1, Lrm0;->j:Ljava/util/ArrayList;

    .line 456
    .line 457
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 458
    .line 459
    .line 460
    move-result v1

    .line 461
    :goto_1cc
    if-ge v4, v1, :cond_1da

    .line 462
    .line 463
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 464
    .line 465
    .line 466
    move-result-object v6

    .line 467
    add-int/lit8 v4, v4, 0x1

    .line 468
    .line 469
    check-cast v6, Lmr;

    .line 470
    .line 471
    invoke-interface {v6, v2, v3}, Lmr;->d(Lce1;Z)V

    .line 472
    .line 473
    .line 474
    goto :goto_1cc

    .line 475
    :cond_1da
    monitor-exit v5

    .line 476
    return-void

    .line 477
    :goto_1dc
    monitor-exit v5
    :try_end_1dd
    .catchall {:try_start_187 .. :try_end_1dd} :catchall_199

    .line 478
    throw v0

    .line 479
    :pswitch_1de
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 480
    .line 481
    check-cast v1, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 482
    .line 483
    iget-object v3, v0, Lj8;->h:Ljava/lang/Object;

    .line 484
    .line 485
    check-cast v3, Lwb;

    .line 486
    .line 487
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 488
    .line 489
    check-cast v0, Lae1;

    .line 490
    .line 491
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 492
    .line 493
    .line 494
    move-result v1

    .line 495
    if-eqz v1, :cond_1f1

    .line 496
    .line 497
    goto :goto_1fc

    .line 498
    :cond_1f1
    :try_start_1f1
    invoke-virtual {v0}, Lae1;->a()Ljava/lang/Object;

    .line 499
    .line 500
    .line 501
    invoke-virtual {v3, v2}, Lwb;->a(Ljava/lang/Object;)V
    :try_end_1f7
    .catchall {:try_start_1f1 .. :try_end_1f7} :catchall_1f8

    .line 502
    .line 503
    .line 504
    goto :goto_1fc

    .line 505
    :catchall_1f8
    move-exception v0

    .line 506
    invoke-virtual {v3, v0}, Lwb;->b(Ljava/lang/Throwable;)V

    .line 507
    .line 508
    .line 509
    :goto_1fc
    return-void

    .line 510
    :pswitch_1fd
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 511
    .line 512
    check-cast v1, Lk9;

    .line 513
    .line 514
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 515
    .line 516
    check-cast v2, Ln40;

    .line 517
    .line 518
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 519
    .line 520
    move-object v3, v0

    .line 521
    check-cast v3, Ljava/util/concurrent/ThreadPoolExecutor;

    .line 522
    .line 523
    :try_start_20a
    iget-object v0, v1, Lk9;->a:Landroid/content/Context;

    .line 524
    .line 525
    invoke-static {v0}, Lhh1;->l(Landroid/content/Context;)Ldx;

    .line 526
    .line 527
    .line 528
    move-result-object v0

    .line 529
    if-eqz v0, :cond_230

    .line 530
    .line 531
    iget-object v1, v0, Lxp;->b:Ljava/lang/Object;

    .line 532
    .line 533
    check-cast v1, Laq;

    .line 534
    .line 535
    check-cast v1, Lcx;

    .line 536
    .line 537
    iget-object v4, v1, Lcx;->d:Ljava/lang/Object;

    .line 538
    .line 539
    monitor-enter v4
    :try_end_21b
    .catchall {:try_start_20a .. :try_end_21b} :catchall_22b

    .line 540
    :try_start_21b
    iput-object v3, v1, Lcx;->f:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 541
    .line 542
    monitor-exit v4
    :try_end_21e
    .catchall {:try_start_21b .. :try_end_21e} :catchall_22d

    .line 543
    :try_start_21e
    iget-object v0, v0, Lxp;->b:Ljava/lang/Object;

    .line 544
    .line 545
    check-cast v0, Laq;

    .line 546
    .line 547
    new-instance v1, Ldq;

    .line 548
    .line 549
    invoke-direct {v1, v2, v3}, Ldq;-><init>(Ln40;Ljava/util/concurrent/ThreadPoolExecutor;)V

    .line 550
    .line 551
    .line 552
    invoke-interface {v0, v1}, Laq;->a(Ln40;)V
    :try_end_22a
    .catchall {:try_start_21e .. :try_end_22a} :catchall_22b

    .line 553
    .line 554
    .line 555
    goto :goto_23e

    .line 556
    :catchall_22b
    move-exception v0

    .line 557
    goto :goto_238

    .line 558
    :catchall_22d
    move-exception v0

    .line 559
    :try_start_22e
    monitor-exit v4
    :try_end_22f
    .catchall {:try_start_22e .. :try_end_22f} :catchall_22d

    .line 560
    :try_start_22f
    throw v0

    .line 561
    :cond_230
    new-instance v0, Ljava/lang/RuntimeException;

    .line 562
    .line 563
    const-string v1, "EmojiCompat font provider not available on this device."

    .line 564
    .line 565
    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 566
    .line 567
    .line 568
    throw v0
    :try_end_238
    .catchall {:try_start_22f .. :try_end_238} :catchall_22b

    .line 569
    :goto_238
    invoke-virtual {v2, v0}, Ln40;->N(Ljava/lang/Throwable;)V

    .line 570
    .line 571
    .line 572
    invoke-virtual {v3}, Ljava/util/concurrent/ThreadPoolExecutor;->shutdown()V

    .line 573
    .line 574
    .line 575
    :goto_23e
    return-void

    .line 576
    :pswitch_23f
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 577
    .line 578
    check-cast v1, Lcom/mypg/mypgallery/dpi/DpiVpnService;

    .line 579
    .line 580
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 581
    .line 582
    check-cast v2, Ljava/util/ArrayList;

    .line 583
    .line 584
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 585
    .line 586
    check-cast v0, Ljava/lang/String;

    .line 587
    .line 588
    const-string v5, "ciadpi did not listen on "

    .line 589
    .line 590
    const-string v6, "\n"

    .line 591
    .line 592
    const-string v7, "\n                tunnel:\n                  mtu: 8500\n                socks5:\n                  port: "

    .line 593
    .line 594
    iget-object v8, v1, Lcom/mypg/mypgallery/dpi/DpiVpnService;->h:Ljava/lang/Thread;

    .line 595
    .line 596
    if-eqz v8, :cond_257

    .line 597
    .line 598
    goto/16 :goto_380

    .line 599
    .line 600
    :cond_257
    const-string v8, "starting"

    .line 601
    .line 602
    invoke-virtual {v1, v8}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->b(Ljava/lang/String;)V

    .line 603
    .line 604
    .line 605
    :try_start_25c
    new-instance v8, Ljava/net/ServerSocket;

    .line 606
    .line 607
    invoke-direct {v8, v4}, Ljava/net/ServerSocket;-><init>(I)V
    :try_end_261
    .catchall {:try_start_25c .. :try_end_261} :catchall_2e9

    .line 608
    .line 609
    .line 610
    :try_start_261
    invoke-virtual {v8}, Ljava/net/ServerSocket;->getLocalPort()I

    .line 611
    .line 612
    .line 613
    move-result v9
    :try_end_265
    .catchall {:try_start_261 .. :try_end_265} :catchall_369

    .line 614
    :try_start_265
    invoke-virtual {v8}, Ljava/net/ServerSocket;->close()V

    .line 615
    .line 616
    .line 617
    new-instance v8, Ljava/io/File;

    .line 618
    .line 619
    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 620
    .line 621
    .line 622
    move-result-object v10

    .line 623
    const-string v11, "dpi_protect"

    .line 624
    .line 625
    invoke-direct {v8, v10, v11}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 626
    .line 627
    .line 628
    new-instance v10, Lfn0;

    .line 629
    .line 630
    new-instance v11, Lf;

    .line 631
    .line 632
    const/4 v12, 0x3

    .line 633
    invoke-direct {v11, v12, v1}, Lf;-><init>(ILjava/lang/Object;)V

    .line 634
    .line 635
    .line 636
    invoke-direct {v10, v8, v11}, Lfn0;-><init>(Ljava/io/File;Lf;)V

    .line 637
    .line 638
    .line 639
    invoke-virtual {v10}, Lfn0;->b()V

    .line 640
    .line 641
    .line 642
    iput-object v10, v1, Lcom/mypg/mypgallery/dpi/DpiVpnService;->g:Lfn0;

    .line 643
    .line 644
    const-string v13, "ciadpi"

    .line 645
    .line 646
    const-string v14, "-i"

    .line 647
    .line 648
    const-string v15, "127.0.0.1"

    .line 649
    .line 650
    const-string v16, "-p"

    .line 651
    .line 652
    invoke-static {v9}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 653
    .line 654
    .line 655
    move-result-object v17

    .line 656
    const-string v18, "-P"

    .line 657
    .line 658
    invoke-virtual {v8}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 659
    .line 660
    .line 661
    move-result-object v19

    .line 662
    filled-new-array/range {v13 .. v19}, [Ljava/lang/String;

    .line 663
    .line 664
    .line 665
    move-result-object v8

    .line 666
    invoke-static {v2, v8}, Lj9;->a0(Ljava/util/Collection;[Ljava/lang/Object;)[Ljava/lang/Object;

    .line 667
    .line 668
    .line 669
    move-result-object v2

    .line 670
    check-cast v2, [Ljava/lang/String;

    .line 671
    .line 672
    new-instance v8, Ljava/lang/Thread;

    .line 673
    .line 674
    new-instance v10, Lg8;

    .line 675
    .line 676
    const/16 v11, 0xa

    .line 677
    .line 678
    invoke-direct {v10, v2, v11, v1}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 679
    .line 680
    .line 681
    const-string v2, "ciadpi"

    .line 682
    .line 683
    invoke-direct {v8, v10, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    .line 684
    .line 685
    .line 686
    invoke-virtual {v8}, Ljava/lang/Thread;->start()V

    .line 687
    .line 688
    .line 689
    iput-object v8, v1, Lcom/mypg/mypgallery/dpi/DpiVpnService;->h:Ljava/lang/Thread;

    .line 690
    .line 691
    invoke-virtual {v1, v9}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->c(I)Z

    .line 692
    .line 693
    .line 694
    move-result v2

    .line 695
    if-eqz v2, :cond_357

    .line 696
    .line 697
    new-instance v2, Landroid/net/VpnService$Builder;

    .line 698
    .line 699
    invoke-direct {v2, v1}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    .line 700
    .line 701
    .line 702
    const-string v5, "MyPGallery"

    .line 703
    .line 704
    invoke-virtual {v2, v5}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    .line 705
    .line 706
    .line 707
    move-result-object v2

    .line 708
    const-string v5, "10.10.10.10"

    .line 709
    .line 710
    const/16 v8, 0x20

    .line 711
    .line 712
    invoke-virtual {v2, v5, v8}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    .line 713
    .line 714
    .line 715
    move-result-object v2

    .line 716
    const-string v5, "0.0.0.0"

    .line 717
    .line 718
    invoke-virtual {v2, v5, v4}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    .line 719
    .line 720
    .line 721
    move-result-object v2

    .line 722
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 723
    .line 724
    .line 725
    move-result-object v4

    .line 726
    invoke-virtual {v2, v4}, Landroid/net/VpnService$Builder;->addAllowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    .line 727
    .line 728
    .line 729
    move-result-object v2

    .line 730
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 731
    .line 732
    .line 733
    if-eqz v0, :cond_2ec

    .line 734
    .line 735
    invoke-static {v0}, Ls01;->j0(Ljava/lang/CharSequence;)Z

    .line 736
    .line 737
    .line 738
    move-result v4

    .line 739
    if-eqz v4, :cond_2e5

    .line 740
    .line 741
    goto :goto_2ec

    .line 742
    :cond_2e5
    invoke-virtual {v2, v0}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    .line 743
    .line 744
    .line 745
    goto :goto_2ec

    .line 746
    :catchall_2e9
    move-exception v0

    .line 747
    goto/16 :goto_371

    .line 748
    .line 749
    :cond_2ec
    :goto_2ec
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 750
    .line 751
    const/16 v4, 0x1d

    .line 752
    .line 753
    if-lt v0, v4, :cond_2f5

    .line 754
    .line 755
    invoke-static {v2}, Ld1;->l(Landroid/net/VpnService$Builder;)V

    .line 756
    .line 757
    .line 758
    :cond_2f5
    invoke-virtual {v2}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    .line 759
    .line 760
    .line 761
    move-result-object v0

    .line 762
    if-eqz v0, :cond_34f

    .line 763
    .line 764
    iput-object v0, v1, Lcom/mypg/mypgallery/dpi/DpiVpnService;->f:Landroid/os/ParcelFileDescriptor;

    .line 765
    .line 766
    new-instance v2, Ljava/io/File;

    .line 767
    .line 768
    invoke-virtual {v1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 769
    .line 770
    .line 771
    move-result-object v4

    .line 772
    const-string v5, "hev-tunnel.yml"

    .line 773
    .line 774
    invoke-direct {v2, v4, v5}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 775
    .line 776
    .line 777
    new-instance v4, Ljava/lang/StringBuilder;

    .line 778
    .line 779
    invoke-direct {v4, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 780
    .line 781
    .line 782
    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 783
    .line 784
    .line 785
    const-string v5, "\n                  address: 127.0.0.1\n                  udp: \'udp\'\n                misc:\n                  task-stack-size: 81920\n                "

    .line 786
    .line 787
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 788
    .line 789
    .line 790
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 791
    .line 792
    .line 793
    move-result-object v4

    .line 794
    invoke-static {v4}, Lt01;->Y(Ljava/lang/String;)Ljava/lang/String;

    .line 795
    .line 796
    .line 797
    move-result-object v4

    .line 798
    invoke-virtual {v4, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 799
    .line 800
    .line 801
    move-result-object v4

    .line 802
    sget-object v5, Lxc;->a:Ljava/nio/charset/Charset;

    .line 803
    .line 804
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 805
    .line 806
    .line 807
    new-instance v6, Ljava/io/FileOutputStream;

    .line 808
    .line 809
    invoke-direct {v6, v2}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_32b
    .catchall {:try_start_265 .. :try_end_32b} :catchall_2e9

    .line 810
    .line 811
    .line 812
    :try_start_32b
    invoke-static {v6, v4, v5}, Lhh1;->L(Ljava/io/FileOutputStream;Ljava/lang/String;Ljava/nio/charset/Charset;)V

    .line 813
    .line 814
    .line 815
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_330
    .catchall {:try_start_32b .. :try_end_330} :catchall_347

    .line 816
    .line 817
    :try_start_330
    invoke-virtual {v6}, Ljava/io/FileOutputStream;->close()V

    .line 818
    .line 819
    .line 820
    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    .line 821
    .line 822
    .line 823
    move-result-object v2

    .line 824
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 825
    .line 826
    .line 827
    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFd()I

    .line 828
    .line 829
    .line 830
    move-result v0

    .line 831
    invoke-static {v2, v0}, Lcom/mypg/mypgallery/dpi/TProxy;->TProxyStartService(Ljava/lang/String;I)V

    .line 832
    .line 833
    .line 834
    const-string v0, "running"

    .line 835
    .line 836
    invoke-virtual {v1, v0}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->b(Ljava/lang/String;)V
    :try_end_346
    .catchall {:try_start_330 .. :try_end_346} :catchall_2e9

    .line 837
    .line 838
    .line 839
    goto :goto_380

    .line 840
    :catchall_347
    move-exception v0

    .line 841
    move-object v2, v0

    .line 842
    :try_start_349
    throw v2
    :try_end_34a
    .catchall {:try_start_349 .. :try_end_34a} :catchall_34a

    .line 843
    :catchall_34a
    move-exception v0

    .line 844
    :try_start_34b
    invoke-static {v6, v2}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 845
    .line 846
    .line 847
    throw v0

    .line 848
    :cond_34f
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 849
    .line 850
    const-string v2, "VPN not prepared"

    .line 851
    .line 852
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 853
    .line 854
    .line 855
    throw v0

    .line 856
    :cond_357
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 857
    .line 858
    new-instance v2, Ljava/lang/StringBuilder;

    .line 859
    .line 860
    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 861
    .line 862
    .line 863
    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 864
    .line 865
    .line 866
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 867
    .line 868
    .line 869
    move-result-object v2

    .line 870
    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 871
    .line 872
    .line 873
    throw v0
    :try_end_369
    .catchall {:try_start_34b .. :try_end_369} :catchall_2e9

    .line 874
    :catchall_369
    move-exception v0

    .line 875
    move-object v2, v0

    .line 876
    :try_start_36b
    throw v2
    :try_end_36c
    .catchall {:try_start_36b .. :try_end_36c} :catchall_36c

    .line 877
    :catchall_36c
    move-exception v0

    .line 878
    :try_start_36d
    invoke-static {v8, v2}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 879
    .line 880
    .line 881
    throw v0
    :try_end_371
    .catchall {:try_start_36d .. :try_end_371} :catchall_2e9

    .line 882
    :goto_371
    const-string v2, "DpiVpn"

    .line 883
    .line 884
    const-string v4, "start failed"

    .line 885
    .line 886
    invoke-static {v2, v4, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 887
    .line 888
    .line 889
    const-string v0, "failed"

    .line 890
    .line 891
    invoke-virtual {v1, v0}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->b(Ljava/lang/String;)V

    .line 892
    .line 893
    .line 894
    invoke-virtual {v1, v3}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->a(Z)V

    .line 895
    .line 896
    .line 897
    :goto_380
    return-void

    .line 898
    :pswitch_381
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 899
    .line 900
    check-cast v1, Loz;

    .line 901
    .line 902
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 903
    .line 904
    check-cast v2, Lno;

    .line 905
    .line 906
    iget-object v2, v2, Lno;->b:Landroid/os/Handler;

    .line 907
    .line 908
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 909
    .line 910
    move-object v3, v0

    .line 911
    check-cast v3, Lqe0;

    .line 912
    .line 913
    :try_start_390
    invoke-interface {v1}, Loz;->a()Ljava/lang/Object;

    .line 914
    .line 915
    .line 916
    move-result-object v0

    .line 917
    new-instance v1, Lko;

    .line 918
    .line 919
    invoke-direct {v1, v3, v0, v4}, Lko;-><init>(Lqe0;Ljava/lang/Object;I)V

    .line 920
    .line 921
    .line 922
    invoke-virtual {v2, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_39c
    .catchall {:try_start_390 .. :try_end_39c} :catchall_39d

    .line 923
    .line 924
    .line 925
    goto :goto_3a8

    .line 926
    :catchall_39d
    move-exception v0

    .line 927
    new-instance v1, Lg8;

    .line 928
    .line 929
    const/16 v4, 0x9

    .line 930
    .line 931
    invoke-direct {v1, v3, v4, v0}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 932
    .line 933
    .line 934
    invoke-virtual {v2, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 935
    .line 936
    .line 937
    :goto_3a8
    return-void

    .line 938
    :pswitch_3a9
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 939
    .line 940
    check-cast v1, Landroidx/work/impl/WorkDatabase;

    .line 941
    .line 942
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 943
    .line 944
    check-cast v2, Ljava/lang/String;

    .line 945
    .line 946
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 947
    .line 948
    check-cast v0, Lee1;

    .line 949
    .line 950
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->v()Lre1;

    .line 951
    .line 952
    .line 953
    move-result-object v1

    .line 954
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 955
    .line 956
    .line 957
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 958
    .line 959
    .line 960
    iget-object v1, v1, Lre1;->a:Lgq0;

    .line 961
    .line 962
    new-instance v5, Lum;

    .line 963
    .line 964
    const/16 v6, 0x8

    .line 965
    .line 966
    invoke-direct {v5, v2, v6}, Lum;-><init>(Ljava/lang/String;I)V

    .line 967
    .line 968
    .line 969
    invoke-static {v1, v3, v4, v5}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 970
    .line 971
    .line 972
    move-result-object v1

    .line 973
    check-cast v1, Ljava/util/List;

    .line 974
    .line 975
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 976
    .line 977
    .line 978
    move-result-object v1

    .line 979
    :goto_3d2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 980
    .line 981
    .line 982
    move-result v2

    .line 983
    if-eqz v2, :cond_3e2

    .line 984
    .line 985
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 986
    .line 987
    .line 988
    move-result-object v2

    .line 989
    check-cast v2, Ljava/lang/String;

    .line 990
    .line 991
    invoke-static {v0, v2}, Llf1;->e(Lee1;Ljava/lang/String;)V

    .line 992
    .line 993
    .line 994
    goto :goto_3d2

    .line 995
    :cond_3e2
    return-void

    .line 996
    :pswitch_3e3
    iget-object v1, v0, Lj8;->g:Ljava/lang/Object;

    .line 997
    .line 998
    check-cast v1, Landroid/content/Context;

    .line 999
    .line 1000
    iget-object v2, v0, Lj8;->h:Ljava/lang/Object;

    .line 1001
    .line 1002
    check-cast v2, Ljava/io/File;

    .line 1003
    .line 1004
    iget-object v0, v0, Lj8;->i:Ljava/lang/Object;

    .line 1005
    .line 1006
    move-object v5, v0

    .line 1007
    check-cast v5, Lqe0;

    .line 1008
    .line 1009
    sget-object v6, Ll8;->b:Landroid/os/Handler;

    .line 1010
    .line 1011
    :try_start_3f2
    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 1012
    .line 1013
    .line 1014
    move-result-object v0

    .line 1015
    invoke-virtual {v0}, Landroid/content/pm/PackageManager;->getPackageInstaller()Landroid/content/pm/PackageInstaller;

    .line 1016
    .line 1017
    .line 1018
    move-result-object v7

    .line 1019
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1020
    .line 1021
    .line 1022
    new-instance v0, Landroid/content/pm/PackageInstaller$SessionParams;

    .line 1023
    .line 1024
    invoke-direct {v0, v3}, Landroid/content/pm/PackageInstaller$SessionParams;-><init>(I)V

    .line 1025
    .line 1026
    .line 1027
    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 1028
    .line 1029
    .line 1030
    move-result-object v3

    .line 1031
    invoke-virtual {v0, v3}, Landroid/content/pm/PackageInstaller$SessionParams;->setAppPackageName(Ljava/lang/String;)V

    .line 1032
    .line 1033
    .line 1034
    invoke-virtual {v2}, Ljava/io/File;->length()J

    .line 1035
    .line 1036
    .line 1037
    move-result-wide v8

    .line 1038
    invoke-virtual {v0, v8, v9}, Landroid/content/pm/PackageInstaller$SessionParams;->setSize(J)V

    .line 1039
    .line 1040
    .line 1041
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 1042
    .line 1043
    const/16 v8, 0x1f

    .line 1044
    .line 1045
    if-lt v3, v8, :cond_41d

    .line 1046
    .line 1047
    invoke-static {v0}, Ls0;->o(Landroid/content/pm/PackageInstaller$SessionParams;)V

    .line 1048
    .line 1049
    .line 1050
    goto :goto_41d

    .line 1051
    :catch_41a
    move-exception v0

    .line 1052
    goto/16 :goto_49e

    .line 1053
    .line 1054
    :cond_41d
    :goto_41d
    invoke-virtual {v7, v0}, Landroid/content/pm/PackageInstaller;->createSession(Landroid/content/pm/PackageInstaller$SessionParams;)I

    .line 1055
    .line 1056
    .line 1057
    move-result v9
    :try_end_421
    .catch Ljava/lang/Exception; {:try_start_3f2 .. :try_end_421} :catch_41a

    .line 1058
    :try_start_421
    invoke-virtual {v7, v9}, Landroid/content/pm/PackageInstaller;->openSession(I)Landroid/content/pm/PackageInstaller$Session;

    .line 1059
    .line 1060
    .line 1061
    move-result-object v10
    :try_end_425
    .catch Ljava/lang/Exception; {:try_start_421 .. :try_end_425} :catch_47b

    .line 1062
    :try_start_425
    new-instance v11, Ljava/io/FileInputStream;

    .line 1063
    .line 1064
    invoke-direct {v11, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_42a
    .catchall {:try_start_425 .. :try_end_42a} :catchall_47d

    .line 1065
    .line 1066
    .line 1067
    move-object v12, v11

    .line 1068
    :try_start_42b
    const-string v11, "base.apk"

    .line 1069
    .line 1070
    invoke-virtual {v2}, Ljava/io/File;->length()J

    .line 1071
    .line 1072
    .line 1073
    move-result-wide v14
    :try_end_431
    .catchall {:try_start_42b .. :try_end_431} :catchall_48b

    .line 1074
    move-object v2, v12

    .line 1075
    const-wide/16 v12, 0x0

    .line 1076
    .line 1077
    :try_start_434
    invoke-virtual/range {v10 .. v15}, Landroid/content/pm/PackageInstaller$Session;->openWrite(Ljava/lang/String;JJ)Ljava/io/OutputStream;

    .line 1078
    .line 1079
    .line 1080
    move-result-object v11
    :try_end_438
    .catchall {:try_start_434 .. :try_end_438} :catchall_480

    .line 1081
    :try_start_438
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1082
    .line 1083
    .line 1084
    const/high16 v0, 0x10000

    .line 1085
    .line 1086
    invoke-static {v2, v11, v0}, Lt51;->j(Ljava/io/InputStream;Ljava/io/OutputStream;I)J

    .line 1087
    .line 1088
    .line 1089
    invoke-virtual {v10, v11}, Landroid/content/pm/PackageInstaller$Session;->fsync(Ljava/io/OutputStream;)V

    .line 1090
    .line 1091
    .line 1092
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_445
    .catchall {:try_start_438 .. :try_end_445} :catchall_483

    .line 1093
    .line 1094
    :try_start_445
    invoke-interface {v11}, Ljava/io/Closeable;->close()V
    :try_end_448
    .catchall {:try_start_445 .. :try_end_448} :catchall_480

    .line 1095
    .line 1096
    .line 1097
    :try_start_448
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 1098
    .line 1099
    .line 1100
    new-instance v0, Landroid/content/Intent;

    .line 1101
    .line 1102
    const-class v2, Lcom/mypg/mypgallery/UpdateInstallReceiver;

    .line 1103
    .line 1104
    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 1105
    .line 1106
    .line 1107
    const-string v2, "com.mypg.mypgallery.UPDATE_INSTALL_STATUS"

    .line 1108
    .line 1109
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 1110
    .line 1111
    .line 1112
    move-result-object v0

    .line 1113
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1114
    .line 1115
    .line 1116
    if-lt v3, v8, :cond_460

    .line 1117
    .line 1118
    const/high16 v2, 0x2000000

    .line 1119
    .line 1120
    goto :goto_461

    .line 1121
    :cond_460
    move v2, v4

    .line 1122
    :goto_461
    const/high16 v3, 0x8000000

    .line 1123
    .line 1124
    or-int/2addr v2, v3

    .line 1125
    invoke-static {v1, v9, v0, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 1126
    .line 1127
    .line 1128
    move-result-object v0

    .line 1129
    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    .line 1130
    .line 1131
    .line 1132
    move-result-object v0

    .line 1133
    invoke-virtual {v10, v0}, Landroid/content/pm/PackageInstaller$Session;->commit(Landroid/content/IntentSender;)V
    :try_end_46f
    .catchall {:try_start_448 .. :try_end_46f} :catchall_47d

    .line 1134
    .line 1135
    .line 1136
    :try_start_46f
    invoke-interface {v10}, Ljava/io/Closeable;->close()V
    :try_end_472
    .catch Ljava/lang/Exception; {:try_start_46f .. :try_end_472} :catch_47b

    .line 1137
    .line 1138
    .line 1139
    :try_start_472
    new-instance v0, Lk8;

    .line 1140
    .line 1141
    invoke-direct {v0, v4, v5}, Lk8;-><init>(ILjava/lang/Object;)V

    .line 1142
    .line 1143
    .line 1144
    invoke-virtual {v6, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_47a
    .catch Ljava/lang/Exception; {:try_start_472 .. :try_end_47a} :catch_41a

    .line 1145
    .line 1146
    .line 1147
    goto :goto_4a7

    .line 1148
    :catch_47b
    move-exception v0

    .line 1149
    goto :goto_49a

    .line 1150
    :catchall_47d
    move-exception v0

    .line 1151
    move-object v1, v0

    .line 1152
    goto :goto_494

    .line 1153
    :catchall_480
    move-exception v0

    .line 1154
    :goto_481
    move-object v1, v0

    .line 1155
    goto :goto_48e

    .line 1156
    :catchall_483
    move-exception v0

    .line 1157
    move-object v1, v0

    .line 1158
    :try_start_485
    throw v1
    :try_end_486
    .catchall {:try_start_485 .. :try_end_486} :catchall_486

    .line 1159
    :catchall_486
    move-exception v0

    .line 1160
    :try_start_487
    invoke-static {v11, v1}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1161
    .line 1162
    .line 1163
    throw v0
    :try_end_48b
    .catchall {:try_start_487 .. :try_end_48b} :catchall_480

    .line 1164
    :catchall_48b
    move-exception v0

    .line 1165
    move-object v2, v12

    .line 1166
    goto :goto_481

    .line 1167
    :goto_48e
    :try_start_48e
    throw v1
    :try_end_48f
    .catchall {:try_start_48e .. :try_end_48f} :catchall_48f

    .line 1168
    :catchall_48f
    move-exception v0

    .line 1169
    :try_start_490
    invoke-static {v2, v1}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1170
    .line 1171
    .line 1172
    throw v0
    :try_end_494
    .catchall {:try_start_490 .. :try_end_494} :catchall_47d

    .line 1173
    :goto_494
    :try_start_494
    throw v1
    :try_end_495
    .catchall {:try_start_494 .. :try_end_495} :catchall_495

    .line 1174
    :catchall_495
    move-exception v0

    .line 1175
    :try_start_496
    invoke-static {v10, v1}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 1176
    .line 1177
    .line 1178
    throw v0
    :try_end_49a
    .catch Ljava/lang/Exception; {:try_start_496 .. :try_end_49a} :catch_47b

    .line 1179
    :goto_49a
    :try_start_49a
    invoke-virtual {v7, v9}, Landroid/content/pm/PackageInstaller;->abandonSession(I)V
    :try_end_49d
    .catch Ljava/lang/Exception; {:try_start_49a .. :try_end_49d} :catch_49d

    .line 1180
    .line 1181
    .line 1182
    :catch_49d
    :try_start_49d
    throw v0
    :try_end_49e
    .catch Ljava/lang/Exception; {:try_start_49d .. :try_end_49e} :catch_41a

    .line 1183
    :goto_49e
    new-instance v1, Lg8;

    .line 1184
    .line 1185
    const/4 v2, 0x2

    .line 1186
    invoke-direct {v1, v5, v2, v0}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 1187
    .line 1188
    .line 1189
    invoke-virtual {v6, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 1190
    .line 1191
    .line 1192
    :goto_4a7
    return-void

    .line 1193
    :pswitch_data_4a8
    .packed-switch 0x0
        :pswitch_3e3
        :pswitch_3a9
        :pswitch_381
        :pswitch_23f
        :pswitch_1fd
        :pswitch_1de
        :pswitch_169
        :pswitch_2a
    .end packed-switch
.end method

###### Class defpackage.qm0 (qm0)
.class public final synthetic Lqm0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/concurrent/Callable;


# instance fields
.field public final synthetic a:Lrm0;

.field public final synthetic b:Ljava/util/ArrayList;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lrm0;Ljava/util/ArrayList;Ljava/lang/String;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lqm0;->a:Lrm0;

    .line 5
    .line 6
    iput-object p2, p0, Lqm0;->b:Ljava/util/ArrayList;

    .line 7
    .line 8
    iput-object p3, p0, Lqm0;->c:Ljava/lang/String;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final call()Ljava/lang/Object;
    .registers 7

    .line 1
    iget-object v0, p0, Lqm0;->a:Lrm0;

    .line 2
    .line 3
    iget-object v0, v0, Lrm0;->e:Landroidx/work/impl/WorkDatabase;

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->w()Lte1;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    iget-object v2, p0, Lqm0;->c:Ljava/lang/String;

    .line 13
    .line 14
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 15
    .line 16
    .line 17
    iget-object v1, v1, Lte1;->a:Lgq0;

    .line 18
    .line 19
    new-instance v3, Lum;

    .line 20
    .line 21
    const/16 v4, 0x10

    .line 22
    .line 23
    invoke-direct {v3, v2, v4}, Lum;-><init>(Ljava/lang/String;I)V

    .line 24
    .line 25
    .line 26
    const/4 v4, 0x1

    .line 27
    const/4 v5, 0x0

    .line 28
    invoke-static {v1, v4, v5, v3}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object v1

    .line 32
    check-cast v1, Ljava/util/List;

    .line 33
    .line 34
    iget-object p0, p0, Lqm0;->b:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 37
    .line 38
    .line 39
    invoke-virtual {v0}, Landroidx/work/impl/WorkDatabase;->v()Lre1;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    invoke-virtual {p0, v2}, Lre1;->b(Ljava/lang/String;)Lne1;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    return-object p0
.end method
