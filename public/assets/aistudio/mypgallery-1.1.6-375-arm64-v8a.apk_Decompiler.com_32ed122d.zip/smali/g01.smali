###### Class defpackage.g01 (g01)
.class public final Lg01;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Lw70;


# direct methods
.method public constructor <init>(Loz;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lw70;

    .line 5
    .line 6
    invoke-direct {v0, p1}, Lw70;-><init>(Loz;)V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Lg01;->a:Lw70;

    .line 10
    .line 11
    return-void
.end method
