###### Class defpackage.lz (lz)
.class public final Llz;
.super Lkz;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lt11;


# instance fields
.field public final g:Landroid/database/sqlite/SQLiteStatement;


# direct methods
.method public constructor <init>(Landroid/database/sqlite/SQLiteStatement;)V
    .registers 2

    .line 1
    invoke-direct {p0, p1}, Lkz;-><init>(Landroid/database/sqlite/SQLiteProgram;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Llz;->g:Landroid/database/sqlite/SQLiteStatement;

    .line 5
    .line 6
    return-void
.end method
