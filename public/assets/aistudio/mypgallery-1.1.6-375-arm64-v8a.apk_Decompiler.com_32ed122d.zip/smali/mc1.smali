###### Class defpackage.mc1 (mc1)
.class public abstract Lmc1;
.super Llc1;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public n:Lo30;


# direct methods
.method public constructor <init>(Lvc1;Landroid/view/WindowInsets;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1, p2}, Llc1;-><init>(Lvc1;Landroid/view/WindowInsets;)V

    .line 2
    .line 3
    .line 4
    const/4 p1, 0x0

    .line 5
    iput-object p1, p0, Lmc1;->n:Lo30;

    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public b()Lvc1;
    .registers 2

    .line 1
    iget-object p0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/WindowInsets;->consumeStableInsets()Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const/4 v0, 0x0

    .line 8
    invoke-static {p0, v0}, Lvc1;->c(Landroid/view/WindowInsets;Landroid/view/View;)Lvc1;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public c()Lvc1;
    .registers 2

    .line 1
    iget-object p0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/WindowInsets;->consumeSystemWindowInsets()Landroid/view/WindowInsets;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    const/4 v0, 0x0

    .line 8
    invoke-static {p0, v0}, Lvc1;->c(Landroid/view/WindowInsets;Landroid/view/View;)Lvc1;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    return-object p0
.end method

.method public final g()Lo30;
    .registers 5

    .line 1
    iget-object v0, p0, Lmc1;->n:Lo30;

    .line 2
    .line 3
    if-nez v0, :cond_1c

    .line 4
    .line 5
    iget-object v0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetLeft()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetTop()I

    .line 12
    .line 13
    .line 14
    move-result v2

    .line 15
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetRight()I

    .line 16
    .line 17
    .line 18
    move-result v3

    .line 19
    invoke-virtual {v0}, Landroid/view/WindowInsets;->getStableInsetBottom()I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {v1, v2, v3, v0}, Lo30;->a(IIII)Lo30;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    iput-object v0, p0, Lmc1;->n:Lo30;

    .line 28
    .line 29
    :cond_1c
    iget-object p0, p0, Lmc1;->n:Lo30;

    .line 30
    .line 31
    return-object p0
.end method

.method public l()Z
    .registers 1

    .line 1
    iget-object p0, p0, Llc1;->c:Landroid/view/WindowInsets;

    .line 2
    .line 3
    invoke-virtual {p0}, Landroid/view/WindowInsets;->isConsumed()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public q(Lo30;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lmc1;->n:Lo30;

    .line 2
    .line 3
    return-void
.end method
