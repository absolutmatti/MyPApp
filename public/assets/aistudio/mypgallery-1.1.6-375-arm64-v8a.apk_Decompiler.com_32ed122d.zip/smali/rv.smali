###### Class defpackage.rv (rv)
.class public final Lrv;
.super Ljava/lang/RuntimeException;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final f:Ljava/lang/String;

.field public final g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/RuntimeException;-><init>()V

    .line 2
    .line 3
    .line 4
    const-string v0, "NO_ACTIVITY"

    .line 5
    .line 6
    iput-object v0, p0, Lrv;->f:Ljava/lang/String;

    .line 7
    .line 8
    const-string v0, "Launching a URL requires a foreground activity."

    .line 9
    .line 10
    iput-object v0, p0, Lrv;->g:Ljava/lang/String;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final getMessage()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Lrv;->g:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method
