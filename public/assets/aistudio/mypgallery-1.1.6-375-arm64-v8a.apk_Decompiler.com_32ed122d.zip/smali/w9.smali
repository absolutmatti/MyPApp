###### Class defpackage.w9 (w9)
.class public final synthetic Lw9;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Loz;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 4

    .line 1
    iput p2, p0, Lw9;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lw9;->g:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, Lw9;->h:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 6

    .line 1
    iget v0, p0, Lw9;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_d8

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lw9;->g:Ljava/lang/Object;

    .line 7
    .line 8
    check-cast v0, Ltm;

    .line 9
    .line 10
    iget-object p0, p0, Lw9;->h:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast p0, Landroid/net/ConnectivityManager;

    .line 13
    .line 14
    sget-object v1, Lzu0;->b:Ljava/lang/Object;

    .line 15
    .line 16
    monitor-enter v1

    .line 17
    :try_start_10
    sget-object v2, Lzu0;->c:Ljava/util/LinkedHashMap;

    .line 18
    .line 19
    invoke-interface {v2, v0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-eqz v0, :cond_36

    .line 27
    .line 28
    invoke-static {}, Lta0;->g()Lta0;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    sget-object v2, Ltd1;->a:Ljava/lang/String;

    .line 33
    .line 34
    const-string v3, "NetworkRequestConstraintController unregister shared callback"

    .line 35
    .line 36
    invoke-virtual {v0, v2, v3}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 37
    .line 38
    .line 39
    sget-object v0, Lzu0;->a:Lzu0;

    .line 40
    .line 41
    invoke-virtual {p0, v0}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V

    .line 42
    .line 43
    .line 44
    const/4 p0, 0x0

    .line 45
    sput-object p0, Lzu0;->f:Ljava/lang/Boolean;

    .line 46
    .line 47
    sput-object p0, Lzu0;->d:Landroid/net/NetworkCapabilities;

    .line 48
    .line 49
    const/4 p0, 0x0

    .line 50
    sput-boolean p0, Lzu0;->e:Z
    :try_end_33
    .catchall {:try_start_10 .. :try_end_33} :catchall_34

    .line 51
    .line 52
    goto :goto_36

    .line 53
    :catchall_34
    move-exception p0

    .line 54
    goto :goto_3a

    .line 55
    :cond_36
    :goto_36
    monitor-exit v1

    .line 56
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 57
    .line 58
    return-object p0

    .line 59
    :goto_3a
    monitor-exit v1

    .line 60
    throw p0

    .line 61
    :pswitch_3c
    iget-object v0, p0, Lw9;->g:Ljava/lang/Object;

    .line 62
    .line 63
    check-cast v0, Landroid/content/Context;

    .line 64
    .line 65
    iget-object p0, p0, Lw9;->h:Ljava/lang/Object;

    .line 66
    .line 67
    check-cast p0, Lvl0;

    .line 68
    .line 69
    iget-object p0, p0, Lvl0;->a:Ljava/lang/String;

    .line 70
    .line 71
    const-string v1, ".preferences_pb"

    .line 72
    .line 73
    invoke-virtual {p0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 74
    .line 75
    .line 76
    move-result-object p0

    .line 77
    new-instance v1, Ljava/io/File;

    .line 78
    .line 79
    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    .line 84
    .line 85
    .line 86
    move-result-object v0

    .line 87
    const-string v2, "datastore/"

    .line 88
    .line 89
    invoke-virtual {v2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 90
    .line 91
    .line 92
    move-result-object p0

    .line 93
    invoke-direct {v1, v0, p0}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    return-object v1

    .line 97
    :pswitch_60
    iget-object v0, p0, Lw9;->g:Ljava/lang/Object;

    .line 98
    .line 99
    check-cast v0, Lee1;

    .line 100
    .line 101
    iget-object p0, p0, Lw9;->h:Ljava/lang/Object;

    .line 102
    .line 103
    check-cast p0, Ljava/util/UUID;

    .line 104
    .line 105
    iget-object v1, v0, Lee1;->c:Landroidx/work/impl/WorkDatabase;

    .line 106
    .line 107
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 108
    .line 109
    .line 110
    invoke-virtual {v1}, Lgq0;->b()V

    .line 111
    .line 112
    .line 113
    :try_start_70
    invoke-virtual {p0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object p0

    .line 117
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    .line 119
    .line 120
    invoke-static {v0, p0}, Llf1;->e(Lee1;Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v1}, Lgq0;->o()V
    :try_end_7d
    .catchall {:try_start_70 .. :try_end_7d} :catchall_8c

    .line 124
    .line 125
    .line 126
    invoke-virtual {v1}, Lgq0;->l()V

    .line 127
    .line 128
    .line 129
    iget-object p0, v0, Lee1;->b:Lig;

    .line 130
    .line 131
    iget-object v1, v0, Lee1;->c:Landroidx/work/impl/WorkDatabase;

    .line 132
    .line 133
    iget-object v0, v0, Lee1;->e:Ljava/util/List;

    .line 134
    .line 135
    invoke-static {p0, v1, v0}, Lcs0;->b(Lig;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 136
    .line 137
    .line 138
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 139
    .line 140
    return-object p0

    .line 141
    :catchall_8c
    move-exception p0

    .line 142
    invoke-virtual {v1}, Lgq0;->l()V

    .line 143
    .line 144
    .line 145
    throw p0

    .line 146
    :pswitch_91
    iget-object v0, p0, Lw9;->g:Ljava/lang/Object;

    .line 147
    .line 148
    check-cast v0, Lfa;

    .line 149
    .line 150
    iget-object p0, p0, Lw9;->h:Ljava/lang/Object;

    .line 151
    .line 152
    check-cast p0, Lx9;

    .line 153
    .line 154
    iget-object v0, v0, Lfa;->a:Lga;

    .line 155
    .line 156
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 157
    .line 158
    .line 159
    iget-object v1, v0, Lga;->c:Ljava/lang/Object;

    .line 160
    .line 161
    monitor-enter v1

    .line 162
    :try_start_a1
    iget-object v2, v0, Lga;->d:Ljava/util/LinkedHashSet;

    .line 163
    .line 164
    invoke-virtual {v2, p0}, Ljava/util/AbstractCollection;->remove(Ljava/lang/Object;)Z

    .line 165
    .line 166
    .line 167
    move-result p0

    .line 168
    if-eqz p0, :cond_d2

    .line 169
    .line 170
    iget-object p0, v0, Lga;->d:Ljava/util/LinkedHashSet;

    .line 171
    .line 172
    invoke-virtual {p0}, Ljava/util/AbstractCollection;->isEmpty()Z

    .line 173
    .line 174
    .line 175
    move-result p0

    .line 176
    if-eqz p0, :cond_d2

    .line 177
    .line 178
    invoke-static {}, Lta0;->g()Lta0;

    .line 179
    .line 180
    .line 181
    move-result-object p0

    .line 182
    sget-object v2, Lya;->a:Ljava/lang/String;

    .line 183
    .line 184
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 185
    .line 186
    .line 187
    move-result-object v3

    .line 188
    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 189
    .line 190
    .line 191
    move-result-object v3

    .line 192
    const-string v4, ": unregistering receiver"

    .line 193
    .line 194
    invoke-virtual {v3, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    invoke-virtual {p0, v2, v3}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 199
    .line 200
    .line 201
    iget-object p0, v0, Lga;->b:Landroid/content/Context;

    .line 202
    .line 203
    iget-object v0, v0, Lga;->f:Le6;

    .line 204
    .line 205
    invoke-virtual {p0, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_cf
    .catchall {:try_start_a1 .. :try_end_cf} :catchall_d0

    .line 206
    .line 207
    .line 208
    goto :goto_d2

    .line 209
    :catchall_d0
    move-exception p0

    .line 210
    goto :goto_d6

    .line 211
    :cond_d2
    :goto_d2
    monitor-exit v1

    .line 212
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 213
    .line 214
    return-object p0

    .line 215
    :goto_d6
    monitor-exit v1

    .line 216
    throw p0

    .line 217
    :pswitch_data_d8
    .packed-switch 0x0
        :pswitch_91
        :pswitch_60
        :pswitch_3c
    .end packed-switch
.end method
