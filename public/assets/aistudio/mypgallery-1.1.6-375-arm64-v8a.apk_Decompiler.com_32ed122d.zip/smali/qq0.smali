###### Class defpackage.qq0 (qq0)
.class public interface abstract Lqq0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/AutoCloseable;


# virtual methods
.method public abstract b(I)V
.end method

.method public abstract c(IJ)V
.end method

.method public abstract e(I[B)V
.end method

.method public abstract f(I)Ljava/lang/String;
.end method

.method public abstract getBlob(I)[B
.end method

.method public abstract getColumnCount()I
.end method

.method public abstract getColumnName(I)Ljava/lang/String;
.end method

.method public abstract getLong(I)J
.end method

.method public abstract isNull(I)Z
.end method

.method public abstract reset()V
.end method

.method public abstract s(ILjava/lang/String;)V
.end method

.method public abstract v()Z
.end method
