###### Class defpackage.dk0 (dk0)
.class public final Ldk0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Ljava/lang/Integer;

.field public final b:I

.field public final c:Ljava/lang/Boolean;

.field public final d:Ljava/lang/Integer;

.field public final e:I

.field public final f:Ljava/lang/Integer;

.field public final g:Ljava/lang/Boolean;


# direct methods
.method public constructor <init>(Ljava/lang/Integer;ILjava/lang/Boolean;Ljava/lang/Integer;ILjava/lang/Integer;Ljava/lang/Boolean;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Ldk0;->a:Ljava/lang/Integer;

    .line 5
    .line 6
    iput p2, p0, Ldk0;->b:I

    .line 7
    .line 8
    iput-object p3, p0, Ldk0;->c:Ljava/lang/Boolean;

    .line 9
    .line 10
    iput-object p4, p0, Ldk0;->d:Ljava/lang/Integer;

    .line 11
    .line 12
    iput p5, p0, Ldk0;->e:I

    .line 13
    .line 14
    iput-object p6, p0, Ldk0;->f:Ljava/lang/Integer;

    .line 15
    .line 16
    iput-object p7, p0, Ldk0;->g:Ljava/lang/Boolean;

    .line 17
    .line 18
    return-void
.end method
