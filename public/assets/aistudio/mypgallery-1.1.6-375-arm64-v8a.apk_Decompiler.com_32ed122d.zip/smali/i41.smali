###### Class defpackage.i41 (i41)
.class public final Li41;
.super Landroid/view/ViewGroup$MarginLayoutParams;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:I

.field public b:I


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .registers 2

    .line 12
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 p1, 0x0

    .line 13
    iput p1, p0, Li41;->a:I

    return-void
.end method

.method public constructor <init>(Li41;)V
    .registers 3

    .line 1
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$MarginLayoutParams;-><init>(Landroid/view/ViewGroup$MarginLayoutParams;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Li41;->a:I

    .line 6
    .line 7
    iget p1, p1, Li41;->a:I

    .line 8
    .line 9
    iput p1, p0, Li41;->a:I

    .line 10
    .line 11
    return-void
.end method
