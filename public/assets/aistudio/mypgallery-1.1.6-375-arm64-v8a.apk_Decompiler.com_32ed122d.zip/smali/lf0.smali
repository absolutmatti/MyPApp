###### Class defpackage.lf0 (lf0)
.class public final Llf0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:[J

.field public b:[I

.field public c:I

.field public d:I

.field public e:I


# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lvr0;->a:[J

    .line 5
    .line 6
    iput-object v0, p0, Llf0;->a:[J

    .line 7
    .line 8
    sget-object v0, Lx30;->a:[I

    .line 9
    .line 10
    iput-object v0, p0, Llf0;->b:[I

    .line 11
    .line 12
    if-ltz p1, :cond_15

    .line 13
    .line 14
    invoke-static {p1}, Lvr0;->f(I)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    invoke-virtual {p0, p1}, Llf0;->b(I)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    const-string p0, "Capacity must be a positive value."

    .line 23
    .line 24
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const/4 p0, 0x0

    .line 28
    throw p0
.end method


# virtual methods
.method public final a(I)I
    .registers 11

    .line 1
    iget v0, p0, Llf0;->c:I

    .line 2
    .line 3
    and-int/2addr p1, v0

    .line 4
    const/4 v1, 0x0

    .line 5
    :goto_4
    iget-object v2, p0, Llf0;->a:[J

    .line 6
    .line 7
    shr-int/lit8 v3, p1, 0x3

    .line 8
    .line 9
    and-int/lit8 v4, p1, 0x7

    .line 10
    .line 11
    shl-int/lit8 v4, v4, 0x3

    .line 12
    .line 13
    aget-wide v5, v2, v3

    .line 14
    .line 15
    ushr-long/2addr v5, v4

    .line 16
    add-int/lit8 v3, v3, 0x1

    .line 17
    .line 18
    aget-wide v2, v2, v3

    .line 19
    .line 20
    rsub-int/lit8 v7, v4, 0x40

    .line 21
    .line 22
    shl-long/2addr v2, v7

    .line 23
    int-to-long v7, v4

    .line 24
    neg-long v7, v7

    .line 25
    const/16 v4, 0x3f

    .line 26
    .line 27
    shr-long/2addr v7, v4

    .line 28
    and-long/2addr v2, v7

    .line 29
    or-long/2addr v2, v5

    .line 30
    not-long v4, v2

    .line 31
    const/4 v6, 0x7

    .line 32
    shl-long/2addr v4, v6

    .line 33
    and-long/2addr v2, v4

    .line 34
    const-wide v4, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    and-long/2addr v2, v4

    .line 40
    const-wide/16 v4, 0x0

    .line 41
    .line 42
    cmp-long v4, v2, v4

    .line 43
    .line 44
    if-eqz v4, :cond_37

    .line 45
    .line 46
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    shr-int/lit8 p0, p0, 0x3

    .line 51
    .line 52
    add-int/2addr p1, p0

    .line 53
    and-int p0, p1, v0

    .line 54
    .line 55
    return p0

    .line 56
    :cond_37
    add-int/lit8 v1, v1, 0x8

    .line 57
    .line 58
    add-int/2addr p1, v1

    .line 59
    and-int/2addr p1, v0

    .line 60
    goto :goto_4
.end method

.method public final b(I)V
    .registers 11

    .line 1
    if-lez p1, :cond_c

    .line 2
    .line 3
    invoke-static {p1}, Lvr0;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    const/4 v0, 0x7

    .line 8
    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 p1, 0x0

    .line 14
    :goto_d
    iput p1, p0, Llf0;->c:I

    .line 15
    .line 16
    if-nez p1, :cond_14

    .line 17
    .line 18
    sget-object v0, Lvr0;->a:[J

    .line 19
    .line 20
    goto :goto_1f

    .line 21
    :cond_14
    add-int/lit8 v0, p1, 0xf

    .line 22
    .line 23
    and-int/lit8 v0, v0, -0x8

    .line 24
    .line 25
    shr-int/lit8 v0, v0, 0x3

    .line 26
    .line 27
    new-array v0, v0, [J

    .line 28
    .line 29
    invoke-static {v0}, Lj9;->Y([J)V

    .line 30
    .line 31
    .line 32
    :goto_1f
    iput-object v0, p0, Llf0;->a:[J

    .line 33
    .line 34
    shr-int/lit8 v1, p1, 0x3

    .line 35
    .line 36
    and-int/lit8 v2, p1, 0x7

    .line 37
    .line 38
    shl-int/lit8 v2, v2, 0x3

    .line 39
    .line 40
    aget-wide v3, v0, v1

    .line 41
    .line 42
    const-wide/16 v5, 0xff

    .line 43
    .line 44
    shl-long/2addr v5, v2

    .line 45
    not-long v7, v5

    .line 46
    and-long v2, v3, v7

    .line 47
    .line 48
    or-long/2addr v2, v5

    .line 49
    aput-wide v2, v0, v1

    .line 50
    .line 51
    iget v0, p0, Llf0;->c:I

    .line 52
    .line 53
    invoke-static {v0}, Lvr0;->c(I)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    iget v1, p0, Llf0;->d:I

    .line 58
    .line 59
    sub-int/2addr v0, v1

    .line 60
    iput v0, p0, Llf0;->e:I

    .line 61
    .line 62
    new-array p1, p1, [I

    .line 63
    .line 64
    iput-object p1, p0, Llf0;->b:[I

    .line 65
    .line 66
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 28

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    if-ne v1, v0, :cond_8

    .line 7
    .line 8
    return v2

    .line 9
    :cond_8
    instance-of v3, v1, Llf0;

    .line 10
    .line 11
    const/4 v4, 0x0

    .line 12
    if-nez v3, :cond_e

    .line 13
    .line 14
    return v4

    .line 15
    :cond_e
    check-cast v1, Llf0;

    .line 16
    .line 17
    iget v3, v1, Llf0;->d:I

    .line 18
    .line 19
    iget v5, v0, Llf0;->d:I

    .line 20
    .line 21
    if-eq v3, v5, :cond_17

    .line 22
    .line 23
    return v4

    .line 24
    :cond_17
    iget-object v3, v0, Llf0;->b:[I

    .line 25
    .line 26
    iget-object v0, v0, Llf0;->a:[J

    .line 27
    .line 28
    array-length v5, v0

    .line 29
    add-int/lit8 v5, v5, -0x2

    .line 30
    .line 31
    if-ltz v5, :cond_107

    .line 32
    .line 33
    move v6, v4

    .line 34
    :goto_21
    aget-wide v7, v0, v6

    .line 35
    .line 36
    not-long v9, v7

    .line 37
    const/4 v11, 0x7

    .line 38
    shl-long/2addr v9, v11

    .line 39
    and-long/2addr v9, v7

    .line 40
    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    and-long/2addr v9, v12

    .line 46
    cmp-long v9, v9, v12

    .line 47
    .line 48
    if-eqz v9, :cond_f9

    .line 49
    .line 50
    sub-int v9, v6, v5

    .line 51
    .line 52
    not-int v9, v9

    .line 53
    ushr-int/lit8 v9, v9, 0x1f

    .line 54
    .line 55
    const/16 v10, 0x8

    .line 56
    .line 57
    rsub-int/lit8 v9, v9, 0x8

    .line 58
    .line 59
    move v14, v4

    .line 60
    :goto_3b
    if-ge v14, v9, :cond_f1

    .line 61
    .line 62
    const-wide/16 v15, 0xff

    .line 63
    .line 64
    and-long/2addr v15, v7

    .line 65
    const-wide/16 v17, 0x80

    .line 66
    .line 67
    cmp-long v15, v15, v17

    .line 68
    .line 69
    if-gez v15, :cond_da

    .line 70
    .line 71
    shl-int/lit8 v15, v6, 0x3

    .line 72
    .line 73
    add-int/2addr v15, v14

    .line 74
    aget v15, v3, v15

    .line 75
    .line 76
    invoke-static {v15}, Ljava/lang/Integer;->hashCode(I)I

    .line 77
    .line 78
    .line 79
    move-result v16

    .line 80
    const v17, -0x3361d2af    # -8.293031E7f

    .line 81
    .line 82
    .line 83
    mul-int v16, v16, v17

    .line 84
    .line 85
    shl-int/lit8 v17, v16, 0x10

    .line 86
    .line 87
    xor-int v16, v16, v17

    .line 88
    .line 89
    move/from16 v17, v2

    .line 90
    .line 91
    and-int/lit8 v2, v16, 0x7f

    .line 92
    .line 93
    move/from16 v18, v4

    .line 94
    .line 95
    iget v4, v1, Llf0;->c:I

    .line 96
    .line 97
    ushr-int/lit8 v16, v16, 0x7

    .line 98
    .line 99
    and-int v16, v16, v4

    .line 100
    .line 101
    move/from16 v19, v18

    .line 102
    .line 103
    :goto_66
    iget-object v11, v1, Llf0;->a:[J

    .line 104
    .line 105
    shr-int/lit8 v20, v16, 0x3

    .line 106
    .line 107
    and-int/lit8 v21, v16, 0x7

    .line 108
    .line 109
    move-wide/from16 v22, v12

    .line 110
    .line 111
    shl-int/lit8 v12, v21, 0x3

    .line 112
    .line 113
    aget-wide v24, v11, v20

    .line 114
    .line 115
    ushr-long v24, v24, v12

    .line 116
    .line 117
    add-int/lit8 v20, v20, 0x1

    .line 118
    .line 119
    aget-wide v20, v11, v20

    .line 120
    .line 121
    rsub-int/lit8 v11, v12, 0x40

    .line 122
    .line 123
    shl-long v20, v20, v11

    .line 124
    .line 125
    int-to-long v11, v12

    .line 126
    neg-long v11, v11

    .line 127
    const/16 v13, 0x3f

    .line 128
    .line 129
    shr-long/2addr v11, v13

    .line 130
    and-long v11, v20, v11

    .line 131
    .line 132
    or-long v11, v24, v11

    .line 133
    .line 134
    move/from16 p1, v10

    .line 135
    .line 136
    move-wide/from16 v20, v11

    .line 137
    .line 138
    int-to-long v10, v2

    .line 139
    const-wide v12, 0x101010101010101L

    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    mul-long/2addr v10, v12

    .line 145
    xor-long v10, v20, v10

    .line 146
    .line 147
    sub-long v12, v10, v12

    .line 148
    .line 149
    not-long v10, v10

    .line 150
    and-long/2addr v10, v12

    .line 151
    and-long v10, v10, v22

    .line 152
    .line 153
    :goto_98
    const-wide/16 v12, 0x0

    .line 154
    .line 155
    cmp-long v24, v10, v12

    .line 156
    .line 157
    if-eqz v24, :cond_b4

    .line 158
    .line 159
    invoke-static {v10, v11}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 160
    .line 161
    .line 162
    move-result v12

    .line 163
    shr-int/lit8 v12, v12, 0x3

    .line 164
    .line 165
    add-int v12, v16, v12

    .line 166
    .line 167
    and-int/2addr v12, v4

    .line 168
    iget-object v13, v1, Llf0;->b:[I

    .line 169
    .line 170
    aget v13, v13, v12

    .line 171
    .line 172
    if-ne v13, v15, :cond_ae

    .line 173
    .line 174
    goto :goto_c5

    .line 175
    :cond_ae
    const-wide/16 v12, 0x1

    .line 176
    .line 177
    sub-long v12, v10, v12

    .line 178
    .line 179
    and-long/2addr v10, v12

    .line 180
    goto :goto_98

    .line 181
    :cond_b4
    move-wide/from16 v10, v20

    .line 182
    .line 183
    move-wide/from16 v20, v12

    .line 184
    .line 185
    not-long v12, v10

    .line 186
    const/16 v24, 0x6

    .line 187
    .line 188
    shl-long v12, v12, v24

    .line 189
    .line 190
    and-long/2addr v10, v12

    .line 191
    and-long v10, v10, v22

    .line 192
    .line 193
    cmp-long v10, v10, v20

    .line 194
    .line 195
    if-eqz v10, :cond_cf

    .line 196
    .line 197
    const/4 v12, -0x1

    .line 198
    :goto_c5
    if-ltz v12, :cond_ca

    .line 199
    .line 200
    move/from16 v2, v17

    .line 201
    .line 202
    goto :goto_cc

    .line 203
    :cond_ca
    move/from16 v2, v18

    .line 204
    .line 205
    :goto_cc
    if-nez v2, :cond_e2

    .line 206
    .line 207
    return v18

    .line 208
    :cond_cf
    add-int/lit8 v19, v19, 0x8

    .line 209
    .line 210
    add-int v16, v16, v19

    .line 211
    .line 212
    and-int v16, v16, v4

    .line 213
    .line 214
    move/from16 v10, p1

    .line 215
    .line 216
    move-wide/from16 v12, v22

    .line 217
    .line 218
    goto :goto_66

    .line 219
    :cond_da
    move/from16 v17, v2

    .line 220
    .line 221
    move/from16 v18, v4

    .line 222
    .line 223
    move/from16 p1, v10

    .line 224
    .line 225
    move-wide/from16 v22, v12

    .line 226
    .line 227
    :cond_e2
    shr-long v7, v7, p1

    .line 228
    .line 229
    add-int/lit8 v14, v14, 0x1

    .line 230
    .line 231
    move/from16 v10, p1

    .line 232
    .line 233
    move/from16 v2, v17

    .line 234
    .line 235
    move/from16 v4, v18

    .line 236
    .line 237
    move-wide/from16 v12, v22

    .line 238
    .line 239
    const/4 v11, 0x7

    .line 240
    goto/16 :goto_3b

    .line 241
    .line 242
    :cond_f1
    move/from16 v17, v2

    .line 243
    .line 244
    move/from16 v18, v4

    .line 245
    .line 246
    move v2, v10

    .line 247
    if-ne v9, v2, :cond_109

    .line 248
    .line 249
    goto :goto_fd

    .line 250
    :cond_f9
    move/from16 v17, v2

    .line 251
    .line 252
    move/from16 v18, v4

    .line 253
    .line 254
    :goto_fd
    if-eq v6, v5, :cond_109

    .line 255
    .line 256
    add-int/lit8 v6, v6, 0x1

    .line 257
    .line 258
    move/from16 v2, v17

    .line 259
    .line 260
    move/from16 v4, v18

    .line 261
    .line 262
    goto/16 :goto_21

    .line 263
    .line 264
    :cond_107
    move/from16 v17, v2

    .line 265
    .line 266
    :cond_109
    return v17
.end method

.method public final hashCode()I
    .registers 15

    .line 1
    iget-object v0, p0, Llf0;->b:[I

    .line 2
    .line 3
    iget-object p0, p0, Llf0;->a:[J

    .line 4
    .line 5
    array-length v1, p0

    .line 6
    add-int/lit8 v1, v1, -0x2

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    if-ltz v1, :cond_4a

    .line 10
    .line 11
    move v3, v2

    .line 12
    move v4, v3

    .line 13
    :goto_c
    aget-wide v5, p0, v3

    .line 14
    .line 15
    not-long v7, v5

    .line 16
    const/4 v9, 0x7

    .line 17
    shl-long/2addr v7, v9

    .line 18
    and-long/2addr v7, v5

    .line 19
    const-wide v9, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    and-long/2addr v7, v9

    .line 25
    cmp-long v7, v7, v9

    .line 26
    .line 27
    if-eqz v7, :cond_44

    .line 28
    .line 29
    sub-int v7, v3, v1

    .line 30
    .line 31
    not-int v7, v7

    .line 32
    ushr-int/lit8 v7, v7, 0x1f

    .line 33
    .line 34
    const/16 v8, 0x8

    .line 35
    .line 36
    rsub-int/lit8 v7, v7, 0x8

    .line 37
    .line 38
    move v9, v2

    .line 39
    :goto_26
    if-ge v9, v7, :cond_40

    .line 40
    .line 41
    const-wide/16 v10, 0xff

    .line 42
    .line 43
    and-long/2addr v10, v5

    .line 44
    const-wide/16 v12, 0x80

    .line 45
    .line 46
    cmp-long v10, v10, v12

    .line 47
    .line 48
    if-gez v10, :cond_3c

    .line 49
    .line 50
    shl-int/lit8 v10, v3, 0x3

    .line 51
    .line 52
    add-int/2addr v10, v9

    .line 53
    aget v10, v0, v10

    .line 54
    .line 55
    invoke-static {v10}, Ljava/lang/Integer;->hashCode(I)I

    .line 56
    .line 57
    .line 58
    move-result v10

    .line 59
    add-int/2addr v10, v4

    .line 60
    move v4, v10

    .line 61
    :cond_3c
    shr-long/2addr v5, v8

    .line 62
    add-int/lit8 v9, v9, 0x1

    .line 63
    .line 64
    goto :goto_26

    .line 65
    :cond_40
    if-ne v7, v8, :cond_43

    .line 66
    .line 67
    goto :goto_44

    .line 68
    :cond_43
    return v4

    .line 69
    :cond_44
    :goto_44
    if-eq v3, v1, :cond_49

    .line 70
    .line 71
    add-int/lit8 v3, v3, 0x1

    .line 72
    .line 73
    goto :goto_c

    .line 74
    :cond_49
    return v4

    .line 75
    :cond_4a
    return v2
.end method

.method public final toString()Ljava/lang/String;
    .registers 16

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "["

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    iget-object v1, p0, Llf0;->b:[I

    .line 12
    .line 13
    iget-object p0, p0, Llf0;->a:[J

    .line 14
    .line 15
    array-length v2, p0

    .line 16
    add-int/lit8 v2, v2, -0x2

    .line 17
    .line 18
    if-ltz v2, :cond_60

    .line 19
    .line 20
    const/4 v3, 0x0

    .line 21
    move v4, v3

    .line 22
    move v5, v4

    .line 23
    :goto_16
    aget-wide v6, p0, v4

    .line 24
    .line 25
    not-long v8, v6

    .line 26
    const/4 v10, 0x7

    .line 27
    shl-long/2addr v8, v10

    .line 28
    and-long/2addr v8, v6

    .line 29
    const-wide v10, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    and-long/2addr v8, v10

    .line 35
    cmp-long v8, v8, v10

    .line 36
    .line 37
    if-eqz v8, :cond_5b

    .line 38
    .line 39
    sub-int v8, v4, v2

    .line 40
    .line 41
    not-int v8, v8

    .line 42
    ushr-int/lit8 v8, v8, 0x1f

    .line 43
    .line 44
    const/16 v9, 0x8

    .line 45
    .line 46
    rsub-int/lit8 v8, v8, 0x8

    .line 47
    .line 48
    move v10, v3

    .line 49
    :goto_30
    if-ge v10, v8, :cond_59

    .line 50
    .line 51
    const-wide/16 v11, 0xff

    .line 52
    .line 53
    and-long/2addr v11, v6

    .line 54
    const-wide/16 v13, 0x80

    .line 55
    .line 56
    cmp-long v11, v11, v13

    .line 57
    .line 58
    if-gez v11, :cond_55

    .line 59
    .line 60
    shl-int/lit8 v11, v4, 0x3

    .line 61
    .line 62
    add-int/2addr v11, v10

    .line 63
    aget v11, v1, v11

    .line 64
    .line 65
    const/4 v12, -0x1

    .line 66
    if-ne v5, v12, :cond_49

    .line 67
    .line 68
    const-string p0, "..."

    .line 69
    .line 70
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 71
    .line 72
    .line 73
    goto :goto_65

    .line 74
    :cond_49
    if-eqz v5, :cond_50

    .line 75
    .line 76
    const-string v12, ", "

    .line 77
    .line 78
    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    :cond_50
    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 82
    .line 83
    .line 84
    add-int/lit8 v5, v5, 0x1

    .line 85
    .line 86
    :cond_55
    shr-long/2addr v6, v9

    .line 87
    add-int/lit8 v10, v10, 0x1

    .line 88
    .line 89
    goto :goto_30

    .line 90
    :cond_59
    if-ne v8, v9, :cond_60

    .line 91
    .line 92
    :cond_5b
    if-eq v4, v2, :cond_60

    .line 93
    .line 94
    add-int/lit8 v4, v4, 0x1

    .line 95
    .line 96
    goto :goto_16

    .line 97
    :cond_60
    const-string p0, "]"

    .line 98
    .line 99
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 100
    .line 101
    .line 102
    :goto_65
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 103
    .line 104
    .line 105
    move-result-object p0

    .line 106
    return-object p0
.end method
