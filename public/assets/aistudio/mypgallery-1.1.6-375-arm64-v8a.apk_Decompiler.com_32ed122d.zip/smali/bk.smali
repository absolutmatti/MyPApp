###### Class defpackage.bk (bk)
.class public final Lbk;
.super Lc01;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final b:Ljava/lang/Object;

.field public final c:I


# direct methods
.method public constructor <init>(IILjava/lang/Object;)V
    .registers 4

    .line 1
    invoke-direct {p0, p2}, Lc01;-><init>(I)V

    .line 2
    .line 3
    .line 4
    iput-object p3, p0, Lbk;->b:Ljava/lang/Object;

    .line 5
    .line 6
    iput p1, p0, Lbk;->c:I

    .line 7
    .line 8
    return-void
.end method
