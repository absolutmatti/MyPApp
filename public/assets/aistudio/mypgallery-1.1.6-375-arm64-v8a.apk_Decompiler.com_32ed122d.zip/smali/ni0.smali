###### Class defpackage.ni0 (ni0)
.class public final Lni0;
.super Lxi0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final c:Lni0;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lni0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x3

    .line 6
    invoke-direct {v0, v3, v1, v2}, Lxi0;-><init>(III)V

    .line 7
    .line 8
    .line 9
    sput-object v0, Lni0;->c:Lni0;

    .line 10
    .line 11
    return-void
.end method


# virtual methods
.method public final a(Lcd;Lt8;Loy0;Lzf;)V
    .registers 6

    .line 1
    const/4 p0, 0x0

    .line 2
    invoke-virtual {p1, p0}, Lcd;->c(I)I

    .line 3
    .line 4
    .line 5
    move-result p0

    .line 6
    const/4 p3, 0x1

    .line 7
    invoke-virtual {p1, p3}, Lcd;->c(I)I

    .line 8
    .line 9
    .line 10
    move-result p4

    .line 11
    const/4 v0, 0x2

    .line 12
    invoke-virtual {p1, v0}, Lcd;->c(I)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    invoke-virtual {p2}, Lt8;->b()Ljava/util/ArrayList;

    .line 17
    .line 18
    .line 19
    move-result-object p2

    .line 20
    if-le p0, p4, :cond_17

    .line 21
    .line 22
    move v0, p4

    .line 23
    goto :goto_19

    .line 24
    :cond_17
    sub-int v0, p4, p1

    .line 25
    .line 26
    :goto_19
    if-ne p1, p3, :cond_38

    .line 27
    .line 28
    add-int/lit8 p1, p4, 0x1

    .line 29
    .line 30
    if-eq p0, p1, :cond_2c

    .line 31
    .line 32
    add-int/lit8 p1, p4, -0x1

    .line 33
    .line 34
    if-ne p0, p1, :cond_24

    .line 35
    .line 36
    goto :goto_2c

    .line 37
    :cond_24
    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object p0

    .line 41
    invoke-interface {p2, v0, p0}, Ljava/util/List;->add(ILjava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    goto :goto_47

    .line 45
    :cond_2c
    :goto_2c
    invoke-virtual {p2, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 46
    .line 47
    .line 48
    move-result-object p1

    .line 49
    invoke-interface {p2, p4, p1}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p1

    .line 53
    invoke-interface {p2, p0, p1}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    goto :goto_47

    .line 57
    :cond_38
    add-int/2addr p1, p0

    .line 58
    invoke-virtual {p2, p0, p1}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    invoke-static {p0}, Lfe;->f0(Ljava/util/List;)Ljava/util/ArrayList;

    .line 63
    .line 64
    .line 65
    move-result-object p1

    .line 66
    invoke-interface {p0}, Ljava/util/List;->clear()V

    .line 67
    .line 68
    .line 69
    invoke-interface {p2, v0, p1}, Ljava/util/List;->addAll(ILjava/util/Collection;)Z

    .line 70
    .line 71
    .line 72
    :goto_47
    return-void
.end method

.method public final b(I)Ljava/lang/String;
    .registers 3

    .line 1
    if-nez p1, :cond_5

    .line 2
    .line 3
    const-string p0, "from"

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    const/4 v0, 0x1

    .line 7
    if-ne p1, v0, :cond_b

    .line 8
    .line 9
    const-string p0, "to"

    .line 10
    .line 11
    return-object p0

    .line 12
    :cond_b
    const/4 v0, 0x2

    .line 13
    if-ne p1, v0, :cond_11

    .line 14
    .line 15
    const-string p0, "count"

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_11
    invoke-super {p0, p1}, Lxi0;->b(I)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method
