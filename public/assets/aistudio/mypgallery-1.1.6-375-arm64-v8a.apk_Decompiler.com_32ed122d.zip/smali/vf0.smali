###### Class defpackage.vf0 (vf0)
.class public final Lvf0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:[J

.field public b:[Ljava/lang/Object;

.field public c:I

.field public d:I

.field public e:I


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    const/4 v0, 0x6

    .line 29
    invoke-direct {p0, v0}, Lvf0;-><init>(I)V

    return-void
.end method

.method public constructor <init>(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lvr0;->a:[J

    .line 5
    .line 6
    iput-object v0, p0, Lvf0;->a:[J

    .line 7
    .line 8
    sget-object v0, Lsa;->c:[Ljava/lang/Object;

    .line 9
    .line 10
    iput-object v0, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 11
    .line 12
    if-ltz p1, :cond_15

    .line 13
    .line 14
    invoke-static {p1}, Lvr0;->f(I)I

    .line 15
    .line 16
    .line 17
    move-result p1

    .line 18
    invoke-virtual {p0, p1}, Lvf0;->f(I)V

    .line 19
    .line 20
    .line 21
    return-void

    .line 22
    :cond_15
    const-string p0, "Capacity must be a positive value."

    .line 23
    .line 24
    invoke-static {p0}, Lm0;->v(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    const/4 p0, 0x0

    .line 28
    throw p0
.end method


# virtual methods
.method public final a(Ljava/lang/Object;)Z
    .registers 5

    .line 1
    iget v0, p0, Lvf0;->d:I

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lvf0;->d(Ljava/lang/Object;)I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    iget-object v2, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 8
    .line 9
    aput-object p1, v2, v1

    .line 10
    .line 11
    iget p0, p0, Lvf0;->d:I

    .line 12
    .line 13
    if-eq p0, v0, :cond_10

    .line 14
    .line 15
    const/4 p0, 0x1

    .line 16
    return p0

    .line 17
    :cond_10
    const/4 p0, 0x0

    .line 18
    return p0
.end method

.method public final b()V
    .registers 11

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lvf0;->d:I

    .line 3
    .line 4
    iget-object v1, p0, Lvf0;->a:[J

    .line 5
    .line 6
    sget-object v2, Lvr0;->a:[J

    .line 7
    .line 8
    if-eq v1, v2, :cond_20

    .line 9
    .line 10
    invoke-static {v1}, Lj9;->Y([J)V

    .line 11
    .line 12
    .line 13
    iget-object v1, p0, Lvf0;->a:[J

    .line 14
    .line 15
    iget v2, p0, Lvf0;->c:I

    .line 16
    .line 17
    shr-int/lit8 v3, v2, 0x3

    .line 18
    .line 19
    and-int/lit8 v2, v2, 0x7

    .line 20
    .line 21
    shl-int/lit8 v2, v2, 0x3

    .line 22
    .line 23
    aget-wide v4, v1, v3

    .line 24
    .line 25
    const-wide/16 v6, 0xff

    .line 26
    .line 27
    shl-long/2addr v6, v2

    .line 28
    not-long v8, v6

    .line 29
    and-long/2addr v4, v8

    .line 30
    or-long/2addr v4, v6

    .line 31
    aput-wide v4, v1, v3

    .line 32
    .line 33
    :cond_20
    iget-object v1, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 34
    .line 35
    const/4 v2, 0x0

    .line 36
    iget v3, p0, Lvf0;->c:I

    .line 37
    .line 38
    invoke-static {v1, v2, v0, v3}, Lj9;->X([Ljava/lang/Object;Lyw;II)V

    .line 39
    .line 40
    .line 41
    iget v0, p0, Lvf0;->c:I

    .line 42
    .line 43
    invoke-static {v0}, Lvr0;->c(I)I

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    iget v1, p0, Lvf0;->d:I

    .line 48
    .line 49
    sub-int/2addr v0, v1

    .line 50
    iput v0, p0, Lvf0;->e:I

    .line 51
    .line 52
    return-void
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_c

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    move v3, v2

    .line 14
    :goto_d
    const v4, -0x3361d2af    # -8.293031E7f

    .line 15
    .line 16
    .line 17
    mul-int/2addr v3, v4

    .line 18
    shl-int/lit8 v4, v3, 0x10

    .line 19
    .line 20
    xor-int/2addr v3, v4

    .line 21
    and-int/lit8 v4, v3, 0x7f

    .line 22
    .line 23
    iget v5, v0, Lvf0;->c:I

    .line 24
    .line 25
    ushr-int/lit8 v3, v3, 0x7

    .line 26
    .line 27
    and-int/2addr v3, v5

    .line 28
    move v6, v2

    .line 29
    :goto_1c
    iget-object v7, v0, Lvf0;->a:[J

    .line 30
    .line 31
    shr-int/lit8 v8, v3, 0x3

    .line 32
    .line 33
    and-int/lit8 v9, v3, 0x7

    .line 34
    .line 35
    shl-int/lit8 v9, v9, 0x3

    .line 36
    .line 37
    aget-wide v10, v7, v8

    .line 38
    .line 39
    ushr-long/2addr v10, v9

    .line 40
    const/4 v12, 0x1

    .line 41
    add-int/2addr v8, v12

    .line 42
    aget-wide v7, v7, v8

    .line 43
    .line 44
    rsub-int/lit8 v13, v9, 0x40

    .line 45
    .line 46
    shl-long/2addr v7, v13

    .line 47
    int-to-long v13, v9

    .line 48
    neg-long v13, v13

    .line 49
    const/16 v9, 0x3f

    .line 50
    .line 51
    shr-long/2addr v13, v9

    .line 52
    and-long/2addr v7, v13

    .line 53
    or-long/2addr v7, v10

    .line 54
    int-to-long v9, v4

    .line 55
    const-wide v13, 0x101010101010101L

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    mul-long/2addr v9, v13

    .line 61
    xor-long/2addr v9, v7

    .line 62
    sub-long v13, v9, v13

    .line 63
    .line 64
    not-long v9, v9

    .line 65
    and-long/2addr v9, v13

    .line 66
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    and-long/2addr v9, v13

    .line 72
    :goto_47
    const-wide/16 v15, 0x0

    .line 73
    .line 74
    cmp-long v11, v9, v15

    .line 75
    .line 76
    if-eqz v11, :cond_66

    .line 77
    .line 78
    invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 79
    .line 80
    .line 81
    move-result v11

    .line 82
    shr-int/lit8 v11, v11, 0x3

    .line 83
    .line 84
    add-int/2addr v11, v3

    .line 85
    and-int/2addr v11, v5

    .line 86
    iget-object v15, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 87
    .line 88
    aget-object v15, v15, v11

    .line 89
    .line 90
    invoke-static {v15, v1}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v15

    .line 94
    if-eqz v15, :cond_60

    .line 95
    .line 96
    goto :goto_70

    .line 97
    :cond_60
    const-wide/16 v15, 0x1

    .line 98
    .line 99
    sub-long v15, v9, v15

    .line 100
    .line 101
    and-long/2addr v9, v15

    .line 102
    goto :goto_47

    .line 103
    :cond_66
    not-long v9, v7

    .line 104
    const/4 v11, 0x6

    .line 105
    shl-long/2addr v9, v11

    .line 106
    and-long/2addr v7, v9

    .line 107
    and-long/2addr v7, v13

    .line 108
    cmp-long v7, v7, v15

    .line 109
    .line 110
    if-eqz v7, :cond_74

    .line 111
    .line 112
    const/4 v11, -0x1

    .line 113
    :goto_70
    if-ltz v11, :cond_73

    .line 114
    .line 115
    return v12

    .line 116
    :cond_73
    return v2

    .line 117
    :cond_74
    add-int/lit8 v6, v6, 0x8

    .line 118
    .line 119
    add-int/2addr v3, v6

    .line 120
    and-int/2addr v3, v5

    .line 121
    goto :goto_1c
.end method

.method public final d(Ljava/lang/Object;)I
    .registers 39

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    if-eqz v1, :cond_b

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 8
    .line 9
    .line 10
    move-result v3

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 v3, 0x0

    .line 13
    :goto_c
    const v4, -0x3361d2af    # -8.293031E7f

    .line 14
    .line 15
    .line 16
    mul-int/2addr v3, v4

    .line 17
    shl-int/lit8 v5, v3, 0x10

    .line 18
    .line 19
    xor-int/2addr v3, v5

    .line 20
    ushr-int/lit8 v5, v3, 0x7

    .line 21
    .line 22
    and-int/lit8 v3, v3, 0x7f

    .line 23
    .line 24
    iget v6, v0, Lvf0;->c:I

    .line 25
    .line 26
    and-int v7, v5, v6

    .line 27
    .line 28
    const/4 v8, 0x0

    .line 29
    :goto_1c
    iget-object v9, v0, Lvf0;->a:[J

    .line 30
    .line 31
    shr-int/lit8 v10, v7, 0x3

    .line 32
    .line 33
    and-int/lit8 v11, v7, 0x7

    .line 34
    .line 35
    shl-int/lit8 v11, v11, 0x3

    .line 36
    .line 37
    aget-wide v12, v9, v10

    .line 38
    .line 39
    ushr-long/2addr v12, v11

    .line 40
    const/4 v14, 0x1

    .line 41
    add-int/2addr v10, v14

    .line 42
    aget-wide v9, v9, v10

    .line 43
    .line 44
    rsub-int/lit8 v15, v11, 0x40

    .line 45
    .line 46
    shl-long/2addr v9, v15

    .line 47
    move/from16 v16, v14

    .line 48
    .line 49
    int-to-long v14, v11

    .line 50
    neg-long v14, v14

    .line 51
    const/16 v11, 0x3f

    .line 52
    .line 53
    shr-long/2addr v14, v11

    .line 54
    and-long/2addr v9, v14

    .line 55
    or-long/2addr v9, v12

    .line 56
    int-to-long v11, v3

    .line 57
    const-wide v13, 0x101010101010101L

    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    mul-long v17, v11, v13

    .line 63
    .line 64
    move/from16 v19, v3

    .line 65
    .line 66
    const/4 v15, 0x0

    .line 67
    xor-long v2, v9, v17

    .line 68
    .line 69
    sub-long v13, v2, v13

    .line 70
    .line 71
    not-long v2, v2

    .line 72
    and-long/2addr v2, v13

    .line 73
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    and-long/2addr v2, v13

    .line 79
    :goto_4e
    const-wide/16 v17, 0x0

    .line 80
    .line 81
    cmp-long v20, v2, v17

    .line 82
    .line 83
    if-eqz v20, :cond_74

    .line 84
    .line 85
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 86
    .line 87
    .line 88
    move-result v17

    .line 89
    shr-int/lit8 v17, v17, 0x3

    .line 90
    .line 91
    add-int v17, v7, v17

    .line 92
    .line 93
    and-int v17, v17, v6

    .line 94
    .line 95
    move/from16 v20, v4

    .line 96
    .line 97
    iget-object v4, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 98
    .line 99
    aget-object v4, v4, v17

    .line 100
    .line 101
    invoke-static {v4, v1}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 102
    .line 103
    .line 104
    move-result v4

    .line 105
    if-eqz v4, :cond_6b

    .line 106
    .line 107
    return v17

    .line 108
    :cond_6b
    const-wide/16 v17, 0x1

    .line 109
    .line 110
    sub-long v17, v2, v17

    .line 111
    .line 112
    and-long v2, v2, v17

    .line 113
    .line 114
    move/from16 v4, v20

    .line 115
    .line 116
    goto :goto_4e

    .line 117
    :cond_74
    move/from16 v20, v4

    .line 118
    .line 119
    not-long v2, v9

    .line 120
    const/4 v4, 0x6

    .line 121
    shl-long/2addr v2, v4

    .line 122
    and-long/2addr v2, v9

    .line 123
    and-long/2addr v2, v13

    .line 124
    cmp-long v2, v2, v17

    .line 125
    .line 126
    const/16 v3, 0x8

    .line 127
    .line 128
    if-eqz v2, :cond_271

    .line 129
    .line 130
    invoke-virtual {v0, v5}, Lvf0;->e(I)I

    .line 131
    .line 132
    .line 133
    move-result v1

    .line 134
    iget v2, v0, Lvf0;->e:I

    .line 135
    .line 136
    const-wide/16 v6, 0x80

    .line 137
    .line 138
    const-wide/16 v8, 0xff

    .line 139
    .line 140
    if-nez v2, :cond_9f

    .line 141
    .line 142
    iget-object v2, v0, Lvf0;->a:[J

    .line 143
    .line 144
    shr-int/lit8 v4, v1, 0x3

    .line 145
    .line 146
    aget-wide v13, v2, v4

    .line 147
    .line 148
    and-int/lit8 v2, v1, 0x7

    .line 149
    .line 150
    shl-int/lit8 v2, v2, 0x3

    .line 151
    .line 152
    shr-long/2addr v13, v2

    .line 153
    and-long/2addr v13, v8

    .line 154
    const-wide/16 v17, 0xfe

    .line 155
    .line 156
    cmp-long v2, v13, v17

    .line 157
    .line 158
    if-nez v2, :cond_a7

    .line 159
    .line 160
    :cond_9f
    move-wide/from16 v26, v6

    .line 161
    .line 162
    move-wide/from16 v32, v8

    .line 163
    .line 164
    move-wide/from16 v34, v11

    .line 165
    .line 166
    goto/16 :goto_23c

    .line 167
    .line 168
    :cond_a7
    iget v1, v0, Lvf0;->c:I

    .line 169
    .line 170
    if-le v1, v3, :cond_1c6

    .line 171
    .line 172
    iget v2, v0, Lvf0;->d:I

    .line 173
    .line 174
    int-to-long v13, v2

    .line 175
    const-wide/16 v21, 0x20

    .line 176
    .line 177
    mul-long v13, v13, v21

    .line 178
    .line 179
    int-to-long v1, v1

    .line 180
    const-wide/16 v21, 0x19

    .line 181
    .line 182
    mul-long v1, v1, v21

    .line 183
    .line 184
    invoke-static {v13, v14, v1, v2}, Ljava/lang/Long;->compareUnsigned(JJ)I

    .line 185
    .line 186
    .line 187
    move-result v1

    .line 188
    if-gtz v1, :cond_1c6

    .line 189
    .line 190
    iget-object v1, v0, Lvf0;->a:[J

    .line 191
    .line 192
    iget v2, v0, Lvf0;->c:I

    .line 193
    .line 194
    iget-object v4, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 195
    .line 196
    invoke-static {v1, v2}, Lvr0;->a([JI)V

    .line 197
    .line 198
    .line 199
    move v13, v15

    .line 200
    const/4 v14, -0x1

    .line 201
    :goto_c8
    if-eq v13, v2, :cond_1b3

    .line 202
    .line 203
    shr-int/lit8 v19, v13, 0x3

    .line 204
    .line 205
    aget-wide v21, v1, v19

    .line 206
    .line 207
    and-int/lit8 v23, v13, 0x7

    .line 208
    .line 209
    shl-int/lit8 v23, v23, 0x3

    .line 210
    .line 211
    shr-long v21, v21, v23

    .line 212
    .line 213
    and-long v21, v21, v8

    .line 214
    .line 215
    cmp-long v24, v21, v6

    .line 216
    .line 217
    if-nez v24, :cond_e2

    .line 218
    .line 219
    add-int/lit8 v14, v13, 0x1

    .line 220
    .line 221
    move/from16 v36, v14

    .line 222
    .line 223
    move v14, v13

    .line 224
    move/from16 v13, v36

    .line 225
    .line 226
    goto :goto_c8

    .line 227
    :cond_e2
    cmp-long v21, v21, v17

    .line 228
    .line 229
    if-eqz v21, :cond_e9

    .line 230
    .line 231
    add-int/lit8 v13, v13, 0x1

    .line 232
    .line 233
    goto :goto_c8

    .line 234
    :cond_e9
    aget-object v21, v4, v13

    .line 235
    .line 236
    if-eqz v21, :cond_f2

    .line 237
    .line 238
    invoke-virtual/range {v21 .. v21}, Ljava/lang/Object;->hashCode()I

    .line 239
    .line 240
    .line 241
    move-result v21

    .line 242
    goto :goto_f4

    .line 243
    :cond_f2
    move/from16 v21, v15

    .line 244
    .line 245
    :goto_f4
    mul-int v21, v21, v20

    .line 246
    .line 247
    shl-int/lit8 v22, v21, 0x10

    .line 248
    .line 249
    xor-int v21, v21, v22

    .line 250
    .line 251
    move/from16 v22, v3

    .line 252
    .line 253
    ushr-int/lit8 v3, v21, 0x7

    .line 254
    .line 255
    invoke-virtual {v0, v3}, Lvf0;->e(I)I

    .line 256
    .line 257
    .line 258
    move-result v24

    .line 259
    and-int/2addr v3, v2

    .line 260
    sub-int v25, v24, v3

    .line 261
    .line 262
    and-int v25, v25, v2

    .line 263
    .line 264
    move-wide/from16 v26, v6

    .line 265
    .line 266
    div-int/lit8 v6, v25, 0x8

    .line 267
    .line 268
    sub-int v3, v13, v3

    .line 269
    .line 270
    and-int/2addr v3, v2

    .line 271
    div-int/lit8 v3, v3, 0x8

    .line 272
    .line 273
    const-wide v28, 0xffffffffffffffL

    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    const-wide/high16 v30, -0x8000000000000000L

    .line 279
    .line 280
    if-ne v6, v3, :cond_13e

    .line 281
    .line 282
    and-int/lit8 v3, v21, 0x7f

    .line 283
    .line 284
    int-to-long v6, v3

    .line 285
    aget-wide v24, v1, v19

    .line 286
    .line 287
    move-wide/from16 v32, v8

    .line 288
    .line 289
    shl-long v8, v32, v23

    .line 290
    .line 291
    not-long v8, v8

    .line 292
    and-long v8, v24, v8

    .line 293
    .line 294
    shl-long v6, v6, v23

    .line 295
    .line 296
    or-long/2addr v6, v8

    .line 297
    aput-wide v6, v1, v19

    .line 298
    .line 299
    array-length v3, v1

    .line 300
    add-int/lit8 v3, v3, -0x1

    .line 301
    .line 302
    aget-wide v6, v1, v15

    .line 303
    .line 304
    and-long v6, v6, v28

    .line 305
    .line 306
    or-long v6, v6, v30

    .line 307
    .line 308
    aput-wide v6, v1, v3

    .line 309
    .line 310
    add-int/lit8 v13, v13, 0x1

    .line 311
    .line 312
    move/from16 v3, v22

    .line 313
    .line 314
    move-wide/from16 v6, v26

    .line 315
    .line 316
    move-wide/from16 v8, v32

    .line 317
    .line 318
    goto :goto_c8

    .line 319
    :cond_13e
    move-wide/from16 v32, v8

    .line 320
    .line 321
    shr-int/lit8 v3, v24, 0x3

    .line 322
    .line 323
    aget-wide v6, v1, v3

    .line 324
    .line 325
    and-int/lit8 v8, v24, 0x7

    .line 326
    .line 327
    shl-int/lit8 v8, v8, 0x3

    .line 328
    .line 329
    shr-long v34, v6, v8

    .line 330
    .line 331
    and-long v34, v34, v32

    .line 332
    .line 333
    cmp-long v9, v34, v26

    .line 334
    .line 335
    if-nez v9, :cond_175

    .line 336
    .line 337
    and-int/lit8 v9, v21, 0x7f

    .line 338
    .line 339
    move-wide/from16 v34, v11

    .line 340
    .line 341
    int-to-long v10, v9

    .line 342
    move v12, v3

    .line 343
    move-object v9, v4

    .line 344
    shl-long v3, v32, v8

    .line 345
    .line 346
    not-long v3, v3

    .line 347
    and-long/2addr v3, v6

    .line 348
    shl-long v6, v10, v8

    .line 349
    .line 350
    or-long/2addr v3, v6

    .line 351
    aput-wide v3, v1, v12

    .line 352
    .line 353
    aget-wide v3, v1, v19

    .line 354
    .line 355
    shl-long v6, v32, v23

    .line 356
    .line 357
    not-long v6, v6

    .line 358
    and-long/2addr v3, v6

    .line 359
    shl-long v6, v26, v23

    .line 360
    .line 361
    or-long/2addr v3, v6

    .line 362
    aput-wide v3, v1, v19

    .line 363
    .line 364
    aget-object v3, v9, v13

    .line 365
    .line 366
    aput-object v3, v9, v24

    .line 367
    .line 368
    const/4 v3, 0x0

    .line 369
    aput-object v3, v9, v13

    .line 370
    .line 371
    move v14, v13

    .line 372
    const/4 v3, -0x1

    .line 373
    goto :goto_19b

    .line 374
    :cond_175
    move-object v9, v4

    .line 375
    move-wide/from16 v34, v11

    .line 376
    .line 377
    move v12, v3

    .line 378
    and-int/lit8 v3, v21, 0x7f

    .line 379
    .line 380
    int-to-long v3, v3

    .line 381
    shl-long v10, v32, v8

    .line 382
    .line 383
    not-long v10, v10

    .line 384
    and-long/2addr v6, v10

    .line 385
    shl-long/2addr v3, v8

    .line 386
    or-long/2addr v3, v6

    .line 387
    aput-wide v3, v1, v12

    .line 388
    .line 389
    const/4 v3, -0x1

    .line 390
    if-ne v14, v3, :cond_18d

    .line 391
    .line 392
    add-int/lit8 v4, v13, 0x1

    .line 393
    .line 394
    invoke-static {v1, v4, v2}, Lvr0;->b([JII)I

    .line 395
    .line 396
    .line 397
    move-result v14

    .line 398
    :cond_18d
    aget-object v4, v9, v24

    .line 399
    .line 400
    aput-object v4, v9, v14

    .line 401
    .line 402
    aget-object v4, v9, v13

    .line 403
    .line 404
    aput-object v4, v9, v24

    .line 405
    .line 406
    aget-object v4, v9, v14

    .line 407
    .line 408
    aput-object v4, v9, v13

    .line 409
    .line 410
    add-int/lit8 v13, v13, -0x1

    .line 411
    .line 412
    :goto_19b
    array-length v4, v1

    .line 413
    add-int/lit8 v4, v4, -0x1

    .line 414
    .line 415
    aget-wide v6, v1, v15

    .line 416
    .line 417
    and-long v6, v6, v28

    .line 418
    .line 419
    or-long v6, v6, v30

    .line 420
    .line 421
    aput-wide v6, v1, v4

    .line 422
    .line 423
    add-int/lit8 v13, v13, 0x1

    .line 424
    .line 425
    move-object v4, v9

    .line 426
    move/from16 v3, v22

    .line 427
    .line 428
    move-wide/from16 v6, v26

    .line 429
    .line 430
    move-wide/from16 v8, v32

    .line 431
    .line 432
    move-wide/from16 v11, v34

    .line 433
    .line 434
    goto/16 :goto_c8

    .line 435
    .line 436
    :cond_1b3
    move-wide/from16 v26, v6

    .line 437
    .line 438
    move-wide/from16 v32, v8

    .line 439
    .line 440
    move-wide/from16 v34, v11

    .line 441
    .line 442
    iget v1, v0, Lvf0;->c:I

    .line 443
    .line 444
    invoke-static {v1}, Lvr0;->c(I)I

    .line 445
    .line 446
    .line 447
    move-result v1

    .line 448
    iget v2, v0, Lvf0;->d:I

    .line 449
    .line 450
    sub-int/2addr v1, v2

    .line 451
    iput v1, v0, Lvf0;->e:I

    .line 452
    .line 453
    goto/16 :goto_238

    .line 454
    .line 455
    :cond_1c6
    move-wide/from16 v26, v6

    .line 456
    .line 457
    move-wide/from16 v32, v8

    .line 458
    .line 459
    move-wide/from16 v34, v11

    .line 460
    .line 461
    iget v1, v0, Lvf0;->c:I

    .line 462
    .line 463
    invoke-static {v1}, Lvr0;->d(I)I

    .line 464
    .line 465
    .line 466
    move-result v1

    .line 467
    iget-object v2, v0, Lvf0;->a:[J

    .line 468
    .line 469
    iget-object v3, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 470
    .line 471
    iget v4, v0, Lvf0;->c:I

    .line 472
    .line 473
    invoke-virtual {v0, v1}, Lvf0;->f(I)V

    .line 474
    .line 475
    .line 476
    iget-object v1, v0, Lvf0;->a:[J

    .line 477
    .line 478
    iget-object v6, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 479
    .line 480
    iget v7, v0, Lvf0;->c:I

    .line 481
    .line 482
    move v8, v15

    .line 483
    :goto_1e2
    if-ge v8, v4, :cond_238

    .line 484
    .line 485
    shr-int/lit8 v9, v8, 0x3

    .line 486
    .line 487
    aget-wide v9, v2, v9

    .line 488
    .line 489
    and-int/lit8 v11, v8, 0x7

    .line 490
    .line 491
    shl-int/lit8 v11, v11, 0x3

    .line 492
    .line 493
    shr-long/2addr v9, v11

    .line 494
    and-long v9, v9, v32

    .line 495
    .line 496
    cmp-long v9, v9, v26

    .line 497
    .line 498
    if-gez v9, :cond_22d

    .line 499
    .line 500
    aget-object v9, v3, v8

    .line 501
    .line 502
    if-eqz v9, :cond_1fc

    .line 503
    .line 504
    invoke-virtual {v9}, Ljava/lang/Object;->hashCode()I

    .line 505
    .line 506
    .line 507
    move-result v10

    .line 508
    goto :goto_1fd

    .line 509
    :cond_1fc
    move v10, v15

    .line 510
    :goto_1fd
    mul-int v10, v10, v20

    .line 511
    .line 512
    shl-int/lit8 v11, v10, 0x10

    .line 513
    .line 514
    xor-int/2addr v10, v11

    .line 515
    ushr-int/lit8 v11, v10, 0x7

    .line 516
    .line 517
    invoke-virtual {v0, v11}, Lvf0;->e(I)I

    .line 518
    .line 519
    .line 520
    move-result v11

    .line 521
    and-int/lit8 v10, v10, 0x7f

    .line 522
    .line 523
    int-to-long v12, v10

    .line 524
    shr-int/lit8 v10, v11, 0x3

    .line 525
    .line 526
    and-int/lit8 v14, v11, 0x7

    .line 527
    .line 528
    shl-int/lit8 v14, v14, 0x3

    .line 529
    .line 530
    aget-wide v17, v1, v10

    .line 531
    .line 532
    move-object/from16 v21, v1

    .line 533
    .line 534
    move-object/from16 v19, v2

    .line 535
    .line 536
    shl-long v1, v32, v14

    .line 537
    .line 538
    not-long v1, v1

    .line 539
    and-long v1, v17, v1

    .line 540
    .line 541
    shl-long/2addr v12, v14

    .line 542
    or-long/2addr v1, v12

    .line 543
    aput-wide v1, v21, v10

    .line 544
    .line 545
    add-int/lit8 v10, v11, -0x7

    .line 546
    .line 547
    and-int/2addr v10, v7

    .line 548
    and-int/lit8 v12, v7, 0x7

    .line 549
    .line 550
    add-int/2addr v10, v12

    .line 551
    shr-int/lit8 v10, v10, 0x3

    .line 552
    .line 553
    aput-wide v1, v21, v10

    .line 554
    .line 555
    aput-object v9, v6, v11

    .line 556
    .line 557
    goto :goto_231

    .line 558
    :cond_22d
    move-object/from16 v21, v1

    .line 559
    .line 560
    move-object/from16 v19, v2

    .line 561
    .line 562
    :goto_231
    add-int/lit8 v8, v8, 0x1

    .line 563
    .line 564
    move-object/from16 v2, v19

    .line 565
    .line 566
    move-object/from16 v1, v21

    .line 567
    .line 568
    goto :goto_1e2

    .line 569
    :cond_238
    :goto_238
    invoke-virtual {v0, v5}, Lvf0;->e(I)I

    .line 570
    .line 571
    .line 572
    move-result v1

    .line 573
    :goto_23c
    iget v2, v0, Lvf0;->d:I

    .line 574
    .line 575
    add-int/lit8 v2, v2, 0x1

    .line 576
    .line 577
    iput v2, v0, Lvf0;->d:I

    .line 578
    .line 579
    iget v2, v0, Lvf0;->e:I

    .line 580
    .line 581
    iget-object v3, v0, Lvf0;->a:[J

    .line 582
    .line 583
    shr-int/lit8 v4, v1, 0x3

    .line 584
    .line 585
    aget-wide v5, v3, v4

    .line 586
    .line 587
    and-int/lit8 v7, v1, 0x7

    .line 588
    .line 589
    shl-int/lit8 v7, v7, 0x3

    .line 590
    .line 591
    shr-long v8, v5, v7

    .line 592
    .line 593
    and-long v8, v8, v32

    .line 594
    .line 595
    cmp-long v8, v8, v26

    .line 596
    .line 597
    if-nez v8, :cond_258

    .line 598
    .line 599
    move/from16 v15, v16

    .line 600
    .line 601
    :cond_258
    sub-int/2addr v2, v15

    .line 602
    iput v2, v0, Lvf0;->e:I

    .line 603
    .line 604
    iget v0, v0, Lvf0;->c:I

    .line 605
    .line 606
    shl-long v8, v32, v7

    .line 607
    .line 608
    not-long v8, v8

    .line 609
    and-long/2addr v5, v8

    .line 610
    shl-long v7, v34, v7

    .line 611
    .line 612
    or-long/2addr v5, v7

    .line 613
    aput-wide v5, v3, v4

    .line 614
    .line 615
    add-int/lit8 v2, v1, -0x7

    .line 616
    .line 617
    and-int/2addr v2, v0

    .line 618
    and-int/lit8 v0, v0, 0x7

    .line 619
    .line 620
    add-int/2addr v2, v0

    .line 621
    shr-int/lit8 v0, v2, 0x3

    .line 622
    .line 623
    aput-wide v5, v3, v0

    .line 624
    .line 625
    return v1

    .line 626
    :cond_271
    move/from16 v22, v3

    .line 627
    .line 628
    add-int/lit8 v8, v8, 0x8

    .line 629
    .line 630
    add-int/2addr v7, v8

    .line 631
    and-int/2addr v7, v6

    .line 632
    move/from16 v3, v19

    .line 633
    .line 634
    move/from16 v4, v20

    .line 635
    .line 636
    goto/16 :goto_1c
.end method

.method public final e(I)I
    .registers 11

    .line 1
    iget v0, p0, Lvf0;->c:I

    .line 2
    .line 3
    and-int/2addr p1, v0

    .line 4
    const/4 v1, 0x0

    .line 5
    :goto_4
    iget-object v2, p0, Lvf0;->a:[J

    .line 6
    .line 7
    shr-int/lit8 v3, p1, 0x3

    .line 8
    .line 9
    and-int/lit8 v4, p1, 0x7

    .line 10
    .line 11
    shl-int/lit8 v4, v4, 0x3

    .line 12
    .line 13
    aget-wide v5, v2, v3

    .line 14
    .line 15
    ushr-long/2addr v5, v4

    .line 16
    add-int/lit8 v3, v3, 0x1

    .line 17
    .line 18
    aget-wide v2, v2, v3

    .line 19
    .line 20
    rsub-int/lit8 v7, v4, 0x40

    .line 21
    .line 22
    shl-long/2addr v2, v7

    .line 23
    int-to-long v7, v4

    .line 24
    neg-long v7, v7

    .line 25
    const/16 v4, 0x3f

    .line 26
    .line 27
    shr-long/2addr v7, v4

    .line 28
    and-long/2addr v2, v7

    .line 29
    or-long/2addr v2, v5

    .line 30
    not-long v4, v2

    .line 31
    const/4 v6, 0x7

    .line 32
    shl-long/2addr v4, v6

    .line 33
    and-long/2addr v2, v4

    .line 34
    const-wide v4, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    and-long/2addr v2, v4

    .line 40
    const-wide/16 v4, 0x0

    .line 41
    .line 42
    cmp-long v4, v2, v4

    .line 43
    .line 44
    if-eqz v4, :cond_37

    .line 45
    .line 46
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    shr-int/lit8 p0, p0, 0x3

    .line 51
    .line 52
    add-int/2addr p1, p0

    .line 53
    and-int p0, p1, v0

    .line 54
    .line 55
    return p0

    .line 56
    :cond_37
    add-int/lit8 v1, v1, 0x8

    .line 57
    .line 58
    add-int/2addr p1, v1

    .line 59
    and-int/2addr p1, v0

    .line 60
    goto :goto_4
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 16

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p1, p0, :cond_4

    .line 3
    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Lvf0;

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 9
    .line 10
    return v2

    .line 11
    :cond_a
    check-cast p1, Lvf0;

    .line 12
    .line 13
    iget v1, p1, Lvf0;->d:I

    .line 14
    .line 15
    iget v3, p0, Lvf0;->d:I

    .line 16
    .line 17
    if-eq v1, v3, :cond_13

    .line 18
    .line 19
    return v2

    .line 20
    :cond_13
    iget-object v1, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 21
    .line 22
    iget-object p0, p0, Lvf0;->a:[J

    .line 23
    .line 24
    array-length v3, p0

    .line 25
    add-int/lit8 v3, v3, -0x2

    .line 26
    .line 27
    if-ltz v3, :cond_59

    .line 28
    .line 29
    move v4, v2

    .line 30
    :goto_1d
    aget-wide v5, p0, v4

    .line 31
    .line 32
    not-long v7, v5

    .line 33
    const/4 v9, 0x7

    .line 34
    shl-long/2addr v7, v9

    .line 35
    and-long/2addr v7, v5

    .line 36
    const-wide v9, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    and-long/2addr v7, v9

    .line 42
    cmp-long v7, v7, v9

    .line 43
    .line 44
    if-eqz v7, :cond_54

    .line 45
    .line 46
    sub-int v7, v4, v3

    .line 47
    .line 48
    not-int v7, v7

    .line 49
    ushr-int/lit8 v7, v7, 0x1f

    .line 50
    .line 51
    const/16 v8, 0x8

    .line 52
    .line 53
    rsub-int/lit8 v7, v7, 0x8

    .line 54
    .line 55
    move v9, v2

    .line 56
    :goto_37
    if-ge v9, v7, :cond_52

    .line 57
    .line 58
    const-wide/16 v10, 0xff

    .line 59
    .line 60
    and-long/2addr v10, v5

    .line 61
    const-wide/16 v12, 0x80

    .line 62
    .line 63
    cmp-long v10, v10, v12

    .line 64
    .line 65
    if-gez v10, :cond_4e

    .line 66
    .line 67
    shl-int/lit8 v10, v4, 0x3

    .line 68
    .line 69
    add-int/2addr v10, v9

    .line 70
    aget-object v10, v1, v10

    .line 71
    .line 72
    invoke-virtual {p1, v10}, Lvf0;->c(Ljava/lang/Object;)Z

    .line 73
    .line 74
    .line 75
    move-result v10

    .line 76
    if-nez v10, :cond_4e

    .line 77
    .line 78
    return v2

    .line 79
    :cond_4e
    shr-long/2addr v5, v8

    .line 80
    add-int/lit8 v9, v9, 0x1

    .line 81
    .line 82
    goto :goto_37

    .line 83
    :cond_52
    if-ne v7, v8, :cond_59

    .line 84
    .line 85
    :cond_54
    if-eq v4, v3, :cond_59

    .line 86
    .line 87
    add-int/lit8 v4, v4, 0x1

    .line 88
    .line 89
    goto :goto_1d

    .line 90
    :cond_59
    return v0
.end method

.method public final f(I)V
    .registers 11

    .line 1
    if-lez p1, :cond_c

    .line 2
    .line 3
    invoke-static {p1}, Lvr0;->e(I)I

    .line 4
    .line 5
    .line 6
    move-result p1

    .line 7
    const/4 v0, 0x7

    .line 8
    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 p1, 0x0

    .line 14
    :goto_d
    iput p1, p0, Lvf0;->c:I

    .line 15
    .line 16
    if-nez p1, :cond_14

    .line 17
    .line 18
    sget-object v0, Lvr0;->a:[J

    .line 19
    .line 20
    goto :goto_1f

    .line 21
    :cond_14
    add-int/lit8 v0, p1, 0xf

    .line 22
    .line 23
    and-int/lit8 v0, v0, -0x8

    .line 24
    .line 25
    shr-int/lit8 v0, v0, 0x3

    .line 26
    .line 27
    new-array v0, v0, [J

    .line 28
    .line 29
    invoke-static {v0}, Lj9;->Y([J)V

    .line 30
    .line 31
    .line 32
    :goto_1f
    iput-object v0, p0, Lvf0;->a:[J

    .line 33
    .line 34
    shr-int/lit8 v1, p1, 0x3

    .line 35
    .line 36
    and-int/lit8 v2, p1, 0x7

    .line 37
    .line 38
    shl-int/lit8 v2, v2, 0x3

    .line 39
    .line 40
    aget-wide v3, v0, v1

    .line 41
    .line 42
    const-wide/16 v5, 0xff

    .line 43
    .line 44
    shl-long/2addr v5, v2

    .line 45
    not-long v7, v5

    .line 46
    and-long v2, v3, v7

    .line 47
    .line 48
    or-long/2addr v2, v5

    .line 49
    aput-wide v2, v0, v1

    .line 50
    .line 51
    iget v0, p0, Lvf0;->c:I

    .line 52
    .line 53
    invoke-static {v0}, Lvr0;->c(I)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    iget v1, p0, Lvf0;->d:I

    .line 58
    .line 59
    sub-int/2addr v0, v1

    .line 60
    iput v0, p0, Lvf0;->e:I

    .line 61
    .line 62
    new-array p1, p1, [Ljava/lang/Object;

    .line 63
    .line 64
    iput-object p1, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 65
    .line 66
    return-void
.end method

.method public final g()Z
    .registers 1

    .line 1
    iget p0, p0, Lvf0;->d:I

    .line 2
    .line 3
    if-nez p0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_6
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public final h()Z
    .registers 1

    .line 1
    iget p0, p0, Lvf0;->d:I

    .line 2
    .line 3
    if-eqz p0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_6
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public final hashCode()I
    .registers 15

    .line 1
    iget-object v0, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 2
    .line 3
    iget-object p0, p0, Lvf0;->a:[J

    .line 4
    .line 5
    array-length v1, p0

    .line 6
    add-int/lit8 v1, v1, -0x2

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    if-ltz v1, :cond_4d

    .line 10
    .line 11
    move v3, v2

    .line 12
    move v4, v3

    .line 13
    :goto_c
    aget-wide v5, p0, v3

    .line 14
    .line 15
    not-long v7, v5

    .line 16
    const/4 v9, 0x7

    .line 17
    shl-long/2addr v7, v9

    .line 18
    and-long/2addr v7, v5

    .line 19
    const-wide v9, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    and-long/2addr v7, v9

    .line 25
    cmp-long v7, v7, v9

    .line 26
    .line 27
    if-eqz v7, :cond_47

    .line 28
    .line 29
    sub-int v7, v3, v1

    .line 30
    .line 31
    not-int v7, v7

    .line 32
    ushr-int/lit8 v7, v7, 0x1f

    .line 33
    .line 34
    const/16 v8, 0x8

    .line 35
    .line 36
    rsub-int/lit8 v7, v7, 0x8

    .line 37
    .line 38
    move v9, v2

    .line 39
    :goto_26
    if-ge v9, v7, :cond_43

    .line 40
    .line 41
    const-wide/16 v10, 0xff

    .line 42
    .line 43
    and-long/2addr v10, v5

    .line 44
    const-wide/16 v12, 0x80

    .line 45
    .line 46
    cmp-long v10, v10, v12

    .line 47
    .line 48
    if-gez v10, :cond_3f

    .line 49
    .line 50
    shl-int/lit8 v10, v3, 0x3

    .line 51
    .line 52
    add-int/2addr v10, v9

    .line 53
    aget-object v10, v0, v10

    .line 54
    .line 55
    if-eqz v10, :cond_3d

    .line 56
    .line 57
    invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I

    .line 58
    .line 59
    .line 60
    move-result v10

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    move v10, v2

    .line 63
    :goto_3e
    add-int/2addr v4, v10

    .line 64
    :cond_3f
    shr-long/2addr v5, v8

    .line 65
    add-int/lit8 v9, v9, 0x1

    .line 66
    .line 67
    goto :goto_26

    .line 68
    :cond_43
    if-ne v7, v8, :cond_46

    .line 69
    .line 70
    goto :goto_47

    .line 71
    :cond_46
    return v4

    .line 72
    :cond_47
    :goto_47
    if-eq v3, v1, :cond_4c

    .line 73
    .line 74
    add-int/lit8 v3, v3, 0x1

    .line 75
    .line 76
    goto :goto_c

    .line 77
    :cond_4c
    return v4

    .line 78
    :cond_4d
    return v2
.end method

.method public final i(Lvf0;)V
    .registers 15

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Lvf0;->b:[Ljava/lang/Object;

    .line 5
    .line 6
    iget-object p1, p1, Lvf0;->a:[J

    .line 7
    .line 8
    array-length v1, p1

    .line 9
    add-int/lit8 v1, v1, -0x2

    .line 10
    .line 11
    if-ltz v1, :cond_4b

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    move v3, v2

    .line 15
    :goto_e
    aget-wide v4, p1, v3

    .line 16
    .line 17
    not-long v6, v4

    .line 18
    const/4 v8, 0x7

    .line 19
    shl-long/2addr v6, v8

    .line 20
    and-long/2addr v6, v4

    .line 21
    const-wide v8, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    and-long/2addr v6, v8

    .line 27
    cmp-long v6, v6, v8

    .line 28
    .line 29
    if-eqz v6, :cond_46

    .line 30
    .line 31
    sub-int v6, v3, v1

    .line 32
    .line 33
    not-int v6, v6

    .line 34
    ushr-int/lit8 v6, v6, 0x1f

    .line 35
    .line 36
    const/16 v7, 0x8

    .line 37
    .line 38
    rsub-int/lit8 v6, v6, 0x8

    .line 39
    .line 40
    move v8, v2

    .line 41
    :goto_28
    if-ge v8, v6, :cond_44

    .line 42
    .line 43
    const-wide/16 v9, 0xff

    .line 44
    .line 45
    and-long/2addr v9, v4

    .line 46
    const-wide/16 v11, 0x80

    .line 47
    .line 48
    cmp-long v9, v9, v11

    .line 49
    .line 50
    if-gez v9, :cond_40

    .line 51
    .line 52
    shl-int/lit8 v9, v3, 0x3

    .line 53
    .line 54
    add-int/2addr v9, v8

    .line 55
    aget-object v9, v0, v9

    .line 56
    .line 57
    invoke-virtual {p0, v9}, Lvf0;->d(Ljava/lang/Object;)I

    .line 58
    .line 59
    .line 60
    move-result v10

    .line 61
    iget-object v11, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 62
    .line 63
    aput-object v9, v11, v10

    .line 64
    .line 65
    :cond_40
    shr-long/2addr v4, v7

    .line 66
    add-int/lit8 v8, v8, 0x1

    .line 67
    .line 68
    goto :goto_28

    .line 69
    :cond_44
    if-ne v6, v7, :cond_4b

    .line 70
    .line 71
    :cond_46
    if-eq v3, v1, :cond_4b

    .line 72
    .line 73
    add-int/lit8 v3, v3, 0x1

    .line 74
    .line 75
    goto :goto_e

    .line 76
    :cond_4b
    return-void
.end method

.method public final j(Ljava/lang/Object;)Z
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eqz v1, :cond_c

    .line 7
    .line 8
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    move v3, v2

    .line 14
    :goto_d
    const v4, -0x3361d2af    # -8.293031E7f

    .line 15
    .line 16
    .line 17
    mul-int/2addr v3, v4

    .line 18
    shl-int/lit8 v4, v3, 0x10

    .line 19
    .line 20
    xor-int/2addr v3, v4

    .line 21
    and-int/lit8 v4, v3, 0x7f

    .line 22
    .line 23
    iget v5, v0, Lvf0;->c:I

    .line 24
    .line 25
    ushr-int/lit8 v3, v3, 0x7

    .line 26
    .line 27
    and-int/2addr v3, v5

    .line 28
    move v6, v2

    .line 29
    :goto_1c
    iget-object v7, v0, Lvf0;->a:[J

    .line 30
    .line 31
    shr-int/lit8 v8, v3, 0x3

    .line 32
    .line 33
    and-int/lit8 v9, v3, 0x7

    .line 34
    .line 35
    shl-int/lit8 v9, v9, 0x3

    .line 36
    .line 37
    aget-wide v10, v7, v8

    .line 38
    .line 39
    ushr-long/2addr v10, v9

    .line 40
    const/4 v12, 0x1

    .line 41
    add-int/2addr v8, v12

    .line 42
    aget-wide v7, v7, v8

    .line 43
    .line 44
    rsub-int/lit8 v13, v9, 0x40

    .line 45
    .line 46
    shl-long/2addr v7, v13

    .line 47
    int-to-long v13, v9

    .line 48
    neg-long v13, v13

    .line 49
    const/16 v9, 0x3f

    .line 50
    .line 51
    shr-long/2addr v13, v9

    .line 52
    and-long/2addr v7, v13

    .line 53
    or-long/2addr v7, v10

    .line 54
    int-to-long v9, v4

    .line 55
    const-wide v13, 0x101010101010101L

    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    mul-long/2addr v9, v13

    .line 61
    xor-long/2addr v9, v7

    .line 62
    sub-long v13, v9, v13

    .line 63
    .line 64
    not-long v9, v9

    .line 65
    and-long/2addr v9, v13

    .line 66
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    and-long/2addr v9, v13

    .line 72
    :goto_47
    const-wide/16 v15, 0x0

    .line 73
    .line 74
    cmp-long v11, v9, v15

    .line 75
    .line 76
    if-eqz v11, :cond_66

    .line 77
    .line 78
    invoke-static {v9, v10}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 79
    .line 80
    .line 81
    move-result v11

    .line 82
    shr-int/lit8 v11, v11, 0x3

    .line 83
    .line 84
    add-int/2addr v11, v3

    .line 85
    and-int/2addr v11, v5

    .line 86
    iget-object v15, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 87
    .line 88
    aget-object v15, v15, v11

    .line 89
    .line 90
    invoke-static {v15, v1}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    move-result v15

    .line 94
    if-eqz v15, :cond_60

    .line 95
    .line 96
    goto :goto_70

    .line 97
    :cond_60
    const-wide/16 v15, 0x1

    .line 98
    .line 99
    sub-long v15, v9, v15

    .line 100
    .line 101
    and-long/2addr v9, v15

    .line 102
    goto :goto_47

    .line 103
    :cond_66
    not-long v9, v7

    .line 104
    const/4 v11, 0x6

    .line 105
    shl-long/2addr v9, v11

    .line 106
    and-long/2addr v7, v9

    .line 107
    and-long/2addr v7, v13

    .line 108
    cmp-long v7, v7, v15

    .line 109
    .line 110
    if-eqz v7, :cond_79

    .line 111
    .line 112
    const/4 v11, -0x1

    .line 113
    :goto_70
    if-ltz v11, :cond_73

    .line 114
    .line 115
    move v2, v12

    .line 116
    :cond_73
    if-eqz v2, :cond_78

    .line 117
    .line 118
    invoke-virtual {v0, v11}, Lvf0;->k(I)V

    .line 119
    .line 120
    .line 121
    :cond_78
    return v2

    .line 122
    :cond_79
    add-int/lit8 v6, v6, 0x8

    .line 123
    .line 124
    add-int/2addr v3, v6

    .line 125
    and-int/2addr v3, v5

    .line 126
    goto :goto_1c
.end method

.method public final k(I)V
    .registers 10

    .line 1
    iget v0, p0, Lvf0;->d:I

    .line 2
    .line 3
    add-int/lit8 v0, v0, -0x1

    .line 4
    .line 5
    iput v0, p0, Lvf0;->d:I

    .line 6
    .line 7
    iget-object v0, p0, Lvf0;->a:[J

    .line 8
    .line 9
    iget v1, p0, Lvf0;->c:I

    .line 10
    .line 11
    shr-int/lit8 v2, p1, 0x3

    .line 12
    .line 13
    and-int/lit8 v3, p1, 0x7

    .line 14
    .line 15
    shl-int/lit8 v3, v3, 0x3

    .line 16
    .line 17
    aget-wide v4, v0, v2

    .line 18
    .line 19
    const-wide/16 v6, 0xff

    .line 20
    .line 21
    shl-long/2addr v6, v3

    .line 22
    not-long v6, v6

    .line 23
    and-long/2addr v4, v6

    .line 24
    const-wide/16 v6, 0xfe

    .line 25
    .line 26
    shl-long/2addr v6, v3

    .line 27
    or-long v3, v4, v6

    .line 28
    .line 29
    aput-wide v3, v0, v2

    .line 30
    .line 31
    add-int/lit8 v2, p1, -0x7

    .line 32
    .line 33
    and-int/2addr v2, v1

    .line 34
    and-int/lit8 v1, v1, 0x7

    .line 35
    .line 36
    add-int/2addr v2, v1

    .line 37
    shr-int/lit8 v1, v2, 0x3

    .line 38
    .line 39
    aput-wide v3, v0, v1

    .line 40
    .line 41
    iget-object p0, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 42
    .line 43
    const/4 v0, 0x0

    .line 44
    aput-object v0, p0, p1

    .line 45
    .line 46
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Ljava/lang/StringBuilder;

    .line 4
    .line 5
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 6
    .line 7
    .line 8
    const-string v2, "["

    .line 9
    .line 10
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    iget-object v2, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 14
    .line 15
    iget-object v3, v0, Lvf0;->a:[J

    .line 16
    .line 17
    array-length v4, v3

    .line 18
    add-int/lit8 v4, v4, -0x2

    .line 19
    .line 20
    if-ltz v4, :cond_6b

    .line 21
    .line 22
    const/4 v5, 0x0

    .line 23
    move v6, v5

    .line 24
    move v7, v6

    .line 25
    :goto_18
    aget-wide v8, v3, v6

    .line 26
    .line 27
    not-long v10, v8

    .line 28
    const/4 v12, 0x7

    .line 29
    shl-long/2addr v10, v12

    .line 30
    and-long/2addr v10, v8

    .line 31
    const-wide v12, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    and-long/2addr v10, v12

    .line 37
    cmp-long v10, v10, v12

    .line 38
    .line 39
    if-eqz v10, :cond_66

    .line 40
    .line 41
    sub-int v10, v6, v4

    .line 42
    .line 43
    not-int v10, v10

    .line 44
    ushr-int/lit8 v10, v10, 0x1f

    .line 45
    .line 46
    const/16 v11, 0x8

    .line 47
    .line 48
    rsub-int/lit8 v10, v10, 0x8

    .line 49
    .line 50
    move v12, v5

    .line 51
    :goto_32
    if-ge v12, v10, :cond_64

    .line 52
    .line 53
    const-wide/16 v13, 0xff

    .line 54
    .line 55
    and-long/2addr v13, v8

    .line 56
    const-wide/16 v15, 0x80

    .line 57
    .line 58
    cmp-long v13, v13, v15

    .line 59
    .line 60
    if-gez v13, :cond_60

    .line 61
    .line 62
    shl-int/lit8 v13, v6, 0x3

    .line 63
    .line 64
    add-int/2addr v13, v12

    .line 65
    aget-object v13, v2, v13

    .line 66
    .line 67
    const/4 v14, -0x1

    .line 68
    if-ne v7, v14, :cond_4b

    .line 69
    .line 70
    const-string v0, "..."

    .line 71
    .line 72
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 73
    .line 74
    .line 75
    goto :goto_70

    .line 76
    :cond_4b
    if-eqz v7, :cond_52

    .line 77
    .line 78
    const-string v14, ", "

    .line 79
    .line 80
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 81
    .line 82
    .line 83
    :cond_52
    if-ne v13, v0, :cond_57

    .line 84
    .line 85
    const-string v13, "(this)"

    .line 86
    .line 87
    goto :goto_5b

    .line 88
    :cond_57
    invoke-static {v13}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 89
    .line 90
    .line 91
    move-result-object v13

    .line 92
    :goto_5b
    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    add-int/lit8 v7, v7, 0x1

    .line 96
    .line 97
    :cond_60
    shr-long/2addr v8, v11

    .line 98
    add-int/lit8 v12, v12, 0x1

    .line 99
    .line 100
    goto :goto_32

    .line 101
    :cond_64
    if-ne v10, v11, :cond_6b

    .line 102
    .line 103
    :cond_66
    if-eq v6, v4, :cond_6b

    .line 104
    .line 105
    add-int/lit8 v6, v6, 0x1

    .line 106
    .line 107
    goto :goto_18

    .line 108
    :cond_6b
    const-string v0, "]"

    .line 109
    .line 110
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/StringBuilder;

    .line 111
    .line 112
    .line 113
    :goto_70
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 114
    .line 115
    .line 116
    move-result-object v0

    .line 117
    return-object v0
.end method
