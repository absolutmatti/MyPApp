###### Class defpackage.nz0 (nz0)
.class public final synthetic Lnz0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Loe0;

.field public final synthetic h:Lqe0;

.field public final synthetic i:Lkl;


# direct methods
.method public synthetic constructor <init>(Lkl;Loe0;Lqe0;)V
    .registers 5

    .line 1
    const/4 v0, 0x6

    .line 2
    iput v0, p0, Lnz0;->f:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lnz0;->i:Lkl;

    .line 8
    .line 9
    iput-object p2, p0, Lnz0;->g:Loe0;

    .line 10
    .line 11
    iput-object p3, p0, Lnz0;->h:Lqe0;

    .line 12
    .line 13
    return-void
.end method

.method public synthetic constructor <init>(Loe0;Lkl;Lqe0;)V
    .registers 5

    .line 14
    const/4 v0, 0x3

    iput v0, p0, Lnz0;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lnz0;->g:Loe0;

    iput-object p2, p0, Lnz0;->i:Lkl;

    iput-object p3, p0, Lnz0;->h:Lqe0;

    return-void
.end method

.method public synthetic constructor <init>(Loe0;Lqe0;Lkl;I)V
    .registers 5

    .line 15
    iput p4, p0, Lnz0;->f:I

    iput-object p1, p0, Lnz0;->g:Loe0;

    iput-object p2, p0, Lnz0;->h:Lqe0;

    iput-object p3, p0, Lnz0;->i:Lkl;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 15

    .line 1
    iget v0, p0, Lnz0;->f:I

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    const/4 v4, 0x0

    .line 7
    const/4 v5, 0x0

    .line 8
    iget-object v6, p0, Lnz0;->h:Lqe0;

    .line 9
    .line 10
    iget-object v7, p0, Lnz0;->g:Loe0;

    .line 11
    .line 12
    iget-object p0, p0, Lnz0;->i:Lkl;

    .line 13
    .line 14
    packed-switch v0, :pswitch_data_1ca

    .line 15
    .line 16
    .line 17
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 18
    .line 19
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 20
    .line 21
    const-string v8, "noResult"

    .line 22
    .line 23
    invoke-virtual {v7, v8}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v8

    .line 27
    invoke-virtual {v0, v8}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 28
    .line 29
    .line 30
    move-result v8

    .line 31
    const-string v9, "continueOnError"

    .line 32
    .line 33
    invoke-virtual {v7, v9}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v9

    .line 37
    invoke-virtual {v0, v9}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    const-string v9, "operations"

    .line 42
    .line 43
    invoke-virtual {v7, v9}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v7

    .line 47
    check-cast v7, Ljava/util/List;

    .line 48
    .line 49
    new-instance v9, Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    .line 52
    .line 53
    .line 54
    invoke-interface {v7}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 55
    .line 56
    .line 57
    move-result-object v7

    .line 58
    :goto_39
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 59
    .line 60
    .line 61
    move-result v10

    .line 62
    if-eqz v10, :cond_13f

    .line 63
    .line 64
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 65
    .line 66
    .line 67
    move-result-object v10

    .line 68
    check-cast v10, Ljava/util/Map;

    .line 69
    .line 70
    new-instance v11, Lea;

    .line 71
    .line 72
    invoke-direct {v11, v10, v8}, Lea;-><init>(Ljava/util/Map;Z)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v11}, Lea;->u()Ljava/lang/String;

    .line 76
    .line 77
    .line 78
    move-result-object v10

    .line 79
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    .line 81
    .line 82
    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    .line 83
    .line 84
    .line 85
    move-result v12

    .line 86
    const/4 v13, -0x1

    .line 87
    sparse-switch v12, :sswitch_data_1da

    .line 88
    .line 89
    .line 90
    goto :goto_85

    .line 91
    :sswitch_5a
    const-string v12, "query"

    .line 92
    .line 93
    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 94
    .line 95
    .line 96
    move-result v12

    .line 97
    if-nez v12, :cond_63

    .line 98
    .line 99
    goto :goto_85

    .line 100
    :cond_63
    move v13, v1

    .line 101
    goto :goto_85

    .line 102
    :sswitch_65
    const-string v12, "update"

    .line 103
    .line 104
    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 105
    .line 106
    .line 107
    move-result v12

    .line 108
    if-nez v12, :cond_6e

    .line 109
    .line 110
    goto :goto_85

    .line 111
    :cond_6e
    move v13, v2

    .line 112
    goto :goto_85

    .line 113
    :sswitch_70
    const-string v12, "insert"

    .line 114
    .line 115
    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 116
    .line 117
    .line 118
    move-result v12

    .line 119
    if-nez v12, :cond_79

    .line 120
    .line 121
    goto :goto_85

    .line 122
    :cond_79
    move v13, v3

    .line 123
    goto :goto_85

    .line 124
    :sswitch_7b
    const-string v12, "execute"

    .line 125
    .line 126
    invoke-virtual {v10, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    move-result v12

    .line 130
    if-nez v12, :cond_84

    .line 131
    .line 132
    goto :goto_85

    .line 133
    :cond_84
    move v13, v4

    .line 134
    :goto_85
    iget-object v12, v11, Lea;->p:Lq1;

    .line 135
    .line 136
    packed-switch v13, :pswitch_data_1ec

    .line 137
    .line 138
    .line 139
    const-string p0, "Batch method \'"

    .line 140
    .line 141
    const-string v0, "\' not supported"

    .line 142
    .line 143
    invoke-static {p0, v10, v0}, Lzi0;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 144
    .line 145
    .line 146
    move-result-object p0

    .line 147
    const-string v0, "bad_param"

    .line 148
    .line 149
    invoke-virtual {v6, v0, p0, v5}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 150
    .line 151
    .line 152
    goto/16 :goto_148

    .line 153
    .line 154
    :pswitch_99
    invoke-virtual {p0, v11}, Lkl;->f(Lhh1;)Z

    .line 155
    .line 156
    .line 157
    move-result v10

    .line 158
    if-eqz v10, :cond_a3

    .line 159
    .line 160
    invoke-virtual {v11, v9}, Lea;->O(Ljava/util/ArrayList;)V

    .line 161
    .line 162
    .line 163
    goto :goto_39

    .line 164
    :cond_a3
    if-eqz v0, :cond_af

    .line 165
    .line 166
    invoke-virtual {v11}, Lea;->P()Z

    .line 167
    .line 168
    .line 169
    move-result v10

    .line 170
    if-nez v10, :cond_af

    .line 171
    .line 172
    invoke-virtual {v11, v9}, Lea;->N(Ljava/util/ArrayList;)V

    .line 173
    .line 174
    .line 175
    goto :goto_39

    .line 176
    :cond_af
    iget-object v0, v12, Lq1;->f:Ljava/lang/Object;

    .line 177
    .line 178
    check-cast v0, Ljava/lang/String;

    .line 179
    .line 180
    iget-object v1, v12, Lq1;->g:Ljava/lang/Object;

    .line 181
    .line 182
    check-cast v1, Ljava/lang/String;

    .line 183
    .line 184
    iget-object v2, v12, Lq1;->i:Ljava/lang/Object;

    .line 185
    .line 186
    invoke-virtual {v6, v0, v1, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 187
    .line 188
    .line 189
    invoke-virtual {p0}, Lkl;->o()V

    .line 190
    .line 191
    .line 192
    goto/16 :goto_148

    .line 193
    .line 194
    :pswitch_c1
    invoke-virtual {p0, v11}, Lkl;->g(Lhh1;)Z

    .line 195
    .line 196
    .line 197
    move-result v10

    .line 198
    if-eqz v10, :cond_cc

    .line 199
    .line 200
    invoke-virtual {v11, v9}, Lea;->O(Ljava/util/ArrayList;)V

    .line 201
    .line 202
    .line 203
    goto/16 :goto_39

    .line 204
    .line 205
    :cond_cc
    if-eqz v0, :cond_d9

    .line 206
    .line 207
    invoke-virtual {v11}, Lea;->P()Z

    .line 208
    .line 209
    .line 210
    move-result v10

    .line 211
    if-nez v10, :cond_d9

    .line 212
    .line 213
    invoke-virtual {v11, v9}, Lea;->N(Ljava/util/ArrayList;)V

    .line 214
    .line 215
    .line 216
    goto/16 :goto_39

    .line 217
    .line 218
    :cond_d9
    iget-object v0, v12, Lq1;->f:Ljava/lang/Object;

    .line 219
    .line 220
    check-cast v0, Ljava/lang/String;

    .line 221
    .line 222
    iget-object v1, v12, Lq1;->g:Ljava/lang/Object;

    .line 223
    .line 224
    check-cast v1, Ljava/lang/String;

    .line 225
    .line 226
    iget-object v2, v12, Lq1;->i:Ljava/lang/Object;

    .line 227
    .line 228
    invoke-virtual {v6, v0, v1, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    invoke-virtual {p0}, Lkl;->o()V

    .line 232
    .line 233
    .line 234
    goto :goto_148

    .line 235
    :pswitch_ea
    invoke-virtual {p0, v11}, Lkl;->e(Lhh1;)Z

    .line 236
    .line 237
    .line 238
    move-result v10

    .line 239
    if-eqz v10, :cond_f5

    .line 240
    .line 241
    invoke-virtual {v11, v9}, Lea;->O(Ljava/util/ArrayList;)V

    .line 242
    .line 243
    .line 244
    goto/16 :goto_39

    .line 245
    .line 246
    :cond_f5
    if-eqz v0, :cond_102

    .line 247
    .line 248
    invoke-virtual {v11}, Lea;->P()Z

    .line 249
    .line 250
    .line 251
    move-result v10

    .line 252
    if-nez v10, :cond_102

    .line 253
    .line 254
    invoke-virtual {v11, v9}, Lea;->N(Ljava/util/ArrayList;)V

    .line 255
    .line 256
    .line 257
    goto/16 :goto_39

    .line 258
    .line 259
    :cond_102
    iget-object v0, v12, Lq1;->f:Ljava/lang/Object;

    .line 260
    .line 261
    check-cast v0, Ljava/lang/String;

    .line 262
    .line 263
    iget-object v1, v12, Lq1;->g:Ljava/lang/Object;

    .line 264
    .line 265
    check-cast v1, Ljava/lang/String;

    .line 266
    .line 267
    iget-object v2, v12, Lq1;->i:Ljava/lang/Object;

    .line 268
    .line 269
    invoke-virtual {v6, v0, v1, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 270
    .line 271
    .line 272
    invoke-virtual {p0}, Lkl;->o()V

    .line 273
    .line 274
    .line 275
    goto :goto_148

    .line 276
    :pswitch_113
    invoke-virtual {p0, v11}, Lkl;->i(Lhh1;)Z

    .line 277
    .line 278
    .line 279
    move-result v10

    .line 280
    if-nez v10, :cond_137

    .line 281
    .line 282
    if-eqz v0, :cond_126

    .line 283
    .line 284
    invoke-virtual {v11}, Lea;->P()Z

    .line 285
    .line 286
    .line 287
    move-result v10

    .line 288
    if-nez v10, :cond_126

    .line 289
    .line 290
    invoke-virtual {v11, v9}, Lea;->N(Ljava/util/ArrayList;)V

    .line 291
    .line 292
    .line 293
    goto/16 :goto_39

    .line 294
    .line 295
    :cond_126
    iget-object v0, v12, Lq1;->f:Ljava/lang/Object;

    .line 296
    .line 297
    check-cast v0, Ljava/lang/String;

    .line 298
    .line 299
    iget-object v1, v12, Lq1;->g:Ljava/lang/Object;

    .line 300
    .line 301
    check-cast v1, Ljava/lang/String;

    .line 302
    .line 303
    iget-object v2, v12, Lq1;->i:Ljava/lang/Object;

    .line 304
    .line 305
    invoke-virtual {v6, v0, v1, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 306
    .line 307
    .line 308
    invoke-virtual {p0}, Lkl;->o()V

    .line 309
    .line 310
    .line 311
    goto :goto_148

    .line 312
    :cond_137
    invoke-virtual {v11, v5}, Lhh1;->success(Ljava/lang/Object;)V

    .line 313
    .line 314
    .line 315
    invoke-virtual {v11, v9}, Lea;->O(Ljava/util/ArrayList;)V

    .line 316
    .line 317
    .line 318
    goto/16 :goto_39

    .line 319
    .line 320
    :cond_13f
    if-eqz v8, :cond_145

    .line 321
    .line 322
    invoke-virtual {v6, v5}, Lqe0;->success(Ljava/lang/Object;)V

    .line 323
    .line 324
    .line 325
    goto :goto_148

    .line 326
    :cond_145
    invoke-virtual {v6, v9}, Lqe0;->success(Ljava/lang/Object;)V

    .line 327
    .line 328
    .line 329
    :goto_148
    return-void

    .line 330
    :pswitch_149
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 331
    .line 332
    new-instance v0, Lpe0;

    .line 333
    .line 334
    invoke-direct {v0, v7, v6}, Lpe0;-><init>(Loe0;Lse0;)V

    .line 335
    .line 336
    .line 337
    new-instance v1, Lhl;

    .line 338
    .line 339
    invoke-direct {v1, p0, v0, v2}, Lhl;-><init>(Lkl;Lpe0;I)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {p0, v0, v1}, Lkl;->p(Lpe0;Ljava/lang/Runnable;)V

    .line 343
    .line 344
    .line 345
    return-void

    .line 346
    :pswitch_159
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 347
    .line 348
    new-instance v0, Lpe0;

    .line 349
    .line 350
    invoke-direct {v0, v7, v6}, Lpe0;-><init>(Loe0;Lse0;)V

    .line 351
    .line 352
    .line 353
    new-instance v1, Lhl;

    .line 354
    .line 355
    const/4 v2, 0x4

    .line 356
    invoke-direct {v1, p0, v0, v2}, Lhl;-><init>(Lkl;Lpe0;I)V

    .line 357
    .line 358
    .line 359
    invoke-virtual {p0, v0, v1}, Lkl;->p(Lpe0;Ljava/lang/Runnable;)V

    .line 360
    .line 361
    .line 362
    return-void

    .line 363
    :pswitch_16a
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 364
    .line 365
    const-string v0, "locale"

    .line 366
    .line 367
    invoke-virtual {v7, v0}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 368
    .line 369
    .line 370
    move-result-object v0

    .line 371
    check-cast v0, Ljava/lang/String;

    .line 372
    .line 373
    :try_start_174
    iget-object p0, p0, Lkl;->i:Landroid/database/sqlite/SQLiteDatabase;

    .line 374
    .line 375
    invoke-static {v0}, Ljava/util/Locale;->forLanguageTag(Ljava/lang/String;)Ljava/util/Locale;

    .line 376
    .line 377
    .line 378
    move-result-object v0

    .line 379
    invoke-virtual {p0, v0}, Landroid/database/sqlite/SQLiteDatabase;->setLocale(Ljava/util/Locale;)V

    .line 380
    .line 381
    .line 382
    invoke-virtual {v6, v5}, Lqe0;->success(Ljava/lang/Object;)V
    :try_end_180
    .catch Ljava/lang/Exception; {:try_start_174 .. :try_end_180} :catch_181

    .line 383
    .line 384
    .line 385
    goto :goto_199

    .line 386
    :catch_181
    move-exception p0

    .line 387
    new-instance v0, Ljava/lang/StringBuilder;

    .line 388
    .line 389
    const-string v1, "Error calling setLocale: "

    .line 390
    .line 391
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 392
    .line 393
    .line 394
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 395
    .line 396
    .line 397
    move-result-object p0

    .line 398
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object p0

    .line 405
    const-string v0, "sqlite_error"

    .line 406
    .line 407
    invoke-virtual {v6, v0, p0, v5}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 408
    .line 409
    .line 410
    :goto_199
    return-void

    .line 411
    :pswitch_19a
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 412
    .line 413
    new-instance v0, Lpe0;

    .line 414
    .line 415
    invoke-direct {v0, v7, v6}, Lpe0;-><init>(Loe0;Lse0;)V

    .line 416
    .line 417
    .line 418
    new-instance v1, Lhl;

    .line 419
    .line 420
    invoke-direct {v1, p0, v0, v3}, Lhl;-><init>(Lkl;Lpe0;I)V

    .line 421
    .line 422
    .line 423
    invoke-virtual {p0, v0, v1}, Lkl;->p(Lpe0;Ljava/lang/Runnable;)V

    .line 424
    .line 425
    .line 426
    return-void

    .line 427
    :pswitch_1aa
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 428
    .line 429
    new-instance v0, Lpe0;

    .line 430
    .line 431
    invoke-direct {v0, v7, v6}, Lpe0;-><init>(Loe0;Lse0;)V

    .line 432
    .line 433
    .line 434
    new-instance v2, Lhl;

    .line 435
    .line 436
    invoke-direct {v2, p0, v0, v1}, Lhl;-><init>(Lkl;Lpe0;I)V

    .line 437
    .line 438
    .line 439
    invoke-virtual {p0, v0, v2}, Lkl;->p(Lpe0;Ljava/lang/Runnable;)V

    .line 440
    .line 441
    .line 442
    return-void

    .line 443
    :pswitch_1ba
    sget-object v0, Lpz0;->h:Ljava/util/HashMap;

    .line 444
    .line 445
    new-instance v0, Lpe0;

    .line 446
    .line 447
    invoke-direct {v0, v7, v6}, Lpe0;-><init>(Loe0;Lse0;)V

    .line 448
    .line 449
    .line 450
    new-instance v1, Lhl;

    .line 451
    .line 452
    invoke-direct {v1, p0, v0, v4}, Lhl;-><init>(Lkl;Lpe0;I)V

    .line 453
    .line 454
    .line 455
    invoke-virtual {p0, v0, v1}, Lkl;->p(Lpe0;Ljava/lang/Runnable;)V

    .line 456
    .line 457
    .line 458
    return-void

    .line 459
    :pswitch_data_1ca
    .packed-switch 0x0
        :pswitch_1ba
        :pswitch_1aa
        :pswitch_19a
        :pswitch_16a
        :pswitch_159
        :pswitch_149
    .end packed-switch

    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    :sswitch_data_1da
    .sparse-switch
        -0x4ea7088b -> :sswitch_7b
        -0x468f3d47 -> :sswitch_70
        -0x31ffc737 -> :sswitch_65
        0x66f18c8 -> :sswitch_5a
    .end sparse-switch

    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    :pswitch_data_1ec
    .packed-switch 0x0
        :pswitch_113
        :pswitch_ea
        :pswitch_c1
        :pswitch_99
    .end packed-switch
.end method

###### Class defpackage.hl (hl)
.class public final synthetic Lhl;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lkl;

.field public final synthetic h:Lpe0;


# direct methods
.method public synthetic constructor <init>(Lkl;Lpe0;I)V
    .registers 4

    .line 1
    iput p3, p0, Lhl;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lhl;->g:Lkl;

    .line 4
    .line 5
    iput-object p2, p0, Lhl;->h:Lpe0;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 12

    .line 1
    iget v0, p0, Lhl;->f:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x1

    .line 6
    iget-object v4, p0, Lhl;->h:Lpe0;

    .line 7
    .line 8
    iget-object p0, p0, Lhl;->g:Lkl;

    .line 9
    .line 10
    packed-switch v0, :pswitch_data_144

    .line 11
    .line 12
    .line 13
    const-string v0, "inTransaction"

    .line 14
    .line 15
    invoke-virtual {v4, v0}, Lhh1;->q(Ljava/lang/String;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    instance-of v5, v0, Ljava/lang/Boolean;

    .line 20
    .line 21
    if-eqz v5, :cond_19

    .line 22
    .line 23
    check-cast v0, Ljava/lang/Boolean;

    .line 24
    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    move-object v0, v2

    .line 27
    :goto_1a
    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 28
    .line 29
    invoke-virtual {v5, v0}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 30
    .line 31
    .line 32
    move-result v5

    .line 33
    const-string v6, "transactionId"

    .line 34
    .line 35
    if-eqz v5, :cond_33

    .line 36
    .line 37
    invoke-virtual {v4}, Lhh1;->z()Z

    .line 38
    .line 39
    .line 40
    move-result v5

    .line 41
    if-eqz v5, :cond_33

    .line 42
    .line 43
    invoke-virtual {v4, v6}, Lhh1;->q(Ljava/lang/String;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v5

    .line 47
    check-cast v5, Ljava/lang/Integer;

    .line 48
    .line 49
    if-nez v5, :cond_33

    .line 50
    .line 51
    move v1, v3

    .line 52
    :cond_33
    if-eqz v1, :cond_40

    .line 53
    .line 54
    iget v5, p0, Lkl;->k:I

    .line 55
    .line 56
    add-int/2addr v5, v3

    .line 57
    iput v5, p0, Lkl;->k:I

    .line 58
    .line 59
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    iput-object v3, p0, Lkl;->l:Ljava/lang/Integer;

    .line 64
    .line 65
    :cond_40
    invoke-virtual {p0, v4}, Lkl;->i(Lhh1;)Z

    .line 66
    .line 67
    .line 68
    move-result v3

    .line 69
    if-nez v3, :cond_56

    .line 70
    .line 71
    if-eqz v1, :cond_4b

    .line 72
    .line 73
    iput-object v2, p0, Lkl;->l:Ljava/lang/Integer;

    .line 74
    .line 75
    goto :goto_73

    .line 76
    :cond_4b
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 77
    .line 78
    invoke-virtual {v1, v0}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 79
    .line 80
    .line 81
    move-result v0

    .line 82
    if-eqz v0, :cond_73

    .line 83
    .line 84
    iput-object v2, p0, Lkl;->l:Ljava/lang/Integer;

    .line 85
    .line 86
    goto :goto_73

    .line 87
    :cond_56
    if-eqz v1, :cond_66

    .line 88
    .line 89
    new-instance v0, Ljava/util/HashMap;

    .line 90
    .line 91
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 92
    .line 93
    .line 94
    iget-object p0, p0, Lkl;->l:Ljava/lang/Integer;

    .line 95
    .line 96
    invoke-virtual {v0, v6, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 97
    .line 98
    .line 99
    invoke-virtual {v4, v0}, Lhh1;->success(Ljava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    goto :goto_73

    .line 103
    :cond_66
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 104
    .line 105
    invoke-virtual {v1, v0}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-eqz v0, :cond_70

    .line 110
    .line 111
    iput-object v2, p0, Lkl;->l:Ljava/lang/Integer;

    .line 112
    .line 113
    :cond_70
    invoke-virtual {v4, v2}, Lhh1;->success(Ljava/lang/Object;)V

    .line 114
    .line 115
    .line 116
    :cond_73
    :goto_73
    return-void

    .line 117
    :pswitch_74
    invoke-virtual {p0, v4}, Lkl;->e(Lhh1;)Z

    .line 118
    .line 119
    .line 120
    return-void

    .line 121
    :pswitch_78
    invoke-virtual {p0, v4}, Lkl;->g(Lhh1;)Z

    .line 122
    .line 123
    .line 124
    return-void

    .line 125
    :pswitch_7c
    invoke-virtual {p0, v4}, Lkl;->f(Lhh1;)Z

    .line 126
    .line 127
    .line 128
    return-void

    .line 129
    :pswitch_80
    const-string v0, "Cursor "

    .line 130
    .line 131
    iget-object v5, v4, Lpe0;->p:Loe0;

    .line 132
    .line 133
    const-string v6, "cursorId"

    .line 134
    .line 135
    invoke-virtual {v5, v6}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 136
    .line 137
    .line 138
    move-result-object v7

    .line 139
    check-cast v7, Ljava/lang/Integer;

    .line 140
    .line 141
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 142
    .line 143
    .line 144
    move-result v8

    .line 145
    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 146
    .line 147
    const-string v10, "cancel"

    .line 148
    .line 149
    invoke-virtual {v5, v10}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v5

    .line 153
    invoke-virtual {v9, v5}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    .line 154
    .line 155
    .line 156
    move-result v5

    .line 157
    iget v9, p0, Lkl;->d:I

    .line 158
    .line 159
    invoke-static {v9}, Lfo0;->A(I)Z

    .line 160
    .line 161
    .line 162
    move-result v9

    .line 163
    if-eqz v9, :cond_cb

    .line 164
    .line 165
    new-instance v9, Ljava/lang/StringBuilder;

    .line 166
    .line 167
    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    .line 168
    .line 169
    .line 170
    invoke-virtual {p0}, Lkl;->j()Ljava/lang/String;

    .line 171
    .line 172
    .line 173
    move-result-object v10

    .line 174
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    .line 176
    .line 177
    const-string v10, "cursor "

    .line 178
    .line 179
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 180
    .line 181
    .line 182
    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    if-eqz v5, :cond_bd

    .line 186
    .line 187
    const-string v10, " cancel"

    .line 188
    .line 189
    goto :goto_bf

    .line 190
    :cond_bd
    const-string v10, " next"

    .line 191
    .line 192
    :goto_bf
    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 193
    .line 194
    .line 195
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 196
    .line 197
    .line 198
    move-result-object v9

    .line 199
    const-string v10, "Sqflite"

    .line 200
    .line 201
    invoke-static {v10, v9}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 202
    .line 203
    .line 204
    :cond_cb
    iget-object v9, p0, Lkl;->g:Ljava/util/HashMap;

    .line 205
    .line 206
    if-eqz v5, :cond_de

    .line 207
    .line 208
    invoke-virtual {v9, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    check-cast v0, Lmz0;

    .line 213
    .line 214
    if-eqz v0, :cond_da

    .line 215
    .line 216
    invoke-virtual {p0, v0}, Lkl;->c(Lmz0;)V

    .line 217
    .line 218
    .line 219
    :cond_da
    invoke-virtual {v4, v2}, Lhh1;->success(Ljava/lang/Object;)V

    .line 220
    .line 221
    .line 222
    goto :goto_13a

    .line 223
    :cond_de
    invoke-virtual {v9, v7}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 224
    .line 225
    .line 226
    move-result-object v5

    .line 227
    check-cast v5, Lmz0;

    .line 228
    .line 229
    if-eqz v5, :cond_112

    .line 230
    .line 231
    :try_start_e6
    iget-object v0, v5, Lmz0;->c:Landroid/database/Cursor;

    .line 232
    .line 233
    iget v8, v5, Lmz0;->b:I

    .line 234
    .line 235
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 236
    .line 237
    .line 238
    move-result-object v8

    .line 239
    invoke-static {v0, v8}, Lkl;->d(Landroid/database/Cursor;Ljava/lang/Integer;)Ljava/util/HashMap;

    .line 240
    .line 241
    .line 242
    move-result-object v8

    .line 243
    invoke-interface {v0}, Landroid/database/Cursor;->isLast()Z

    .line 244
    .line 245
    .line 246
    move-result v9

    .line 247
    if-nez v9, :cond_104

    .line 248
    .line 249
    invoke-interface {v0}, Landroid/database/Cursor;->isAfterLast()Z

    .line 250
    .line 251
    .line 252
    move-result v0

    .line 253
    if-nez v0, :cond_104

    .line 254
    .line 255
    move v1, v3

    .line 256
    goto :goto_104

    .line 257
    :catchall_100
    move-exception v0

    .line 258
    goto :goto_13b

    .line 259
    :catch_102
    move-exception v0

    .line 260
    goto :goto_129

    .line 261
    :cond_104
    :goto_104
    if-eqz v1, :cond_109

    .line 262
    .line 263
    invoke-interface {v8, v6, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 264
    .line 265
    .line 266
    :cond_109
    invoke-virtual {v4, v8}, Lhh1;->success(Ljava/lang/Object;)V
    :try_end_10c
    .catch Ljava/lang/Exception; {:try_start_e6 .. :try_end_10c} :catch_102
    .catchall {:try_start_e6 .. :try_end_10c} :catchall_100

    .line 267
    .line 268
    .line 269
    if-nez v1, :cond_13a

    .line 270
    .line 271
    invoke-virtual {p0, v5}, Lkl;->c(Lmz0;)V

    .line 272
    .line 273
    .line 274
    goto :goto_13a

    .line 275
    :cond_112
    :try_start_112
    new-instance v3, Ljava/lang/IllegalStateException;

    .line 276
    .line 277
    new-instance v6, Ljava/lang/StringBuilder;

    .line 278
    .line 279
    invoke-direct {v6, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 283
    .line 284
    .line 285
    const-string v0, " not found"

    .line 286
    .line 287
    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 288
    .line 289
    .line 290
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 291
    .line 292
    .line 293
    move-result-object v0

    .line 294
    invoke-direct {v3, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 295
    .line 296
    .line 297
    throw v3
    :try_end_129
    .catch Ljava/lang/Exception; {:try_start_112 .. :try_end_129} :catch_102
    .catchall {:try_start_112 .. :try_end_129} :catchall_100

    .line 298
    :goto_129
    :try_start_129
    invoke-virtual {p0, v0, v4}, Lkl;->k(Ljava/lang/Exception;Lhh1;)V

    .line 299
    .line 300
    .line 301
    if-eqz v5, :cond_132

    .line 302
    .line 303
    invoke-virtual {p0, v5}, Lkl;->c(Lmz0;)V
    :try_end_131
    .catchall {:try_start_129 .. :try_end_131} :catchall_100

    .line 304
    .line 305
    .line 306
    goto :goto_133

    .line 307
    :cond_132
    move-object v2, v5

    .line 308
    :goto_133
    if-nez v1, :cond_13a

    .line 309
    .line 310
    if-eqz v2, :cond_13a

    .line 311
    .line 312
    invoke-virtual {p0, v2}, Lkl;->c(Lmz0;)V

    .line 313
    .line 314
    .line 315
    :cond_13a
    :goto_13a
    return-void

    .line 316
    :goto_13b
    if-nez v1, :cond_142

    .line 317
    .line 318
    if-eqz v5, :cond_142

    .line 319
    .line 320
    invoke-virtual {p0, v5}, Lkl;->c(Lmz0;)V

    .line 321
    .line 322
    .line 323
    :cond_142
    throw v0

    .line 324
    nop

    .line 325
    :pswitch_data_144
    .packed-switch 0x0
        :pswitch_80
        :pswitch_7c
        :pswitch_78
        :pswitch_74
    .end packed-switch
.end method
