###### Class defpackage.v40 (v40)
.class public abstract Lv40;
.super Lu40;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# direct methods
.method public static getCOROUTINE_SUSPENDED()Ljava/lang/Object;
    .registers 1

    .line 1
    sget-object v0, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 2
    .line 3
    return-object v0
.end method

.method public static synthetic getCOROUTINE_SUSPENDED$annotations()V
    .registers 0

    .line 1
    return-void
.end method
