###### Class defpackage.uf1 (uf1)
.class public final Luf1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lz9;


# instance fields
.field public final f:Lr4;

.field public final g:Lh5;

.field public h:Ll20;

.field public i:Ljava/util/Set;

.field public j:Z

.field public final synthetic k:Lo10;


# direct methods
.method public constructor <init>(Lo10;Lr4;Lh5;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Luf1;->k:Lo10;

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, Luf1;->h:Ll20;

    .line 8
    .line 9
    iput-object p1, p0, Luf1;->i:Ljava/util/Set;

    .line 10
    .line 11
    const/4 p1, 0x0

    .line 12
    iput-boolean p1, p0, Luf1;->j:Z

    .line 13
    .line 14
    iput-object p2, p0, Luf1;->f:Lr4;

    .line 15
    .line 16
    iput-object p3, p0, Luf1;->g:Lh5;

    .line 17
    .line 18
    return-void
.end method


# virtual methods
.method public final a(Lrg;)V
    .registers 3

    .line 1
    iget-object v0, p0, Luf1;->k:Lo10;

    .line 2
    .line 3
    iget-object v0, v0, Lo10;->j:Ljava/util/concurrent/ConcurrentHashMap;

    .line 4
    .line 5
    iget-object p0, p0, Luf1;->g:Lh5;

    .line 6
    .line 7
    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    check-cast p0, Lsf1;

    .line 12
    .line 13
    if-eqz p0, :cond_11

    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lsf1;->p(Lrg;)V

    .line 16
    .line 17
    .line 18
    :cond_11
    return-void
.end method

.method public final g(Lrg;)V
    .registers 5

    .line 1
    iget-object v0, p0, Luf1;->k:Lo10;

    .line 2
    .line 3
    iget-object v0, v0, Lo10;->m:Lsg1;

    .line 4
    .line 5
    new-instance v1, Lr2;

    .line 6
    .line 7
    const/16 v2, 0xa

    .line 8
    .line 9
    invoke-direct {v1, p0, v2, p1}, Lr2;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 13
    .line 14
    .line 15
    return-void
.end method
