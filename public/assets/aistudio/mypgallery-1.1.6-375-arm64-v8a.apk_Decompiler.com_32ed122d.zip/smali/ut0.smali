###### Class defpackage.ut0 (ut0)
.class public final Lut0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/concurrent/Executor;


# instance fields
.field public final synthetic f:I

.field public final g:Ljava/util/concurrent/Executor;

.field public final h:Ljava/util/ArrayDeque;

.field public i:Ljava/lang/Runnable;

.field public final j:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lh8;)V
    .registers 3

    const/4 v0, 0x2

    iput v0, p0, Lut0;->f:I

    .line 49
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 50
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lut0;->j:Ljava/lang/Object;

    .line 51
    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 52
    iput-object p1, p0, Lut0;->g:Ljava/util/concurrent/Executor;

    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/Executor;I)V
    .registers 3

    .line 1
    iput p2, p0, Lut0;->f:I

    .line 2
    .line 3
    packed-switch p2, :pswitch_data_30

    .line 4
    .line 5
    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object p1, p0, Lut0;->g:Ljava/util/concurrent/Executor;

    .line 10
    .line 11
    new-instance p1, Ljava/util/ArrayDeque;

    .line 12
    .line 13
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 17
    .line 18
    new-instance p1, Ljava/lang/Object;

    .line 19
    .line 20
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object p1, p0, Lut0;->j:Ljava/lang/Object;

    .line 24
    .line 25
    return-void

    .line 26
    :pswitch_19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object p1, p0, Lut0;->g:Ljava/util/concurrent/Executor;

    .line 33
    .line 34
    new-instance p1, Ljava/util/ArrayDeque;

    .line 35
    .line 36
    invoke-direct {p1}, Ljava/util/ArrayDeque;-><init>()V

    .line 37
    .line 38
    .line 39
    iput-object p1, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 40
    .line 41
    new-instance p1, Ljava/lang/Object;

    .line 42
    .line 43
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 44
    .line 45
    .line 46
    iput-object p1, p0, Lut0;->j:Ljava/lang/Object;

    .line 47
    .line 48
    return-void

    .line 49
    :pswitch_data_30
    .packed-switch 0x1
        :pswitch_19
    .end packed-switch
.end method


# virtual methods
.method public final a()V
    .registers 4

    .line 1
    iget v0, p0, Lut0;->f:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_52

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lut0;->j:Ljava/lang/Object;

    .line 7
    .line 8
    monitor-enter v0

    .line 9
    :try_start_8
    iget-object v1, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 10
    .line 11
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    check-cast v1, Ljava/lang/Runnable;

    .line 16
    .line 17
    iput-object v1, p0, Lut0;->i:Ljava/lang/Runnable;

    .line 18
    .line 19
    if-eqz v1, :cond_1e

    .line 20
    .line 21
    iget-object p0, p0, Lut0;->g:Ljava/util/concurrent/Executor;

    .line 22
    .line 23
    check-cast p0, Lh8;

    .line 24
    .line 25
    invoke-virtual {p0, v1}, Lh8;->execute(Ljava/lang/Runnable;)V

    .line 26
    .line 27
    .line 28
    goto :goto_1e

    .line 29
    :catchall_1c
    move-exception p0

    .line 30
    goto :goto_20

    .line 31
    :cond_1e
    :goto_1e
    monitor-exit v0

    .line 32
    return-void

    .line 33
    :goto_20
    monitor-exit v0
    :try_end_21
    .catchall {:try_start_8 .. :try_end_21} :catchall_1c

    .line 34
    throw p0

    .line 35
    :pswitch_22
    iget-object v0, p0, Lut0;->j:Ljava/lang/Object;

    .line 36
    .line 37
    monitor-enter v0

    .line 38
    :try_start_25
    iget-object v1, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    move-object v2, v1

    .line 45
    check-cast v2, Ljava/lang/Runnable;

    .line 46
    .line 47
    iput-object v2, p0, Lut0;->i:Ljava/lang/Runnable;

    .line 48
    .line 49
    if-eqz v1, :cond_3a

    .line 50
    .line 51
    iget-object p0, p0, Lut0;->g:Ljava/util/concurrent/Executor;

    .line 52
    .line 53
    invoke-interface {p0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 54
    .line 55
    .line 56
    goto :goto_3a

    .line 57
    :catchall_38
    move-exception p0

    .line 58
    goto :goto_3e

    .line 59
    :cond_3a
    :goto_3a
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3c
    .catchall {:try_start_25 .. :try_end_3c} :catchall_38

    .line 60
    .line 61
    monitor-exit v0

    .line 62
    return-void

    .line 63
    :goto_3e
    monitor-exit v0

    .line 64
    throw p0

    .line 65
    :pswitch_40
    iget-object v0, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 66
    .line 67
    invoke-virtual {v0}, Ljava/util/ArrayDeque;->poll()Ljava/lang/Object;

    .line 68
    .line 69
    .line 70
    move-result-object v0

    .line 71
    check-cast v0, Ljava/lang/Runnable;

    .line 72
    .line 73
    iput-object v0, p0, Lut0;->i:Ljava/lang/Runnable;

    .line 74
    .line 75
    if-eqz v0, :cond_51

    .line 76
    .line 77
    iget-object p0, p0, Lut0;->g:Ljava/util/concurrent/Executor;

    .line 78
    .line 79
    invoke-interface {p0, v0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    .line 80
    .line 81
    .line 82
    :cond_51
    return-void

    .line 83
    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_40
        :pswitch_22
    .end packed-switch
.end method

.method public final execute(Ljava/lang/Runnable;)V
    .registers 7

    .line 1
    iget v0, p0, Lut0;->f:I

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    packed-switch v0, :pswitch_data_60

    .line 5
    .line 6
    .line 7
    iget-object v0, p0, Lut0;->j:Ljava/lang/Object;

    .line 8
    .line 9
    monitor-enter v0

    .line 10
    :try_start_9
    iget-object v2, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 11
    .line 12
    new-instance v3, Lg8;

    .line 13
    .line 14
    invoke-direct {v3, p0, v1, p1}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v2, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    iget-object p1, p0, Lut0;->i:Ljava/lang/Runnable;

    .line 21
    .line 22
    if-nez p1, :cond_1d

    .line 23
    .line 24
    invoke-virtual {p0}, Lut0;->a()V

    .line 25
    .line 26
    .line 27
    goto :goto_1d

    .line 28
    :catchall_1b
    move-exception p0

    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    :goto_1d
    monitor-exit v0

    .line 31
    return-void

    .line 32
    :goto_1f
    monitor-exit v0
    :try_end_20
    .catchall {:try_start_9 .. :try_end_20} :catchall_1b

    .line 33
    throw p0

    .line 34
    :pswitch_21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 35
    .line 36
    .line 37
    iget-object v0, p0, Lut0;->j:Ljava/lang/Object;

    .line 38
    .line 39
    monitor-enter v0

    .line 40
    :try_start_27
    iget-object v1, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 41
    .line 42
    new-instance v2, Lg8;

    .line 43
    .line 44
    const/16 v3, 0x11

    .line 45
    .line 46
    invoke-direct {v2, p1, p0, v3}, Lg8;-><init>(Ljava/lang/Runnable;Ljava/lang/Object;I)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v1, v2}, Ljava/util/ArrayDeque;->offer(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    iget-object p1, p0, Lut0;->i:Ljava/lang/Runnable;

    .line 53
    .line 54
    if-nez p1, :cond_3d

    .line 55
    .line 56
    invoke-virtual {p0}, Lut0;->a()V

    .line 57
    .line 58
    .line 59
    goto :goto_3d

    .line 60
    :catchall_3b
    move-exception p0

    .line 61
    goto :goto_41

    .line 62
    :cond_3d
    :goto_3d
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3f
    .catchall {:try_start_27 .. :try_end_3f} :catchall_3b

    .line 63
    .line 64
    monitor-exit v0

    .line 65
    return-void

    .line 66
    :goto_41
    monitor-exit v0

    .line 67
    throw p0

    .line 68
    :pswitch_43
    iget-object v0, p0, Lut0;->j:Ljava/lang/Object;

    .line 69
    .line 70
    monitor-enter v0

    .line 71
    :try_start_46
    iget-object v2, p0, Lut0;->h:Ljava/util/ArrayDeque;

    .line 72
    .line 73
    new-instance v3, Lr2;

    .line 74
    .line 75
    const/4 v4, 0x6

    .line 76
    invoke-direct {v3, v4, p0, p1, v1}, Lr2;-><init>(ILjava/lang/Object;Ljava/lang/Object;Z)V

    .line 77
    .line 78
    .line 79
    invoke-virtual {v2, v3}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z

    .line 80
    .line 81
    .line 82
    iget-object p1, p0, Lut0;->i:Ljava/lang/Runnable;

    .line 83
    .line 84
    if-nez p1, :cond_5b

    .line 85
    .line 86
    invoke-virtual {p0}, Lut0;->a()V

    .line 87
    .line 88
    .line 89
    goto :goto_5b

    .line 90
    :catchall_59
    move-exception p0

    .line 91
    goto :goto_5d

    .line 92
    :cond_5b
    :goto_5b
    monitor-exit v0

    .line 93
    return-void

    .line 94
    :goto_5d
    monitor-exit v0
    :try_end_5e
    .catchall {:try_start_46 .. :try_end_5e} :catchall_59

    .line 95
    throw p0

    .line 96
    nop

    .line 97
    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_43
        :pswitch_21
    .end packed-switch
.end method
