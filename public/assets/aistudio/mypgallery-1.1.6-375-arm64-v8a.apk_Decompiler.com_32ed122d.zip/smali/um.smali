###### Class defpackage.um (um)
.class public final synthetic Lum;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lqz;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .line 1
    iput p2, p0, Lum;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lum;->g:Ljava/lang/String;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 81

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lum;->f:I

    .line 4
    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v4, 0x1

    .line 7
    iget-object v0, v0, Lum;->g:Ljava/lang/String;

    .line 8
    .line 9
    packed-switch v1, :pswitch_data_516

    .line 10
    .line 11
    .line 12
    move-object/from16 v1, p1

    .line 13
    .line 14
    check-cast v1, Loq0;

    .line 15
    .line 16
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 17
    .line 18
    .line 19
    const-string v2, "SELECT DISTINCT tag FROM worktag WHERE work_spec_id=?"

    .line 20
    .line 21
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    :try_start_18
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 26
    .line 27
    .line 28
    new-instance v0, Ljava/util/ArrayList;

    .line 29
    .line 30
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 31
    .line 32
    .line 33
    :goto_20
    invoke-interface {v1}, Lqq0;->v()Z

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_30

    .line 38
    .line 39
    invoke-interface {v1, v3}, Lqq0;->f(I)Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object v2

    .line 43
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_2d
    .catchall {:try_start_18 .. :try_end_2d} :catchall_2e

    .line 44
    .line 45
    .line 46
    goto :goto_20

    .line 47
    :catchall_2e
    move-exception v0

    .line 48
    goto :goto_34

    .line 49
    :cond_30
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 50
    .line 51
    .line 52
    return-object v0

    .line 53
    :goto_34
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 54
    .line 55
    .line 56
    throw v0

    .line 57
    :pswitch_38
    move-object/from16 v1, p1

    .line 58
    .line 59
    check-cast v1, Loq0;

    .line 60
    .line 61
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 62
    .line 63
    .line 64
    const-string v2, "SELECT id, state FROM workspec WHERE id IN (SELECT work_spec_id FROM workname WHERE name=?)"

    .line 65
    .line 66
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 67
    .line 68
    .line 69
    move-result-object v1

    .line 70
    :try_start_45
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 71
    .line 72
    .line 73
    new-instance v0, Ljava/util/ArrayList;

    .line 74
    .line 75
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 76
    .line 77
    .line 78
    :goto_4d
    invoke-interface {v1}, Lqq0;->v()Z

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    if-eqz v2, :cond_72

    .line 83
    .line 84
    invoke-interface {v1, v3}, Lqq0;->f(I)Ljava/lang/String;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    invoke-interface {v1, v4}, Lqq0;->getLong(I)J

    .line 89
    .line 90
    .line 91
    move-result-wide v5

    .line 92
    long-to-int v5, v5

    .line 93
    invoke-static {v5}, Lsa;->H(I)Lde1;

    .line 94
    .line 95
    .line 96
    move-result-object v5

    .line 97
    new-instance v6, Lme1;

    .line 98
    .line 99
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 100
    .line 101
    .line 102
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 103
    .line 104
    .line 105
    iput-object v2, v6, Lme1;->a:Ljava/lang/String;

    .line 106
    .line 107
    iput-object v5, v6, Lme1;->b:Lde1;

    .line 108
    .line 109
    invoke-virtual {v0, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_6f
    .catchall {:try_start_45 .. :try_end_6f} :catchall_70

    .line 110
    .line 111
    .line 112
    goto :goto_4d

    .line 113
    :catchall_70
    move-exception v0

    .line 114
    goto :goto_76

    .line 115
    :cond_72
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 116
    .line 117
    .line 118
    return-object v0

    .line 119
    :goto_76
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 120
    .line 121
    .line 122
    throw v0

    .line 123
    :pswitch_7a
    move-object/from16 v1, p1

    .line 124
    .line 125
    check-cast v1, Loq0;

    .line 126
    .line 127
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    .line 129
    .line 130
    const-string v2, "DELETE FROM workspec WHERE id=?"

    .line 131
    .line 132
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 133
    .line 134
    .line 135
    move-result-object v1

    .line 136
    :try_start_87
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 137
    .line 138
    .line 139
    invoke-interface {v1}, Lqq0;->v()Z
    :try_end_8d
    .catchall {:try_start_87 .. :try_end_8d} :catchall_93

    .line 140
    .line 141
    .line 142
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 143
    .line 144
    .line 145
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 146
    .line 147
    return-object v0

    .line 148
    :catchall_93
    move-exception v0

    .line 149
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 150
    .line 151
    .line 152
    throw v0

    .line 153
    :pswitch_98
    move-object/from16 v1, p1

    .line 154
    .line 155
    check-cast v1, Loq0;

    .line 156
    .line 157
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 158
    .line 159
    .line 160
    const-string v2, "UPDATE workspec SET run_attempt_count=run_attempt_count+1 WHERE id=?"

    .line 161
    .line 162
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 163
    .line 164
    .line 165
    move-result-object v2

    .line 166
    :try_start_a5
    invoke-interface {v2, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 167
    .line 168
    .line 169
    invoke-interface {v2}, Lqq0;->v()Z

    .line 170
    .line 171
    .line 172
    invoke-static {v1}, Lsa;->D(Loq0;)I

    .line 173
    .line 174
    .line 175
    move-result v0
    :try_end_af
    .catchall {:try_start_a5 .. :try_end_af} :catchall_b7

    .line 176
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 177
    .line 178
    .line 179
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 180
    .line 181
    .line 182
    move-result-object v0

    .line 183
    return-object v0

    .line 184
    :catchall_b7
    move-exception v0

    .line 185
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 186
    .line 187
    .line 188
    throw v0

    .line 189
    :pswitch_bc
    move-object/from16 v1, p1

    .line 190
    .line 191
    check-cast v1, Loq0;

    .line 192
    .line 193
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    .line 195
    .line 196
    const-string v2, "SELECT output FROM workspec WHERE id IN\n             (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)"

    .line 197
    .line 198
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 199
    .line 200
    .line 201
    move-result-object v1

    .line 202
    :try_start_c9
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 203
    .line 204
    .line 205
    new-instance v0, Ljava/util/ArrayList;

    .line 206
    .line 207
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 208
    .line 209
    .line 210
    :goto_d1
    invoke-interface {v1}, Lqq0;->v()Z

    .line 211
    .line 212
    .line 213
    move-result v2

    .line 214
    if-eqz v2, :cond_e7

    .line 215
    .line 216
    invoke-interface {v1, v3}, Lqq0;->getBlob(I)[B

    .line 217
    .line 218
    .line 219
    move-result-object v2

    .line 220
    sget-object v4, Lak;->b:Lak;

    .line 221
    .line 222
    invoke-static {v2}, Lge1;->z([B)Lak;

    .line 223
    .line 224
    .line 225
    move-result-object v2

    .line 226
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_e4
    .catchall {:try_start_c9 .. :try_end_e4} :catchall_e5

    .line 227
    .line 228
    .line 229
    goto :goto_d1

    .line 230
    :catchall_e5
    move-exception v0

    .line 231
    goto :goto_eb

    .line 232
    :cond_e7
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 233
    .line 234
    .line 235
    return-object v0

    .line 236
    :goto_eb
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 237
    .line 238
    .line 239
    throw v0

    .line 240
    :pswitch_ef
    move-object/from16 v1, p1

    .line 241
    .line 242
    check-cast v1, Loq0;

    .line 243
    .line 244
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    .line 246
    .line 247
    const-string v2, "UPDATE workspec SET period_count=period_count+1 WHERE id=?"

    .line 248
    .line 249
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 250
    .line 251
    .line 252
    move-result-object v1

    .line 253
    :try_start_fc
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 254
    .line 255
    .line 256
    invoke-interface {v1}, Lqq0;->v()Z
    :try_end_102
    .catchall {:try_start_fc .. :try_end_102} :catchall_108

    .line 257
    .line 258
    .line 259
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 260
    .line 261
    .line 262
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 263
    .line 264
    return-object v0

    .line 265
    :catchall_108
    move-exception v0

    .line 266
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 267
    .line 268
    .line 269
    throw v0

    .line 270
    :pswitch_10d
    move-object/from16 v1, p1

    .line 271
    .line 272
    check-cast v1, Loq0;

    .line 273
    .line 274
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 275
    .line 276
    .line 277
    const-string v2, "UPDATE workspec SET run_attempt_count=0 WHERE id=?"

    .line 278
    .line 279
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 280
    .line 281
    .line 282
    move-result-object v2

    .line 283
    :try_start_11a
    invoke-interface {v2, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 284
    .line 285
    .line 286
    invoke-interface {v2}, Lqq0;->v()Z

    .line 287
    .line 288
    .line 289
    invoke-static {v1}, Lsa;->D(Loq0;)I

    .line 290
    .line 291
    .line 292
    move-result v0
    :try_end_124
    .catchall {:try_start_11a .. :try_end_124} :catchall_12c

    .line 293
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 294
    .line 295
    .line 296
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 297
    .line 298
    .line 299
    move-result-object v0

    .line 300
    return-object v0

    .line 301
    :catchall_12c
    move-exception v0

    .line 302
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 303
    .line 304
    .line 305
    throw v0

    .line 306
    :pswitch_131
    move-object/from16 v1, p1

    .line 307
    .line 308
    check-cast v1, Loq0;

    .line 309
    .line 310
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 311
    .line 312
    .line 313
    const-string v2, "UPDATE workspec SET stop_reason = CASE WHEN state=1 THEN 1 ELSE -256 END, state=5 WHERE id=?"

    .line 314
    .line 315
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 316
    .line 317
    .line 318
    move-result-object v2

    .line 319
    :try_start_13e
    invoke-interface {v2, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 320
    .line 321
    .line 322
    invoke-interface {v2}, Lqq0;->v()Z

    .line 323
    .line 324
    .line 325
    invoke-static {v1}, Lsa;->D(Loq0;)I

    .line 326
    .line 327
    .line 328
    move-result v0
    :try_end_148
    .catchall {:try_start_13e .. :try_end_148} :catchall_150

    .line 329
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 330
    .line 331
    .line 332
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 333
    .line 334
    .line 335
    move-result-object v0

    .line 336
    return-object v0

    .line 337
    :catchall_150
    move-exception v0

    .line 338
    invoke-interface {v2}, Ljava/lang/AutoCloseable;->close()V

    .line 339
    .line 340
    .line 341
    throw v0

    .line 342
    :pswitch_155
    move-object/from16 v1, p1

    .line 343
    .line 344
    check-cast v1, Loq0;

    .line 345
    .line 346
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 347
    .line 348
    .line 349
    const-string v2, "SELECT id FROM workspec WHERE state NOT IN (2, 3, 5) AND id IN (SELECT work_spec_id FROM workname WHERE name=?)"

    .line 350
    .line 351
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 352
    .line 353
    .line 354
    move-result-object v1

    .line 355
    :try_start_162
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 356
    .line 357
    .line 358
    new-instance v0, Ljava/util/ArrayList;

    .line 359
    .line 360
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 361
    .line 362
    .line 363
    :goto_16a
    invoke-interface {v1}, Lqq0;->v()Z

    .line 364
    .line 365
    .line 366
    move-result v2

    .line 367
    if-eqz v2, :cond_17a

    .line 368
    .line 369
    invoke-interface {v1, v3}, Lqq0;->f(I)Ljava/lang/String;

    .line 370
    .line 371
    .line 372
    move-result-object v2

    .line 373
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_177
    .catchall {:try_start_162 .. :try_end_177} :catchall_178

    .line 374
    .line 375
    .line 376
    goto :goto_16a

    .line 377
    :catchall_178
    move-exception v0

    .line 378
    goto :goto_17e

    .line 379
    :cond_17a
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 380
    .line 381
    .line 382
    return-object v0

    .line 383
    :goto_17e
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 384
    .line 385
    .line 386
    throw v0

    .line 387
    :pswitch_182
    move-object/from16 v1, p1

    .line 388
    .line 389
    check-cast v1, Loq0;

    .line 390
    .line 391
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 392
    .line 393
    .line 394
    const-string v5, "SELECT state FROM workspec WHERE id=?"

    .line 395
    .line 396
    invoke-interface {v1, v5}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 397
    .line 398
    .line 399
    move-result-object v1

    .line 400
    :try_start_18f
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 401
    .line 402
    .line 403
    invoke-interface {v1}, Lqq0;->v()Z

    .line 404
    .line 405
    .line 406
    move-result v0

    .line 407
    if-eqz v0, :cond_1ab

    .line 408
    .line 409
    invoke-interface {v1, v3}, Lqq0;->isNull(I)Z

    .line 410
    .line 411
    .line 412
    move-result v0

    .line 413
    if-eqz v0, :cond_1a0

    .line 414
    .line 415
    const/4 v0, 0x0

    .line 416
    goto :goto_1a9

    .line 417
    :cond_1a0
    invoke-interface {v1, v3}, Lqq0;->getLong(I)J

    .line 418
    .line 419
    .line 420
    move-result-wide v3

    .line 421
    long-to-int v0, v3

    .line 422
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 423
    .line 424
    .line 425
    move-result-object v0

    .line 426
    :goto_1a9
    if-nez v0, :cond_1ad

    .line 427
    .line 428
    :cond_1ab
    const/4 v2, 0x0

    .line 429
    goto :goto_1b8

    .line 430
    :cond_1ad
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 431
    .line 432
    .line 433
    move-result v0

    .line 434
    invoke-static {v0}, Lsa;->H(I)Lde1;

    .line 435
    .line 436
    .line 437
    move-result-object v2
    :try_end_1b5
    .catchall {:try_start_18f .. :try_end_1b5} :catchall_1b6

    .line 438
    goto :goto_1b8

    .line 439
    :catchall_1b6
    move-exception v0

    .line 440
    goto :goto_1bc

    .line 441
    :goto_1b8
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 442
    .line 443
    .line 444
    return-object v2

    .line 445
    :goto_1bc
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 446
    .line 447
    .line 448
    throw v0

    .line 449
    :pswitch_1c0
    move-object/from16 v1, p1

    .line 450
    .line 451
    check-cast v1, Loq0;

    .line 452
    .line 453
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 454
    .line 455
    .line 456
    const-string v5, "SELECT * FROM workspec WHERE id=?"

    .line 457
    .line 458
    invoke-interface {v1, v5}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 459
    .line 460
    .line 461
    move-result-object v1

    .line 462
    :try_start_1cd
    invoke-interface {v1, v4, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 463
    .line 464
    .line 465
    const-string v0, "id"

    .line 466
    .line 467
    invoke-static {v1, v0}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 468
    .line 469
    .line 470
    move-result v0

    .line 471
    const-string v5, "state"

    .line 472
    .line 473
    invoke-static {v1, v5}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 474
    .line 475
    .line 476
    move-result v5

    .line 477
    const-string v6, "worker_class_name"

    .line 478
    .line 479
    invoke-static {v1, v6}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 480
    .line 481
    .line 482
    move-result v6

    .line 483
    const-string v7, "input_merger_class_name"

    .line 484
    .line 485
    invoke-static {v1, v7}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 486
    .line 487
    .line 488
    move-result v7

    .line 489
    const-string v8, "input"

    .line 490
    .line 491
    invoke-static {v1, v8}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 492
    .line 493
    .line 494
    move-result v8

    .line 495
    const-string v9, "output"

    .line 496
    .line 497
    invoke-static {v1, v9}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 498
    .line 499
    .line 500
    move-result v9

    .line 501
    const-string v10, "initial_delay"

    .line 502
    .line 503
    invoke-static {v1, v10}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 504
    .line 505
    .line 506
    move-result v10

    .line 507
    const-string v11, "interval_duration"

    .line 508
    .line 509
    invoke-static {v1, v11}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 510
    .line 511
    .line 512
    move-result v11

    .line 513
    const-string v12, "flex_duration"

    .line 514
    .line 515
    invoke-static {v1, v12}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 516
    .line 517
    .line 518
    move-result v12

    .line 519
    const-string v13, "run_attempt_count"

    .line 520
    .line 521
    invoke-static {v1, v13}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 522
    .line 523
    .line 524
    move-result v13

    .line 525
    const-string v14, "backoff_policy"

    .line 526
    .line 527
    invoke-static {v1, v14}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 528
    .line 529
    .line 530
    move-result v14

    .line 531
    const-string v15, "backoff_delay_duration"

    .line 532
    .line 533
    invoke-static {v1, v15}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 534
    .line 535
    .line 536
    move-result v15

    .line 537
    const-string v2, "last_enqueue_time"

    .line 538
    .line 539
    invoke-static {v1, v2}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 540
    .line 541
    .line 542
    move-result v2

    .line 543
    const-string v3, "minimum_retention_duration"

    .line 544
    .line 545
    invoke-static {v1, v3}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 546
    .line 547
    .line 548
    move-result v3

    .line 549
    const-string v4, "schedule_requested_at"

    .line 550
    .line 551
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 552
    .line 553
    .line 554
    move-result v4

    .line 555
    move/from16 p0, v4

    .line 556
    .line 557
    const-string v4, "run_in_foreground"

    .line 558
    .line 559
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 560
    .line 561
    .line 562
    move-result v4

    .line 563
    move/from16 p1, v4

    .line 564
    .line 565
    const-string v4, "out_of_quota_policy"

    .line 566
    .line 567
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 568
    .line 569
    .line 570
    move-result v4

    .line 571
    move/from16 v16, v4

    .line 572
    .line 573
    const-string v4, "period_count"

    .line 574
    .line 575
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 576
    .line 577
    .line 578
    move-result v4

    .line 579
    move/from16 v17, v4

    .line 580
    .line 581
    const-string v4, "generation"

    .line 582
    .line 583
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 584
    .line 585
    .line 586
    move-result v4

    .line 587
    move/from16 v18, v4

    .line 588
    .line 589
    const-string v4, "next_schedule_time_override"

    .line 590
    .line 591
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 592
    .line 593
    .line 594
    move-result v4

    .line 595
    move/from16 v19, v4

    .line 596
    .line 597
    const-string v4, "next_schedule_time_override_generation"

    .line 598
    .line 599
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 600
    .line 601
    .line 602
    move-result v4

    .line 603
    move/from16 v20, v4

    .line 604
    .line 605
    const-string v4, "stop_reason"

    .line 606
    .line 607
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 608
    .line 609
    .line 610
    move-result v4

    .line 611
    move/from16 v21, v4

    .line 612
    .line 613
    const-string v4, "trace_tag"

    .line 614
    .line 615
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 616
    .line 617
    .line 618
    move-result v4

    .line 619
    move/from16 v22, v4

    .line 620
    .line 621
    const-string v4, "backoff_on_system_interruptions"

    .line 622
    .line 623
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 624
    .line 625
    .line 626
    move-result v4

    .line 627
    move/from16 v23, v4

    .line 628
    .line 629
    const-string v4, "required_network_type"

    .line 630
    .line 631
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 632
    .line 633
    .line 634
    move-result v4

    .line 635
    move/from16 v24, v4

    .line 636
    .line 637
    const-string v4, "required_network_request"

    .line 638
    .line 639
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 640
    .line 641
    .line 642
    move-result v4

    .line 643
    move/from16 v25, v4

    .line 644
    .line 645
    const-string v4, "requires_charging"

    .line 646
    .line 647
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 648
    .line 649
    .line 650
    move-result v4

    .line 651
    move/from16 v26, v4

    .line 652
    .line 653
    const-string v4, "requires_device_idle"

    .line 654
    .line 655
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 656
    .line 657
    .line 658
    move-result v4

    .line 659
    move/from16 v27, v4

    .line 660
    .line 661
    const-string v4, "requires_battery_not_low"

    .line 662
    .line 663
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 664
    .line 665
    .line 666
    move-result v4

    .line 667
    move/from16 v28, v4

    .line 668
    .line 669
    const-string v4, "requires_storage_not_low"

    .line 670
    .line 671
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 672
    .line 673
    .line 674
    move-result v4

    .line 675
    move/from16 v29, v4

    .line 676
    .line 677
    const-string v4, "trigger_content_update_delay"

    .line 678
    .line 679
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 680
    .line 681
    .line 682
    move-result v4

    .line 683
    move/from16 v30, v4

    .line 684
    .line 685
    const-string v4, "trigger_max_content_delay"

    .line 686
    .line 687
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 688
    .line 689
    .line 690
    move-result v4

    .line 691
    move/from16 v31, v4

    .line 692
    .line 693
    const-string v4, "content_uri_triggers"

    .line 694
    .line 695
    invoke-static {v1, v4}, Lrl;->F(Lqq0;Ljava/lang/String;)I

    .line 696
    .line 697
    .line 698
    move-result v4

    .line 699
    invoke-interface {v1}, Lqq0;->v()Z

    .line 700
    .line 701
    .line 702
    move-result v32

    .line 703
    if-eqz v32, :cond_40d

    .line 704
    .line 705
    invoke-interface {v1, v0}, Lqq0;->f(I)Ljava/lang/String;

    .line 706
    .line 707
    .line 708
    move-result-object v34

    .line 709
    move v0, v4

    .line 710
    invoke-interface {v1, v5}, Lqq0;->getLong(I)J

    .line 711
    .line 712
    .line 713
    move-result-wide v4

    .line 714
    long-to-int v4, v4

    .line 715
    invoke-static {v4}, Lsa;->H(I)Lde1;

    .line 716
    .line 717
    .line 718
    move-result-object v35

    .line 719
    invoke-interface {v1, v6}, Lqq0;->f(I)Ljava/lang/String;

    .line 720
    .line 721
    .line 722
    move-result-object v36

    .line 723
    invoke-interface {v1, v7}, Lqq0;->f(I)Ljava/lang/String;

    .line 724
    .line 725
    .line 726
    move-result-object v37

    .line 727
    invoke-interface {v1, v8}, Lqq0;->getBlob(I)[B

    .line 728
    .line 729
    .line 730
    move-result-object v4

    .line 731
    sget-object v5, Lak;->b:Lak;

    .line 732
    .line 733
    invoke-static {v4}, Lge1;->z([B)Lak;

    .line 734
    .line 735
    .line 736
    move-result-object v38

    .line 737
    invoke-interface {v1, v9}, Lqq0;->getBlob(I)[B

    .line 738
    .line 739
    .line 740
    move-result-object v4

    .line 741
    invoke-static {v4}, Lge1;->z([B)Lak;

    .line 742
    .line 743
    .line 744
    move-result-object v39

    .line 745
    invoke-interface {v1, v10}, Lqq0;->getLong(I)J

    .line 746
    .line 747
    .line 748
    move-result-wide v40

    .line 749
    invoke-interface {v1, v11}, Lqq0;->getLong(I)J

    .line 750
    .line 751
    .line 752
    move-result-wide v42

    .line 753
    invoke-interface {v1, v12}, Lqq0;->getLong(I)J

    .line 754
    .line 755
    .line 756
    move-result-wide v44

    .line 757
    invoke-interface {v1, v13}, Lqq0;->getLong(I)J

    .line 758
    .line 759
    .line 760
    move-result-wide v4

    .line 761
    long-to-int v4, v4

    .line 762
    invoke-interface {v1, v14}, Lqq0;->getLong(I)J

    .line 763
    .line 764
    .line 765
    move-result-wide v5

    .line 766
    long-to-int v5, v5

    .line 767
    invoke-static {v5}, Lsa;->E(I)Lv9;

    .line 768
    .line 769
    .line 770
    move-result-object v48

    .line 771
    invoke-interface {v1, v15}, Lqq0;->getLong(I)J

    .line 772
    .line 773
    .line 774
    move-result-wide v49

    .line 775
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 776
    .line 777
    .line 778
    move-result-wide v51

    .line 779
    invoke-interface {v1, v3}, Lqq0;->getLong(I)J

    .line 780
    .line 781
    .line 782
    move-result-wide v53

    .line 783
    move/from16 v2, p0

    .line 784
    .line 785
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 786
    .line 787
    .line 788
    move-result-wide v55

    .line 789
    move/from16 v2, p1

    .line 790
    .line 791
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 792
    .line 793
    .line 794
    move-result-wide v2

    .line 795
    long-to-int v2, v2

    .line 796
    if-eqz v2, :cond_322

    .line 797
    .line 798
    const/16 v57, 0x1

    .line 799
    .line 800
    :goto_31f
    move/from16 v2, v16

    .line 801
    .line 802
    goto :goto_325

    .line 803
    :cond_322
    const/16 v57, 0x0

    .line 804
    .line 805
    goto :goto_31f

    .line 806
    :goto_325
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 807
    .line 808
    .line 809
    move-result-wide v2

    .line 810
    long-to-int v2, v2

    .line 811
    invoke-static {v2}, Lsa;->G(I)Lej0;

    .line 812
    .line 813
    .line 814
    move-result-object v58

    .line 815
    move/from16 v2, v17

    .line 816
    .line 817
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 818
    .line 819
    .line 820
    move-result-wide v2

    .line 821
    long-to-int v2, v2

    .line 822
    move/from16 v3, v18

    .line 823
    .line 824
    invoke-interface {v1, v3}, Lqq0;->getLong(I)J

    .line 825
    .line 826
    .line 827
    move-result-wide v5

    .line 828
    long-to-int v3, v5

    .line 829
    move/from16 v5, v19

    .line 830
    .line 831
    invoke-interface {v1, v5}, Lqq0;->getLong(I)J

    .line 832
    .line 833
    .line 834
    move-result-wide v61

    .line 835
    move/from16 v5, v20

    .line 836
    .line 837
    invoke-interface {v1, v5}, Lqq0;->getLong(I)J

    .line 838
    .line 839
    .line 840
    move-result-wide v5

    .line 841
    long-to-int v5, v5

    .line 842
    move/from16 v6, v21

    .line 843
    .line 844
    invoke-interface {v1, v6}, Lqq0;->getLong(I)J

    .line 845
    .line 846
    .line 847
    move-result-wide v6

    .line 848
    long-to-int v6, v6

    .line 849
    move/from16 v7, v22

    .line 850
    .line 851
    invoke-interface {v1, v7}, Lqq0;->isNull(I)Z

    .line 852
    .line 853
    .line 854
    move-result v8

    .line 855
    if-eqz v8, :cond_35d

    .line 856
    .line 857
    const/16 v65, 0x0

    .line 858
    .line 859
    :goto_35a
    move/from16 v7, v23

    .line 860
    .line 861
    goto :goto_364

    .line 862
    :cond_35d
    invoke-interface {v1, v7}, Lqq0;->f(I)Ljava/lang/String;

    .line 863
    .line 864
    .line 865
    move-result-object v7

    .line 866
    move-object/from16 v65, v7

    .line 867
    .line 868
    goto :goto_35a

    .line 869
    :goto_364
    invoke-interface {v1, v7}, Lqq0;->isNull(I)Z

    .line 870
    .line 871
    .line 872
    move-result v8

    .line 873
    if-eqz v8, :cond_36c

    .line 874
    .line 875
    const/4 v7, 0x0

    .line 876
    goto :goto_375

    .line 877
    :cond_36c
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 878
    .line 879
    .line 880
    move-result-wide v7

    .line 881
    long-to-int v7, v7

    .line 882
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 883
    .line 884
    .line 885
    move-result-object v7

    .line 886
    :goto_375
    if-eqz v7, :cond_38c

    .line 887
    .line 888
    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    .line 889
    .line 890
    .line 891
    move-result v7

    .line 892
    if-eqz v7, :cond_37f

    .line 893
    .line 894
    const/4 v7, 0x1

    .line 895
    goto :goto_380

    .line 896
    :cond_37f
    const/4 v7, 0x0

    .line 897
    :goto_380
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 898
    .line 899
    .line 900
    move-result-object v7

    .line 901
    move-object/from16 v66, v7

    .line 902
    .line 903
    :goto_386
    move/from16 v7, v24

    .line 904
    .line 905
    goto :goto_38f

    .line 906
    :catchall_389
    move-exception v0

    .line 907
    goto/16 :goto_412

    .line 908
    .line 909
    :cond_38c
    const/16 v66, 0x0

    .line 910
    .line 911
    goto :goto_386

    .line 912
    :goto_38f
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 913
    .line 914
    .line 915
    move-result-wide v7

    .line 916
    long-to-int v7, v7

    .line 917
    invoke-static {v7}, Lsa;->F(I)Llg0;

    .line 918
    .line 919
    .line 920
    move-result-object v69

    .line 921
    move/from16 v7, v25

    .line 922
    .line 923
    invoke-interface {v1, v7}, Lqq0;->getBlob(I)[B

    .line 924
    .line 925
    .line 926
    move-result-object v7

    .line 927
    invoke-static {v7}, Lsa;->T([B)Ljg0;

    .line 928
    .line 929
    .line 930
    move-result-object v68

    .line 931
    move/from16 v7, v26

    .line 932
    .line 933
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 934
    .line 935
    .line 936
    move-result-wide v7

    .line 937
    long-to-int v7, v7

    .line 938
    if-eqz v7, :cond_3b0

    .line 939
    .line 940
    const/16 v70, 0x1

    .line 941
    .line 942
    :goto_3ad
    move/from16 v7, v27

    .line 943
    .line 944
    goto :goto_3b3

    .line 945
    :cond_3b0
    const/16 v70, 0x0

    .line 946
    .line 947
    goto :goto_3ad

    .line 948
    :goto_3b3
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 949
    .line 950
    .line 951
    move-result-wide v7

    .line 952
    long-to-int v7, v7

    .line 953
    if-eqz v7, :cond_3bf

    .line 954
    .line 955
    const/16 v71, 0x1

    .line 956
    .line 957
    :goto_3bc
    move/from16 v7, v28

    .line 958
    .line 959
    goto :goto_3c2

    .line 960
    :cond_3bf
    const/16 v71, 0x0

    .line 961
    .line 962
    goto :goto_3bc

    .line 963
    :goto_3c2
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 964
    .line 965
    .line 966
    move-result-wide v7

    .line 967
    long-to-int v7, v7

    .line 968
    if-eqz v7, :cond_3ce

    .line 969
    .line 970
    const/16 v72, 0x1

    .line 971
    .line 972
    :goto_3cb
    move/from16 v7, v29

    .line 973
    .line 974
    goto :goto_3d1

    .line 975
    :cond_3ce
    const/16 v72, 0x0

    .line 976
    .line 977
    goto :goto_3cb

    .line 978
    :goto_3d1
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 979
    .line 980
    .line 981
    move-result-wide v7

    .line 982
    long-to-int v7, v7

    .line 983
    if-eqz v7, :cond_3dd

    .line 984
    .line 985
    const/16 v73, 0x1

    .line 986
    .line 987
    :goto_3da
    move/from16 v7, v30

    .line 988
    .line 989
    goto :goto_3e0

    .line 990
    :cond_3dd
    const/16 v73, 0x0

    .line 991
    .line 992
    goto :goto_3da

    .line 993
    :goto_3e0
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 994
    .line 995
    .line 996
    move-result-wide v74

    .line 997
    move/from16 v7, v31

    .line 998
    .line 999
    invoke-interface {v1, v7}, Lqq0;->getLong(I)J

    .line 1000
    .line 1001
    .line 1002
    move-result-wide v76

    .line 1003
    invoke-interface {v1, v0}, Lqq0;->getBlob(I)[B

    .line 1004
    .line 1005
    .line 1006
    move-result-object v0

    .line 1007
    invoke-static {v0}, Lsa;->i([B)Ljava/util/LinkedHashSet;

    .line 1008
    .line 1009
    .line 1010
    move-result-object v78

    .line 1011
    new-instance v46, Lyg;

    .line 1012
    .line 1013
    move-object/from16 v67, v46

    .line 1014
    .line 1015
    invoke-direct/range {v67 .. v78}, Lyg;-><init>(Ljg0;Llg0;ZZZZJJLjava/util/Set;)V

    .line 1016
    .line 1017
    .line 1018
    move-object/from16 v46, v67

    .line 1019
    .line 1020
    new-instance v33, Lne1;

    .line 1021
    .line 1022
    move/from16 v59, v2

    .line 1023
    .line 1024
    move/from16 v60, v3

    .line 1025
    .line 1026
    move/from16 v47, v4

    .line 1027
    .line 1028
    move/from16 v63, v5

    .line 1029
    .line 1030
    move/from16 v64, v6

    .line 1031
    .line 1032
    invoke-direct/range {v33 .. v66}, Lne1;-><init>(Ljava/lang/String;Lde1;Ljava/lang/String;Ljava/lang/String;Lak;Lak;JJJLyg;ILv9;JJJJZLej0;IIJIILjava/lang/String;Ljava/lang/Boolean;)V
    :try_end_40a
    .catchall {:try_start_1cd .. :try_end_40a} :catchall_389

    .line 1033
    .line 1034
    .line 1035
    move-object/from16 v2, v33

    .line 1036
    .line 1037
    goto :goto_40e

    .line 1038
    :cond_40d
    const/4 v2, 0x0

    .line 1039
    :goto_40e
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1040
    .line 1041
    .line 1042
    return-object v2

    .line 1043
    :goto_412
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1044
    .line 1045
    .line 1046
    throw v0

    .line 1047
    :pswitch_416
    move-object/from16 v1, p1

    .line 1048
    .line 1049
    check-cast v1, Loq0;

    .line 1050
    .line 1051
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1052
    .line 1053
    .line 1054
    const-string v2, "DELETE from WorkProgress where work_spec_id=?"

    .line 1055
    .line 1056
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 1057
    .line 1058
    .line 1059
    move-result-object v1

    .line 1060
    const/4 v2, 0x1

    .line 1061
    :try_start_424
    invoke-interface {v1, v2, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 1062
    .line 1063
    .line 1064
    invoke-interface {v1}, Lqq0;->v()Z
    :try_end_42a
    .catchall {:try_start_424 .. :try_end_42a} :catchall_430

    .line 1065
    .line 1066
    .line 1067
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1068
    .line 1069
    .line 1070
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1071
    .line 1072
    return-object v0

    .line 1073
    :catchall_430
    move-exception v0

    .line 1074
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1075
    .line 1076
    .line 1077
    throw v0

    .line 1078
    :pswitch_435
    move-object/from16 v1, p1

    .line 1079
    .line 1080
    check-cast v1, Loq0;

    .line 1081
    .line 1082
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1083
    .line 1084
    .line 1085
    const-string v2, "SELECT name FROM workname WHERE work_spec_id=?"

    .line 1086
    .line 1087
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 1088
    .line 1089
    .line 1090
    move-result-object v1

    .line 1091
    const/4 v2, 0x1

    .line 1092
    :try_start_443
    invoke-interface {v1, v2, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 1093
    .line 1094
    .line 1095
    new-instance v0, Ljava/util/ArrayList;

    .line 1096
    .line 1097
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1098
    .line 1099
    .line 1100
    :goto_44b
    invoke-interface {v1}, Lqq0;->v()Z

    .line 1101
    .line 1102
    .line 1103
    move-result v2

    .line 1104
    if-eqz v2, :cond_45c

    .line 1105
    .line 1106
    const/4 v2, 0x0

    .line 1107
    invoke-interface {v1, v2}, Lqq0;->f(I)Ljava/lang/String;

    .line 1108
    .line 1109
    .line 1110
    move-result-object v3

    .line 1111
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_459
    .catchall {:try_start_443 .. :try_end_459} :catchall_45a

    .line 1112
    .line 1113
    .line 1114
    goto :goto_44b

    .line 1115
    :catchall_45a
    move-exception v0

    .line 1116
    goto :goto_460

    .line 1117
    :cond_45c
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1118
    .line 1119
    .line 1120
    return-object v0

    .line 1121
    :goto_460
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1122
    .line 1123
    .line 1124
    throw v0

    .line 1125
    :pswitch_464
    move-object/from16 v1, p1

    .line 1126
    .line 1127
    check-cast v1, Loq0;

    .line 1128
    .line 1129
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1130
    .line 1131
    .line 1132
    const-string v2, "DELETE FROM SystemIdInfo where work_spec_id=?"

    .line 1133
    .line 1134
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 1135
    .line 1136
    .line 1137
    move-result-object v1

    .line 1138
    const/4 v2, 0x1

    .line 1139
    :try_start_472
    invoke-interface {v1, v2, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 1140
    .line 1141
    .line 1142
    invoke-interface {v1}, Lqq0;->v()Z
    :try_end_478
    .catchall {:try_start_472 .. :try_end_478} :catchall_47e

    .line 1143
    .line 1144
    .line 1145
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1146
    .line 1147
    .line 1148
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1149
    .line 1150
    return-object v0

    .line 1151
    :catchall_47e
    move-exception v0

    .line 1152
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1153
    .line 1154
    .line 1155
    throw v0

    .line 1156
    :pswitch_483
    move-object/from16 v1, p1

    .line 1157
    .line 1158
    check-cast v1, Loq0;

    .line 1159
    .line 1160
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1161
    .line 1162
    .line 1163
    const-string v2, "SELECT long_value FROM Preference where `key`=?"

    .line 1164
    .line 1165
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 1166
    .line 1167
    .line 1168
    move-result-object v1

    .line 1169
    const/4 v2, 0x1

    .line 1170
    :try_start_491
    invoke-interface {v1, v2, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 1171
    .line 1172
    .line 1173
    invoke-interface {v1}, Lqq0;->v()Z

    .line 1174
    .line 1175
    .line 1176
    move-result v0

    .line 1177
    if-eqz v0, :cond_4a1

    .line 1178
    .line 1179
    const/4 v2, 0x0

    .line 1180
    invoke-interface {v1, v2}, Lqq0;->isNull(I)Z

    .line 1181
    .line 1182
    .line 1183
    move-result v0

    .line 1184
    if-eqz v0, :cond_4a3

    .line 1185
    .line 1186
    :cond_4a1
    const/4 v2, 0x0

    .line 1187
    goto :goto_4ae

    .line 1188
    :cond_4a3
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 1189
    .line 1190
    .line 1191
    move-result-wide v2

    .line 1192
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1193
    .line 1194
    .line 1195
    move-result-object v2
    :try_end_4ab
    .catchall {:try_start_491 .. :try_end_4ab} :catchall_4ac

    .line 1196
    goto :goto_4ae

    .line 1197
    :catchall_4ac
    move-exception v0

    .line 1198
    goto :goto_4b2

    .line 1199
    :goto_4ae
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1200
    .line 1201
    .line 1202
    return-object v2

    .line 1203
    :goto_4b2
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1204
    .line 1205
    .line 1206
    throw v0

    .line 1207
    :pswitch_4b6
    move-object/from16 v1, p1

    .line 1208
    .line 1209
    check-cast v1, Loq0;

    .line 1210
    .line 1211
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1212
    .line 1213
    .line 1214
    const-string v2, "SELECT COUNT(*)=0 FROM dependency WHERE work_spec_id=? AND prerequisite_id IN (SELECT id FROM workspec WHERE state!=2)"

    .line 1215
    .line 1216
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 1217
    .line 1218
    .line 1219
    move-result-object v1

    .line 1220
    const/4 v2, 0x1

    .line 1221
    :try_start_4c4
    invoke-interface {v1, v2, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 1222
    .line 1223
    .line 1224
    invoke-interface {v1}, Lqq0;->v()Z

    .line 1225
    .line 1226
    .line 1227
    move-result v0

    .line 1228
    if-eqz v0, :cond_4d9

    .line 1229
    .line 1230
    const/4 v2, 0x0

    .line 1231
    invoke-interface {v1, v2}, Lqq0;->getLong(I)J

    .line 1232
    .line 1233
    .line 1234
    move-result-wide v3
    :try_end_4d2
    .catchall {:try_start_4c4 .. :try_end_4d2} :catchall_4d7

    .line 1235
    long-to-int v0, v3

    .line 1236
    if-eqz v0, :cond_4d9

    .line 1237
    .line 1238
    const/4 v3, 0x1

    .line 1239
    goto :goto_4da

    .line 1240
    :catchall_4d7
    move-exception v0

    .line 1241
    goto :goto_4e2

    .line 1242
    :cond_4d9
    const/4 v3, 0x0

    .line 1243
    :goto_4da
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1244
    .line 1245
    .line 1246
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1247
    .line 1248
    .line 1249
    move-result-object v0

    .line 1250
    return-object v0

    .line 1251
    :goto_4e2
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1252
    .line 1253
    .line 1254
    throw v0

    .line 1255
    :pswitch_4e6
    move-object/from16 v1, p1

    .line 1256
    .line 1257
    check-cast v1, Loq0;

    .line 1258
    .line 1259
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1260
    .line 1261
    .line 1262
    const-string v2, "SELECT work_spec_id FROM dependency WHERE prerequisite_id=?"

    .line 1263
    .line 1264
    invoke-interface {v1, v2}, Loq0;->x(Ljava/lang/String;)Lqq0;

    .line 1265
    .line 1266
    .line 1267
    move-result-object v1

    .line 1268
    const/4 v2, 0x1

    .line 1269
    :try_start_4f4
    invoke-interface {v1, v2, v0}, Lqq0;->s(ILjava/lang/String;)V

    .line 1270
    .line 1271
    .line 1272
    new-instance v0, Ljava/util/ArrayList;

    .line 1273
    .line 1274
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 1275
    .line 1276
    .line 1277
    :goto_4fc
    invoke-interface {v1}, Lqq0;->v()Z

    .line 1278
    .line 1279
    .line 1280
    move-result v2

    .line 1281
    if-eqz v2, :cond_50d

    .line 1282
    .line 1283
    const/4 v2, 0x0

    .line 1284
    invoke-interface {v1, v2}, Lqq0;->f(I)Ljava/lang/String;

    .line 1285
    .line 1286
    .line 1287
    move-result-object v3

    .line 1288
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_50a
    .catchall {:try_start_4f4 .. :try_end_50a} :catchall_50b

    .line 1289
    .line 1290
    .line 1291
    goto :goto_4fc

    .line 1292
    :catchall_50b
    move-exception v0

    .line 1293
    goto :goto_511

    .line 1294
    :cond_50d
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1295
    .line 1296
    .line 1297
    return-object v0

    .line 1298
    :goto_511
    invoke-interface {v1}, Ljava/lang/AutoCloseable;->close()V

    .line 1299
    .line 1300
    .line 1301
    throw v0

    .line 1302
    nop

    .line 1303
    :pswitch_data_516
    .packed-switch 0x0
        :pswitch_4e6
        :pswitch_4b6
        :pswitch_483
        :pswitch_464
        :pswitch_435
        :pswitch_416
        :pswitch_1c0
        :pswitch_182
        :pswitch_155
        :pswitch_131
        :pswitch_10d
        :pswitch_ef
        :pswitch_bc
        :pswitch_98
        :pswitch_7a
        :pswitch_38
    .end packed-switch
.end method
