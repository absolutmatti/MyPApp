###### Class defpackage.hp0 (hp0)
.class public Lhp0;
.super Landroid/app/Fragment;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lhp0$a;
    }
.end annotation


# static fields
.field public static final synthetic g:I


# instance fields
.field public f:Lnw;


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Landroid/app/Fragment;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method


# virtual methods
.method public final a(Lg80;)V
    .registers 4

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    if-ge v0, v1, :cond_10

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/app/Fragment;->getActivity()Landroid/app/Activity;

    .line 8
    .line 9
    .line 10
    move-result-object p0

    .line 11
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    .line 13
    .line 14
    invoke-static {p0, p1}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 15
    .line 16
    .line 17
    :cond_10
    return-void
.end method

.method public final onActivityCreated(Landroid/os/Bundle;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroid/app/Fragment;->onActivityCreated(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    sget-object p1, Lg80;->ON_CREATE:Lg80;

    .line 5
    .line 6
    invoke-virtual {p0, p1}, Lhp0;->a(Lg80;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final onDestroy()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/app/Fragment;->onDestroy()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lg80;->ON_DESTROY:Lg80;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lhp0;->a(Lg80;)V

    .line 7
    .line 8
    .line 9
    const/4 v0, 0x0

    .line 10
    iput-object v0, p0, Lhp0;->f:Lnw;

    .line 11
    .line 12
    return-void
.end method

.method public final onPause()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/app/Fragment;->onPause()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lg80;->ON_PAUSE:Lg80;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lhp0;->a(Lg80;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final onResume()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/app/Fragment;->onResume()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lhp0;->f:Lnw;

    .line 5
    .line 6
    if-eqz v0, :cond_e

    .line 7
    .line 8
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lmm0;

    .line 11
    .line 12
    invoke-virtual {v0}, Lmm0;->a()V

    .line 13
    .line 14
    .line 15
    :cond_e
    sget-object v0, Lg80;->ON_RESUME:Lg80;

    .line 16
    .line 17
    invoke-virtual {p0, v0}, Lhp0;->a(Lg80;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final onStart()V
    .registers 4

    .line 1
    invoke-super {p0}, Landroid/app/Fragment;->onStart()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lhp0;->f:Lnw;

    .line 5
    .line 6
    if-eqz v0, :cond_21

    .line 7
    .line 8
    iget-object v0, v0, Lnw;->g:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Lmm0;

    .line 11
    .line 12
    iget v1, v0, Lmm0;->f:I

    .line 13
    .line 14
    const/4 v2, 0x1

    .line 15
    add-int/2addr v1, v2

    .line 16
    iput v1, v0, Lmm0;->f:I

    .line 17
    .line 18
    if-ne v1, v2, :cond_21

    .line 19
    .line 20
    iget-boolean v1, v0, Lmm0;->i:Z

    .line 21
    .line 22
    if-eqz v1, :cond_21

    .line 23
    .line 24
    iget-object v1, v0, Lmm0;->k:Lr80;

    .line 25
    .line 26
    sget-object v2, Lg80;->ON_START:Lg80;

    .line 27
    .line 28
    invoke-virtual {v1, v2}, Lr80;->e(Lg80;)V

    .line 29
    .line 30
    .line 31
    const/4 v1, 0x0

    .line 32
    iput-boolean v1, v0, Lmm0;->i:Z

    .line 33
    .line 34
    :cond_21
    sget-object v0, Lg80;->ON_START:Lg80;

    .line 35
    .line 36
    invoke-virtual {p0, v0}, Lhp0;->a(Lg80;)V

    .line 37
    .line 38
    .line 39
    return-void
.end method

.method public final onStop()V
    .registers 2

    .line 1
    invoke-super {p0}, Landroid/app/Fragment;->onStop()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lg80;->ON_STOP:Lg80;

    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lhp0;->a(Lg80;)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

###### Class hp0.a (hp0$a)
.class public final Lhp0$a;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroid/app/Application$ActivityLifecycleCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lhp0;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field public static final Companion:Lgp0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lgp0;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lhp0$a;->Companion:Lgp0;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public static final registerIn(Landroid/app/Activity;)V
    .registers 2

    .line 1
    sget-object v0, Lhp0$a;->Companion:Lgp0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    .line 8
    .line 9
    new-instance v0, Lhp0$a;

    .line 10
    .line 11
    invoke-direct {v0}, Lhp0$a;-><init>()V

    .line 12
    .line 13
    .line 14
    invoke-static {p0, v0}, Ln30;->n(Landroid/app/Activity;Lhp0$a;)V

    .line 15
    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onActivityDestroyed(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onActivityPaused(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onActivityPostCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget p0, Lhp0;->g:I

    .line 5
    .line 6
    sget-object p0, Lg80;->ON_CREATE:Lg80;

    .line 7
    .line 8
    invoke-static {p1, p0}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onActivityPostResumed(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget p0, Lhp0;->g:I

    .line 5
    .line 6
    sget-object p0, Lg80;->ON_RESUME:Lg80;

    .line 7
    .line 8
    invoke-static {p1, p0}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onActivityPostStarted(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget p0, Lhp0;->g:I

    .line 5
    .line 6
    sget-object p0, Lg80;->ON_START:Lg80;

    .line 7
    .line 8
    invoke-static {p1, p0}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onActivityPreDestroyed(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget p0, Lhp0;->g:I

    .line 5
    .line 6
    sget-object p0, Lg80;->ON_DESTROY:Lg80;

    .line 7
    .line 8
    invoke-static {p1, p0}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onActivityPrePaused(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget p0, Lhp0;->g:I

    .line 5
    .line 6
    sget-object p0, Lg80;->ON_PAUSE:Lg80;

    .line 7
    .line 8
    invoke-static {p1, p0}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onActivityPreStopped(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget p0, Lhp0;->g:I

    .line 5
    .line 6
    sget-object p0, Lg80;->ON_STOP:Lg80;

    .line 7
    .line 8
    invoke-static {p1, p0}, Lfp0;->a(Landroid/app/Activity;Lg80;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onActivityResumed(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 3

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onActivityStarted(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onActivityStopped(Landroid/app/Activity;)V
    .registers 2

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    return-void
.end method
