###### Class defpackage.kw (kw)
.class public final Lkw;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:F

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:I

.field public o:I

.field public p:I

.field public q:I

.field public r:I

.field public s:I

.field public t:I

.field public u:I

.field public v:I

.field public w:I

.field public x:I

.field public final y:Ljava/util/ArrayList;

.field public final z:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/high16 v0, 0x3f800000    # 1.0f

    .line 5
    .line 6
    iput v0, p0, Lkw;->a:F

    .line 7
    .line 8
    const/4 v0, 0x0

    .line 9
    iput v0, p0, Lkw;->b:I

    .line 10
    .line 11
    iput v0, p0, Lkw;->c:I

    .line 12
    .line 13
    iput v0, p0, Lkw;->d:I

    .line 14
    .line 15
    iput v0, p0, Lkw;->e:I

    .line 16
    .line 17
    iput v0, p0, Lkw;->f:I

    .line 18
    .line 19
    iput v0, p0, Lkw;->g:I

    .line 20
    .line 21
    iput v0, p0, Lkw;->h:I

    .line 22
    .line 23
    iput v0, p0, Lkw;->i:I

    .line 24
    .line 25
    iput v0, p0, Lkw;->j:I

    .line 26
    .line 27
    iput v0, p0, Lkw;->k:I

    .line 28
    .line 29
    iput v0, p0, Lkw;->l:I

    .line 30
    .line 31
    iput v0, p0, Lkw;->m:I

    .line 32
    .line 33
    iput v0, p0, Lkw;->n:I

    .line 34
    .line 35
    iput v0, p0, Lkw;->o:I

    .line 36
    .line 37
    iput v0, p0, Lkw;->p:I

    .line 38
    .line 39
    iput v0, p0, Lkw;->q:I

    .line 40
    .line 41
    iput v0, p0, Lkw;->r:I

    .line 42
    .line 43
    iput v0, p0, Lkw;->s:I

    .line 44
    .line 45
    const/4 v0, -0x1

    .line 46
    iput v0, p0, Lkw;->t:I

    .line 47
    .line 48
    iput v0, p0, Lkw;->u:I

    .line 49
    .line 50
    iput v0, p0, Lkw;->v:I

    .line 51
    .line 52
    iput v0, p0, Lkw;->w:I

    .line 53
    .line 54
    iput v0, p0, Lkw;->x:I

    .line 55
    .line 56
    new-instance v0, Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 59
    .line 60
    .line 61
    iput-object v0, p0, Lkw;->y:Ljava/util/ArrayList;

    .line 62
    .line 63
    new-instance v0, Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 66
    .line 67
    .line 68
    iput-object v0, p0, Lkw;->z:Ljava/util/ArrayList;

    .line 69
    .line 70
    return-void
.end method
