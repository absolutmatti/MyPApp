###### Class defpackage.d8 (d8)
.class public final Ld8;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lja;
.implements Lio/flutter/plugins/sharedpreferences/SharedPreferencesAsyncApi;
.implements Lr71;


# static fields
.field public static volatile i:Ld8;

.field public static final j:Ljava/lang/Object;

.field public static k:Ld8;

.field public static l:Ld8;


# instance fields
.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Ld8;->j:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>(I)V
    .registers 3

    packed-switch p1, :pswitch_data_22

    .line 130
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 131
    new-instance p1, Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    return-void

    .line 132
    :pswitch_e
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 133
    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    sget-object v0, Lt51;->p:Lt31;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    .line 134
    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld8;->g:Ljava/lang/Object;

    return-void

    :pswitch_data_22
    .packed-switch 0x11
        :pswitch_e
    .end packed-switch
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .registers 3

    packed-switch p2, :pswitch_data_28

    .line 122
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 123
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Ld8;->h:Ljava/lang/Object;

    .line 124
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, Ld8;->g:Ljava/lang/Object;

    .line 125
    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    return-void

    .line 126
    :pswitch_1b
    new-instance p2, Lo71;

    invoke-direct {p2, p1}, Lo71;-><init>(Landroid/content/Context;)V

    .line 127
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 128
    iput-object p1, p0, Ld8;->h:Ljava/lang/Object;

    .line 129
    iput-object p2, p0, Ld8;->f:Ljava/lang/Object;

    return-void

    :pswitch_data_28
    .packed-switch 0x14
        :pswitch_1b
    .end packed-switch
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V
    .registers 3

    .line 119
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 120
    iput-object p1, p0, Ld8;->h:Ljava/lang/Object;

    .line 121
    iput-object p2, p0, Ld8;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Liq0;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 135
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 136
    iput-object p1, p0, Ld8;->h:Ljava/lang/Object;

    .line 137
    iput-object p2, p0, Ld8;->f:Ljava/lang/Object;

    .line 138
    sget-object p1, Ltn;->a:Lam;

    .line 139
    sget-object p1, Lxl;->h:Lxl;

    const/4 p2, 0x1

    .line 140
    invoke-virtual {p1, p2}, Lxl;->B(I)Lbi;

    move-result-object p1

    .line 141
    iput-object p1, p0, Ld8;->g:Ljava/lang/Object;

    .line 142
    :try_start_18
    new-instance p1, Lio/flutter/plugins/sharedpreferences/SharedPreferencesAsyncApiRegistrar;

    invoke-direct {p1}, Lio/flutter/plugins/sharedpreferences/SharedPreferencesAsyncApiRegistrar;-><init>()V

    const-string p2, "shared_preferences"

    invoke-virtual {p1, p0, p2}, Lio/flutter/plugins/sharedpreferences/SharedPreferencesAsyncApiRegistrar;->register(Lio/flutter/plugins/sharedpreferences/SharedPreferencesAsyncApi;Ljava/lang/String;)Lio/flutter/plugins/sharedpreferences/SharedPreferencesAsyncApiRegistrar;
    :try_end_22
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_22} :catch_23

    return-void

    :catch_23
    move-exception p0

    .line 143
    const-string p1, "SharedPreferencesPlugin"

    const-string p2, "Received exception while setting up SharedPreferencesBackend"

    invoke-static {p1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .registers 38

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    iput-object v1, v0, Ld8;->f:Ljava/lang/Object;

    .line 14
    .line 15
    new-instance v2, Lne1;

    .line 16
    .line 17
    iget-object v1, v0, Ld8;->f:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v1, Ljava/util/UUID;

    .line 20
    .line 21
    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 29
    .line 30
    .line 31
    move-result-object v5

    .line 32
    const/16 v34, 0x0

    .line 33
    .line 34
    const v35, 0x1fffffa

    .line 35
    .line 36
    .line 37
    const/4 v4, 0x0

    .line 38
    const/4 v6, 0x0

    .line 39
    const/4 v7, 0x0

    .line 40
    const/4 v8, 0x0

    .line 41
    const-wide/16 v9, 0x0

    .line 42
    .line 43
    const-wide/16 v11, 0x0

    .line 44
    .line 45
    const-wide/16 v13, 0x0

    .line 46
    .line 47
    const/4 v15, 0x0

    .line 48
    const/16 v16, 0x0

    .line 49
    .line 50
    const/16 v17, 0x0

    .line 51
    .line 52
    const-wide/16 v18, 0x0

    .line 53
    .line 54
    const-wide/16 v20, 0x0

    .line 55
    .line 56
    const-wide/16 v22, 0x0

    .line 57
    .line 58
    const-wide/16 v24, 0x0

    .line 59
    .line 60
    const/16 v26, 0x0

    .line 61
    .line 62
    const/16 v27, 0x0

    .line 63
    .line 64
    const/16 v28, 0x0

    .line 65
    .line 66
    const-wide/16 v29, 0x0

    .line 67
    .line 68
    const/16 v31, 0x0

    .line 69
    .line 70
    const/16 v32, 0x0

    .line 71
    .line 72
    const/16 v33, 0x0

    .line 73
    .line 74
    invoke-direct/range {v2 .. v35}, Lne1;-><init>(Ljava/lang/String;Lde1;Ljava/lang/String;Ljava/lang/String;Lak;Lak;JJJLyg;ILv9;JJJJZLej0;IJIILjava/lang/String;Ljava/lang/Boolean;I)V

    .line 75
    .line 76
    .line 77
    iput-object v2, v0, Ld8;->g:Ljava/lang/Object;

    .line 78
    .line 79
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    filled-new-array {v1}, [Ljava/lang/String;

    .line 84
    .line 85
    .line 86
    move-result-object v1

    .line 87
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 88
    .line 89
    const/4 v3, 0x1

    .line 90
    invoke-static {v3}, Lwb0;->V(I)I

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    invoke-direct {v2, v3}, Ljava/util/LinkedHashSet;-><init>(I)V

    .line 95
    .line 96
    .line 97
    const/4 v3, 0x0

    .line 98
    aget-object v1, v1, v3

    .line 99
    .line 100
    invoke-interface {v2, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 101
    .line 102
    .line 103
    iput-object v2, v0, Ld8;->h:Ljava/lang/Object;

    .line 104
    .line 105
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 118
    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    iput-object p2, p0, Ld8;->g:Ljava/lang/Object;

    iput-object p3, p0, Ld8;->h:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Liy0;Ljava/lang/Integer;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 106
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    iput-object p2, p0, Ld8;->g:Ljava/lang/Object;

    iput-object p3, p0, Ld8;->h:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lla;Ljava/lang/String;)V
    .registers 4

    .line 111
    sget-object v0, Lzz0;->f:Lzz0;

    .line 112
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 113
    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    .line 114
    iput-object p2, p0, Ld8;->g:Ljava/lang/Object;

    .line 115
    iput-object v0, p0, Ld8;->h:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lo91;Ln91;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 116
    sget-object v0, Loi;->b:Loi;

    .line 117
    invoke-direct {p0, p1, p2, v0}, Ld8;-><init>(Lo91;Ln91;Lpi;)V

    return-void
.end method

.method public constructor <init>(Lo91;Ln91;Lpi;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 108
    iput-object p1, p0, Ld8;->f:Ljava/lang/Object;

    .line 109
    iput-object p2, p0, Ld8;->g:Ljava/lang/Object;

    .line 110
    iput-object p3, p0, Ld8;->h:Ljava/lang/Object;

    return-void
.end method

.method public static final a(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;)Landroid/content/SharedPreferences;
    .registers 4

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;->getFileName()Ljava/lang/String;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast p0, Landroid/content/Context;

    .line 11
    .line 12
    const/4 v1, 0x0

    .line 13
    if-nez v0, :cond_2b

    .line 14
    .line 15
    new-instance p1, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    .line 26
    .line 27
    const-string v0, "_preferences"

    .line 28
    .line 29
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 30
    .line 31
    .line 32
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    move-result-object p1

    .line 36
    invoke-virtual {p0, p1, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 37
    .line 38
    .line 39
    move-result-object p0

    .line 40
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 41
    .line 42
    .line 43
    return-object p0

    .line 44
    :cond_2b
    invoke-virtual {p1}, Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;->getFileName()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p1

    .line 48
    invoke-virtual {p0, p1, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    .line 49
    .line 50
    .line 51
    move-result-object p0

    .line 52
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    .line 54
    .line 55
    return-object p0
.end method

.method public static h(Ljava/util/Map;)Landroid/os/Bundle;
    .registers 5

    .line 1
    new-instance v0, Landroid/os/Bundle;

    .line 2
    .line 3
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-interface {p0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    :goto_d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-eqz v2, :cond_23

    .line 19
    .line 20
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Ljava/lang/String;

    .line 25
    .line 26
    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    check-cast v3, Ljava/lang/String;

    .line 31
    .line 32
    invoke-virtual {v0, v2, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    .line 33
    .line 34
    .line 35
    goto :goto_d

    .line 36
    :cond_23
    return-object v0
.end method

.method public static o(Landroid/content/Context;)Ld8;
    .registers 4

    .line 1
    sget-object v0, Ld8;->i:Ld8;

    .line 2
    .line 3
    if-nez v0, :cond_1a

    .line 4
    .line 5
    sget-object v0, Ld8;->j:Ljava/lang/Object;

    .line 6
    .line 7
    monitor-enter v0

    .line 8
    :try_start_7
    sget-object v1, Ld8;->i:Ld8;

    .line 9
    .line 10
    if-nez v1, :cond_16

    .line 11
    .line 12
    new-instance v1, Ld8;

    .line 13
    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-direct {v1, p0, v2}, Ld8;-><init>(Landroid/content/Context;I)V

    .line 16
    .line 17
    .line 18
    sput-object v1, Ld8;->i:Ld8;

    .line 19
    .line 20
    goto :goto_16

    .line 21
    :catchall_14
    move-exception p0

    .line 22
    goto :goto_18

    .line 23
    :cond_16
    :goto_16
    monitor-exit v0

    .line 24
    goto :goto_1a

    .line 25
    :goto_18
    monitor-exit v0
    :try_end_19
    .catchall {:try_start_7 .. :try_end_19} :catchall_14

    .line 26
    throw p0

    .line 27
    :cond_1a
    :goto_1a
    sget-object p0, Ld8;->i:Ld8;

    .line 28
    .line 29
    return-object p0
.end method

.method public static q()Ld8;
    .registers 5

    .line 1
    sget-object v0, Ld8;->k:Ld8;

    .line 2
    .line 3
    if-nez v0, :cond_36

    .line 4
    .line 5
    new-instance v0, Liq0;

    .line 6
    .line 7
    const/16 v1, 0x15

    .line 8
    .line 9
    invoke-direct {v0, v1}, Liq0;-><init>(I)V

    .line 10
    .line 11
    .line 12
    new-instance v1, Luv;

    .line 13
    .line 14
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 15
    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    iput v2, v1, Luv;->a:I

    .line 19
    .line 20
    invoke-static {v1}, Ljava/util/concurrent/Executors;->newCachedThreadPool(Ljava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    new-instance v3, Law;

    .line 25
    .line 26
    new-instance v4, Lio/flutter/embedding/engine/FlutterJNI;

    .line 27
    .line 28
    invoke-direct {v4}, Lio/flutter/embedding/engine/FlutterJNI;-><init>()V

    .line 29
    .line 30
    .line 31
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 32
    .line 33
    .line 34
    iput-boolean v2, v3, Law;->a:Z

    .line 35
    .line 36
    iput-boolean v2, v3, Law;->b:Z

    .line 37
    .line 38
    iput-object v4, v3, Law;->f:Lio/flutter/embedding/engine/FlutterJNI;

    .line 39
    .line 40
    iput-object v1, v3, Law;->g:Ljava/util/concurrent/ExecutorService;

    .line 41
    .line 42
    new-instance v2, Ld8;

    .line 43
    .line 44
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 45
    .line 46
    .line 47
    iput-object v3, v2, Ld8;->f:Ljava/lang/Object;

    .line 48
    .line 49
    iput-object v0, v2, Ld8;->g:Ljava/lang/Object;

    .line 50
    .line 51
    iput-object v1, v2, Ld8;->h:Ljava/lang/Object;

    .line 52
    .line 53
    sput-object v2, Ld8;->k:Ld8;

    .line 54
    .line 55
    :cond_36
    sget-object v0, Ld8;->k:Ld8;

    .line 56
    .line 57
    return-object v0
.end method

.method public static r(Landroid/content/Context;Landroid/util/AttributeSet;[II)Ld8;
    .registers 6

    .line 1
    new-instance v0, Ld8;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-virtual {p0, p1, p2, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-direct {v0, p0, p1}, Ld8;-><init>(Landroid/content/Context;Landroid/content/res/TypedArray;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method


# virtual methods
.method public A(Ler;)V
    .registers 6

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lla;

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    if-nez p1, :cond_c

    .line 11
    .line 12
    goto :goto_1d

    .line 13
    :cond_c
    new-instance v3, Ld8;

    .line 14
    .line 15
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object p0, v3, Ld8;->h:Ljava/lang/Object;

    .line 19
    .line 20
    new-instance p0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    .line 22
    invoke-direct {p0, v2}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 23
    .line 24
    .line 25
    iput-object p0, v3, Ld8;->g:Ljava/lang/Object;

    .line 26
    .line 27
    iput-object p1, v3, Ld8;->f:Ljava/lang/Object;

    .line 28
    .line 29
    move-object v2, v3

    .line 30
    :goto_1d
    invoke-interface {v1, v0, v2}, Lla;->e(Ljava/lang/String;Lja;)V

    .line 31
    .line 32
    .line 33
    return-void
.end method

.method public b()Lai0;
    .registers 41

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Lai0;

    .line 4
    .line 5
    iget-object v2, v0, Ld8;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v2, Ljava/util/UUID;

    .line 8
    .line 9
    iget-object v3, v0, Ld8;->g:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v3, Lne1;

    .line 12
    .line 13
    iget-object v4, v0, Ld8;->h:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v4, Ljava/util/Set;

    .line 16
    .line 17
    invoke-direct {v1, v2, v3, v4}, Lai0;-><init>(Ljava/util/UUID;Lne1;Ljava/util/Set;)V

    .line 18
    .line 19
    .line 20
    iget-object v2, v0, Ld8;->g:Ljava/lang/Object;

    .line 21
    .line 22
    check-cast v2, Lne1;

    .line 23
    .line 24
    iget-object v2, v2, Lne1;->j:Lyg;

    .line 25
    .line 26
    iget-object v3, v2, Lyg;->i:Ljava/util/Set;

    .line 27
    .line 28
    check-cast v3, Ljava/util/Collection;

    .line 29
    .line 30
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    const/4 v4, 0x1

    .line 35
    const/4 v5, 0x0

    .line 36
    if-eqz v3, :cond_34

    .line 37
    .line 38
    iget-boolean v3, v2, Lyg;->e:Z

    .line 39
    .line 40
    if-nez v3, :cond_34

    .line 41
    .line 42
    iget-boolean v3, v2, Lyg;->c:Z

    .line 43
    .line 44
    if-nez v3, :cond_34

    .line 45
    .line 46
    iget-boolean v2, v2, Lyg;->d:Z

    .line 47
    .line 48
    if-eqz v2, :cond_32

    .line 49
    .line 50
    goto :goto_34

    .line 51
    :cond_32
    move v2, v5

    .line 52
    goto :goto_35

    .line 53
    :cond_34
    :goto_34
    move v2, v4

    .line 54
    :goto_35
    iget-object v3, v0, Ld8;->g:Ljava/lang/Object;

    .line 55
    .line 56
    check-cast v3, Lne1;

    .line 57
    .line 58
    iget-boolean v6, v3, Lne1;->q:Z

    .line 59
    .line 60
    if-eqz v6, :cond_55

    .line 61
    .line 62
    const/4 v6, 0x0

    .line 63
    if-nez v2, :cond_4f

    .line 64
    .line 65
    iget-wide v7, v3, Lne1;->g:J

    .line 66
    .line 67
    const-wide/16 v9, 0x0

    .line 68
    .line 69
    cmp-long v2, v7, v9

    .line 70
    .line 71
    if-gtz v2, :cond_49

    .line 72
    .line 73
    goto :goto_55

    .line 74
    :cond_49
    const-string v0, "Expedited jobs cannot be delayed"

    .line 75
    .line 76
    invoke-static {v0}, Lm0;->v(Ljava/lang/String;)V

    .line 77
    .line 78
    .line 79
    return-object v6

    .line 80
    :cond_4f
    const-string v0, "Expedited jobs only support network and storage constraints"

    .line 81
    .line 82
    invoke-static {v0}, Lm0;->v(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    return-object v6

    .line 86
    :cond_55
    :goto_55
    iget-object v2, v3, Lne1;->x:Ljava/lang/String;

    .line 87
    .line 88
    const/16 v6, 0x7f

    .line 89
    .line 90
    if-nez v2, :cond_88

    .line 91
    .line 92
    iget-object v2, v3, Lne1;->c:Ljava/lang/String;

    .line 93
    .line 94
    const-string v7, "."

    .line 95
    .line 96
    filled-new-array {v7}, [Ljava/lang/String;

    .line 97
    .line 98
    .line 99
    move-result-object v7

    .line 100
    invoke-static {v2, v7}, Ls01;->n0(Ljava/lang/CharSequence;[Ljava/lang/String;)Ljava/util/List;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 105
    .line 106
    .line 107
    move-result v7

    .line 108
    if-ne v7, v4, :cond_74

    .line 109
    .line 110
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 111
    .line 112
    .line 113
    move-result-object v2

    .line 114
    check-cast v2, Ljava/lang/String;

    .line 115
    .line 116
    goto :goto_7a

    .line 117
    :cond_74
    invoke-static {v2}, Lfe;->W(Ljava/util/List;)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v2

    .line 121
    check-cast v2, Ljava/lang/String;

    .line 122
    .line 123
    :goto_7a
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 124
    .line 125
    .line 126
    move-result v4

    .line 127
    if-gt v4, v6, :cond_81

    .line 128
    .line 129
    goto :goto_85

    .line 130
    :cond_81
    invoke-static {v2}, Ls01;->q0(Ljava/lang/String;)Ljava/lang/String;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    :goto_85
    iput-object v2, v3, Lne1;->x:Ljava/lang/String;

    .line 135
    .line 136
    goto :goto_98

    .line 137
    :cond_88
    invoke-virtual {v2}, Ljava/lang/String;->length()I

    .line 138
    .line 139
    .line 140
    move-result v3

    .line 141
    if-le v3, v6, :cond_98

    .line 142
    .line 143
    iget-object v3, v0, Ld8;->g:Ljava/lang/Object;

    .line 144
    .line 145
    check-cast v3, Lne1;

    .line 146
    .line 147
    invoke-static {v2}, Ls01;->q0(Ljava/lang/String;)Ljava/lang/String;

    .line 148
    .line 149
    .line 150
    move-result-object v2

    .line 151
    iput-object v2, v3, Lne1;->x:Ljava/lang/String;

    .line 152
    .line 153
    :cond_98
    :goto_98
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    .line 154
    .line 155
    .line 156
    move-result-object v2

    .line 157
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 158
    .line 159
    .line 160
    iput-object v2, v0, Ld8;->f:Ljava/lang/Object;

    .line 161
    .line 162
    new-instance v3, Lne1;

    .line 163
    .line 164
    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 165
    .line 166
    .line 167
    move-result-object v4

    .line 168
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 169
    .line 170
    .line 171
    iget-object v2, v0, Ld8;->g:Ljava/lang/Object;

    .line 172
    .line 173
    check-cast v2, Lne1;

    .line 174
    .line 175
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 176
    .line 177
    .line 178
    iget-object v6, v2, Lne1;->c:Ljava/lang/String;

    .line 179
    .line 180
    iget-object v5, v2, Lne1;->b:Lde1;

    .line 181
    .line 182
    iget-object v7, v2, Lne1;->d:Ljava/lang/String;

    .line 183
    .line 184
    new-instance v8, Lak;

    .line 185
    .line 186
    iget-object v9, v2, Lne1;->e:Lak;

    .line 187
    .line 188
    invoke-direct {v8, v9}, Lak;-><init>(Lak;)V

    .line 189
    .line 190
    .line 191
    new-instance v9, Lak;

    .line 192
    .line 193
    iget-object v10, v2, Lne1;->f:Lak;

    .line 194
    .line 195
    invoke-direct {v9, v10}, Lak;-><init>(Lak;)V

    .line 196
    .line 197
    .line 198
    iget-wide v10, v2, Lne1;->g:J

    .line 199
    .line 200
    iget-wide v12, v2, Lne1;->h:J

    .line 201
    .line 202
    iget-wide v14, v2, Lne1;->i:J

    .line 203
    .line 204
    move-object/from16 v37, v1

    .line 205
    .line 206
    new-instance v1, Lyg;

    .line 207
    .line 208
    move-object/from16 v16, v3

    .line 209
    .line 210
    iget-object v3, v2, Lne1;->j:Lyg;

    .line 211
    .line 212
    invoke-direct {v1, v3}, Lyg;-><init>(Lyg;)V

    .line 213
    .line 214
    .line 215
    iget v3, v2, Lne1;->k:I

    .line 216
    .line 217
    move-object/from16 v17, v1

    .line 218
    .line 219
    iget-object v1, v2, Lne1;->l:Lv9;

    .line 220
    .line 221
    move/from16 v19, v3

    .line 222
    .line 223
    move-object/from16 v18, v4

    .line 224
    .line 225
    iget-wide v3, v2, Lne1;->m:J

    .line 226
    .line 227
    move-wide/from16 v20, v3

    .line 228
    .line 229
    iget-wide v3, v2, Lne1;->n:J

    .line 230
    .line 231
    move-wide/from16 v22, v3

    .line 232
    .line 233
    iget-wide v3, v2, Lne1;->o:J

    .line 234
    .line 235
    move-wide/from16 v24, v3

    .line 236
    .line 237
    iget-wide v3, v2, Lne1;->p:J

    .line 238
    .line 239
    move-object/from16 v26, v1

    .line 240
    .line 241
    iget-boolean v1, v2, Lne1;->q:Z

    .line 242
    .line 243
    move/from16 v27, v1

    .line 244
    .line 245
    iget-object v1, v2, Lne1;->r:Lej0;

    .line 246
    .line 247
    move-object/from16 v28, v1

    .line 248
    .line 249
    iget v1, v2, Lne1;->s:I

    .line 250
    .line 251
    move-wide/from16 v29, v3

    .line 252
    .line 253
    iget-wide v3, v2, Lne1;->u:J

    .line 254
    .line 255
    move/from16 v31, v1

    .line 256
    .line 257
    iget v1, v2, Lne1;->v:I

    .line 258
    .line 259
    move/from16 v32, v1

    .line 260
    .line 261
    iget v1, v2, Lne1;->w:I

    .line 262
    .line 263
    move/from16 v33, v1

    .line 264
    .line 265
    iget-object v1, v2, Lne1;->x:Ljava/lang/String;

    .line 266
    .line 267
    iget-object v2, v2, Lne1;->y:Ljava/lang/Boolean;

    .line 268
    .line 269
    const/high16 v36, 0x80000

    .line 270
    .line 271
    move-object/from16 v34, v1

    .line 272
    .line 273
    move-object/from16 v35, v2

    .line 274
    .line 275
    move-wide/from16 v38, v3

    .line 276
    .line 277
    move-object/from16 v3, v16

    .line 278
    .line 279
    move-object/from16 v16, v17

    .line 280
    .line 281
    move-object/from16 v4, v18

    .line 282
    .line 283
    move/from16 v17, v19

    .line 284
    .line 285
    move-wide/from16 v19, v20

    .line 286
    .line 287
    move-wide/from16 v21, v22

    .line 288
    .line 289
    move-wide/from16 v23, v24

    .line 290
    .line 291
    move-object/from16 v18, v26

    .line 292
    .line 293
    move-wide/from16 v25, v29

    .line 294
    .line 295
    move/from16 v29, v31

    .line 296
    .line 297
    move-wide/from16 v30, v38

    .line 298
    .line 299
    invoke-direct/range {v3 .. v36}, Lne1;-><init>(Ljava/lang/String;Lde1;Ljava/lang/String;Ljava/lang/String;Lak;Lak;JJJLyg;ILv9;JJJJZLej0;IJIILjava/lang/String;Ljava/lang/Boolean;I)V

    .line 300
    .line 301
    .line 302
    iput-object v3, v0, Ld8;->g:Ljava/lang/Object;

    .line 303
    .line 304
    return-object v37
.end method

.method public c(Landroid/os/Bundle;)V
    .registers 8

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashSet;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->h:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Landroid/content/Context;

    .line 8
    .line 9
    const v2, 0x7f110021

    .line 10
    .line 11
    .line 12
    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    if-eqz p1, :cond_60

    .line 17
    .line 18
    :try_start_11
    new-instance v2, Ljava/util/HashSet;

    .line 19
    .line 20
    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    .line 24
    .line 25
    .line 26
    move-result-object v3

    .line 27
    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 28
    .line 29
    .line 30
    move-result-object v3

    .line 31
    :cond_1e
    :goto_1e
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-eqz v4, :cond_45

    .line 36
    .line 37
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 38
    .line 39
    .line 40
    move-result-object v4

    .line 41
    check-cast v4, Ljava/lang/String;

    .line 42
    .line 43
    const/4 v5, 0x0

    .line 44
    invoke-virtual {p1, v4, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    if-eqz v5, :cond_1e

    .line 53
    .line 54
    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 55
    .line 56
    .line 57
    move-result-object v4

    .line 58
    const-class v5, Li30;

    .line 59
    .line 60
    invoke-virtual {v5, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    .line 61
    .line 62
    .line 63
    move-result v5

    .line 64
    if-eqz v5, :cond_1e

    .line 65
    .line 66
    invoke-virtual {v0, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 67
    .line 68
    .line 69
    goto :goto_1e

    .line 70
    :cond_45
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 71
    .line 72
    .line 73
    move-result-object p1

    .line 74
    :goto_49
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_60

    .line 79
    .line 80
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    check-cast v0, Ljava/lang/Class;

    .line 85
    .line 86
    invoke-virtual {p0, v0, v2}, Ld8;->f(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;
    :try_end_58
    .catch Ljava/lang/ClassNotFoundException; {:try_start_11 .. :try_end_58} :catch_59

    .line 87
    .line 88
    .line 89
    goto :goto_49

    .line 90
    :catch_59
    move-exception p0

    .line 91
    new-instance p1, Lye;

    .line 92
    .line 93
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 94
    .line 95
    .line 96
    throw p1

    .line 97
    :cond_60
    return-void
.end method

.method public clear(Ljava/util/List;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lyv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x0

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lyv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/util/List;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    if-ne p0, p1, :cond_19

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 27
    .line 28
    return-object p0
.end method

.method public d(ILr0;)V
    .registers 3

    .line 1
    iget-object p0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lio/flutter/embedding/engine/FlutterJNI;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lio/flutter/embedding/engine/FlutterJNI;->dispatchSemanticsAction(ILr0;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public e(ILr0;Ljava/io/Serializable;)V
    .registers 4

    .line 1
    iget-object p0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Lio/flutter/embedding/engine/FlutterJNI;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2, p3}, Lio/flutter/embedding/engine/FlutterJNI;->dispatchSemanticsAction(ILr0;Ljava/lang/Object;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public f(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashMap;

    .line 4
    .line 5
    const-string v1, "Cannot initialize "

    .line 6
    .line 7
    invoke-static {}, Lrl;->L()Z

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    if-eqz v2, :cond_17

    .line 12
    .line 13
    :try_start_c
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {v2}, Lrl;->b0(Ljava/lang/String;)Ljava/lang/String;

    .line 18
    .line 19
    .line 20
    move-result-object v2

    .line 21
    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 22
    .line 23
    .line 24
    :cond_17
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 25
    .line 26
    .line 27
    move-result v2

    .line 28
    if-nez v2, :cond_73

    .line 29
    .line 30
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-nez v1, :cond_6b

    .line 35
    .line 36
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_26
    .catchall {:try_start_c .. :try_end_26} :catchall_8e

    .line 37
    .line 38
    .line 39
    const/4 v1, 0x0

    .line 40
    :try_start_27
    invoke-virtual {p1, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 41
    .line 42
    .line 43
    move-result-object v2

    .line 44
    invoke-virtual {v2, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    check-cast v1, Li30;

    .line 49
    .line 50
    invoke-interface {v1}, Li30;->a()Ljava/util/List;

    .line 51
    .line 52
    .line 53
    move-result-object v2

    .line 54
    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    .line 55
    .line 56
    .line 57
    move-result v3

    .line 58
    if-nez v3, :cond_55

    .line 59
    .line 60
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 61
    .line 62
    .line 63
    move-result-object v2

    .line 64
    :cond_3f
    :goto_3f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    if-eqz v3, :cond_55

    .line 69
    .line 70
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    check-cast v3, Ljava/lang/Class;

    .line 75
    .line 76
    invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 77
    .line 78
    .line 79
    move-result v4

    .line 80
    if-nez v4, :cond_3f

    .line 81
    .line 82
    invoke-virtual {p0, v3, p2}, Ld8;->f(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    goto :goto_3f

    .line 86
    :cond_55
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 87
    .line 88
    check-cast p0, Landroid/content/Context;

    .line 89
    .line 90
    invoke-interface {v1, p0}, Li30;->b(Landroid/content/Context;)Ljava/lang/Object;

    .line 91
    .line 92
    .line 93
    move-result-object p0

    .line 94
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_63
    .catchall {:try_start_27 .. :try_end_63} :catchall_64

    .line 98
    .line 99
    .line 100
    goto :goto_6f

    .line 101
    :catchall_64
    move-exception p0

    .line 102
    :try_start_65
    new-instance p1, Lye;

    .line 103
    .line 104
    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 105
    .line 106
    .line 107
    throw p1

    .line 108
    :cond_6b
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    .line 110
    .line 111
    move-result-object p0
    :try_end_6f
    .catchall {:try_start_65 .. :try_end_6f} :catchall_8e

    .line 112
    :goto_6f
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 113
    .line 114
    .line 115
    return-object p0

    .line 116
    :cond_73
    :try_start_73
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 117
    .line 118
    .line 119
    move-result-object p0

    .line 120
    new-instance p1, Ljava/lang/StringBuilder;

    .line 121
    .line 122
    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 126
    .line 127
    .line 128
    const-string p0, ". Cycle detected."

    .line 129
    .line 130
    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 131
    .line 132
    .line 133
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 134
    .line 135
    .line 136
    move-result-object p0

    .line 137
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 138
    .line 139
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 140
    .line 141
    .line 142
    throw p1
    :try_end_8e
    .catchall {:try_start_73 .. :try_end_8e} :catchall_8e

    .line 143
    :catchall_8e
    move-exception p0

    .line 144
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 145
    .line 146
    .line 147
    throw p0
.end method

.method public g(Ljava/nio/ByteBuffer;Lwj;)V
    .registers 13

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ler;

    .line 8
    .line 9
    iget-object v2, p0, Ld8;->h:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Ld8;

    .line 12
    .line 13
    iget-object v3, v2, Ld8;->g:Ljava/lang/Object;

    .line 14
    .line 15
    check-cast v3, Ljava/lang/String;

    .line 16
    .line 17
    iget-object v2, v2, Ld8;->h:Ljava/lang/Object;

    .line 18
    .line 19
    check-cast v2, Lue0;

    .line 20
    .line 21
    invoke-interface {v2, p1}, Lue0;->g(Ljava/nio/ByteBuffer;)Loe0;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    iget-object v4, p1, Loe0;->a:Ljava/lang/String;

    .line 26
    .line 27
    iget-object p1, p1, Loe0;->b:Ljava/lang/Object;

    .line 28
    .line 29
    const-string v5, "listen"

    .line 30
    .line 31
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 32
    .line 33
    .line 34
    move-result v5

    .line 35
    const-string v6, "error"

    .line 36
    .line 37
    const-string v7, "EventChannel#"

    .line 38
    .line 39
    const/4 v8, 0x0

    .line 40
    if-eqz v5, :cond_78

    .line 41
    .line 42
    new-instance v4, Ldr;

    .line 43
    .line 44
    invoke-direct {v4, p0}, Ldr;-><init>(Ld8;)V

    .line 45
    .line 46
    .line 47
    invoke-virtual {v0, v4}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    check-cast p0, Ldr;

    .line 52
    .line 53
    if-eqz p0, :cond_4c

    .line 54
    .line 55
    :try_start_36
    invoke-interface {v1}, Ler;->onCancel()V
    :try_end_39
    .catch Ljava/lang/RuntimeException; {:try_start_36 .. :try_end_39} :catch_3a

    .line 56
    .line 57
    .line 58
    goto :goto_4c

    .line 59
    :catch_3a
    move-exception p0

    .line 60
    new-instance v5, Ljava/lang/StringBuilder;

    .line 61
    .line 62
    invoke-direct {v5, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 63
    .line 64
    .line 65
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 66
    .line 67
    .line 68
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 69
    .line 70
    .line 71
    move-result-object v5

    .line 72
    const-string v9, "Failed to close existing event stream"

    .line 73
    .line 74
    invoke-static {v5, v9, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 75
    .line 76
    .line 77
    :cond_4c
    :goto_4c
    :try_start_4c
    invoke-interface {v1, p1, v4}, Ler;->h(Ljava/lang/Object;Ldr;)V

    .line 78
    .line 79
    .line 80
    invoke-interface {v2, v8}, Lue0;->b(Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 81
    .line 82
    .line 83
    move-result-object p0

    .line 84
    invoke-virtual {p2, p0}, Lwj;->a(Ljava/nio/ByteBuffer;)V
    :try_end_56
    .catch Ljava/lang/RuntimeException; {:try_start_4c .. :try_end_56} :catch_57

    .line 85
    .line 86
    .line 87
    goto :goto_ba

    .line 88
    :catch_57
    move-exception p0

    .line 89
    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 90
    .line 91
    .line 92
    new-instance p1, Ljava/lang/StringBuilder;

    .line 93
    .line 94
    invoke-direct {p1, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 95
    .line 96
    .line 97
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 98
    .line 99
    .line 100
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    const-string v0, "Failed to open event stream"

    .line 105
    .line 106
    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 107
    .line 108
    .line 109
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 110
    .line 111
    .line 112
    move-result-object p0

    .line 113
    invoke-interface {v2, v6, p0, v8}, Lue0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 114
    .line 115
    .line 116
    move-result-object p0

    .line 117
    invoke-virtual {p2, p0}, Lwj;->a(Ljava/nio/ByteBuffer;)V

    .line 118
    .line 119
    .line 120
    goto :goto_ba

    .line 121
    :cond_78
    const-string p0, "cancel"

    .line 122
    .line 123
    invoke-virtual {v4, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result p0

    .line 127
    if-eqz p0, :cond_bb

    .line 128
    .line 129
    invoke-virtual {v0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->getAndSet(Ljava/lang/Object;)Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    check-cast p0, Ldr;

    .line 134
    .line 135
    if-eqz p0, :cond_b1

    .line 136
    .line 137
    :try_start_88
    invoke-interface {v1}, Ler;->onCancel()V

    .line 138
    .line 139
    .line 140
    invoke-interface {v2, v8}, Lue0;->b(Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 141
    .line 142
    .line 143
    move-result-object p0

    .line 144
    invoke-virtual {p2, p0}, Lwj;->a(Ljava/nio/ByteBuffer;)V
    :try_end_92
    .catch Ljava/lang/RuntimeException; {:try_start_88 .. :try_end_92} :catch_93

    .line 145
    .line 146
    .line 147
    goto :goto_ba

    .line 148
    :catch_93
    move-exception p0

    .line 149
    new-instance p1, Ljava/lang/StringBuilder;

    .line 150
    .line 151
    invoke-direct {p1, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 152
    .line 153
    .line 154
    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 155
    .line 156
    .line 157
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 158
    .line 159
    .line 160
    move-result-object p1

    .line 161
    const-string v0, "Failed to close event stream"

    .line 162
    .line 163
    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 164
    .line 165
    .line 166
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 167
    .line 168
    .line 169
    move-result-object p0

    .line 170
    invoke-interface {v2, v6, p0, v8}, Lue0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 171
    .line 172
    .line 173
    move-result-object p0

    .line 174
    invoke-virtual {p2, p0}, Lwj;->a(Ljava/nio/ByteBuffer;)V

    .line 175
    .line 176
    .line 177
    goto :goto_ba

    .line 178
    :cond_b1
    const-string p0, "No active stream to cancel"

    .line 179
    .line 180
    invoke-interface {v2, v6, p0, v8}, Lue0;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 181
    .line 182
    .line 183
    move-result-object p0

    .line 184
    invoke-virtual {p2, p0}, Lwj;->a(Ljava/nio/ByteBuffer;)V

    .line 185
    .line 186
    .line 187
    :goto_ba
    return-void

    .line 188
    :cond_bb
    invoke-virtual {p2, v8}, Lwj;->a(Ljava/nio/ByteBuffer;)V

    .line 189
    .line 190
    .line 191
    return-void
.end method

.method public getAll(Ljava/util/List;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lyv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x1

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lyv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/util/List;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getBool(Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lzv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x0

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lzv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getDouble(Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lzv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x1

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lzv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getInt(Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lzv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x2

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lzv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getKeys(Ljava/util/List;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lyv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x2

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lyv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/util/List;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getPlatformEncodedStringList(Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lzv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x3

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lzv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getString(Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lzv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x4

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lzv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public getStringList(Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lzv0;

    .line 6
    .line 7
    const/4 v5, 0x0

    .line 8
    const/4 v6, 0x5

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v3, p2

    .line 12
    invoke-direct/range {v1 .. v6}, Lzv0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p3}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    return-object p0
.end method

.method public i(Ljava/lang/Class;Ljava/lang/String;)Ll91;
    .registers 7

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ln91;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lo91;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    iget-object v1, v1, Lo91;->a:Ljava/util/LinkedHashMap;

    .line 13
    .line 14
    invoke-virtual {v1, p2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object v2

    .line 18
    check-cast v2, Ll91;

    .line 19
    .line 20
    invoke-virtual {p1, v2}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    .line 21
    .line 22
    .line 23
    move-result v3

    .line 24
    if-eqz v3, :cond_36

    .line 25
    .line 26
    instance-of p0, v0, Ltr0;

    .line 27
    .line 28
    if-eqz p0, :cond_20

    .line 29
    .line 30
    check-cast v0, Ltr0;

    .line 31
    .line 32
    goto :goto_21

    .line 33
    :cond_20
    const/4 v0, 0x0

    .line 34
    :goto_21
    if-eqz v0, :cond_32

    .line 35
    .line 36
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    iget-object p0, v0, Ltr0;->d:Li80;

    .line 40
    .line 41
    if-eqz p0, :cond_32

    .line 42
    .line 43
    iget-object p1, v0, Ltr0;->e:Lqr0;

    .line 44
    .line 45
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-static {v2, p1, p0}, Lsa;->f(Ll91;Lqr0;Li80;)V

    .line 49
    .line 50
    .line 51
    :cond_32
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    .line 53
    .line 54
    return-object v2

    .line 55
    :cond_36
    new-instance v2, Lhf0;

    .line 56
    .line 57
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p0, Lpi;

    .line 60
    .line 61
    invoke-direct {v2, p0}, Lhf0;-><init>(Lpi;)V

    .line 62
    .line 63
    .line 64
    sget-object p0, Lmp;->o:Lmp;

    .line 65
    .line 66
    iget-object v3, v2, Lpi;->a:Ljava/util/LinkedHashMap;

    .line 67
    .line 68
    invoke-interface {v3, p0, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    :try_start_46
    invoke-interface {v0, p1, v2}, Ln91;->b(Ljava/lang/Class;Lhf0;)Ll91;

    .line 72
    .line 73
    .line 74
    move-result-object p0
    :try_end_4a
    .catch Ljava/lang/AbstractMethodError; {:try_start_46 .. :try_end_4a} :catch_4b

    .line 75
    goto :goto_4f

    .line 76
    :catch_4b
    invoke-interface {v0, p1}, Ln91;->a(Ljava/lang/Class;)Ll91;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    :goto_4f
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 81
    .line 82
    .line 83
    invoke-interface {v1, p2, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    check-cast p1, Ll91;

    .line 88
    .line 89
    if-eqz p1, :cond_5d

    .line 90
    .line 91
    invoke-virtual {p1}, Ll91;->b()V

    .line 92
    .line 93
    .line 94
    :cond_5d
    return-object p0
.end method

.method public j()Ljava/lang/Object;
    .registers 5

    .line 1
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    sget-wide v2, Lq3;->a:J

    .line 10
    .line 11
    cmp-long v2, v0, v2

    .line 12
    .line 13
    if-nez v2, :cond_11

    .line 14
    .line 15
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 16
    .line 17
    return-object p0

    .line 18
    :cond_11
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 21
    .line 22
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    check-cast p0, Lt31;

    .line 27
    .line 28
    invoke-virtual {p0, v0, v1}, Lt31;->a(J)I

    .line 29
    .line 30
    .line 31
    move-result v0

    .line 32
    if-ltz v0, :cond_26

    .line 33
    .line 34
    iget-object p0, p0, Lt31;->c:[Ljava/lang/Object;

    .line 35
    .line 36
    aget-object p0, p0, v0

    .line 37
    .line 38
    return-object p0

    .line 39
    :cond_26
    const/4 p0, 0x0

    .line 40
    return-object p0
.end method

.method public k(I)Landroid/content/res/ColorStateList;
    .registers 4

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_1c

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_1c

    .line 17
    .line 18
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Landroid/content/Context;

    .line 21
    .line 22
    invoke-static {p0, v1}, Lge1;->B(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    if-eqz p0, :cond_1c

    .line 27
    .line 28
    return-object p0

    .line 29
    :cond_1c
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->getColorStateList(I)Landroid/content/res/ColorStateList;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    return-object p0
.end method

.method public l(I)Landroid/graphics/drawable/Drawable;
    .registers 4

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    if-eqz v1, :cond_1a

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-eqz v1, :cond_1a

    .line 17
    .line 18
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast p0, Landroid/content/Context;

    .line 21
    .line 22
    invoke-static {p0, v1}, Lhh1;->t(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    .line 23
    .line 24
    .line 25
    move-result-object p0

    .line 26
    return-object p0

    .line 27
    :cond_1a
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    return-object p0
.end method

.method public m(I)Landroid/graphics/drawable/Drawable;
    .registers 5

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {v0, p1}, Landroid/content/res/TypedArray;->hasValue(I)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-eqz v0, :cond_2a

    .line 10
    .line 11
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Landroid/content/res/TypedArray;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    if-eqz p1, :cond_2a

    .line 21
    .line 22
    invoke-static {}, Ll6;->a()Ll6;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 27
    .line 28
    check-cast p0, Landroid/content/Context;

    .line 29
    .line 30
    monitor-enter v0

    .line 31
    :try_start_1e
    iget-object v1, v0, Ll6;->a:Lup0;

    .line 32
    .line 33
    const/4 v2, 0x1

    .line 34
    invoke-virtual {v1, p0, p1, v2}, Lup0;->e(Landroid/content/Context;IZ)Landroid/graphics/drawable/Drawable;

    .line 35
    .line 36
    .line 37
    move-result-object p0
    :try_end_25
    .catchall {:try_start_1e .. :try_end_25} :catchall_27

    .line 38
    monitor-exit v0

    .line 39
    return-object p0

    .line 40
    :catchall_27
    move-exception p0

    .line 41
    :try_start_28
    monitor-exit v0
    :try_end_29
    .catchall {:try_start_28 .. :try_end_29} :catchall_27

    .line 42
    throw p0

    .line 43
    :cond_2a
    const/4 p0, 0x0

    .line 44
    return-object p0
.end method

.method public n(IILn7;)Landroid/graphics/Typeface;
    .registers 14

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, p1, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    .line 7
    .line 8
    .line 9
    move-result v5

    .line 10
    const/4 p1, 0x0

    .line 11
    if-nez v5, :cond_d

    .line 12
    .line 13
    goto :goto_2b

    .line 14
    :cond_d
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Landroid/util/TypedValue;

    .line 17
    .line 18
    if-nez v0, :cond_1a

    .line 19
    .line 20
    new-instance v0, Landroid/util/TypedValue;

    .line 21
    .line 22
    invoke-direct {v0}, Landroid/util/TypedValue;-><init>()V

    .line 23
    .line 24
    .line 25
    iput-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 26
    .line 27
    :cond_1a
    iget-object v0, p0, Ld8;->h:Ljava/lang/Object;

    .line 28
    .line 29
    move-object v2, v0

    .line 30
    check-cast v2, Landroid/content/Context;

    .line 31
    .line 32
    iget-object p0, p0, Ld8;->g:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p0, Landroid/util/TypedValue;

    .line 35
    .line 36
    sget-object v0, Lxp0;->a:Ljava/lang/ThreadLocal;

    .line 37
    .line 38
    invoke-virtual {v2}, Landroid/content/Context;->isRestricted()Z

    .line 39
    .line 40
    .line 41
    move-result v0

    .line 42
    if-eqz v0, :cond_2c

    .line 43
    .line 44
    :goto_2b
    return-object p1

    .line 45
    :cond_2c
    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    const/4 v0, 0x1

    .line 50
    invoke-virtual {v4, v5, p0, v0}, Landroid/content/res/Resources;->getValue(ILandroid/util/TypedValue;Z)V

    .line 51
    .line 52
    .line 53
    const-string v1, "ResourcesCompat"

    .line 54
    .line 55
    iget-object v0, p0, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    .line 56
    .line 57
    if-eqz v0, :cond_f1

    .line 58
    .line 59
    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v6

    .line 63
    const-string v0, "res/"

    .line 64
    .line 65
    invoke-virtual {v6, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 66
    .line 67
    .line 68
    move-result v0

    .line 69
    if-nez v0, :cond_4b

    .line 70
    .line 71
    invoke-virtual {p3}, Ln7;->a()V

    .line 72
    .line 73
    .line 74
    goto/16 :goto_f0

    .line 75
    .line 76
    :cond_4b
    iget v0, p0, Landroid/util/TypedValue;->assetCookie:I

    .line 77
    .line 78
    sget-object v3, Lv51;->b:Lxa0;

    .line 79
    .line 80
    invoke-static {v4, v5, v6, v0, p2}, Lv51;->b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object v0

    .line 84
    invoke-virtual {v3, v0}, Lxa0;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object v0

    .line 88
    check-cast v0, Landroid/graphics/Typeface;

    .line 89
    .line 90
    const/16 v7, 0xe

    .line 91
    .line 92
    if-eqz v0, :cond_71

    .line 93
    .line 94
    new-instance p0, Landroid/os/Handler;

    .line 95
    .line 96
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 101
    .line 102
    .line 103
    new-instance p1, Lg8;

    .line 104
    .line 105
    invoke-direct {p1, p3, v7, v0}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 106
    .line 107
    .line 108
    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 109
    .line 110
    .line 111
    move-object p1, v0

    .line 112
    goto/16 :goto_f0

    .line 113
    .line 114
    :cond_71
    :try_start_71
    invoke-virtual {v6}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    const-string v8, ".xml"

    .line 119
    .line 120
    invoke-virtual {v0, v8}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 121
    .line 122
    .line 123
    move-result v0

    .line 124
    if-eqz v0, :cond_ae

    .line 125
    .line 126
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    .line 127
    .line 128
    .line 129
    move-result-object v0

    .line 130
    invoke-static {v0, v4}, Ln40;->P(Landroid/content/res/XmlResourceParser;Landroid/content/res/Resources;)Lix;

    .line 131
    .line 132
    .line 133
    move-result-object v3
    :try_end_85
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_71 .. :try_end_85} :catch_ab
    .catch Ljava/io/IOException; {:try_start_71 .. :try_end_85} :catch_a8

    .line 134
    if-nez v3, :cond_99

    .line 135
    .line 136
    :try_start_87
    const-string p0, "Failed to find font-family tag"

    .line 137
    .line 138
    invoke-static {v1, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 139
    .line 140
    .line 141
    invoke-virtual {p3}, Ln7;->a()V
    :try_end_8f
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_87 .. :try_end_8f} :catch_95
    .catch Ljava/io/IOException; {:try_start_87 .. :try_end_8f} :catch_91

    .line 142
    .line 143
    .line 144
    goto/16 :goto_f0

    .line 145
    .line 146
    :catch_91
    move-exception v0

    .line 147
    move-object p0, v0

    .line 148
    move-object v9, p3

    .line 149
    goto :goto_da

    .line 150
    :catch_95
    move-exception v0

    .line 151
    move-object p0, v0

    .line 152
    move-object v9, p3

    .line 153
    goto :goto_e4

    .line 154
    :cond_99
    :try_start_99
    iget v7, p0, Landroid/util/TypedValue;->assetCookie:I
    :try_end_9b
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_99 .. :try_end_9b} :catch_ab
    .catch Ljava/io/IOException; {:try_start_99 .. :try_end_9b} :catch_a8

    .line 155
    .line 156
    move v8, p2

    .line 157
    move-object v9, p3

    .line 158
    :try_start_9d
    invoke-static/range {v2 .. v9}, Lv51;->a(Landroid/content/Context;Lix;Landroid/content/res/Resources;ILjava/lang/String;IILn7;)Landroid/graphics/Typeface;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    goto :goto_f0

    .line 163
    :catch_a2
    move-exception v0

    .line 164
    :goto_a3
    move-object p0, v0

    .line 165
    goto :goto_da

    .line 166
    :catch_a5
    move-exception v0

    .line 167
    :goto_a6
    move-object p0, v0

    .line 168
    goto :goto_e4

    .line 169
    :catch_a8
    move-exception v0

    .line 170
    move-object v9, p3

    .line 171
    goto :goto_a3

    .line 172
    :catch_ab
    move-exception v0

    .line 173
    move-object v9, p3

    .line 174
    goto :goto_a6

    .line 175
    :cond_ae
    move v8, p2

    .line 176
    move-object v9, p3

    .line 177
    iget p0, p0, Landroid/util/TypedValue;->assetCookie:I

    .line 178
    .line 179
    sget-object p2, Lv51;->a:Lge1;

    .line 180
    .line 181
    invoke-virtual {p2, v2, v4, v5, v6}, Lge1;->o(Landroid/content/Context;Landroid/content/res/Resources;ILjava/lang/String;)Landroid/graphics/Typeface;

    .line 182
    .line 183
    .line 184
    move-result-object p2

    .line 185
    if-eqz p2, :cond_c1

    .line 186
    .line 187
    invoke-static {v4, v5, v6, p0, v8}, Lv51;->b(Landroid/content/res/Resources;ILjava/lang/String;II)Ljava/lang/String;

    .line 188
    .line 189
    .line 190
    move-result-object p0

    .line 191
    invoke-virtual {v3, p0, p2}, Lxa0;->b(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    :cond_c1
    if-eqz p2, :cond_d6

    .line 195
    .line 196
    new-instance p0, Landroid/os/Handler;

    .line 197
    .line 198
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 199
    .line 200
    .line 201
    move-result-object p3

    .line 202
    invoke-direct {p0, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 203
    .line 204
    .line 205
    new-instance p3, Lg8;

    .line 206
    .line 207
    invoke-direct {p3, v9, v7, p2}, Lg8;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {p0, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 211
    .line 212
    .line 213
    :goto_d4
    move-object p1, p2

    .line 214
    goto :goto_f0

    .line 215
    :cond_d6
    invoke-virtual {v9}, Ln7;->a()V
    :try_end_d9
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_9d .. :try_end_d9} :catch_a5
    .catch Ljava/io/IOException; {:try_start_9d .. :try_end_d9} :catch_a2

    .line 216
    .line 217
    .line 218
    goto :goto_d4

    .line 219
    :goto_da
    const-string p2, "Failed to read xml resource "

    .line 220
    .line 221
    invoke-virtual {p2, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 222
    .line 223
    .line 224
    move-result-object p2

    .line 225
    invoke-static {v1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 226
    .line 227
    .line 228
    goto :goto_ed

    .line 229
    :goto_e4
    const-string p2, "Failed to parse xml resource "

    .line 230
    .line 231
    invoke-virtual {p2, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 232
    .line 233
    .line 234
    move-result-object p2

    .line 235
    invoke-static {v1, p2, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 236
    .line 237
    .line 238
    :goto_ed
    invoke-virtual {v9}, Ln7;->a()V

    .line 239
    .line 240
    .line 241
    :goto_f0
    return-object p1

    .line 242
    :cond_f1
    new-instance p1, Landroid/content/res/Resources$NotFoundException;

    .line 243
    .line 244
    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    .line 245
    .line 246
    .line 247
    move-result-object p2

    .line 248
    invoke-static {v5}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    .line 249
    .line 250
    .line 251
    move-result-object p3

    .line 252
    new-instance v0, Ljava/lang/StringBuilder;

    .line 253
    .line 254
    const-string v1, "Resource \""

    .line 255
    .line 256
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 257
    .line 258
    .line 259
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 260
    .line 261
    .line 262
    const-string p2, "\" ("

    .line 263
    .line 264
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 265
    .line 266
    .line 267
    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 268
    .line 269
    .line 270
    const-string p2, ") is not a Font: "

    .line 271
    .line 272
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 273
    .line 274
    .line 275
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 276
    .line 277
    .line 278
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 279
    .line 280
    .line 281
    move-result-object p0

    .line 282
    invoke-direct {p1, p0}, Landroid/content/res/Resources$NotFoundException;-><init>(Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    throw p1
.end method

.method public p(Landroid/view/KeyEvent;)Z
    .registers 9

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, [Ln60;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/util/HashSet;

    .line 8
    .line 9
    invoke-virtual {v1, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    const/4 v2, 0x0

    .line 14
    if-eqz v1, :cond_10

    .line 15
    .line 16
    return v2

    .line 17
    :cond_10
    array-length v1, v0

    .line 18
    const/4 v3, 0x1

    .line 19
    if-lez v1, :cond_2f

    .line 20
    .line 21
    new-instance v1, Lm60;

    .line 22
    .line 23
    invoke-direct {v1, p0, p1}, Lm60;-><init>(Ld8;Landroid/view/KeyEvent;)V

    .line 24
    .line 25
    .line 26
    array-length p0, v0

    .line 27
    move v4, v2

    .line 28
    :goto_1b
    if-ge v4, p0, :cond_2e

    .line 29
    .line 30
    aget-object v5, v0, v4

    .line 31
    .line 32
    new-instance v6, Ll60;

    .line 33
    .line 34
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 35
    .line 36
    .line 37
    iput-object v1, v6, Ll60;->g:Ljava/lang/Object;

    .line 38
    .line 39
    iput-boolean v2, v6, Ll60;->f:Z

    .line 40
    .line 41
    invoke-interface {v5, p1, v6}, Ln60;->f(Landroid/view/KeyEvent;Ll60;)V

    .line 42
    .line 43
    .line 44
    add-int/lit8 v4, v4, 0x1

    .line 45
    .line 46
    goto :goto_1b

    .line 47
    :cond_2e
    return v3

    .line 48
    :cond_2f
    invoke-virtual {p0, p1}, Ld8;->s(Landroid/view/KeyEvent;)V

    .line 49
    .line 50
    .line 51
    return v3
.end method

.method public s(Landroid/view/KeyEvent;)V
    .registers 10

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/HashSet;

    .line 4
    .line 5
    iget-object p0, p0, Ld8;->h:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast p0, Lvw;

    .line 8
    .line 9
    if-eqz p0, :cond_e3

    .line 10
    .line 11
    iget-object v1, p0, Lvw;->q:Lio/flutter/plugin/editing/b;

    .line 12
    .line 13
    iget-object v2, v1, Lio/flutter/plugin/editing/b;->b:Landroid/view/inputmethod/InputMethodManager;

    .line 14
    .line 15
    invoke-virtual {v2}, Landroid/view/inputmethod/InputMethodManager;->isAcceptingText()Z

    .line 16
    .line 17
    .line 18
    move-result v2

    .line 19
    const/4 v3, 0x0

    .line 20
    if-eqz v2, :cond_c9

    .line 21
    .line 22
    iget-object v1, v1, Lio/flutter/plugin/editing/b;->j:Landroid/view/inputmethod/InputConnection;

    .line 23
    .line 24
    if-nez v1, :cond_1b

    .line 25
    .line 26
    goto/16 :goto_c9

    .line 27
    .line 28
    :cond_1b
    instance-of v2, v1, Lj30;

    .line 29
    .line 30
    if-eqz v2, :cond_c5

    .line 31
    .line 32
    check-cast v1, Lj30;

    .line 33
    .line 34
    iget-object v2, v1, Lj30;->d:Lv90;

    .line 35
    .line 36
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 37
    .line 38
    .line 39
    move-result v4

    .line 40
    if-nez v4, :cond_c9

    .line 41
    .line 42
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 43
    .line 44
    .line 45
    move-result v4

    .line 46
    const/16 v5, 0x15

    .line 47
    .line 48
    const/4 v6, 0x1

    .line 49
    if-ne v4, v5, :cond_3c

    .line 50
    .line 51
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    invoke-virtual {v1, v6, v2}, Lj30;->d(ZZ)Z

    .line 56
    .line 57
    .line 58
    move-result v3

    .line 59
    goto/16 :goto_c9

    .line 60
    .line 61
    :cond_3c
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    const/16 v5, 0x16

    .line 66
    .line 67
    if-ne v4, v5, :cond_4e

    .line 68
    .line 69
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    .line 70
    .line 71
    .line 72
    move-result v2

    .line 73
    invoke-virtual {v1, v3, v2}, Lj30;->d(ZZ)Z

    .line 74
    .line 75
    .line 76
    move-result v3

    .line 77
    goto/16 :goto_c9

    .line 78
    .line 79
    :cond_4e
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    const/16 v5, 0x13

    .line 84
    .line 85
    if-ne v4, v5, :cond_5f

    .line 86
    .line 87
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    .line 88
    .line 89
    .line 90
    move-result v2

    .line 91
    invoke-virtual {v1, v6, v2}, Lj30;->e(ZZ)Z

    .line 92
    .line 93
    .line 94
    move-result v3

    .line 95
    goto :goto_c9

    .line 96
    :cond_5f
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 97
    .line 98
    .line 99
    move-result v4

    .line 100
    const/16 v5, 0x14

    .line 101
    .line 102
    if-ne v4, v5, :cond_70

    .line 103
    .line 104
    invoke-virtual {p1}, Landroid/view/KeyEvent;->isShiftPressed()Z

    .line 105
    .line 106
    .line 107
    move-result v2

    .line 108
    invoke-virtual {v1, v3, v2}, Lj30;->e(ZZ)Z

    .line 109
    .line 110
    .line 111
    move-result v3

    .line 112
    goto :goto_c9

    .line 113
    :cond_70
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 114
    .line 115
    .line 116
    move-result v4

    .line 117
    const/16 v5, 0x42

    .line 118
    .line 119
    if-eq v4, v5, :cond_80

    .line 120
    .line 121
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 122
    .line 123
    .line 124
    move-result v4

    .line 125
    const/16 v5, 0xa0

    .line 126
    .line 127
    if-ne v4, v5, :cond_92

    .line 128
    .line 129
    :cond_80
    iget-object v4, v1, Lj30;->e:Landroid/view/inputmethod/EditorInfo;

    .line 130
    .line 131
    iget v5, v4, Landroid/view/inputmethod/EditorInfo;->inputType:I

    .line 132
    .line 133
    const/high16 v7, 0x20000

    .line 134
    .line 135
    and-int/2addr v5, v7

    .line 136
    if-nez v5, :cond_92

    .line 137
    .line 138
    iget v2, v4, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 139
    .line 140
    and-int/lit16 v2, v2, 0xff

    .line 141
    .line 142
    invoke-virtual {v1, v2}, Lj30;->performEditorAction(I)Z

    .line 143
    .line 144
    .line 145
    :goto_90
    move v3, v6

    .line 146
    goto :goto_c9

    .line 147
    :cond_92
    invoke-static {v2}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 148
    .line 149
    .line 150
    move-result v4

    .line 151
    invoke-static {v2}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 152
    .line 153
    .line 154
    move-result v5

    .line 155
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getUnicodeChar()I

    .line 156
    .line 157
    .line 158
    move-result v7

    .line 159
    if-ltz v4, :cond_c9

    .line 160
    .line 161
    if-ltz v5, :cond_c9

    .line 162
    .line 163
    if-nez v7, :cond_a5

    .line 164
    .line 165
    goto :goto_c9

    .line 166
    :cond_a5
    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    .line 167
    .line 168
    .line 169
    move-result v3

    .line 170
    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    .line 171
    .line 172
    .line 173
    move-result v4

    .line 174
    invoke-virtual {v1}, Lj30;->beginBatchEdit()Z

    .line 175
    .line 176
    .line 177
    if-eq v3, v4, :cond_b5

    .line 178
    .line 179
    invoke-virtual {v2, v3, v4}, Landroid/text/SpannableStringBuilder;->delete(II)Landroid/text/SpannableStringBuilder;

    .line 180
    .line 181
    .line 182
    :cond_b5
    int-to-char v4, v7

    .line 183
    invoke-static {v4}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 184
    .line 185
    .line 186
    move-result-object v4

    .line 187
    invoke-virtual {v2, v3, v4}, Landroid/text/SpannableStringBuilder;->insert(ILjava/lang/CharSequence;)Landroid/text/SpannableStringBuilder;

    .line 188
    .line 189
    .line 190
    add-int/2addr v3, v6

    .line 191
    invoke-virtual {v1, v3, v3}, Lj30;->setSelection(II)Z

    .line 192
    .line 193
    .line 194
    invoke-virtual {v1}, Lj30;->endBatchEdit()Z

    .line 195
    .line 196
    .line 197
    goto :goto_90

    .line 198
    :cond_c5
    invoke-interface {v1, p1}, Landroid/view/inputmethod/InputConnection;->sendKeyEvent(Landroid/view/KeyEvent;)Z

    .line 199
    .line 200
    .line 201
    move-result v3

    .line 202
    :cond_c9
    :goto_c9
    if-eqz v3, :cond_cc

    .line 203
    .line 204
    goto :goto_e3

    .line 205
    :cond_cc
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 206
    .line 207
    .line 208
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 209
    .line 210
    .line 211
    move-result-object p0

    .line 212
    invoke-virtual {p0, p1}, Landroid/view/View;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 213
    .line 214
    .line 215
    invoke-virtual {v0, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 216
    .line 217
    .line 218
    move-result p0

    .line 219
    if-eqz p0, :cond_e3

    .line 220
    .line 221
    const-string p0, "KeyboardManager"

    .line 222
    .line 223
    const-string p1, "A redispatched key event was consumed before reaching KeyboardManager"

    .line 224
    .line 225
    invoke-static {p0, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 226
    .line 227
    .line 228
    :cond_e3
    :goto_e3
    return-void
.end method

.method public setBool(Ljava/lang/String;ZLio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Law0;

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    move-object v2, p0

    .line 9
    move-object v4, p1

    .line 10
    move v5, p2

    .line 11
    move-object v3, p3

    .line 12
    invoke-direct/range {v1 .. v6}, Law0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;ZLkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p4}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    if-ne p0, p1, :cond_19

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 27
    .line 28
    return-object p0
.end method

.method public setDeprecatedStringList(Ljava/lang/String;Ljava/util/List;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 12

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lcw0;

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    move-object v2, p0

    .line 9
    move-object v5, p1

    .line 10
    move-object v3, p2

    .line 11
    move-object v4, p3

    .line 12
    invoke-direct/range {v1 .. v6}, Lcw0;-><init>(Ld8;Ljava/util/List;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Lkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p4}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    if-ne p0, p1, :cond_19

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 27
    .line 28
    return-object p0
.end method

.method public setDouble(Ljava/lang/String;DLio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 14

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lbw0;

    .line 6
    .line 7
    const/4 v7, 0x0

    .line 8
    move-object v2, p0

    .line 9
    move-object v4, p1

    .line 10
    move-wide v5, p2

    .line 11
    move-object v3, p4

    .line 12
    invoke-direct/range {v1 .. v7}, Lbw0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;DLkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p5}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    if-ne p0, p1, :cond_19

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 27
    .line 28
    return-object p0
.end method

.method public setEncodedStringList(Ljava/lang/String;Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lcw0;

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    const/4 v7, 0x0

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v5, p2

    .line 12
    move-object v3, p3

    .line 13
    invoke-direct/range {v1 .. v7}, Lcw0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1, p4}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    if-ne p0, p1, :cond_1a

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_1a
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 28
    .line 29
    return-object p0
.end method

.method public setInt(Ljava/lang/String;JLio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 14

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Ldw0;

    .line 6
    .line 7
    const/4 v7, 0x0

    .line 8
    move-object v2, p0

    .line 9
    move-object v4, p1

    .line 10
    move-wide v5, p2

    .line 11
    move-object v3, p4

    .line 12
    invoke-direct/range {v1 .. v7}, Ldw0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;JLkotlin/coroutines/Continuation;)V

    .line 13
    .line 14
    .line 15
    invoke-static {v0, v1, p5}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object p0

    .line 19
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    if-ne p0, p1, :cond_19

    .line 24
    .line 25
    return-object p0

    .line 26
    :cond_19
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 27
    .line 28
    return-object p0
.end method

.method public setString(Ljava/lang/String;Ljava/lang/String;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lbi;

    .line 4
    .line 5
    new-instance v1, Lcw0;

    .line 6
    .line 7
    const/4 v6, 0x0

    .line 8
    const/4 v7, 0x1

    .line 9
    move-object v2, p0

    .line 10
    move-object v4, p1

    .line 11
    move-object v5, p2

    .line 12
    move-object v3, p3

    .line 13
    invoke-direct/range {v1 .. v7}, Lcw0;-><init>(Ld8;Lio/flutter/plugins/sharedpreferences/SharedPreferencesPigeonOptions;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;I)V

    .line 14
    .line 15
    .line 16
    invoke-static {v0, v1, p4}, Lr30;->a0(Lyh;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    if-ne p0, p1, :cond_1a

    .line 25
    .line 26
    return-object p0

    .line 27
    :cond_1a
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 28
    .line 29
    return-object p0
.end method

.method public t(Landroid/app/Activity;Lzc1;)V
    .registers 6

    .line 1
    iget-object v0, p0, Ld8;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/util/WeakHashMap;

    .line 4
    .line 5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Ld8;->g:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v1, Ljava/util/concurrent/locks/ReentrantLock;

    .line 11
    .line 12
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 13
    .line 14
    .line 15
    :try_start_e
    invoke-virtual {v0, p1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    check-cast v2, Lzc1;

    .line 20
    .line 21
    invoke-virtual {p2, v2}, Lzc1;->equals(Ljava/lang/Object;)Z

    .line 22
    .line 23
    .line 24
    move-result v2
    :try_end_18
    .catchall {:try_start_e .. :try_end_18} :catchall_53

    .line 25
    if-eqz v2, :cond_1e

    .line 26
    .line 27
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_1e
    :try_start_1e
    invoke-virtual {v0, p1, p2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    .line 33
    .line 34
    move-result-object v0

    .line 35
    check-cast v0, Lzc1;
    :try_end_24
    .catchall {:try_start_1e .. :try_end_24} :catchall_53

    .line 36
    .line 37
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 38
    .line 39
    .line 40
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 41
    .line 42
    check-cast p0, Lns0;

    .line 43
    .line 44
    iget-object p0, p0, Lns0;->g:Ljava/lang/Object;

    .line 45
    .line 46
    check-cast p0, Lux0;

    .line 47
    .line 48
    iget-object p0, p0, Lux0;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 49
    .line 50
    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    :goto_35
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    if-eqz v0, :cond_52

    .line 59
    .line 60
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object v0

    .line 64
    check-cast v0, Ltx0;

    .line 65
    .line 66
    iget-object v1, v0, Ltx0;->a:Landroid/app/Activity;

    .line 67
    .line 68
    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    if-nez v1, :cond_4a

    .line 73
    .line 74
    goto :goto_35

    .line 75
    :cond_4a
    iput-object p2, v0, Ltx0;->c:Lzc1;

    .line 76
    .line 77
    iget-object v0, v0, Ltx0;->b:Lsw;

    .line 78
    .line 79
    invoke-virtual {v0, p2}, Lsw;->accept(Ljava/lang/Object;)V

    .line 80
    .line 81
    .line 82
    goto :goto_35

    .line 83
    :cond_52
    return-void

    .line 84
    :catchall_53
    move-exception p0

    .line 85
    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 86
    .line 87
    .line 88
    throw p0
.end method

.method public u(Ljava/lang/String;ZLpb1;Lza;)Z
    .registers 13

    .line 1
    iget-object v0, p3, Lpb1;->c:Ljava/util/Map;

    .line 2
    .line 3
    iget-object v1, p0, Ld8;->g:Ljava/lang/Object;

    .line 4
    .line 5
    check-cast v1, Landroid/app/Activity;

    .line 6
    .line 7
    if-eqz v1, :cond_bf

    .line 8
    .line 9
    invoke-static {v0}, Ld8;->h(Ljava/util/Map;)Landroid/os/Bundle;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    const/4 v2, 0x0

    .line 14
    const/4 v3, 0x1

    .line 15
    const-string v4, "com.android.browser.headers"

    .line 16
    .line 17
    if-eqz p2, :cond_8f

    .line 18
    .line 19
    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    .line 20
    .line 21
    .line 22
    move-result-object p2

    .line 23
    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 24
    .line 25
    .line 26
    move-result-object p2

    .line 27
    :pswitch_1a
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-eqz v0, :cond_67

    .line 32
    .line 33
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    check-cast v0, Ljava/lang/String;

    .line 38
    .line 39
    sget-object v5, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 40
    .line 41
    invoke-virtual {v0, v5}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 42
    .line 43
    .line 44
    move-result-object v0

    .line 45
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 49
    .line 50
    .line 51
    move-result v5

    .line 52
    const/4 v6, -0x1

    .line 53
    sparse-switch v5, :sswitch_data_c6

    .line 54
    .line 55
    .line 56
    goto :goto_63

    .line 57
    :sswitch_38
    const-string v5, "accept-language"

    .line 58
    .line 59
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    if-nez v0, :cond_41

    .line 64
    .line 65
    goto :goto_63

    .line 66
    :cond_41
    const/4 v6, 0x3

    .line 67
    goto :goto_63

    .line 68
    :sswitch_43
    const-string v5, "content-type"

    .line 69
    .line 70
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 71
    .line 72
    .line 73
    move-result v0

    .line 74
    if-nez v0, :cond_4c

    .line 75
    .line 76
    goto :goto_63

    .line 77
    :cond_4c
    const/4 v6, 0x2

    .line 78
    goto :goto_63

    .line 79
    :sswitch_4e
    const-string v5, "content-language"

    .line 80
    .line 81
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-nez v0, :cond_57

    .line 86
    .line 87
    goto :goto_63

    .line 88
    :cond_57
    move v6, v3

    .line 89
    goto :goto_63

    .line 90
    :sswitch_59
    const-string v5, "accept"

    .line 91
    .line 92
    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 93
    .line 94
    .line 95
    move-result v0

    .line 96
    if-nez v0, :cond_62

    .line 97
    .line 98
    goto :goto_63

    .line 99
    :cond_62
    move v6, v2

    .line 100
    :goto_63
    packed-switch v6, :pswitch_data_d8

    .line 101
    .line 102
    .line 103
    goto :goto_8f

    .line 104
    :cond_67
    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    .line 105
    .line 106
    .line 107
    move-result-object p2

    .line 108
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 109
    .line 110
    check-cast v0, Landroid/app/Activity;

    .line 111
    .line 112
    new-instance v5, Lcj;

    .line 113
    .line 114
    invoke-direct {v5}, Lcj;-><init>()V

    .line 115
    .line 116
    .line 117
    iget-boolean p4, p4, Lza;->a:Z

    .line 118
    .line 119
    iget-object v6, v5, Lcj;->a:Landroid/content/Intent;

    .line 120
    .line 121
    const-string v7, "android.support.customtabs.extra.TITLE_VISIBILITY"

    .line 122
    .line 123
    invoke-virtual {v6, v7, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 124
    .line 125
    .line 126
    invoke-virtual {v5}, Lcj;->a()Ldj;

    .line 127
    .line 128
    .line 129
    move-result-object p4

    .line 130
    iget-object v5, p4, Ldj;->a:Landroid/content/Intent;

    .line 131
    .line 132
    invoke-virtual {v5, v4, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    .line 133
    .line 134
    .line 135
    :try_start_86
    invoke-virtual {v5, p2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 136
    .line 137
    .line 138
    iget-object p2, p4, Ldj;->b:Landroid/os/Bundle;

    .line 139
    .line 140
    invoke-virtual {v0, v5, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;Landroid/os/Bundle;)V
    :try_end_8e
    .catch Landroid/content/ActivityNotFoundException; {:try_start_86 .. :try_end_8e} :catch_8f

    .line 141
    .line 142
    .line 143
    return v3

    .line 144
    :catch_8f
    :cond_8f
    :goto_8f
    iget-object p2, p0, Ld8;->g:Ljava/lang/Object;

    .line 145
    .line 146
    check-cast p2, Landroid/app/Activity;

    .line 147
    .line 148
    iget-boolean p4, p3, Lpb1;->a:Z

    .line 149
    .line 150
    iget-boolean p3, p3, Lpb1;->b:Z

    .line 151
    .line 152
    sget v0, Lio/flutter/plugins/urllauncher/WebViewActivity;->j:I

    .line 153
    .line 154
    new-instance v0, Landroid/content/Intent;

    .line 155
    .line 156
    const-class v5, Lio/flutter/plugins/urllauncher/WebViewActivity;

    .line 157
    .line 158
    invoke-direct {v0, p2, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 159
    .line 160
    .line 161
    const-string p2, "url"

    .line 162
    .line 163
    invoke-virtual {v0, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 164
    .line 165
    .line 166
    move-result-object p1

    .line 167
    const-string p2, "enableJavaScript"

    .line 168
    .line 169
    invoke-virtual {p1, p2, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 170
    .line 171
    .line 172
    move-result-object p1

    .line 173
    const-string p2, "enableDomStorage"

    .line 174
    .line 175
    invoke-virtual {p1, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 176
    .line 177
    .line 178
    move-result-object p1

    .line 179
    invoke-virtual {p1, v4, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    .line 180
    .line 181
    .line 182
    move-result-object p1

    .line 183
    :try_start_b6
    iget-object p0, p0, Ld8;->g:Ljava/lang/Object;

    .line 184
    .line 185
    check-cast p0, Landroid/app/Activity;

    .line 186
    .line 187
    invoke-virtual {p0, p1}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_bd
    .catch Landroid/content/ActivityNotFoundException; {:try_start_b6 .. :try_end_bd} :catch_be

    .line 188
    .line 189
    .line 190
    return v3

    .line 191
    :catch_be
    return v2

    .line 192
    :cond_bf
    new-instance p0, Lrv;

    .line 193
    .line 194
    invoke-direct {p0}, Lrv;-><init>()V

    .line 195
    .line 196
    .line 197
    throw p0

    .line 198
    nop

    .line 199
    :sswitch_data_c6
    .sparse-switch
        -0x54d84af8 -> :sswitch_59
        -0x494c25d4 -> :sswitch_4e
        0x2ed4600e -> :sswitch_43
        0x2fd98a7d -> :sswitch_38
    .end sparse-switch

    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    :pswitch_data_d8
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_1a
        :pswitch_1a
        :pswitch_1a
    .end packed-switch
.end method

.method public v(Lg80;)V
    .registers 4

    .line 1
    iget-object v0, p0, Ld8;->h:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lvt0;

    .line 4
    .line 5
    if-eqz v0, :cond_9

    .line 6
    .line 7
    invoke-virtual {v0}, Lvt0;->run()V

    .line 8
    .line 9
    .line 10
    :cond_9
    new-instance v0, Lvt0;

    .line 11
    .line 12
    iget-object v1, p0, Ld8;->f:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Lr80;

    .line 15
    .line 16
    invoke-direct {v0, v1, p1}, Lvt0;-><init>(Lr80;Lg80;)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Ld8;->h:Ljava/lang/Object;

    .line 20
    .line 21
    iget-object p0, p0, Ld8;->g:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast p0, Landroid/os/Handler;

    .line 24
    .line 25
    invoke-virtual {p0, v0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public w()V
    .registers 1

    .line 1
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast p0, Landroid/content/res/TypedArray;

    .line 4
    .line 5
    invoke-virtual {p0}, Landroid/content/res/TypedArray;->recycle()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public x(Ljava/io/Serializable;Lda;)V
    .registers 7

    .line 1
    iget-object v0, p0, Ld8;->f:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Lla;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->g:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Ljava/lang/String;

    .line 8
    .line 9
    iget-object v2, p0, Ld8;->h:Ljava/lang/Object;

    .line 10
    .line 11
    check-cast v2, Lsd0;

    .line 12
    .line 13
    invoke-interface {v2, p1}, Lsd0;->a(Ljava/lang/Object;)Ljava/nio/ByteBuffer;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    if-nez p2, :cond_14

    .line 18
    .line 19
    const/4 p0, 0x0

    .line 20
    goto :goto_1b

    .line 21
    :cond_14
    new-instance v2, Lba;

    .line 22
    .line 23
    const/4 v3, 0x0

    .line 24
    invoke-direct {v2, p0, v3, p2}, Lba;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    move-object p0, v2

    .line 28
    :goto_1b
    invoke-interface {v0, v1, p1, p0}, Lla;->m(Ljava/lang/String;Ljava/nio/ByteBuffer;Lka;)V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public y(Ljava/lang/Object;)V
    .registers 7

    .line 1
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    .line 6
    .line 7
    .line 8
    move-result-wide v0

    .line 9
    sget-wide v2, Lq3;->a:J

    .line 10
    .line 11
    cmp-long v2, v0, v2

    .line 12
    .line 13
    if-nez v2, :cond_11

    .line 14
    .line 15
    iput-object p1, p0, Ld8;->h:Ljava/lang/Object;

    .line 16
    .line 17
    return-void

    .line 18
    :cond_11
    iget-object v2, p0, Ld8;->g:Ljava/lang/Object;

    .line 19
    .line 20
    monitor-enter v2

    .line 21
    :try_start_14
    iget-object v3, p0, Ld8;->f:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v3, Ljava/util/concurrent/atomic/AtomicReference;

    .line 24
    .line 25
    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Lt31;

    .line 30
    .line 31
    invoke-virtual {v3, v0, v1}, Lt31;->a(J)I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    if-gez v4, :cond_35

    .line 36
    .line 37
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 38
    .line 39
    check-cast p0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 40
    .line 41
    invoke-virtual {v3, v0, v1, p1}, Lt31;->b(JLjava/lang/Object;)Lt31;

    .line 42
    .line 43
    .line 44
    move-result-object p1

    .line 45
    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    .line 46
    .line 47
    .line 48
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_31
    .catchall {:try_start_14 .. :try_end_31} :catchall_33

    .line 49
    .line 50
    monitor-exit v2

    .line 51
    return-void

    .line 52
    :catchall_33
    move-exception p0

    .line 53
    goto :goto_3b

    .line 54
    :cond_35
    :try_start_35
    iget-object p0, v3, Lt31;->c:[Ljava/lang/Object;

    .line 55
    .line 56
    aput-object p1, p0, v4
    :try_end_39
    .catchall {:try_start_35 .. :try_end_39} :catchall_33

    .line 57
    .line 58
    monitor-exit v2

    .line 59
    return-void

    .line 60
    :goto_3b
    monitor-exit v2

    .line 61
    throw p0
.end method

.method public z(Lca;)V
    .registers 6

    .line 1
    iget-object v0, p0, Ld8;->g:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Ljava/lang/String;

    .line 4
    .line 5
    iget-object v1, p0, Ld8;->f:Ljava/lang/Object;

    .line 6
    .line 7
    check-cast v1, Lla;

    .line 8
    .line 9
    if-nez p1, :cond_c

    .line 10
    .line 11
    const/4 p0, 0x0

    .line 12
    goto :goto_14

    .line 13
    :cond_c
    new-instance v2, Lu6;

    .line 14
    .line 15
    const/16 v3, 0x9

    .line 16
    .line 17
    invoke-direct {v2, p0, v3, p1}, Lu6;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 18
    .line 19
    .line 20
    move-object p0, v2

    .line 21
    :goto_14
    invoke-interface {v1, v0, p0}, Lla;->e(Ljava/lang/String;Lja;)V

    .line 22
    .line 23
    .line 24
    return-void
.end method
