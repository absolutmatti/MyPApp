###### Class defpackage.xl (xl)
.class public final Lxl;
.super Lnr;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/concurrent/Executor;


# static fields
.field public static final h:Lxl;

.field public static final i:Lbi;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lxl;

    .line 2
    .line 3
    invoke-direct {v0}, Lbi;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lxl;->h:Lxl;

    .line 7
    .line 8
    sget-object v0, Lr61;->h:Lr61;

    .line 9
    .line 10
    sget v1, Lr21;->a:I

    .line 11
    .line 12
    const/16 v2, 0x40

    .line 13
    .line 14
    if-ge v2, v1, :cond_10

    .line 15
    .line 16
    goto :goto_11

    .line 17
    :cond_10
    move v1, v2

    .line 18
    :goto_11
    const/16 v2, 0xc

    .line 19
    .line 20
    const-string v3, "kotlinx.coroutines.io.parallelism"

    .line 21
    .line 22
    invoke-static {v3, v1, v2}, Lrl;->Z(Ljava/lang/String;II)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    invoke-virtual {v0, v1}, Lr61;->B(I)Lbi;

    .line 27
    .line 28
    .line 29
    move-result-object v0

    .line 30
    sput-object v0, Lxl;->i:Lbi;

    .line 31
    .line 32
    return-void
.end method


# virtual methods
.method public final B(I)Lbi;
    .registers 2

    .line 1
    sget-object p0, Lr61;->h:Lr61;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lr61;->B(I)Lbi;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final close()V
    .registers 2

    .line 1
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 2
    .line 3
    const-string v0, "Cannot be invoked on Dispatchers.IO"

    .line 4
    .line 5
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    throw p0
.end method

.method public final execute(Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    sget-object v0, Lsq;->f:Lsq;

    .line 2
    .line 3
    invoke-virtual {p0, v0, p1}, Lxl;->y(Lyh;Ljava/lang/Runnable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    const-string p0, "Dispatchers.IO"

    .line 2
    .line 3
    return-object p0
.end method

.method public final y(Lyh;Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    sget-object p0, Lxl;->i:Lbi;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lbi;->y(Lyh;Ljava/lang/Runnable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public final z(Lyh;Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    sget-object p0, Lxl;->i:Lbi;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lbi;->z(Lyh;Ljava/lang/Runnable;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method
