###### Class defpackage.oo0 (oo0)
.class public final Loo0;
.super Ls60;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lqz;


# instance fields
.field public final synthetic g:Lqo0;

.field public final synthetic h:Lvf0;

.field public final synthetic i:Lvf0;

.field public final synthetic j:Ljava/util/List;

.field public final synthetic k:Ljava/util/List;

.field public final synthetic l:Lvf0;

.field public final synthetic m:Ljava/util/List;

.field public final synthetic n:Lvf0;

.field public final synthetic o:Ljava/util/Set;


# direct methods
.method public constructor <init>(Lqo0;Lvf0;Lvf0;Ljava/util/List;Ljava/util/List;Lvf0;Ljava/util/List;Lvf0;Ljava/util/Set;)V
    .registers 10

    .line 1
    iput-object p1, p0, Loo0;->g:Lqo0;

    .line 2
    .line 3
    iput-object p2, p0, Loo0;->h:Lvf0;

    .line 4
    .line 5
    iput-object p3, p0, Loo0;->i:Lvf0;

    .line 6
    .line 7
    iput-object p4, p0, Loo0;->j:Ljava/util/List;

    .line 8
    .line 9
    iput-object p5, p0, Loo0;->k:Ljava/util/List;

    .line 10
    .line 11
    iput-object p6, p0, Loo0;->l:Lvf0;

    .line 12
    .line 13
    iput-object p7, p0, Loo0;->m:Ljava/util/List;

    .line 14
    .line 15
    iput-object p8, p0, Loo0;->n:Lvf0;

    .line 16
    .line 17
    iput-object p9, p0, Loo0;->o:Ljava/util/Set;

    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    invoke-direct {p0, p1}, Ls60;-><init>(I)V

    .line 21
    .line 22
    .line 23
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 27

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    check-cast v1, Ljava/lang/Number;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 8
    .line 9
    .line 10
    move-result-wide v1

    .line 11
    iget-object v3, v0, Loo0;->g:Lqo0;

    .line 12
    .line 13
    iget-object v4, v3, Lqo0;->b:Ljava/lang/Object;

    .line 14
    .line 15
    monitor-enter v4

    .line 16
    :try_start_f
    invoke-virtual {v3}, Lqo0;->e()Z

    .line 17
    .line 18
    .line 19
    move-result v3
    :try_end_13
    .catchall {:try_start_f .. :try_end_13} :catchall_2d1

    .line 20
    monitor-exit v4

    .line 21
    const/4 v4, 0x1

    .line 22
    if-eqz v3, :cond_53

    .line 23
    .line 24
    const-string v3, "Recomposer:animation"

    .line 25
    .line 26
    iget-object v6, v0, Loo0;->g:Lqo0;

    .line 27
    .line 28
    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    :try_start_1e
    iget-object v3, v6, Lqo0;->a:Lxa;

    .line 32
    .line 33
    invoke-virtual {v3, v1, v2}, Lxa;->b(J)V

    .line 34
    .line 35
    .line 36
    sget-object v1, Lbz0;->b:Ljava/lang/Object;

    .line 37
    .line 38
    monitor-enter v1
    :try_end_26
    .catchall {:try_start_1e .. :try_end_26} :catchall_4e

    .line 39
    :try_start_26
    sget-object v2, Lbz0;->i:Ljava/util/concurrent/atomic/AtomicReference;

    .line 40
    .line 41
    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    check-cast v2, Li10;

    .line 46
    .line 47
    iget-object v2, v2, Lwf0;->g:Lvf0;

    .line 48
    .line 49
    if-eqz v2, :cond_3a

    .line 50
    .line 51
    invoke-virtual {v2}, Lvf0;->h()Z

    .line 52
    .line 53
    .line 54
    move-result v2
    :try_end_36
    .catchall {:try_start_26 .. :try_end_36} :catchall_3c

    .line 55
    if-ne v2, v4, :cond_3a

    .line 56
    .line 57
    move v2, v4

    .line 58
    goto :goto_3e

    .line 59
    :cond_3a
    const/4 v2, 0x0

    .line 60
    goto :goto_3e

    .line 61
    :catchall_3c
    move-exception v0

    .line 62
    goto :goto_4c

    .line 63
    :goto_3e
    :try_start_3e
    monitor-exit v1

    .line 64
    if-eqz v2, :cond_46

    .line 65
    .line 66
    sget-object v1, Laz0;->h:Laz0;

    .line 67
    .line 68
    invoke-static {v1}, Lbz0;->c(Lqz;)Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    :cond_46
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_48
    .catchall {:try_start_3e .. :try_end_48} :catchall_4e

    .line 72
    .line 73
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 74
    .line 75
    .line 76
    goto :goto_53

    .line 77
    :goto_4c
    :try_start_4c
    monitor-exit v1

    .line 78
    throw v0
    :try_end_4e
    .catchall {:try_start_4c .. :try_end_4e} :catchall_4e

    .line 79
    :catchall_4e
    move-exception v0

    .line 80
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 81
    .line 82
    .line 83
    throw v0

    .line 84
    :cond_53
    :goto_53
    const-string v1, "Recomposer:recompose"

    .line 85
    .line 86
    iget-object v6, v0, Loo0;->g:Lqo0;

    .line 87
    .line 88
    iget-object v12, v0, Loo0;->h:Lvf0;

    .line 89
    .line 90
    iget-object v13, v0, Loo0;->i:Lvf0;

    .line 91
    .line 92
    iget-object v7, v0, Loo0;->j:Ljava/util/List;

    .line 93
    .line 94
    iget-object v8, v0, Loo0;->k:Ljava/util/List;

    .line 95
    .line 96
    iget-object v10, v0, Loo0;->l:Lvf0;

    .line 97
    .line 98
    iget-object v9, v0, Loo0;->m:Ljava/util/List;

    .line 99
    .line 100
    iget-object v11, v0, Loo0;->n:Lvf0;

    .line 101
    .line 102
    iget-object v0, v0, Loo0;->o:Ljava/util/Set;

    .line 103
    .line 104
    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    :try_start_6a
    invoke-static {v6}, Lqo0;->b(Lqo0;)Z

    .line 108
    .line 109
    .line 110
    iget-object v1, v6, Lqo0;->b:Ljava/lang/Object;

    .line 111
    .line 112
    monitor-enter v1
    :try_end_70
    .catchall {:try_start_6a .. :try_end_70} :catchall_2cc

    .line 113
    :try_start_70
    iget-object v2, v6, Lqo0;->h:Lxf0;

    .line 114
    .line 115
    iget v3, v2, Lxf0;->g:I

    .line 116
    .line 117
    if-lez v3, :cond_88

    .line 118
    .line 119
    iget-object v2, v2, Lxf0;->f:[Ljava/lang/Object;

    .line 120
    .line 121
    const/4 v14, 0x0

    .line 122
    :cond_79
    aget-object v15, v2, v14

    .line 123
    .line 124
    check-cast v15, Lag;

    .line 125
    .line 126
    invoke-interface {v7, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    add-int/lit8 v14, v14, 0x1

    .line 130
    .line 131
    if-lt v14, v3, :cond_79

    .line 132
    .line 133
    goto :goto_88

    .line 134
    :catchall_85
    move-exception v0

    .line 135
    goto/16 :goto_2ca

    .line 136
    .line 137
    :cond_88
    :goto_88
    iget-object v2, v6, Lqo0;->h:Lxf0;

    .line 138
    .line 139
    invoke-virtual {v2}, Lxf0;->c()V

    .line 140
    .line 141
    .line 142
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_8f
    .catchall {:try_start_70 .. :try_end_8f} :catchall_85

    .line 143
    .line 144
    :try_start_8f
    monitor-exit v1

    .line 145
    invoke-virtual {v12}, Lvf0;->b()V

    .line 146
    .line 147
    .line 148
    invoke-virtual {v13}, Lvf0;->b()V

    .line 149
    .line 150
    .line 151
    :cond_96
    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    const/4 v2, 0x0

    .line 156
    if-eqz v1, :cond_1df

    .line 157
    .line 158
    invoke-interface {v8}, Ljava/util/Collection;->isEmpty()Z

    .line 159
    .line 160
    .line 161
    move-result v1

    .line 162
    if-nez v1, :cond_a5

    .line 163
    .line 164
    goto/16 :goto_1df

    .line 165
    .line 166
    :cond_a5
    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    .line 167
    .line 168
    .line 169
    move-result v0
    :try_end_a9
    .catchall {:try_start_8f .. :try_end_a9} :catchall_2cc

    .line 170
    if-nez v0, :cond_eb

    .line 171
    .line 172
    :try_start_ab
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 173
    .line 174
    .line 175
    move-result v0

    .line 176
    const/4 v1, 0x0

    .line 177
    :goto_b0
    if-ge v1, v0, :cond_c2

    .line 178
    .line 179
    invoke-interface {v9, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 180
    .line 181
    .line 182
    move-result-object v3

    .line 183
    check-cast v3, Lag;

    .line 184
    .line 185
    invoke-virtual {v11, v3}, Lvf0;->a(Ljava/lang/Object;)Z

    .line 186
    .line 187
    .line 188
    add-int/lit8 v1, v1, 0x1

    .line 189
    .line 190
    goto :goto_b0

    .line 191
    :catchall_be
    move-exception v0

    .line 192
    goto :goto_e7

    .line 193
    :catch_c0
    move-exception v0

    .line 194
    goto :goto_d9

    .line 195
    :cond_c2
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 196
    .line 197
    .line 198
    move-result v0

    .line 199
    const/4 v1, 0x0

    .line 200
    :goto_c7
    if-ge v1, v0, :cond_d5

    .line 201
    .line 202
    invoke-interface {v9, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 203
    .line 204
    .line 205
    move-result-object v3

    .line 206
    check-cast v3, Lag;

    .line 207
    .line 208
    invoke-virtual {v3}, Lag;->d()V
    :try_end_d2
    .catch Ljava/lang/Exception; {:try_start_ab .. :try_end_d2} :catch_c0
    .catchall {:try_start_ab .. :try_end_d2} :catchall_be

    .line 209
    .line 210
    .line 211
    add-int/lit8 v1, v1, 0x1

    .line 212
    .line 213
    goto :goto_c7

    .line 214
    :cond_d5
    :try_start_d5
    invoke-interface {v9}, Ljava/util/List;->clear()V
    :try_end_d8
    .catchall {:try_start_d5 .. :try_end_d8} :catchall_2cc

    .line 215
    .line 216
    .line 217
    goto :goto_eb

    .line 218
    :goto_d9
    :try_start_d9
    invoke-virtual {v6, v0, v2}, Lqo0;->i(Ljava/lang/Exception;Lag;)V

    .line 219
    .line 220
    .line 221
    invoke-static/range {v6 .. v13}, Lpo0;->q(Lqo0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lvf0;Lvf0;Lvf0;Lvf0;)V
    :try_end_df
    .catchall {:try_start_d9 .. :try_end_df} :catchall_be

    .line 222
    .line 223
    .line 224
    :try_start_df
    invoke-interface {v9}, Ljava/util/List;->clear()V
    :try_end_e2
    .catchall {:try_start_df .. :try_end_e2} :catchall_2cc

    .line 225
    .line 226
    .line 227
    :goto_e2
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 228
    .line 229
    .line 230
    goto/16 :goto_2c3

    .line 231
    .line 232
    :goto_e7
    :try_start_e7
    invoke-interface {v9}, Ljava/util/List;->clear()V

    .line 233
    .line 234
    .line 235
    throw v0

    .line 236
    :cond_eb
    :goto_eb
    invoke-virtual {v10}, Lvf0;->h()Z

    .line 237
    .line 238
    .line 239
    move-result v0
    :try_end_ef
    .catchall {:try_start_e7 .. :try_end_ef} :catchall_2cc

    .line 240
    const-wide v16, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    const/16 p0, 0x7

    .line 246
    .line 247
    const/16 v1, 0x8

    .line 248
    .line 249
    if-eqz v0, :cond_15c

    .line 250
    .line 251
    :try_start_fa
    invoke-virtual {v11, v10}, Lvf0;->i(Lvf0;)V

    .line 252
    .line 253
    .line 254
    iget-object v0, v10, Lvf0;->b:[Ljava/lang/Object;

    .line 255
    .line 256
    const-wide/16 v18, 0x80

    .line 257
    .line 258
    iget-object v3, v10, Lvf0;->a:[J

    .line 259
    .line 260
    array-length v4, v3

    .line 261
    add-int/lit8 v4, v4, -0x2

    .line 262
    .line 263
    if-ltz v4, :cond_148

    .line 264
    .line 265
    const/4 v5, 0x0

    .line 266
    const-wide/16 v20, 0xff

    .line 267
    .line 268
    :goto_10b
    aget-wide v14, v3, v5

    .line 269
    .line 270
    move-object/from16 v22, v3

    .line 271
    .line 272
    not-long v2, v14

    .line 273
    shl-long v2, v2, p0

    .line 274
    .line 275
    and-long/2addr v2, v14

    .line 276
    and-long v2, v2, v16

    .line 277
    .line 278
    cmp-long v2, v2, v16

    .line 279
    .line 280
    if-eqz v2, :cond_140

    .line 281
    .line 282
    sub-int v2, v5, v4

    .line 283
    .line 284
    not-int v2, v2

    .line 285
    ushr-int/lit8 v2, v2, 0x1f

    .line 286
    .line 287
    rsub-int/lit8 v2, v2, 0x8

    .line 288
    .line 289
    const/4 v3, 0x0

    .line 290
    :goto_121
    if-ge v3, v2, :cond_13e

    .line 291
    .line 292
    and-long v23, v14, v20

    .line 293
    .line 294
    cmp-long v23, v23, v18

    .line 295
    .line 296
    if-gez v23, :cond_13a

    .line 297
    .line 298
    shl-int/lit8 v23, v5, 0x3

    .line 299
    .line 300
    add-int v23, v23, v3

    .line 301
    .line 302
    aget-object v23, v0, v23

    .line 303
    .line 304
    check-cast v23, Lag;

    .line 305
    .line 306
    invoke-virtual/range {v23 .. v23}, Lag;->f()V
    :try_end_134
    .catch Ljava/lang/Exception; {:try_start_fa .. :try_end_134} :catch_137
    .catchall {:try_start_fa .. :try_end_134} :catchall_135

    .line 307
    .line 308
    .line 309
    goto :goto_13a

    .line 310
    :catchall_135
    move-exception v0

    .line 311
    goto :goto_158

    .line 312
    :catch_137
    move-exception v0

    .line 313
    const/4 v1, 0x0

    .line 314
    goto :goto_14e

    .line 315
    :cond_13a
    :goto_13a
    shr-long/2addr v14, v1

    .line 316
    add-int/lit8 v3, v3, 0x1

    .line 317
    .line 318
    goto :goto_121

    .line 319
    :cond_13e
    if-ne v2, v1, :cond_14a

    .line 320
    .line 321
    :cond_140
    if-eq v5, v4, :cond_14a

    .line 322
    .line 323
    add-int/lit8 v5, v5, 0x1

    .line 324
    .line 325
    move-object/from16 v3, v22

    .line 326
    .line 327
    const/4 v2, 0x0

    .line 328
    goto :goto_10b

    .line 329
    :cond_148
    const-wide/16 v20, 0xff

    .line 330
    .line 331
    :cond_14a
    :try_start_14a
    invoke-virtual {v10}, Lvf0;->b()V
    :try_end_14d
    .catchall {:try_start_14a .. :try_end_14d} :catchall_2cc

    .line 332
    .line 333
    .line 334
    goto :goto_160

    .line 335
    :goto_14e
    :try_start_14e
    invoke-virtual {v6, v0, v1}, Lqo0;->i(Ljava/lang/Exception;Lag;)V

    .line 336
    .line 337
    .line 338
    invoke-static/range {v6 .. v13}, Lpo0;->q(Lqo0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lvf0;Lvf0;Lvf0;Lvf0;)V
    :try_end_154
    .catchall {:try_start_14e .. :try_end_154} :catchall_135

    .line 339
    .line 340
    .line 341
    :try_start_154
    invoke-virtual {v10}, Lvf0;->b()V

    .line 342
    .line 343
    .line 344
    goto :goto_e2

    .line 345
    :goto_158
    invoke-virtual {v10}, Lvf0;->b()V

    .line 346
    .line 347
    .line 348
    throw v0

    .line 349
    :cond_15c
    const-wide/16 v18, 0x80

    .line 350
    .line 351
    const-wide/16 v20, 0xff

    .line 352
    .line 353
    :goto_160
    invoke-virtual {v11}, Lvf0;->h()Z

    .line 354
    .line 355
    .line 356
    move-result v0
    :try_end_164
    .catchall {:try_start_154 .. :try_end_164} :catchall_2cc

    .line 357
    if-eqz v0, :cond_1c1

    .line 358
    .line 359
    :try_start_166
    iget-object v0, v11, Lvf0;->b:[Ljava/lang/Object;

    .line 360
    .line 361
    iget-object v2, v11, Lvf0;->a:[J

    .line 362
    .line 363
    array-length v3, v2

    .line 364
    add-int/lit8 v3, v3, -0x2

    .line 365
    .line 366
    if-ltz v3, :cond_1ae

    .line 367
    .line 368
    const/4 v4, 0x0

    .line 369
    :goto_170
    aget-wide v14, v2, v4

    .line 370
    .line 371
    move v5, v1

    .line 372
    move-object/from16 v22, v2

    .line 373
    .line 374
    not-long v1, v14

    .line 375
    shl-long v1, v1, p0

    .line 376
    .line 377
    and-long/2addr v1, v14

    .line 378
    and-long v1, v1, v16

    .line 379
    .line 380
    cmp-long v1, v1, v16

    .line 381
    .line 382
    if-eqz v1, :cond_1a6

    .line 383
    .line 384
    sub-int v1, v4, v3

    .line 385
    .line 386
    not-int v1, v1

    .line 387
    ushr-int/lit8 v1, v1, 0x1f

    .line 388
    .line 389
    rsub-int/lit8 v1, v1, 0x8

    .line 390
    .line 391
    const/4 v2, 0x0

    .line 392
    :goto_187
    if-ge v2, v1, :cond_1a4

    .line 393
    .line 394
    and-long v23, v14, v20

    .line 395
    .line 396
    cmp-long v23, v23, v18

    .line 397
    .line 398
    if-gez v23, :cond_1a0

    .line 399
    .line 400
    shl-int/lit8 v23, v4, 0x3

    .line 401
    .line 402
    add-int v23, v23, v2

    .line 403
    .line 404
    aget-object v23, v0, v23

    .line 405
    .line 406
    check-cast v23, Lag;

    .line 407
    .line 408
    invoke-virtual/range {v23 .. v23}, Lag;->g()V
    :try_end_19a
    .catch Ljava/lang/Exception; {:try_start_166 .. :try_end_19a} :catch_19d
    .catchall {:try_start_166 .. :try_end_19a} :catchall_19b

    .line 409
    .line 410
    .line 411
    goto :goto_1a0

    .line 412
    :catchall_19b
    move-exception v0

    .line 413
    goto :goto_1bd

    .line 414
    :catch_19d
    move-exception v0

    .line 415
    const/4 v1, 0x0

    .line 416
    goto :goto_1b2

    .line 417
    :cond_1a0
    :goto_1a0
    shr-long/2addr v14, v5

    .line 418
    add-int/lit8 v2, v2, 0x1

    .line 419
    .line 420
    goto :goto_187

    .line 421
    :cond_1a4
    if-ne v1, v5, :cond_1ae

    .line 422
    .line 423
    :cond_1a6
    if-eq v4, v3, :cond_1ae

    .line 424
    .line 425
    add-int/lit8 v4, v4, 0x1

    .line 426
    .line 427
    move v1, v5

    .line 428
    move-object/from16 v2, v22

    .line 429
    .line 430
    goto :goto_170

    .line 431
    :cond_1ae
    :try_start_1ae
    invoke-virtual {v11}, Lvf0;->b()V
    :try_end_1b1
    .catchall {:try_start_1ae .. :try_end_1b1} :catchall_2cc

    .line 432
    .line 433
    .line 434
    goto :goto_1c1

    .line 435
    :goto_1b2
    :try_start_1b2
    invoke-virtual {v6, v0, v1}, Lqo0;->i(Ljava/lang/Exception;Lag;)V

    .line 436
    .line 437
    .line 438
    invoke-static/range {v6 .. v13}, Lpo0;->q(Lqo0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lvf0;Lvf0;Lvf0;Lvf0;)V
    :try_end_1b8
    .catchall {:try_start_1b2 .. :try_end_1b8} :catchall_19b

    .line 439
    .line 440
    .line 441
    :try_start_1b8
    invoke-virtual {v11}, Lvf0;->b()V

    .line 442
    .line 443
    .line 444
    goto/16 :goto_e2

    .line 445
    .line 446
    :goto_1bd
    invoke-virtual {v11}, Lvf0;->b()V

    .line 447
    .line 448
    .line 449
    throw v0

    .line 450
    :cond_1c1
    :goto_1c1
    iget-object v1, v6, Lqo0;->b:Ljava/lang/Object;

    .line 451
    .line 452
    monitor-enter v1
    :try_end_1c4
    .catchall {:try_start_1b8 .. :try_end_1c4} :catchall_2cc

    .line 453
    :try_start_1c4
    invoke-virtual {v6}, Lqo0;->d()Lec;
    :try_end_1c7
    .catchall {:try_start_1c4 .. :try_end_1c7} :catchall_1dc

    .line 454
    .line 455
    .line 456
    :try_start_1c7
    monitor-exit v1

    .line 457
    invoke-static {}, Lbz0;->f()Lwf0;

    .line 458
    .line 459
    .line 460
    move-result-object v0

    .line 461
    invoke-virtual {v0}, Lwf0;->g()V

    .line 462
    .line 463
    .line 464
    invoke-virtual {v13}, Lvf0;->b()V

    .line 465
    .line 466
    .line 467
    invoke-virtual {v12}, Lvf0;->b()V

    .line 468
    .line 469
    .line 470
    const/4 v1, 0x0

    .line 471
    iput-object v1, v6, Lqo0;->n:Ljava/util/LinkedHashSet;

    .line 472
    .line 473
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 474
    .line 475
    goto/16 :goto_e2

    .line 476
    .line 477
    :catchall_1dc
    move-exception v0

    .line 478
    monitor-exit v1

    .line 479
    throw v0
    :try_end_1df
    .catchall {:try_start_1c7 .. :try_end_1df} :catchall_2cc

    .line 480
    :cond_1df
    :goto_1df
    :try_start_1df
    invoke-interface {v7}, Ljava/util/List;->size()I

    .line 481
    .line 482
    .line 483
    move-result v1

    .line 484
    const/4 v2, 0x0

    .line 485
    :goto_1e4
    if-ge v2, v1, :cond_205

    .line 486
    .line 487
    invoke-interface {v7, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 488
    .line 489
    .line 490
    move-result-object v3

    .line 491
    check-cast v3, Lag;

    .line 492
    .line 493
    invoke-static {v6, v3, v12}, Lqo0;->a(Lqo0;Lag;Lvf0;)Lag;

    .line 494
    .line 495
    .line 496
    move-result-object v5

    .line 497
    if-eqz v5, :cond_1ff

    .line 498
    .line 499
    invoke-interface {v9, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 500
    .line 501
    .line 502
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 503
    .line 504
    goto :goto_1ff

    .line 505
    :catchall_1f8
    move-exception v0

    .line 506
    goto/16 :goto_2c6

    .line 507
    .line 508
    :catch_1fb
    move-exception v0

    .line 509
    const/4 v1, 0x0

    .line 510
    goto/16 :goto_2b8

    .line 511
    .line 512
    :cond_1ff
    :goto_1ff
    invoke-virtual {v13, v3}, Lvf0;->a(Ljava/lang/Object;)Z
    :try_end_202
    .catch Ljava/lang/Exception; {:try_start_1df .. :try_end_202} :catch_1fb
    .catchall {:try_start_1df .. :try_end_202} :catchall_1f8

    .line 513
    .line 514
    .line 515
    add-int/lit8 v2, v2, 0x1

    .line 516
    .line 517
    goto :goto_1e4

    .line 518
    :cond_205
    :try_start_205
    invoke-interface {v7}, Ljava/util/List;->clear()V

    .line 519
    .line 520
    .line 521
    invoke-virtual {v12}, Lvf0;->h()Z

    .line 522
    .line 523
    .line 524
    move-result v1

    .line 525
    if-nez v1, :cond_219

    .line 526
    .line 527
    iget-object v1, v6, Lqo0;->h:Lxf0;

    .line 528
    .line 529
    iget v1, v1, Lxf0;->g:I

    .line 530
    .line 531
    if-eqz v1, :cond_216

    .line 532
    .line 533
    move v1, v4

    .line 534
    goto :goto_217

    .line 535
    :cond_216
    const/4 v1, 0x0

    .line 536
    :goto_217
    if-eqz v1, :cond_27b

    .line 537
    .line 538
    :cond_219
    iget-object v1, v6, Lqo0;->b:Ljava/lang/Object;

    .line 539
    .line 540
    monitor-enter v1
    :try_end_21c
    .catchall {:try_start_205 .. :try_end_21c} :catchall_2cc

    .line 541
    :try_start_21c
    invoke-virtual {v6}, Lqo0;->g()Ljava/util/List;

    .line 542
    .line 543
    .line 544
    move-result-object v2

    .line 545
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 546
    .line 547
    .line 548
    move-result v3

    .line 549
    const/4 v5, 0x0

    .line 550
    :goto_225
    if-ge v5, v3, :cond_243

    .line 551
    .line 552
    invoke-interface {v2, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 553
    .line 554
    .line 555
    move-result-object v14

    .line 556
    check-cast v14, Lag;

    .line 557
    .line 558
    invoke-virtual {v13, v14}, Lvf0;->c(Ljava/lang/Object;)Z

    .line 559
    .line 560
    .line 561
    move-result v15

    .line 562
    if-nez v15, :cond_240

    .line 563
    .line 564
    invoke-virtual {v14, v0}, Lag;->p(Ljava/util/Set;)Z

    .line 565
    .line 566
    .line 567
    move-result v15

    .line 568
    if-eqz v15, :cond_240

    .line 569
    .line 570
    invoke-interface {v7, v14}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 571
    .line 572
    .line 573
    goto :goto_240

    .line 574
    :catchall_23d
    move-exception v0

    .line 575
    goto/16 :goto_2b6

    .line 576
    .line 577
    :cond_240
    :goto_240
    add-int/lit8 v5, v5, 0x1

    .line 578
    .line 579
    goto :goto_225

    .line 580
    :cond_243
    iget-object v2, v6, Lqo0;->h:Lxf0;

    .line 581
    .line 582
    iget v3, v2, Lxf0;->g:I
    :try_end_247
    .catchall {:try_start_21c .. :try_end_247} :catchall_23d

    .line 583
    .line 584
    const/4 v5, 0x0

    .line 585
    const/4 v14, 0x0

    .line 586
    :goto_249
    iget-object v15, v2, Lxf0;->f:[Ljava/lang/Object;

    .line 587
    .line 588
    if-ge v5, v3, :cond_270

    .line 589
    .line 590
    :try_start_24d
    aget-object v15, v15, v5

    .line 591
    .line 592
    check-cast v15, Lag;

    .line 593
    .line 594
    invoke-virtual {v13, v15}, Lvf0;->c(Ljava/lang/Object;)Z

    .line 595
    .line 596
    .line 597
    move-result v16

    .line 598
    if-nez v16, :cond_263

    .line 599
    .line 600
    invoke-interface {v7, v15}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 601
    .line 602
    .line 603
    move-result v16

    .line 604
    if-nez v16, :cond_263

    .line 605
    .line 606
    invoke-interface {v7, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 607
    .line 608
    .line 609
    add-int/lit8 v14, v14, 0x1

    .line 610
    .line 611
    goto :goto_26d

    .line 612
    :cond_263
    if-lez v14, :cond_26d

    .line 613
    .line 614
    iget-object v15, v2, Lxf0;->f:[Ljava/lang/Object;

    .line 615
    .line 616
    sub-int v16, v5, v14

    .line 617
    .line 618
    aget-object v17, v15, v5

    .line 619
    .line 620
    aput-object v17, v15, v16

    .line 621
    .line 622
    :cond_26d
    :goto_26d
    add-int/lit8 v5, v5, 0x1

    .line 623
    .line 624
    goto :goto_249

    .line 625
    :cond_270
    sub-int v5, v3, v14

    .line 626
    .line 627
    const/4 v14, 0x0

    .line 628
    invoke-static {v15, v5, v3, v14}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 629
    .line 630
    .line 631
    iput v5, v2, Lxf0;->g:I

    .line 632
    .line 633
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_27a
    .catchall {:try_start_24d .. :try_end_27a} :catchall_23d

    .line 634
    .line 635
    :try_start_27a
    monitor-exit v1

    .line 636
    :cond_27b
    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    .line 637
    .line 638
    .line 639
    move-result v1
    :try_end_27f
    .catchall {:try_start_27a .. :try_end_27f} :catchall_2cc

    .line 640
    if-eqz v1, :cond_96

    .line 641
    .line 642
    :try_start_281
    invoke-static {v8, v6}, Lpo0;->r(Ljava/util/List;Lqo0;)V

    .line 643
    .line 644
    .line 645
    :goto_284
    invoke-interface {v8}, Ljava/util/Collection;->isEmpty()Z

    .line 646
    .line 647
    .line 648
    move-result v1

    .line 649
    if-nez v1, :cond_96

    .line 650
    .line 651
    invoke-virtual {v6, v8, v12}, Lqo0;->h(Ljava/util/List;Lvf0;)Ljava/util/List;

    .line 652
    .line 653
    .line 654
    move-result-object v1

    .line 655
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 656
    .line 657
    .line 658
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 659
    .line 660
    .line 661
    move-result-object v1

    .line 662
    :goto_295
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 663
    .line 664
    .line 665
    move-result v2

    .line 666
    if-eqz v2, :cond_2a8

    .line 667
    .line 668
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 669
    .line 670
    .line 671
    move-result-object v2

    .line 672
    invoke-virtual {v10, v2}, Lvf0;->d(Ljava/lang/Object;)I

    .line 673
    .line 674
    .line 675
    move-result v3

    .line 676
    iget-object v5, v10, Lvf0;->b:[Ljava/lang/Object;

    .line 677
    .line 678
    aput-object v2, v5, v3

    .line 679
    .line 680
    goto :goto_295

    .line 681
    :cond_2a8
    invoke-static {v8, v6}, Lpo0;->r(Ljava/util/List;Lqo0;)V
    :try_end_2ab
    .catch Ljava/lang/Exception; {:try_start_281 .. :try_end_2ab} :catch_2ac
    .catchall {:try_start_281 .. :try_end_2ab} :catchall_2cc

    .line 682
    .line 683
    .line 684
    goto :goto_284

    .line 685
    :catch_2ac
    move-exception v0

    .line 686
    const/4 v1, 0x0

    .line 687
    :try_start_2ae
    invoke-virtual {v6, v0, v1}, Lqo0;->i(Ljava/lang/Exception;Lag;)V

    .line 688
    .line 689
    .line 690
    invoke-static/range {v6 .. v13}, Lpo0;->q(Lqo0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lvf0;Lvf0;Lvf0;Lvf0;)V

    .line 691
    .line 692
    .line 693
    goto/16 :goto_e2

    .line 694
    .line 695
    :goto_2b6
    monitor-exit v1

    .line 696
    throw v0
    :try_end_2b8
    .catchall {:try_start_2ae .. :try_end_2b8} :catchall_2cc

    .line 697
    :goto_2b8
    :try_start_2b8
    invoke-virtual {v6, v0, v1}, Lqo0;->i(Ljava/lang/Exception;Lag;)V

    .line 698
    .line 699
    .line 700
    invoke-static/range {v6 .. v13}, Lpo0;->q(Lqo0;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lvf0;Lvf0;Lvf0;Lvf0;)V
    :try_end_2be
    .catchall {:try_start_2b8 .. :try_end_2be} :catchall_1f8

    .line 701
    .line 702
    .line 703
    :try_start_2be
    invoke-interface {v7}, Ljava/util/List;->clear()V
    :try_end_2c1
    .catchall {:try_start_2be .. :try_end_2c1} :catchall_2cc

    .line 704
    .line 705
    .line 706
    goto/16 :goto_e2

    .line 707
    .line 708
    :goto_2c3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 709
    .line 710
    return-object v0

    .line 711
    :goto_2c6
    :try_start_2c6
    invoke-interface {v7}, Ljava/util/List;->clear()V

    .line 712
    .line 713
    .line 714
    throw v0

    .line 715
    :goto_2ca
    monitor-exit v1

    .line 716
    throw v0
    :try_end_2cc
    .catchall {:try_start_2c6 .. :try_end_2cc} :catchall_2cc

    .line 717
    :catchall_2cc
    move-exception v0

    .line 718
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 719
    .line 720
    .line 721
    throw v0

    .line 722
    :catchall_2d1
    move-exception v0

    .line 723
    monitor-exit v4

    .line 724
    throw v0
.end method
