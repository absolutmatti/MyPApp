###### Class defpackage.ae1 (ae1)
.class public final synthetic Lae1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Loz;


# instance fields
.field public final synthetic f:Lbe1;

.field public final synthetic g:Ljava/util/UUID;

.field public final synthetic h:Lpx;

.field public final synthetic i:Landroid/content/Context;


# direct methods
.method public synthetic constructor <init>(Lbe1;Ljava/util/UUID;Lpx;Landroid/content/Context;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lae1;->f:Lbe1;

    .line 5
    .line 6
    iput-object p2, p0, Lae1;->g:Ljava/util/UUID;

    .line 7
    .line 8
    iput-object p3, p0, Lae1;->h:Lpx;

    .line 9
    .line 10
    iput-object p4, p0, Lae1;->i:Landroid/content/Context;

    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 11

    .line 1
    iget-object v0, p0, Lae1;->f:Lbe1;

    .line 2
    .line 3
    iget-object v1, p0, Lae1;->g:Ljava/util/UUID;

    .line 4
    .line 5
    iget-object v2, p0, Lae1;->h:Lpx;

    .line 6
    .line 7
    iget-object p0, p0, Lae1;->i:Landroid/content/Context;

    .line 8
    .line 9
    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    .line 10
    .line 11
    .line 12
    move-result-object v1

    .line 13
    iget-object v3, v0, Lbe1;->c:Lre1;

    .line 14
    .line 15
    invoke-virtual {v3, v1}, Lre1;->b(Ljava/lang/String;)Lne1;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    const/4 v4, 0x0

    .line 20
    if-eqz v3, :cond_ac

    .line 21
    .line 22
    iget-object v5, v3, Lne1;->b:Lde1;

    .line 23
    .line 24
    invoke-virtual {v5}, Lde1;->a()Z

    .line 25
    .line 26
    .line 27
    move-result v5

    .line 28
    if-nez v5, :cond_ac

    .line 29
    .line 30
    iget-object v0, v0, Lbe1;->b:Lrm0;

    .line 31
    .line 32
    const-string v5, "Moving WorkSpec ("

    .line 33
    .line 34
    iget-object v6, v0, Lrm0;->k:Ljava/lang/Object;

    .line 35
    .line 36
    monitor-enter v6

    .line 37
    :try_start_24
    invoke-static {}, Lta0;->g()Lta0;

    .line 38
    .line 39
    .line 40
    move-result-object v7

    .line 41
    sget-object v8, Lrm0;->l:Ljava/lang/String;

    .line 42
    .line 43
    new-instance v9, Ljava/lang/StringBuilder;

    .line 44
    .line 45
    invoke-direct {v9, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 46
    .line 47
    .line 48
    invoke-virtual {v9, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 49
    .line 50
    .line 51
    const-string v5, ") to the foreground"

    .line 52
    .line 53
    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 54
    .line 55
    .line 56
    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 57
    .line 58
    .line 59
    move-result-object v5

    .line 60
    invoke-virtual {v7, v8, v5}, Lta0;->h(Ljava/lang/String;Ljava/lang/String;)V

    .line 61
    .line 62
    .line 63
    iget-object v5, v0, Lrm0;->g:Ljava/util/HashMap;

    .line 64
    .line 65
    invoke-virtual {v5, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    check-cast v5, Lff1;

    .line 70
    .line 71
    if-eqz v5, :cond_70

    .line 72
    .line 73
    iget-object v7, v0, Lrm0;->a:Landroid/os/PowerManager$WakeLock;

    .line 74
    .line 75
    if-nez v7, :cond_5a

    .line 76
    .line 77
    iget-object v7, v0, Lrm0;->b:Landroid/content/Context;

    .line 78
    .line 79
    invoke-static {v7}, Lka1;->a(Landroid/content/Context;)Landroid/os/PowerManager$WakeLock;

    .line 80
    .line 81
    .line 82
    move-result-object v7

    .line 83
    iput-object v7, v0, Lrm0;->a:Landroid/os/PowerManager$WakeLock;

    .line 84
    .line 85
    invoke-virtual {v7}, Landroid/os/PowerManager$WakeLock;->acquire()V

    .line 86
    .line 87
    .line 88
    goto :goto_5a

    .line 89
    :catchall_58
    move-exception p0

    .line 90
    goto :goto_aa

    .line 91
    :cond_5a
    :goto_5a
    iget-object v7, v0, Lrm0;->f:Ljava/util/HashMap;

    .line 92
    .line 93
    invoke-virtual {v7, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 94
    .line 95
    .line 96
    iget-object v1, v0, Lrm0;->b:Landroid/content/Context;

    .line 97
    .line 98
    iget-object v5, v5, Lff1;->a:Lne1;

    .line 99
    .line 100
    invoke-static {v5}, Lhh1;->p(Lne1;)Lce1;

    .line 101
    .line 102
    .line 103
    move-result-object v5

    .line 104
    invoke-static {v1, v5, v2}, Ll21;->a(Landroid/content/Context;Lce1;Lpx;)Landroid/content/Intent;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    iget-object v0, v0, Lrm0;->b:Landroid/content/Context;

    .line 109
    .line 110
    invoke-virtual {v0, v1}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 111
    .line 112
    .line 113
    :cond_70
    monitor-exit v6
    :try_end_71
    .catchall {:try_start_24 .. :try_end_71} :catchall_58

    .line 114
    invoke-static {v3}, Lhh1;->p(Lne1;)Lce1;

    .line 115
    .line 116
    .line 117
    move-result-object v0

    .line 118
    sget-object v1, Ll21;->o:Ljava/lang/String;

    .line 119
    .line 120
    new-instance v1, Landroid/content/Intent;

    .line 121
    .line 122
    const-class v3, Landroidx/work/impl/foreground/SystemForegroundService;

    .line 123
    .line 124
    invoke-direct {v1, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 125
    .line 126
    .line 127
    const-string v3, "ACTION_NOTIFY"

    .line 128
    .line 129
    invoke-virtual {v1, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 130
    .line 131
    .line 132
    const-string v3, "KEY_NOTIFICATION_ID"

    .line 133
    .line 134
    iget v5, v2, Lpx;->a:I

    .line 135
    .line 136
    invoke-virtual {v1, v3, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 137
    .line 138
    .line 139
    const-string v3, "KEY_FOREGROUND_SERVICE_TYPE"

    .line 140
    .line 141
    iget v5, v2, Lpx;->b:I

    .line 142
    .line 143
    invoke-virtual {v1, v3, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 144
    .line 145
    .line 146
    const-string v3, "KEY_NOTIFICATION"

    .line 147
    .line 148
    iget-object v2, v2, Lpx;->c:Landroid/app/Notification;

    .line 149
    .line 150
    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 151
    .line 152
    .line 153
    const-string v2, "KEY_WORKSPEC_ID"

    .line 154
    .line 155
    iget-object v3, v0, Lce1;->a:Ljava/lang/String;

    .line 156
    .line 157
    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 158
    .line 159
    .line 160
    const-string v2, "KEY_GENERATION"

    .line 161
    .line 162
    iget v0, v0, Lce1;->b:I

    .line 163
    .line 164
    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 165
    .line 166
    .line 167
    invoke-virtual {p0, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    .line 168
    .line 169
    .line 170
    return-object v4

    .line 171
    :goto_aa
    :try_start_aa
    monitor-exit v6
    :try_end_ab
    .catchall {:try_start_aa .. :try_end_ab} :catchall_58

    .line 172
    throw p0

    .line 173
    :cond_ac
    const-string p0, "Calls to setForegroundAsync() must complete before a ListenableWorker signals completion of work by returning an instance of Result."

    .line 174
    .line 175
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 176
    .line 177
    .line 178
    return-object v4
.end method
