###### Class defpackage.kg0 (kg0)
.class public final Lkg0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lvg;


# instance fields
.field public final a:Landroid/net/ConnectivityManager;


# direct methods
.method public constructor <init>(Landroid/net/ConnectivityManager;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lkg0;->a:Landroid/net/ConnectivityManager;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a(Lyg;)Lub;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    new-instance v0, Lpc;

    .line 5
    .line 6
    const/4 v1, 0x0

    .line 7
    const/4 v2, 0x7

    .line 8
    invoke-direct {v0, p1, p0, v1, v2}, Lpc;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 9
    .line 10
    .line 11
    new-instance p0, Lub;

    .line 12
    .line 13
    const/4 p1, -0x2

    .line 14
    sget-object v1, Lab;->f:Lab;

    .line 15
    .line 16
    sget-object v2, Lsq;->f:Lsq;

    .line 17
    .line 18
    invoke-direct {p0, v0, v2, p1, v1}, Lub;-><init>(Lsz;Lyh;ILab;)V

    .line 19
    .line 20
    .line 21
    return-object p0
.end method

.method public final b(Lne1;)Z
    .registers 2

    .line 1
    iget-object p0, p1, Lne1;->j:Lyg;

    .line 2
    .line 3
    invoke-virtual {p0}, Lyg;->a()Landroid/net/NetworkRequest;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    if-nez p0, :cond_13

    .line 8
    .line 9
    iget-object p0, p1, Lne1;->j:Lyg;

    .line 10
    .line 11
    iget-object p0, p0, Lyg;->a:Llg0;

    .line 12
    .line 13
    sget-object p1, Llg0;->f:Llg0;

    .line 14
    .line 15
    if-eq p0, p1, :cond_11

    .line 16
    .line 17
    goto :goto_13

    .line 18
    :cond_11
    const/4 p0, 0x0

    .line 19
    return p0

    .line 20
    :cond_13
    :goto_13
    const/4 p0, 0x1

    .line 21
    return p0
.end method
