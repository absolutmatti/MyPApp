###### Class defpackage.ee (ee)
.class public interface abstract Lee;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract onActionViewCollapsed()V
.end method

.method public abstract onActionViewExpanded()V
.end method
