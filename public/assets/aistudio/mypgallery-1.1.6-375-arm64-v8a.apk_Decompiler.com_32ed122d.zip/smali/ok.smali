###### Class defpackage.ok (ok)
.class public final Lok;
.super Lc21;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ltz;


# instance fields
.field public final synthetic j:I

.field public k:I

.field public synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILkotlin/coroutines/Continuation;)V
    .registers 4

    .line 11
    const/4 v0, 0x1

    iput v0, p0, Lok;->j:I

    invoke-direct {p0, p1, p2}, Lc21;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method public constructor <init>(Lel;Lkotlin/coroutines/Continuation;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lok;->j:I

    .line 3
    .line 4
    iput-object p1, p0, Lok;->l:Ljava/lang/Object;

    .line 5
    .line 6
    const/4 p1, 0x3

    .line 7
    invoke-direct {p0, p1, p2}, Lc21;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final d(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lok;->j:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_34

    .line 4
    .line 5
    .line 6
    check-cast p1, Lgt;

    .line 7
    .line 8
    check-cast p2, Ljava/lang/Boolean;

    .line 9
    .line 10
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    check-cast p3, Lkotlin/coroutines/Continuation;

    .line 14
    .line 15
    new-instance p0, Lok;

    .line 16
    .line 17
    const/4 p2, 0x3

    .line 18
    invoke-direct {p0, p2, p3}, Lok;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 19
    .line 20
    .line 21
    iput-object p1, p0, Lok;->l:Ljava/lang/Object;

    .line 22
    .line 23
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 24
    .line 25
    invoke-virtual {p0, p1}, Lok;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    return-object p0

    .line 30
    :pswitch_1d
    check-cast p1, Lfu;

    .line 31
    .line 32
    check-cast p2, Ljava/lang/Throwable;

    .line 33
    .line 34
    check-cast p3, Lkotlin/coroutines/Continuation;

    .line 35
    .line 36
    new-instance p1, Lok;

    .line 37
    .line 38
    iget-object p0, p0, Lok;->l:Ljava/lang/Object;

    .line 39
    .line 40
    check-cast p0, Lel;

    .line 41
    .line 42
    invoke-direct {p1, p0, p3}, Lok;-><init>(Lel;Lkotlin/coroutines/Continuation;)V

    .line 43
    .line 44
    .line 45
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 46
    .line 47
    invoke-virtual {p1, p0}, Lok;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object p0

    .line 51
    return-object p0

    .line 52
    nop

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_1d
    .end packed-switch
.end method

.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Lok;->j:I

    .line 2
    .line 3
    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    .line 4
    .line 5
    const/4 v2, 0x1

    .line 6
    const/4 v3, 0x0

    .line 7
    packed-switch v0, :pswitch_data_6a

    .line 8
    .line 9
    .line 10
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    iget v4, p0, Lok;->k:I

    .line 15
    .line 16
    if-eqz v4, :cond_1c

    .line 17
    .line 18
    if-ne v4, v2, :cond_17

    .line 19
    .line 20
    invoke-static {p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 21
    .line 22
    .line 23
    goto :goto_42

    .line 24
    :cond_17
    invoke-static {v1}, Lm0;->g(Ljava/lang/String;)V

    .line 25
    .line 26
    .line 27
    :goto_1a
    move-object p1, v3

    .line 28
    goto :goto_42

    .line 29
    :cond_1c
    invoke-static {p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    iget-object p1, p0, Lok;->l:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p1, Lgt;

    .line 35
    .line 36
    iput v2, p0, Lok;->k:I

    .line 37
    .line 38
    iget-object v1, p1, Lgt;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-nez v1, :cond_3c

    .line 45
    .line 46
    iget-object v1, p1, Lgt;->a:Ljava/io/File;

    .line 47
    .line 48
    new-instance v4, Lyk;

    .line 49
    .line 50
    invoke-direct {v4, p1, v3, v2}, Lyk;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 51
    .line 52
    .line 53
    invoke-static {v1, v4, p0}, Lge1;->b(Ljava/io/File;Lqz;Lsh;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object p1

    .line 57
    if-ne p1, v0, :cond_42

    .line 58
    .line 59
    move-object p1, v0

    .line 60
    goto :goto_42

    .line 61
    :cond_3c
    const-string p0, "This scope has already been closed."

    .line 62
    .line 63
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 64
    .line 65
    .line 66
    goto :goto_1a

    .line 67
    :cond_42
    :goto_42
    return-object p1

    .line 68
    :pswitch_43
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 69
    .line 70
    .line 71
    move-result-object v0

    .line 72
    iget v4, p0, Lok;->k:I

    .line 73
    .line 74
    if-eqz v4, :cond_55

    .line 75
    .line 76
    if-ne v4, v2, :cond_51

    .line 77
    .line 78
    invoke-static {p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 79
    .line 80
    .line 81
    goto :goto_66

    .line 82
    :cond_51
    invoke-static {v1}, Lm0;->g(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    goto :goto_68

    .line 86
    :cond_55
    invoke-static {p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 87
    .line 88
    .line 89
    iget-object p1, p0, Lok;->l:Ljava/lang/Object;

    .line 90
    .line 91
    check-cast p1, Lel;

    .line 92
    .line 93
    iput v2, p0, Lok;->k:I

    .line 94
    .line 95
    invoke-static {p1, p0}, Lel;->b(Lel;Lsh;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    if-ne p0, v0, :cond_66

    .line 100
    .line 101
    move-object v3, v0

    .line 102
    goto :goto_68

    .line 103
    :cond_66
    :goto_66
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 104
    .line 105
    :goto_68
    return-object v3

    .line 106
    nop

    .line 107
    :pswitch_data_6a
    .packed-switch 0x0
        :pswitch_43
    .end packed-switch
.end method
