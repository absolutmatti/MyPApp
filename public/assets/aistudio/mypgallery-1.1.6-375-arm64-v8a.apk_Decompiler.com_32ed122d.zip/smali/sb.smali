###### Class defpackage.sb (sb)
.class public abstract Lsb;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements La60;
.implements Ljava/io/Serializable;


# instance fields
.field public transient f:La60;

.field public final g:Ljava/lang/Object;

.field public final h:Ljava/lang/Class;

.field public final i:Ljava/lang/String;

.field public final j:Ljava/lang/String;

.field public final k:Z


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;Z)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lsb;->g:Ljava/lang/Object;

    .line 5
    .line 6
    iput-object p2, p0, Lsb;->h:Ljava/lang/Class;

    .line 7
    .line 8
    iput-object p3, p0, Lsb;->i:Ljava/lang/String;

    .line 9
    .line 10
    iput-object p4, p0, Lsb;->j:Ljava/lang/String;

    .line 11
    .line 12
    iput-boolean p5, p0, Lsb;->k:Z

    .line 13
    .line 14
    return-void
.end method


# virtual methods
.method public abstract c()La60;
.end method

.method public final f()Lhd;
    .registers 2

    .line 1
    iget-boolean v0, p0, Lsb;->k:Z

    .line 2
    .line 3
    iget-object p0, p0, Lsb;->h:Ljava/lang/Class;

    .line 4
    .line 5
    if-eqz v0, :cond_11

    .line 6
    .line 7
    sget-object v0, Lwo0;->a:Lxo0;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    new-instance v0, Lhj0;

    .line 13
    .line 14
    invoke-direct {v0, p0}, Lhj0;-><init>(Ljava/lang/Class;)V

    .line 15
    .line 16
    .line 17
    return-object v0

    .line 18
    :cond_11
    invoke-static {p0}, Lwo0;->a(Ljava/lang/Class;)Ljd;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0
.end method
