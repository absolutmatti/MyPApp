###### Class defpackage.og1 (og1)
.class public final Log1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final i:Lu6;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/lang/String;

.field public final c:Lu6;

.field public final d:Ld31;

.field public final e:Lh5;

.field public final f:I

.field public final g:Ls10;

.field public final h:Lo10;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lmp;

    .line 2
    .line 3
    const/16 v1, 0xa

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lmp;-><init>(I)V

    .line 6
    .line 7
    .line 8
    new-instance v1, Lmf1;

    .line 9
    .line 10
    const/4 v2, 0x2

    .line 11
    invoke-direct {v1, v2}, Lmf1;-><init>(I)V

    .line 12
    .line 13
    .line 14
    new-instance v2, Lu6;

    .line 15
    .line 16
    invoke-direct {v2, v1, v0}, Lu6;-><init>(Lmf1;Lmp;)V

    .line 17
    .line 18
    .line 19
    sput-object v2, Log1;->i:Lu6;

    .line 20
    .line 21
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ld31;)V
    .registers 8

    .line 1
    sget-object v0, Lj10;->b:Lj10;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const-string v1, "Null context is not permitted."

    .line 7
    .line 8
    invoke-static {p1, v1}, Lr30;->k(Ljava/lang/Object;Ljava/lang/String;)V

    .line 9
    .line 10
    .line 11
    const-string v1, "Api must not be null."

    .line 12
    .line 13
    sget-object v2, Log1;->i:Lu6;

    .line 14
    .line 15
    invoke-static {v2, v1}, Lr30;->k(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    const-string v1, "Settings must not be null; use Settings.DEFAULT_SETTINGS instead."

    .line 19
    .line 20
    invoke-static {v0, v1}, Lr30;->k(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    const-string v3, "The provided context did not have an application context."

    .line 28
    .line 29
    invoke-static {v1, v3}, Lr30;->k(Ljava/lang/Object;Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    iput-object v1, p0, Log1;->a:Landroid/content/Context;

    .line 33
    .line 34
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 35
    .line 36
    const/16 v4, 0x1e

    .line 37
    .line 38
    if-lt v3, v4, :cond_2c

    .line 39
    .line 40
    invoke-static {p1}, Le1;->q(Landroid/content/Context;)Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    const/4 p1, 0x0

    .line 46
    :goto_2d
    iput-object p1, p0, Log1;->b:Ljava/lang/String;

    .line 47
    .line 48
    iput-object v2, p0, Log1;->c:Lu6;

    .line 49
    .line 50
    iput-object p2, p0, Log1;->d:Ld31;

    .line 51
    .line 52
    new-instance v3, Lh5;

    .line 53
    .line 54
    invoke-direct {v3, v2, p2, p1}, Lh5;-><init>(Lu6;Ld31;Ljava/lang/String;)V

    .line 55
    .line 56
    .line 57
    iput-object v3, p0, Log1;->e:Lh5;

    .line 58
    .line 59
    new-instance p1, Lvf1;

    .line 60
    .line 61
    invoke-static {v1}, Lo10;->d(Landroid/content/Context;)Lo10;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    iput-object p1, p0, Log1;->h:Lo10;

    .line 66
    .line 67
    iget-object p2, p1, Lo10;->h:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 68
    .line 69
    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    .line 70
    .line 71
    .line 72
    move-result p2

    .line 73
    iput p2, p0, Log1;->f:I

    .line 74
    .line 75
    iget-object p2, v0, Lj10;->a:Ls10;

    .line 76
    .line 77
    iput-object p2, p0, Log1;->g:Ls10;

    .line 78
    .line 79
    iget-object p1, p1, Lo10;->m:Lsg1;

    .line 80
    .line 81
    const/4 p2, 0x7

    .line 82
    invoke-virtual {p1, p2, p0}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    .line 83
    .line 84
    .line 85
    move-result-object p0

    .line 86
    invoke-virtual {p1, p0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 87
    .line 88
    .line 89
    return-void
.end method


# virtual methods
.method public final a()Ld8;
    .registers 4

    .line 1
    new-instance v0, Ld8;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sget-object v1, Ljava/util/Collections;->EMPTY_SET:Ljava/util/Set;

    .line 7
    .line 8
    iget-object v2, v0, Ld8;->f:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v2, Li9;

    .line 11
    .line 12
    if-nez v2, :cond_14

    .line 13
    .line 14
    new-instance v2, Li9;

    .line 15
    .line 16
    invoke-direct {v2}, Li9;-><init>()V

    .line 17
    .line 18
    .line 19
    iput-object v2, v0, Ld8;->f:Ljava/lang/Object;

    .line 20
    .line 21
    :cond_14
    iget-object v2, v0, Ld8;->f:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v2, Li9;

    .line 24
    .line 25
    invoke-virtual {v2, v1}, Li9;->addAll(Ljava/util/Collection;)Z

    .line 26
    .line 27
    .line 28
    iget-object p0, p0, Log1;->a:Landroid/content/Context;

    .line 29
    .line 30
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iput-object v1, v0, Ld8;->h:Ljava/lang/Object;

    .line 39
    .line 40
    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 41
    .line 42
    .line 43
    move-result-object p0

    .line 44
    iput-object p0, v0, Ld8;->g:Ljava/lang/Object;

    .line 45
    .line 46
    return-object v0
.end method

.method public final b(Lc31;)Lfi1;
    .registers 6

    .line 1
    new-instance v0, Lns0;

    .line 2
    .line 3
    const/16 v1, 0xb

    .line 4
    .line 5
    invoke-direct {v0, v1}, Lns0;-><init>(I)V

    .line 6
    .line 7
    .line 8
    sget-object v1, Llf1;->f:Lws;

    .line 9
    .line 10
    filled-new-array {v1}, [Lws;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    new-instance v2, Lns0;

    .line 15
    .line 16
    const/16 v3, 0x1b

    .line 17
    .line 18
    invoke-direct {v2, v3, p1}, Lns0;-><init>(ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    iput-object v2, v0, Lns0;->g:Ljava/lang/Object;

    .line 22
    .line 23
    new-instance p1, Lj31;

    .line 24
    .line 25
    const/4 v2, 0x0

    .line 26
    invoke-direct {p1, v0, v1, v2}, Lj31;-><init>(Lns0;[Lws;Z)V

    .line 27
    .line 28
    .line 29
    new-instance v0, Lx21;

    .line 30
    .line 31
    invoke-direct {v0}, Lx21;-><init>()V

    .line 32
    .line 33
    .line 34
    iget-object v1, p0, Log1;->h:Lo10;

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    new-instance v2, Lkg1;

    .line 40
    .line 41
    iget-object v3, p0, Log1;->g:Ls10;

    .line 42
    .line 43
    invoke-direct {v2, p1, v0, v3}, Lkg1;-><init>(Lj31;Lx21;Ls10;)V

    .line 44
    .line 45
    .line 46
    iget-object p1, v1, Lo10;->i:Ljava/util/concurrent/atomic/AtomicInteger;

    .line 47
    .line 48
    new-instance v3, Lbg1;

    .line 49
    .line 50
    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 51
    .line 52
    .line 53
    move-result p1

    .line 54
    invoke-direct {v3, v2, p1, p0}, Lbg1;-><init>(Lkg1;ILog1;)V

    .line 55
    .line 56
    .line 57
    iget-object p0, v1, Lo10;->m:Lsg1;

    .line 58
    .line 59
    const/4 p1, 0x4

    .line 60
    invoke-virtual {p0, p1, v3}, Landroid/os/Handler;->obtainMessage(ILjava/lang/Object;)Landroid/os/Message;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    invoke-virtual {p0, p1}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z

    .line 65
    .line 66
    .line 67
    iget-object p0, v0, Lx21;->a:Lfi1;

    .line 68
    .line 69
    return-object p0
.end method
