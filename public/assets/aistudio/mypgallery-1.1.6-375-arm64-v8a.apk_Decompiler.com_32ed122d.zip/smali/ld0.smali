###### Class defpackage.ld0 (ld0)
.class public interface abstract Lld0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract a(Lrc0;Z)V
.end method

.method public abstract r(Lrc0;)Z
.end method
