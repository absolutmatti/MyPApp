###### Class defpackage.w90 (w90)
.class public interface abstract Lw90;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/concurrent/Future;


# virtual methods
.method public abstract a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
.end method
