###### Class defpackage.qn0 (qn0)
.class public final Lqn0;
.super Lpn0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:Lorg/chromium/support_lib_boundary/ProxyControllerBoundaryInterface;
