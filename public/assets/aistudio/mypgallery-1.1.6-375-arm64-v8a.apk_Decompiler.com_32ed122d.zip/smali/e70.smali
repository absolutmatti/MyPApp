###### Class defpackage.e70 (e70)
.class public final Le70;
.super Lq00;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final APP_WIDGET_IDS_FIELD_NUMBER:I = 0x2

.field private static final DEFAULT_INSTANCE:Le70;

.field private static volatile PARSER:Loj0; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Loj0;"
        }
    .end annotation
.end field

.field public static final RECEIVER_FIELD_NUMBER:I = 0x1


# instance fields
.field private appWidgetIdsMemoizedSerializedSize:I

.field private appWidgetIds_:Lf40;

.field private receiver_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Le70;

    .line 2
    .line 3
    invoke-direct {v0}, Le70;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Le70;->DEFAULT_INSTANCE:Le70;

    .line 7
    .line 8
    const-class v1, Le70;

    .line 9
    .line 10
    invoke-static {v1, v0}, Lq00;->i(Ljava/lang/Class;Lq00;)V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    .line 1
    invoke-direct {p0}, Lq00;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, -0x1

    .line 5
    iput v0, p0, Le70;->appWidgetIdsMemoizedSerializedSize:I

    .line 6
    .line 7
    const-string v0, ""

    .line 8
    .line 9
    iput-object v0, p0, Le70;->receiver_:Ljava/lang/String;

    .line 10
    .line 11
    sget-object v0, Lt30;->i:Lt30;

    .line 12
    .line 13
    iput-object v0, p0, Le70;->appWidgetIds_:Lf40;

    .line 14
    .line 15
    return-void
.end method

.method public static k()Le70;
    .registers 1

    .line 1
    sget-object v0, Le70;->DEFAULT_INSTANCE:Le70;

    .line 2
    .line 3
    return-object v0
.end method


# virtual methods
.method public final b(I)Ljava/lang/Object;
    .registers 4

    .line 1
    invoke-static {p1}, Lzi0;->y(I)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const/4 p1, 0x0

    .line 6
    packed-switch p0, :pswitch_data_50

    .line 7
    .line 8
    .line 9
    invoke-static {}, Lm0;->r()V

    .line 10
    .line 11
    .line 12
    return-object p1

    .line 13
    :pswitch_c
    sget-object p0, Le70;->PARSER:Loj0;

    .line 14
    .line 15
    if-nez p0, :cond_25

    .line 16
    .line 17
    const-class p1, Le70;

    .line 18
    .line 19
    monitor-enter p1

    .line 20
    :try_start_13
    sget-object p0, Le70;->PARSER:Loj0;

    .line 21
    .line 22
    if-nez p0, :cond_21

    .line 23
    .line 24
    new-instance p0, Lk00;

    .line 25
    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 27
    .line 28
    .line 29
    sput-object p0, Le70;->PARSER:Loj0;

    .line 30
    .line 31
    goto :goto_21

    .line 32
    :catchall_1f
    move-exception p0

    .line 33
    goto :goto_23

    .line 34
    :cond_21
    :goto_21
    monitor-exit p1

    .line 35
    return-object p0

    .line 36
    :goto_23
    monitor-exit p1
    :try_end_24
    .catchall {:try_start_13 .. :try_end_24} :catchall_1f

    .line 37
    throw p0

    .line 38
    :cond_25
    return-object p0

    .line 39
    :pswitch_26
    sget-object p0, Le70;->DEFAULT_INSTANCE:Le70;

    .line 40
    .line 41
    return-object p0

    .line 42
    :pswitch_29
    new-instance p0, Lw60;

    .line 43
    .line 44
    sget-object p1, Le70;->DEFAULT_INSTANCE:Le70;

    .line 45
    .line 46
    invoke-direct {p0, p1}, Lh00;-><init>(Lq00;)V

    .line 47
    .line 48
    .line 49
    return-object p0

    .line 50
    :pswitch_31
    new-instance p0, Le70;

    .line 51
    .line 52
    invoke-direct {p0}, Le70;-><init>()V

    .line 53
    .line 54
    .line 55
    return-object p0

    .line 56
    :pswitch_37
    const-string p0, "receiver_"

    .line 57
    .line 58
    const-string p1, "appWidgetIds_"

    .line 59
    .line 60
    filled-new-array {p0, p1}, [Ljava/lang/Object;

    .line 61
    .line 62
    .line 63
    move-result-object p0

    .line 64
    const-string p1, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u0208\u0002\'"

    .line 65
    .line 66
    sget-object v0, Le70;->DEFAULT_INSTANCE:Le70;

    .line 67
    .line 68
    new-instance v1, Lco0;

    .line 69
    .line 70
    invoke-direct {v1, v0, p1, p0}, Lco0;-><init>(Lq00;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 71
    .line 72
    .line 73
    return-object v1

    .line 74
    :pswitch_49
    return-object p1

    .line 75
    :pswitch_4a
    const/4 p0, 0x1

    .line 76
    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    return-object p0

    .line 81
    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_4a
        :pswitch_49
        :pswitch_37
        :pswitch_31
        :pswitch_29
        :pswitch_26
        :pswitch_c
    .end packed-switch
.end method

.method public final l()Ljava/lang/String;
    .registers 1

    .line 1
    iget-object p0, p0, Le70;->receiver_:Ljava/lang/String;

    .line 2
    .line 3
    return-object p0
.end method
