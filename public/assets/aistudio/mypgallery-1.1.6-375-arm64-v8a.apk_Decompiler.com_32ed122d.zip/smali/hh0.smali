###### Class defpackage.hh0 (hh0)
.class public final Lhh0;
.super Lsh;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:Lfl;

.field public k:I


# direct methods
.method public constructor <init>(Lfl;Lsh;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lhh0;->j:Lfl;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lsh;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lhh0;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lhh0;->k:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lhh0;->k:I

    .line 9
    .line 10
    iget-object p1, p0, Lhh0;->j:Lfl;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lfl;->a(Lf51;Lsh;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
