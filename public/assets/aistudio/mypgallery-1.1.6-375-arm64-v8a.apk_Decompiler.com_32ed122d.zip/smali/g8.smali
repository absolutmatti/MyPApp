###### Class defpackage.g8 (g8)
.class public final synthetic Lg8;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .registers 4

    .line 1
    iput p2, p0, Lg8;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lg8;->g:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p3, p0, Lg8;->h:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Runnable;Ljava/lang/Object;I)V
    .registers 4

    .line 11
    iput p3, p0, Lg8;->f:I

    iput-object p1, p0, Lg8;->h:Ljava/lang/Object;

    iput-object p2, p0, Lg8;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    .line 1
    iget v0, p0, Lg8;->f:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x0

    .line 5
    packed-switch v0, :pswitch_data_24c

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Lg8;->h:Ljava/lang/Object;

    .line 9
    .line 10
    check-cast v0, Ljava/lang/Runnable;

    .line 11
    .line 12
    iget-object p0, p0, Lg8;->g:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast p0, Lut0;

    .line 15
    .line 16
    :try_start_f
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_12
    .catchall {:try_start_f .. :try_end_12} :catchall_16

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0}, Lut0;->a()V

    .line 20
    .line 21
    .line 22
    return-void

    .line 23
    :catchall_16
    move-exception v0

    .line 24
    invoke-virtual {p0}, Lut0;->a()V

    .line 25
    .line 26
    .line 27
    throw v0

    .line 28
    :pswitch_1b
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 29
    .line 30
    check-cast v0, Lq1;

    .line 31
    .line 32
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 33
    .line 34
    check-cast p0, La01;

    .line 35
    .line 36
    iget-object v0, v0, Lq1;->g:Ljava/lang/Object;

    .line 37
    .line 38
    check-cast v0, Lbl0;

    .line 39
    .line 40
    const/4 v1, 0x3

    .line 41
    invoke-virtual {v0, p0, v1}, Lbl0;->u(La01;I)V

    .line 42
    .line 43
    .line 44
    return-void

    .line 45
    :pswitch_2c
    iget-object v0, p0, Lg8;->h:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v0, Ljava/lang/Runnable;

    .line 48
    .line 49
    iget-object p0, p0, Lg8;->g:Ljava/lang/Object;

    .line 50
    .line 51
    check-cast p0, Lkl;

    .line 52
    .line 53
    sget-object v2, Lpz0;->h:Ljava/util/HashMap;

    .line 54
    .line 55
    :try_start_36
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_39
    .catchall {:try_start_36 .. :try_end_39} :catchall_49

    .line 56
    .line 57
    .line 58
    sget-object v0, Lpz0;->j:Ljava/lang/Object;

    .line 59
    .line 60
    monitor-enter v0

    .line 61
    :try_start_3c
    sget v2, Lpz0;->r:I

    .line 62
    .line 63
    sub-int/2addr v2, v1

    .line 64
    sput v2, Lpz0;->r:I

    .line 65
    .line 66
    invoke-static {p0}, Lpz0;->f(Lkl;)V

    .line 67
    .line 68
    .line 69
    monitor-exit v0

    .line 70
    return-void

    .line 71
    :catchall_46
    move-exception p0

    .line 72
    monitor-exit v0
    :try_end_48
    .catchall {:try_start_3c .. :try_end_48} :catchall_46

    .line 73
    throw p0

    .line 74
    :catchall_49
    move-exception v0

    .line 75
    sget-object v2, Lpz0;->j:Ljava/lang/Object;

    .line 76
    .line 77
    monitor-enter v2

    .line 78
    :try_start_4d
    sget v3, Lpz0;->r:I

    .line 79
    .line 80
    sub-int/2addr v3, v1

    .line 81
    sput v3, Lpz0;->r:I

    .line 82
    .line 83
    invoke-static {p0}, Lpz0;->f(Lkl;)V

    .line 84
    .line 85
    .line 86
    monitor-exit v2
    :try_end_56
    .catchall {:try_start_4d .. :try_end_56} :catchall_57

    .line 87
    throw v0

    .line 88
    :catchall_57
    move-exception p0

    .line 89
    :try_start_58
    monitor-exit v2
    :try_end_59
    .catchall {:try_start_58 .. :try_end_59} :catchall_57

    .line 90
    throw p0

    .line 91
    :pswitch_5a
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v0, Ln7;

    .line 94
    .line 95
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 96
    .line 97
    check-cast p0, Landroid/graphics/Typeface;

    .line 98
    .line 99
    invoke-virtual {v0, p0}, Ln7;->b(Landroid/graphics/Typeface;)V

    .line 100
    .line 101
    .line 102
    return-void

    .line 103
    :pswitch_66
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 104
    .line 105
    check-cast v0, Lfn0;

    .line 106
    .line 107
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast p0, Landroid/net/LocalServerSocket;

    .line 110
    .line 111
    :goto_6e
    iget-boolean v1, v0, Lfn0;->e:Z

    .line 112
    .line 113
    if-nez v1, :cond_a1

    .line 114
    .line 115
    :try_start_72
    invoke-virtual {p0}, Landroid/net/LocalServerSocket;->accept()Landroid/net/LocalSocket;

    .line 116
    .line 117
    .line 118
    move-result-object v1
    :try_end_76
    .catch Ljava/lang/Exception; {:try_start_72 .. :try_end_76} :catch_89

    .line 119
    :try_start_76
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 120
    .line 121
    .line 122
    invoke-virtual {v0, v1}, Lfn0;->a(Landroid/net/LocalSocket;)V

    .line 123
    .line 124
    .line 125
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_7e
    .catchall {:try_start_76 .. :try_end_7e} :catchall_82

    .line 126
    .line 127
    invoke-interface {v1}, Ljava/io/Closeable;->close()V

    .line 128
    .line 129
    .line 130
    goto :goto_6e

    .line 131
    :catchall_82
    move-exception p0

    .line 132
    :try_start_83
    throw p0
    :try_end_84
    .catchall {:try_start_83 .. :try_end_84} :catchall_84

    .line 133
    :catchall_84
    move-exception v0

    .line 134
    invoke-static {v1, p0}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 135
    .line 136
    .line 137
    throw v0

    .line 138
    :catch_89
    move-exception p0

    .line 139
    iget-boolean v0, v0, Lfn0;->e:Z

    .line 140
    .line 141
    if-nez v0, :cond_a1

    .line 142
    .line 143
    const-string v0, "DpiProtect"

    .line 144
    .line 145
    new-instance v1, Ljava/lang/StringBuilder;

    .line 146
    .line 147
    const-string v2, "accept failed: "

    .line 148
    .line 149
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 153
    .line 154
    .line 155
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 156
    .line 157
    .line 158
    move-result-object p0

    .line 159
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 160
    .line 161
    .line 162
    :cond_a1
    return-void

    .line 163
    :pswitch_a2
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 164
    .line 165
    check-cast v0, Lrm0;

    .line 166
    .line 167
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 168
    .line 169
    check-cast p0, Lce1;

    .line 170
    .line 171
    iget-object v1, v0, Lrm0;->k:Ljava/lang/Object;

    .line 172
    .line 173
    monitor-enter v1

    .line 174
    :try_start_ad
    iget-object v0, v0, Lrm0;->j:Ljava/util/ArrayList;

    .line 175
    .line 176
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 177
    .line 178
    .line 179
    move-result v2

    .line 180
    const/4 v3, 0x0

    .line 181
    move v4, v3

    .line 182
    :goto_b5
    if-ge v4, v2, :cond_c5

    .line 183
    .line 184
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v5

    .line 188
    add-int/lit8 v4, v4, 0x1

    .line 189
    .line 190
    check-cast v5, Lmr;

    .line 191
    .line 192
    invoke-interface {v5, p0, v3}, Lmr;->d(Lce1;Z)V

    .line 193
    .line 194
    .line 195
    goto :goto_b5

    .line 196
    :catchall_c3
    move-exception p0

    .line 197
    goto :goto_c7

    .line 198
    :cond_c5
    monitor-exit v1

    .line 199
    return-void

    .line 200
    :goto_c7
    monitor-exit v1
    :try_end_c8
    .catchall {:try_start_ad .. :try_end_c8} :catchall_c3

    .line 201
    throw p0

    .line 202
    :pswitch_c9
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 203
    .line 204
    check-cast v0, Lgc;

    .line 205
    .line 206
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 207
    .line 208
    check-cast p0, Lz10;

    .line 209
    .line 210
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 211
    .line 212
    invoke-virtual {v0, p0, v1}, Lgc;->C(Lbi;Lkotlin/Unit;)V

    .line 213
    .line 214
    .line 215
    return-void

    .line 216
    :pswitch_d7
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 217
    .line 218
    check-cast v0, [Ljava/lang/String;

    .line 219
    .line 220
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 221
    .line 222
    check-cast p0, Lcom/mypg/mypgallery/dpi/DpiVpnService;

    .line 223
    .line 224
    sget v2, Lcom/mypg/mypgallery/dpi/DpiVpnService;->k:I

    .line 225
    .line 226
    invoke-static {v0}, Lcom/mypg/mypgallery/dpi/DpiNative;->startProxy([Ljava/lang/String;)I

    .line 227
    .line 228
    .line 229
    move-result v0

    .line 230
    const-string v2, "DpiVpn"

    .line 231
    .line 232
    new-instance v3, Ljava/lang/StringBuilder;

    .line 233
    .line 234
    const-string v4, "ciadpi exited with "

    .line 235
    .line 236
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 237
    .line 238
    .line 239
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 240
    .line 241
    .line 242
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 243
    .line 244
    .line 245
    move-result-object v0

    .line 246
    invoke-static {v2, v0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 247
    .line 248
    .line 249
    iget-boolean v0, p0, Lcom/mypg/mypgallery/dpi/DpiVpnService;->i:Z

    .line 250
    .line 251
    if-nez v0, :cond_104

    .line 252
    .line 253
    const-string v0, "failed"

    .line 254
    .line 255
    invoke-virtual {p0, v0}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->b(Ljava/lang/String;)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {p0, v1}, Lcom/mypg/mypgallery/dpi/DpiVpnService;->a(Z)V

    .line 259
    .line 260
    .line 261
    :cond_104
    return-void

    .line 262
    :pswitch_105
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 263
    .line 264
    check-cast v0, Lqe0;

    .line 265
    .line 266
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 267
    .line 268
    check-cast p0, Ljava/lang/Throwable;

    .line 269
    .line 270
    const-string v1, "dpi"

    .line 271
    .line 272
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 273
    .line 274
    .line 275
    move-result-object p0

    .line 276
    invoke-virtual {v0, v1, p0, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 277
    .line 278
    .line 279
    return-void

    .line 280
    :pswitch_117
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 281
    .line 282
    check-cast v0, Lno;

    .line 283
    .line 284
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 285
    .line 286
    check-cast p0, Ljava/util/Map;

    .line 287
    .line 288
    iget-object v0, v0, Lno;->d:Ldr;

    .line 289
    .line 290
    if-eqz v0, :cond_126

    .line 291
    .line 292
    invoke-virtual {v0, p0}, Ldr;->a(Ljava/lang/Object;)V

    .line 293
    .line 294
    .line 295
    :cond_126
    return-void

    .line 296
    :pswitch_127
    iget-object p0, p0, Lg8;->g:Ljava/lang/Object;

    .line 297
    .line 298
    check-cast p0, Landroid/view/ViewGroup;

    .line 299
    .line 300
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 301
    .line 302
    .line 303
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->endViewTransition(Landroid/view/View;)V

    .line 304
    .line 305
    .line 306
    throw v2

    .line 307
    :pswitch_132
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 308
    .line 309
    check-cast v0, Lpl;

    .line 310
    .line 311
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 312
    .line 313
    check-cast p0, Lnl;

    .line 314
    .line 315
    monitor-enter v0

    .line 316
    :try_start_13b
    iget-boolean v1, v0, Lpl;->h:Z
    :try_end_13d
    .catchall {:try_start_13b .. :try_end_13d} :catchall_17f

    .line 317
    .line 318
    if-eqz v1, :cond_141

    .line 319
    .line 320
    monitor-exit v0

    .line 321
    goto :goto_199

    .line 322
    :cond_141
    :try_start_141
    new-instance v1, Ljava/util/HashSet;

    .line 323
    .line 324
    iget-object v3, v0, Lpl;->e:Ljava/util/HashSet;

    .line 325
    .line 326
    invoke-direct {v1, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    .line 327
    .line 328
    .line 329
    iget-object v3, v0, Lpl;->f:Ljava/util/HashSet;

    .line 330
    .line 331
    invoke-virtual {v3, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    .line 332
    .line 333
    .line 334
    iget-object v3, v0, Lpl;->e:Ljava/util/HashSet;

    .line 335
    .line 336
    invoke-virtual {v3, p0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 337
    .line 338
    .line 339
    iget-object v3, p0, Lnl;->f:Lml;

    .line 340
    .line 341
    if-eqz v3, :cond_165

    .line 342
    .line 343
    iget-object v3, v3, Lml;->a:Ldb0;

    .line 344
    .line 345
    if-eqz v3, :cond_165

    .line 346
    .line 347
    iget-object v3, v3, Ldb0;->g:Ljava/lang/Object;

    .line 348
    .line 349
    check-cast v3, Lkl;

    .line 350
    .line 351
    invoke-virtual {v3}, Lkl;->m()Z

    .line 352
    .line 353
    .line 354
    move-result v3

    .line 355
    if-eqz v3, :cond_165

    .line 356
    .line 357
    goto :goto_181

    .line 358
    :cond_165
    iget-object v3, p0, Lnl;->f:Lml;

    .line 359
    .line 360
    if-eqz v3, :cond_16e

    .line 361
    .line 362
    invoke-virtual {v3}, Lml;->a()Ljava/lang/Integer;

    .line 363
    .line 364
    .line 365
    move-result-object v3

    .line 366
    goto :goto_16f

    .line 367
    :cond_16e
    move-object v3, v2

    .line 368
    :goto_16f
    if-eqz v3, :cond_181

    .line 369
    .line 370
    iget-object v3, v0, Lpl;->g:Ljava/util/HashMap;

    .line 371
    .line 372
    iget-object v4, p0, Lnl;->f:Lml;

    .line 373
    .line 374
    if-eqz v4, :cond_17b

    .line 375
    .line 376
    invoke-virtual {v4}, Lml;->a()Ljava/lang/Integer;

    .line 377
    .line 378
    .line 379
    move-result-object v2

    .line 380
    :cond_17b
    invoke-virtual {v3, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 381
    .line 382
    .line 383
    goto :goto_181

    .line 384
    :catchall_17f
    move-exception p0

    .line 385
    goto :goto_19a

    .line 386
    :cond_181
    :goto_181
    invoke-virtual {v0, p0}, Lpl;->e(Lnl;)V

    .line 387
    .line 388
    .line 389
    invoke-virtual {v1}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 390
    .line 391
    .line 392
    move-result-object p0

    .line 393
    :goto_188
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 394
    .line 395
    .line 396
    move-result v1

    .line 397
    if-eqz v1, :cond_198

    .line 398
    .line 399
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 400
    .line 401
    .line 402
    move-result-object v1

    .line 403
    check-cast v1, Lnl;

    .line 404
    .line 405
    invoke-virtual {v0, v1}, Lpl;->e(Lnl;)V
    :try_end_197
    .catchall {:try_start_141 .. :try_end_197} :catchall_17f

    .line 406
    .line 407
    .line 408
    goto :goto_188

    .line 409
    :cond_198
    monitor-exit v0

    .line 410
    :goto_199
    return-void

    .line 411
    :goto_19a
    :try_start_19a
    monitor-exit v0
    :try_end_19b
    .catchall {:try_start_19a .. :try_end_19b} :catchall_17f

    .line 412
    throw p0

    .line 413
    :pswitch_19c
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 414
    .line 415
    check-cast v0, Lnl;

    .line 416
    .line 417
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 418
    .line 419
    check-cast p0, Lml;

    .line 420
    .line 421
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 422
    .line 423
    .line 424
    iget-object v1, p0, Lml;->b:Ljava/lang/Runnable;

    .line 425
    .line 426
    invoke-interface {v1}, Ljava/lang/Runnable;->run()V

    .line 427
    .line 428
    .line 429
    iput-object p0, v0, Lnl;->f:Lml;

    .line 430
    .line 431
    iget-object p0, v0, Lnl;->e:Lg8;

    .line 432
    .line 433
    invoke-virtual {p0}, Lg8;->run()V

    .line 434
    .line 435
    .line 436
    return-void

    .line 437
    :pswitch_1b4
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 438
    .line 439
    check-cast v0, Ljava/util/List;

    .line 440
    .line 441
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 442
    .line 443
    check-cast p0, Lga;

    .line 444
    .line 445
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 446
    .line 447
    .line 448
    move-result-object v0

    .line 449
    :goto_1c0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 450
    .line 451
    .line 452
    move-result v1

    .line 453
    if-eqz v1, :cond_1eb

    .line 454
    .line 455
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v1

    .line 459
    check-cast v1, Lx9;

    .line 460
    .line 461
    iget-object v2, p0, Lga;->e:Ljava/lang/Object;

    .line 462
    .line 463
    iget-object v3, v1, Lx9;->a:Lfa;

    .line 464
    .line 465
    invoke-virtual {v3, v2}, Lfa;->d(Ljava/lang/Object;)Z

    .line 466
    .line 467
    .line 468
    move-result v2

    .line 469
    if-eqz v2, :cond_1e0

    .line 470
    .line 471
    new-instance v2, Lah;

    .line 472
    .line 473
    invoke-virtual {v3}, Lfa;->c()I

    .line 474
    .line 475
    .line 476
    move-result v3

    .line 477
    invoke-direct {v2, v3}, Lah;-><init>(I)V

    .line 478
    .line 479
    .line 480
    goto :goto_1e2

    .line 481
    :cond_1e0
    sget-object v2, Lzg;->a:Lzg;

    .line 482
    .line 483
    :goto_1e2
    iget-object v1, v1, Lx9;->b:Lum0;

    .line 484
    .line 485
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 486
    .line 487
    .line 488
    invoke-virtual {v1, v2}, Lum0;->i(Ljava/lang/Object;)Ljava/lang/Object;

    .line 489
    .line 490
    .line 491
    goto :goto_1c0

    .line 492
    :cond_1eb
    return-void

    .line 493
    :pswitch_1ec
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 494
    .line 495
    check-cast v0, Lay;

    .line 496
    .line 497
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 498
    .line 499
    check-cast p0, Lsh0;

    .line 500
    .line 501
    invoke-static {v0, p0}, Lnf;->access$addObserverForBackInvoker(Lnf;Lsh0;)V

    .line 502
    .line 503
    .line 504
    return-void

    .line 505
    :pswitch_1f8
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 506
    .line 507
    check-cast v0, Lqe0;

    .line 508
    .line 509
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 510
    .line 511
    check-cast p0, Ljava/lang/Exception;

    .line 512
    .line 513
    const-string v1, "install_failed"

    .line 514
    .line 515
    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    .line 516
    .line 517
    .line 518
    move-result-object v3

    .line 519
    if-nez v3, :cond_20c

    .line 520
    .line 521
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 522
    .line 523
    .line 524
    move-result-object v3

    .line 525
    :cond_20c
    invoke-virtual {v0, v1, v3, v2}, Lqe0;->error(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    .line 526
    .line 527
    .line 528
    return-void

    .line 529
    :pswitch_210
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 530
    .line 531
    check-cast v0, Ljava/lang/String;

    .line 532
    .line 533
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 534
    .line 535
    check-cast p0, Ljava/lang/String;

    .line 536
    .line 537
    sget-object v1, Ll8;->a:Lte0;

    .line 538
    .line 539
    if-eqz v1, :cond_237

    .line 540
    .line 541
    const-string v3, "onInstallStatus"

    .line 542
    .line 543
    const-string v4, "status"

    .line 544
    .line 545
    new-instance v5, Lkj0;

    .line 546
    .line 547
    invoke-direct {v5, v4, v0}, Lkj0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 548
    .line 549
    .line 550
    const-string v0, "message"

    .line 551
    .line 552
    new-instance v4, Lkj0;

    .line 553
    .line 554
    invoke-direct {v4, v0, p0}, Lkj0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 555
    .line 556
    .line 557
    filled-new-array {v5, v4}, [Lkj0;

    .line 558
    .line 559
    .line 560
    move-result-object p0

    .line 561
    invoke-static {p0}, Lwb0;->W([Lkj0;)Ljava/util/Map;

    .line 562
    .line 563
    .line 564
    move-result-object p0

    .line 565
    invoke-virtual {v1, v3, p0, v2}, Lte0;->a(Ljava/lang/String;Ljava/lang/Object;Lse0;)V

    .line 566
    .line 567
    .line 568
    :cond_237
    return-void

    .line 569
    :pswitch_238
    iget-object v0, p0, Lg8;->g:Ljava/lang/Object;

    .line 570
    .line 571
    check-cast v0, Lut0;

    .line 572
    .line 573
    iget-object p0, p0, Lg8;->h:Ljava/lang/Object;

    .line 574
    .line 575
    check-cast p0, Ljava/lang/Runnable;

    .line 576
    .line 577
    :try_start_240
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V
    :try_end_243
    .catchall {:try_start_240 .. :try_end_243} :catchall_247

    .line 578
    .line 579
    .line 580
    invoke-virtual {v0}, Lut0;->a()V

    .line 581
    .line 582
    .line 583
    return-void

    .line 584
    :catchall_247
    move-exception p0

    .line 585
    invoke-virtual {v0}, Lut0;->a()V

    .line 586
    .line 587
    .line 588
    throw p0

    .line 589
    :pswitch_data_24c
    .packed-switch 0x0
        :pswitch_238
        :pswitch_210
        :pswitch_1f8
        :pswitch_1ec
        :pswitch_1b4
        :pswitch_19c
        :pswitch_132
        :pswitch_127
        :pswitch_117
        :pswitch_105
        :pswitch_d7
        :pswitch_c9
        :pswitch_a2
        :pswitch_66
        :pswitch_5a
        :pswitch_2c
        :pswitch_1b
    .end packed-switch
.end method
