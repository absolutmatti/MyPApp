###### Class defpackage.r61 (r61)
.class public final Lr61;
.super Lbi;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final h:Lr61;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lr61;

    .line 2
    .line 3
    invoke-direct {v0}, Lbi;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lr61;->h:Lr61;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final B(I)Lbi;
    .registers 3

    .line 1
    invoke-static {p1}, Lrl;->t(I)V

    .line 2
    .line 3
    .line 4
    sget v0, Lb31;->d:I

    .line 5
    .line 6
    if-lt p1, v0, :cond_8

    .line 7
    .line 8
    return-object p0

    .line 9
    :cond_8
    invoke-super {p0, p1}, Lbi;->B(I)Lbi;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .line 1
    const-string p0, "Dispatchers.IO"

    .line 2
    .line 3
    return-object p0
.end method

.method public final y(Lyh;Ljava/lang/Runnable;)V
    .registers 4

    .line 1
    sget-object p0, Lam;->i:Lam;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    iget-object p0, p0, Lam;->h:Lgi;

    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    invoke-virtual {p0, p2, p1, v0}, Lgi;->d(Ljava/lang/Runnable;ZZ)V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public final z(Lyh;Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    sget-object p0, Lam;->i:Lam;

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    iget-object p0, p0, Lam;->h:Lgi;

    .line 5
    .line 6
    invoke-virtual {p0, p2, p1, p1}, Lgi;->d(Ljava/lang/Runnable;ZZ)V

    .line 7
    .line 8
    .line 9
    return-void
.end method
