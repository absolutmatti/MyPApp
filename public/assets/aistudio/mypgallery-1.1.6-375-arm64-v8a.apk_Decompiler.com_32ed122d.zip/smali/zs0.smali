###### Class defpackage.zs0 (zs0)
.class public final Lzs0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic a:Landroidx/appcompat/widget/SearchView;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/SearchView;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lzs0;->a:Landroidx/appcompat/widget/SearchView;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .registers 10

    .line 1
    iget-object p0, p0, Lzs0;->a:Landroidx/appcompat/widget/SearchView;

    .line 2
    .line 3
    iget-object p1, p0, Landroidx/appcompat/widget/SearchView;->u:Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    .line 4
    .line 5
    iget-object p2, p0, Landroidx/appcompat/widget/SearchView;->C:Landroid/view/View;

    .line 6
    .line 7
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    .line 8
    .line 9
    .line 10
    move-result p3

    .line 11
    const/4 p4, 0x1

    .line 12
    if-le p3, p4, :cond_5b

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 15
    .line 16
    .line 17
    move-result-object p3

    .line 18
    invoke-virtual {p3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 19
    .line 20
    .line 21
    move-result-object p3

    .line 22
    iget-object p4, p0, Landroidx/appcompat/widget/SearchView;->w:Landroid/view/View;

    .line 23
    .line 24
    invoke-virtual {p4}, Landroid/view/View;->getPaddingLeft()I

    .line 25
    .line 26
    .line 27
    move-result p4

    .line 28
    new-instance p5, Landroid/graphics/Rect;

    .line 29
    .line 30
    invoke-direct {p5}, Landroid/graphics/Rect;-><init>()V

    .line 31
    .line 32
    .line 33
    invoke-static {p0}, Lx91;->a(Landroid/view/View;)Z

    .line 34
    .line 35
    .line 36
    move-result p6

    .line 37
    iget-boolean p0, p0, Landroidx/appcompat/widget/SearchView;->R:Z

    .line 38
    .line 39
    if-eqz p0, :cond_38

    .line 40
    .line 41
    const p0, 0x7f060029

    .line 42
    .line 43
    .line 44
    invoke-virtual {p3, p0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 45
    .line 46
    .line 47
    move-result p0

    .line 48
    const p7, 0x7f06002a

    .line 49
    .line 50
    .line 51
    invoke-virtual {p3, p7}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 52
    .line 53
    .line 54
    move-result p3

    .line 55
    add-int/2addr p3, p0

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    const/4 p3, 0x0

    .line 58
    :goto_39
    invoke-virtual {p1}, Landroid/widget/AutoCompleteTextView;->getDropDownBackground()Landroid/graphics/drawable/Drawable;

    .line 59
    .line 60
    .line 61
    move-result-object p0

    .line 62
    invoke-virtual {p0, p5}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    .line 63
    .line 64
    .line 65
    iget p0, p5, Landroid/graphics/Rect;->left:I

    .line 66
    .line 67
    if-eqz p6, :cond_46

    .line 68
    .line 69
    neg-int p0, p0

    .line 70
    goto :goto_49

    .line 71
    :cond_46
    add-int/2addr p0, p3

    .line 72
    sub-int p0, p4, p0

    .line 73
    .line 74
    :goto_49
    invoke-virtual {p1, p0}, Landroid/widget/AutoCompleteTextView;->setDropDownHorizontalOffset(I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {p2}, Landroid/view/View;->getWidth()I

    .line 78
    .line 79
    .line 80
    move-result p0

    .line 81
    iget p2, p5, Landroid/graphics/Rect;->left:I

    .line 82
    .line 83
    add-int/2addr p0, p2

    .line 84
    iget p2, p5, Landroid/graphics/Rect;->right:I

    .line 85
    .line 86
    add-int/2addr p0, p2

    .line 87
    add-int/2addr p0, p3

    .line 88
    sub-int/2addr p0, p4

    .line 89
    invoke-virtual {p1, p0}, Landroid/widget/AutoCompleteTextView;->setDropDownWidth(I)V

    .line 90
    .line 91
    .line 92
    :cond_5b
    return-void
.end method
