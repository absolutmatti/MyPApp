###### Class defpackage.yf (yf)
.class public abstract Lyf;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Luj0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Luj0;->i:Luj0;

    .line 2
    .line 3
    sput-object v0, Lyf;->a:Luj0;

    .line 4
    .line 5
    return-void
.end method
