###### Class defpackage.ps (ps)
.class public abstract Lps;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# direct methods
.method public static a(Lbd1;Landroidx/window/extensions/layout/FoldingFeature;)Lb20;
    .registers 9

    .line 1
    invoke-virtual {p1}, Landroidx/window/extensions/layout/FoldingFeature;->getType()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x2

    .line 6
    const/4 v2, 0x0

    .line 7
    const/4 v3, 0x1

    .line 8
    if-eq v0, v3, :cond_f

    .line 9
    .line 10
    if-eq v0, v1, :cond_c

    .line 11
    .line 12
    goto :goto_67

    .line 13
    :cond_c
    sget-object v0, Lyw;->h:Lyw;

    .line 14
    .line 15
    goto :goto_11

    .line 16
    :cond_f
    sget-object v0, Lyw;->g:Lyw;

    .line 17
    .line 18
    :goto_11
    invoke-virtual {p1}, Landroidx/window/extensions/layout/FoldingFeature;->getState()I

    .line 19
    .line 20
    .line 21
    move-result v4

    .line 22
    if-eq v4, v3, :cond_1d

    .line 23
    .line 24
    if-eq v4, v1, :cond_1a

    .line 25
    .line 26
    goto :goto_67

    .line 27
    :cond_1a
    sget-object v1, Lyw;->f:Lyw;

    .line 28
    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    sget-object v1, Lyw;->e:Lyw;

    .line 31
    .line 32
    :goto_1f
    invoke-virtual {p1}, Landroidx/window/extensions/layout/FoldingFeature;->getBounds()Landroid/graphics/Rect;

    .line 33
    .line 34
    .line 35
    move-result-object v3

    .line 36
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    iget v4, v3, Landroid/graphics/Rect;->left:I

    .line 40
    .line 41
    iget v5, v3, Landroid/graphics/Rect;->top:I

    .line 42
    .line 43
    iget v6, v3, Landroid/graphics/Rect;->right:I

    .line 44
    .line 45
    iget v3, v3, Landroid/graphics/Rect;->bottom:I

    .line 46
    .line 47
    if-gt v4, v6, :cond_86

    .line 48
    .line 49
    if-gt v5, v3, :cond_7a

    .line 50
    .line 51
    iget-object p0, p0, Lbd1;->a:Lta;

    .line 52
    .line 53
    invoke-virtual {p0}, Lta;->a()Landroid/graphics/Rect;

    .line 54
    .line 55
    .line 56
    move-result-object p0

    .line 57
    sub-int/2addr v3, v5

    .line 58
    if-nez v3, :cond_40

    .line 59
    .line 60
    sub-int v5, v6, v4

    .line 61
    .line 62
    if-nez v5, :cond_40

    .line 63
    .line 64
    goto :goto_67

    .line 65
    :cond_40
    sub-int/2addr v6, v4

    .line 66
    invoke-virtual {p0}, Landroid/graphics/Rect;->width()I

    .line 67
    .line 68
    .line 69
    move-result v4

    .line 70
    if-eq v6, v4, :cond_4e

    .line 71
    .line 72
    invoke-virtual {p0}, Landroid/graphics/Rect;->height()I

    .line 73
    .line 74
    .line 75
    move-result v4

    .line 76
    if-eq v3, v4, :cond_4e

    .line 77
    .line 78
    goto :goto_67

    .line 79
    :cond_4e
    invoke-virtual {p0}, Landroid/graphics/Rect;->width()I

    .line 80
    .line 81
    .line 82
    move-result v4

    .line 83
    if-ge v6, v4, :cond_5b

    .line 84
    .line 85
    invoke-virtual {p0}, Landroid/graphics/Rect;->height()I

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    if-ge v3, v4, :cond_5b

    .line 90
    .line 91
    goto :goto_67

    .line 92
    :cond_5b
    invoke-virtual {p0}, Landroid/graphics/Rect;->width()I

    .line 93
    .line 94
    .line 95
    move-result v4

    .line 96
    if-ne v6, v4, :cond_68

    .line 97
    .line 98
    invoke-virtual {p0}, Landroid/graphics/Rect;->height()I

    .line 99
    .line 100
    .line 101
    move-result p0

    .line 102
    if-ne v3, p0, :cond_68

    .line 103
    .line 104
    :goto_67
    return-object v2

    .line 105
    :cond_68
    new-instance p0, Lb20;

    .line 106
    .line 107
    new-instance v2, Lta;

    .line 108
    .line 109
    invoke-virtual {p1}, Landroidx/window/extensions/layout/FoldingFeature;->getBounds()Landroid/graphics/Rect;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 114
    .line 115
    .line 116
    invoke-direct {v2, p1}, Lta;-><init>(Landroid/graphics/Rect;)V

    .line 117
    .line 118
    .line 119
    invoke-direct {p0, v2, v0, v1}, Lb20;-><init>(Lta;Lyw;Lyw;)V

    .line 120
    .line 121
    .line 122
    return-object p0

    .line 123
    :cond_7a
    const-string p0, "top must be less than or equal to bottom, top: "

    .line 124
    .line 125
    const-string p1, ", bottom: "

    .line 126
    .line 127
    invoke-static {p0, p1, v5, v3}, Lzi0;->o(Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 128
    .line 129
    .line 130
    move-result-object p0

    .line 131
    invoke-static {p0}, Lc11;->d(Ljava/lang/Object;)V

    .line 132
    .line 133
    .line 134
    return-object v2

    .line 135
    :cond_86
    const-string p0, "Left must be less than or equal to right, left: "

    .line 136
    .line 137
    const-string p1, ", right: "

    .line 138
    .line 139
    invoke-static {p0, p1, v4, v6}, Lzi0;->o(Ljava/lang/String;Ljava/lang/String;II)Ljava/lang/String;

    .line 140
    .line 141
    .line 142
    move-result-object p0

    .line 143
    invoke-static {p0}, Lc11;->d(Ljava/lang/Object;)V

    .line 144
    .line 145
    .line 146
    return-object v2
.end method

.method public static b(Lbd1;Landroidx/window/extensions/layout/WindowLayoutInfo;)Lzc1;
    .registers 5

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroidx/window/extensions/layout/WindowLayoutInfo;->getDisplayFeatures()Ljava/util/List;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    .line 10
    .line 11
    new-instance v0, Ljava/util/ArrayList;

    .line 12
    .line 13
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 14
    .line 15
    .line 16
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    :cond_13
    :goto_13
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-eqz v1, :cond_34

    .line 25
    .line 26
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 27
    .line 28
    .line 29
    move-result-object v1

    .line 30
    check-cast v1, Landroidx/window/extensions/layout/DisplayFeature;

    .line 31
    .line 32
    instance-of v2, v1, Landroidx/window/extensions/layout/FoldingFeature;

    .line 33
    .line 34
    if-eqz v2, :cond_2d

    .line 35
    .line 36
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    check-cast v1, Landroidx/window/extensions/layout/FoldingFeature;

    .line 40
    .line 41
    invoke-static {p0, v1}, Lps;->a(Lbd1;Landroidx/window/extensions/layout/FoldingFeature;)Lb20;

    .line 42
    .line 43
    .line 44
    move-result-object v1

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    const/4 v1, 0x0

    .line 47
    :goto_2e
    if-eqz v1, :cond_13

    .line 48
    .line 49
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    goto :goto_13

    .line 53
    :cond_34
    new-instance p0, Lzc1;

    .line 54
    .line 55
    invoke-direct {p0, v0}, Lzc1;-><init>(Ljava/util/List;)V

    .line 56
    .line 57
    .line 58
    return-object p0
.end method

.method public static c(Landroid/content/Context;Landroidx/window/extensions/layout/WindowLayoutInfo;)Lzc1;
    .registers 10

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 5
    .line 6
    const/16 v1, 0x1d

    .line 7
    .line 8
    const/16 v2, 0x1e

    .line 9
    .line 10
    if-lt v0, v2, :cond_ec

    .line 11
    .line 12
    sget v3, Ldd1;->b:I

    .line 13
    .line 14
    const/4 v3, 0x0

    .line 15
    if-lt v0, v2, :cond_3b

    .line 16
    .line 17
    const-class v0, Landroid/view/WindowManager;

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 20
    .line 21
    .line 22
    move-result-object p0

    .line 23
    check-cast p0, Landroid/view/WindowManager;

    .line 24
    .line 25
    invoke-static {p0}, Le1;->z(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-static {v0}, Le1;->k(Landroid/view/WindowMetrics;)Landroid/view/WindowInsets;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    invoke-static {v0, v3}, Lvc1;->c(Landroid/view/WindowInsets;Landroid/view/View;)Lvc1;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    new-instance v1, Lbd1;

    .line 38
    .line 39
    invoke-static {p0}, Le1;->D(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    invoke-static {p0}, Le1;->j(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    .line 44
    .line 45
    .line 46
    move-result-object p0

    .line 47
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    .line 49
    .line 50
    new-instance v2, Lta;

    .line 51
    .line 52
    invoke-direct {v2, p0}, Lta;-><init>(Landroid/graphics/Rect;)V

    .line 53
    .line 54
    .line 55
    invoke-direct {v1, v2, v0}, Lbd1;-><init>(Lta;Lvc1;)V

    .line 56
    .line 57
    .line 58
    goto/16 :goto_c3

    .line 59
    .line 60
    :cond_3b
    move-object v0, p0

    .line 61
    :goto_3c
    instance-of v4, v0, Landroid/content/ContextWrapper;

    .line 62
    .line 63
    const-string v5, " is not a UiContext"

    .line 64
    .line 65
    if-eqz v4, :cond_e6

    .line 66
    .line 67
    instance-of v4, v0, Landroid/app/Activity;

    .line 68
    .line 69
    if-eqz v4, :cond_47

    .line 70
    .line 71
    goto :goto_55

    .line 72
    :cond_47
    instance-of v6, v0, Landroid/inputmethodservice/InputMethodService;

    .line 73
    .line 74
    if-eqz v6, :cond_4c

    .line 75
    .line 76
    goto :goto_55

    .line 77
    :cond_4c
    move-object v6, v0

    .line 78
    check-cast v6, Landroid/content/ContextWrapper;

    .line 79
    .line 80
    invoke-virtual {v6}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 81
    .line 82
    .line 83
    move-result-object v7

    .line 84
    if-nez v7, :cond_dd

    .line 85
    .line 86
    :goto_55
    if-eqz v4, :cond_5e

    .line 87
    .line 88
    check-cast p0, Landroid/app/Activity;

    .line 89
    .line 90
    invoke-static {p0}, Ldd1;->a(Landroid/app/Activity;)Lbd1;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    goto :goto_c3

    .line 95
    :cond_5e
    instance-of v0, v0, Landroid/inputmethodservice/InputMethodService;

    .line 96
    .line 97
    if-eqz v0, :cond_c8

    .line 98
    .line 99
    const-string v0, "window"

    .line 100
    .line 101
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 102
    .line 103
    .line 104
    move-result-object p0

    .line 105
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 106
    .line 107
    .line 108
    check-cast p0, Landroid/view/WindowManager;

    .line 109
    .line 110
    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 111
    .line 112
    .line 113
    move-result-object p0

    .line 114
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 115
    .line 116
    .line 117
    new-instance v0, Landroid/graphics/Point;

    .line 118
    .line 119
    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p0, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 123
    .line 124
    .line 125
    new-instance p0, Landroid/graphics/Rect;

    .line 126
    .line 127
    iget v3, v0, Landroid/graphics/Point;->x:I

    .line 128
    .line 129
    iget v0, v0, Landroid/graphics/Point;->y:I

    .line 130
    .line 131
    const/4 v4, 0x0

    .line 132
    invoke-direct {p0, v4, v4, v3, v0}, Landroid/graphics/Rect;-><init>(IIII)V

    .line 133
    .line 134
    .line 135
    new-instance v0, Lbd1;

    .line 136
    .line 137
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 138
    .line 139
    const/16 v4, 0x22

    .line 140
    .line 141
    if-lt v3, v4, :cond_94

    .line 142
    .line 143
    new-instance v1, Ljc1;

    .line 144
    .line 145
    invoke-direct {v1}, Ljc1;-><init>()V

    .line 146
    .line 147
    .line 148
    goto :goto_b3

    .line 149
    :cond_94
    const/16 v4, 0x1f

    .line 150
    .line 151
    if-lt v3, v4, :cond_9e

    .line 152
    .line 153
    new-instance v1, Lic1;

    .line 154
    .line 155
    invoke-direct {v1}, Lic1;-><init>()V

    .line 156
    .line 157
    .line 158
    goto :goto_b3

    .line 159
    :cond_9e
    if-lt v3, v2, :cond_a6

    .line 160
    .line 161
    new-instance v1, Lhc1;

    .line 162
    .line 163
    invoke-direct {v1}, Lhc1;-><init>()V

    .line 164
    .line 165
    .line 166
    goto :goto_b3

    .line 167
    :cond_a6
    if-lt v3, v1, :cond_ae

    .line 168
    .line 169
    new-instance v1, Lgc1;

    .line 170
    .line 171
    invoke-direct {v1}, Lgc1;-><init>()V

    .line 172
    .line 173
    .line 174
    goto :goto_b3

    .line 175
    :cond_ae
    new-instance v1, Lfc1;

    .line 176
    .line 177
    invoke-direct {v1}, Lfc1;-><init>()V

    .line 178
    .line 179
    .line 180
    :goto_b3
    invoke-virtual {v1}, Lkc1;->b()Lvc1;

    .line 181
    .line 182
    .line 183
    move-result-object v1

    .line 184
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 185
    .line 186
    .line 187
    new-instance v2, Lta;

    .line 188
    .line 189
    invoke-direct {v2, p0}, Lta;-><init>(Landroid/graphics/Rect;)V

    .line 190
    .line 191
    .line 192
    invoke-direct {v0, v2, v1}, Lbd1;-><init>(Lta;Lvc1;)V

    .line 193
    .line 194
    .line 195
    move-object v1, v0

    .line 196
    :goto_c3
    invoke-static {v1, p1}, Lps;->b(Lbd1;Landroidx/window/extensions/layout/WindowLayoutInfo;)Lzc1;

    .line 197
    .line 198
    .line 199
    move-result-object p0

    .line 200
    return-object p0

    .line 201
    :cond_c8
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 202
    .line 203
    new-instance v0, Ljava/lang/StringBuilder;

    .line 204
    .line 205
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 206
    .line 207
    .line 208
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 209
    .line 210
    .line 211
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 212
    .line 213
    .line 214
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 215
    .line 216
    .line 217
    move-result-object p0

    .line 218
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 219
    .line 220
    .line 221
    throw p1

    .line 222
    :cond_dd
    invoke-virtual {v6}, Landroid/content/ContextWrapper;->getBaseContext()Landroid/content/Context;

    .line 223
    .line 224
    .line 225
    move-result-object v0

    .line 226
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 227
    .line 228
    .line 229
    goto/16 :goto_3c

    .line 230
    .line 231
    :cond_e6
    const-string p1, "Context "

    .line 232
    .line 233
    invoke-static {p1, p0, v5}, Lc11;->f(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    .line 234
    .line 235
    .line 236
    return-object v3

    .line 237
    :cond_ec
    if-lt v0, v1, :cond_ff

    .line 238
    .line 239
    instance-of v0, p0, Landroid/app/Activity;

    .line 240
    .line 241
    if-eqz v0, :cond_ff

    .line 242
    .line 243
    sget v0, Ldd1;->b:I

    .line 244
    .line 245
    check-cast p0, Landroid/app/Activity;

    .line 246
    .line 247
    invoke-static {p0}, Ldd1;->a(Landroid/app/Activity;)Lbd1;

    .line 248
    .line 249
    .line 250
    move-result-object p0

    .line 251
    invoke-static {p0, p1}, Lps;->b(Lbd1;Landroidx/window/extensions/layout/WindowLayoutInfo;)Lzc1;

    .line 252
    .line 253
    .line 254
    move-result-object p0

    .line 255
    return-object p0

    .line 256
    :cond_ff
    new-instance p0, Ljava/lang/UnsupportedOperationException;

    .line 257
    .line 258
    const-string p1, "Display Features are only supported after Q. Display features for non-Activity contexts are not expected to be reported on devices running Q."

    .line 259
    .line 260
    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    .line 261
    .line 262
    .line 263
    throw p0
.end method
