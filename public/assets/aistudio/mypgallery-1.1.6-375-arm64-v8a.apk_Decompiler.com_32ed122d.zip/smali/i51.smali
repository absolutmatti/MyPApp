###### Class defpackage.i51 (i51)
.class public final Li51;
.super Lsh;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public i:Lm51;

.field public j:Lfl0;

.field public k:Ljava/lang/String;

.field public l:[Ljava/lang/String;

.field public m:I

.field public n:I

.field public o:I

.field public synthetic p:Ljava/lang/Object;

.field public final synthetic q:Lm51;

.field public r:I


# direct methods
.method public constructor <init>(Lm51;Lsh;)V
    .registers 3

    .line 1
    iput-object p1, p0, Li51;->q:Lm51;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lsh;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iput-object p1, p0, Li51;->p:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Li51;->r:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Li51;->r:I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    const/4 v0, 0x0

    .line 12
    iget-object v1, p0, Li51;->q:Lm51;

    .line 13
    .line 14
    invoke-static {v1, p1, v0, p0}, Lm51;->c(Lm51;Lz41;ILsh;)Ljava/lang/Object;

    .line 15
    .line 16
    .line 17
    move-result-object p0

    .line 18
    return-object p0
.end method
