###### Class defpackage.xp (xp)
.class public abstract Lxp;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 18
    iput p1, p0, Lxp;->a:I

    .line 19
    iput-object p2, p0, Lxp;->b:Ljava/lang/Object;

    .line 20
    iput-object p3, p0, Lxp;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Laq;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Lxp;->a:I

    .line 6
    .line 7
    new-instance v0, Lwl;

    .line 8
    .line 9
    invoke-direct {v0}, Lwl;-><init>()V

    .line 10
    .line 11
    .line 12
    iput-object v0, p0, Lxp;->c:Ljava/lang/Object;

    .line 13
    .line 14
    iput-object p1, p0, Lxp;->b:Ljava/lang/Object;

    .line 15
    .line 16
    return-void
.end method


# virtual methods
.method public abstract a(Loq0;)V
.end method

.method public abstract b(Loq0;)V
.end method

.method public abstract c(Loq0;)V
.end method

.method public abstract d(Loq0;)V
.end method

.method public abstract e(Loq0;)V
.end method

.method public abstract f(Loq0;)V
.end method

.method public abstract g(Loq0;)Lhq0;
.end method
