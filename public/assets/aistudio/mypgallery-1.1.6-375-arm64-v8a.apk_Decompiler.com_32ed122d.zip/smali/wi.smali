###### Class defpackage.wi (wi)
.class public final Lwi;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic h:Landroid/os/Bundle;

.field public final synthetic i:Laj;


# direct methods
.method public synthetic constructor <init>(Laj;Ljava/lang/String;Landroid/os/Bundle;I)V
    .registers 5

    .line 1
    iput p4, p0, Lwi;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lwi;->i:Laj;

    .line 4
    .line 5
    iput-object p2, p0, Lwi;->g:Ljava/lang/String;

    .line 6
    .line 7
    iput-object p3, p0, Lwi;->h:Landroid/os/Bundle;

    .line 8
    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .line 1
    iget v0, p0, Lwi;->f:I

    .line 2
    .line 3
    iget-object v1, p0, Lwi;->h:Landroid/os/Bundle;

    .line 4
    .line 5
    iget-object v2, p0, Lwi;->g:Ljava/lang/String;

    .line 6
    .line 7
    iget-object p0, p0, Lwi;->i:Laj;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_18

    .line 10
    .line 11
    .line 12
    iget-object p0, p0, Laj;->g:Lui;

    .line 13
    .line 14
    invoke-virtual {p0, v2, v1}, Lui;->onPostMessage(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :pswitch_11
    iget-object p0, p0, Laj;->g:Lui;

    .line 19
    .line 20
    invoke-virtual {p0, v2, v1}, Lui;->extraCallback(Ljava/lang/String;Landroid/os/Bundle;)V

    .line 21
    .line 22
    .line 23
    return-void

    .line 24
    nop

    .line 25
    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method
