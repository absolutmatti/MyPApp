###### Class defpackage.gl0 (gl0)
.class public final Lgl0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lqq0;


# instance fields
.field public final f:Lqq0;

.field public final g:J

.field public final synthetic h:Lnl0;


# direct methods
.method public constructor <init>(Lnl0;Lqq0;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lgl0;->h:Lnl0;

    .line 8
    .line 9
    iput-object p2, p0, Lgl0;->f:Lqq0;

    .line 10
    .line 11
    invoke-static {}, Lhh1;->m()J

    .line 12
    .line 13
    .line 14
    move-result-wide p1

    .line 15
    iput-wide p1, p0, Lgl0;->g:J

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final b(I)V
    .registers 9

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_23

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1d

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Lqq0;->b(I)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    const-string p0, "Attempted to use statement on a different thread"

    .line 31
    .line 32
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v1

    .line 36
    :cond_23
    const-string p0, "Statement is recycled"

    .line 37
    .line 38
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw v1
.end method

.method public final c(IJ)V
    .registers 11

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_23

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1d

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1, p2, p3}, Lqq0;->c(IJ)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    const-string p0, "Attempted to use statement on a different thread"

    .line 31
    .line 32
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v1

    .line 36
    :cond_23
    const-string p0, "Statement is recycled"

    .line 37
    .line 38
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw v1
.end method

.method public final close()V
    .registers 8

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_23

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1d

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0}, Ljava/lang/AutoCloseable;->close()V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    const-string p0, "Attempted to use statement on a different thread"

    .line 31
    .line 32
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v1

    .line 36
    :cond_23
    const-string p0, "Statement is recycled"

    .line 37
    .line 38
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw v1
.end method

.method public final e(I[B)V
    .registers 10

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_23

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1d

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1, p2}, Lqq0;->e(I[B)V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    const-string p0, "Attempted to use statement on a different thread"

    .line 31
    .line 32
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v1

    .line 36
    :cond_23
    const-string p0, "Statement is recycled"

    .line 37
    .line 38
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw v1
.end method

.method public final f(I)Ljava/lang/String;
    .registers 9

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Lqq0;->f(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method

.method public final getBlob(I)[B
    .registers 9

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Lqq0;->getBlob(I)[B

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method

.method public final getColumnCount()I
    .registers 8

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0}, Lqq0;->getColumnCount()I

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    return p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method

.method public final getColumnName(I)Ljava/lang/String;
    .registers 9

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Lqq0;->getColumnName(I)Ljava/lang/String;

    .line 27
    .line 28
    .line 29
    move-result-object p0

    .line 30
    return-object p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method

.method public final getLong(I)J
    .registers 9

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Lqq0;->getLong(I)J

    .line 27
    .line 28
    .line 29
    move-result-wide p0

    .line 30
    return-wide p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method

.method public final isNull(I)Z
    .registers 9

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0, p1}, Lqq0;->isNull(I)Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    return p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method

.method public final reset()V
    .registers 8

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_23

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1d

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0}, Lqq0;->reset()V

    .line 27
    .line 28
    .line 29
    return-void

    .line 30
    :cond_1d
    const-string p0, "Attempted to use statement on a different thread"

    .line 31
    .line 32
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 33
    .line 34
    .line 35
    throw v1

    .line 36
    :cond_23
    const-string p0, "Statement is recycled"

    .line 37
    .line 38
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 39
    .line 40
    .line 41
    throw v1
.end method

.method public final s(ILjava/lang/String;)V
    .registers 10

    .line 1
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 5
    .line 6
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 7
    .line 8
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    const/4 v1, 0x0

    .line 13
    const/16 v2, 0x15

    .line 14
    .line 15
    if-nez v0, :cond_26

    .line 16
    .line 17
    iget-wide v3, p0, Lgl0;->g:J

    .line 18
    .line 19
    invoke-static {}, Lhh1;->m()J

    .line 20
    .line 21
    .line 22
    move-result-wide v5

    .line 23
    cmp-long v0, v3, v5

    .line 24
    .line 25
    if-nez v0, :cond_20

    .line 26
    .line 27
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 28
    .line 29
    invoke-interface {p0, p1, p2}, Lqq0;->s(ILjava/lang/String;)V

    .line 30
    .line 31
    .line 32
    return-void

    .line 33
    :cond_20
    const-string p0, "Attempted to use statement on a different thread"

    .line 34
    .line 35
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 36
    .line 37
    .line 38
    throw v1

    .line 39
    :cond_26
    const-string p0, "Statement is recycled"

    .line 40
    .line 41
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 42
    .line 43
    .line 44
    throw v1
.end method

.method public final v()Z
    .registers 8

    .line 1
    iget-object v0, p0, Lgl0;->h:Lnl0;

    .line 2
    .line 3
    iget-object v0, v0, Lnl0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x0

    .line 10
    const/16 v2, 0x15

    .line 11
    .line 12
    if-nez v0, :cond_24

    .line 13
    .line 14
    iget-wide v3, p0, Lgl0;->g:J

    .line 15
    .line 16
    invoke-static {}, Lhh1;->m()J

    .line 17
    .line 18
    .line 19
    move-result-wide v5

    .line 20
    cmp-long v0, v3, v5

    .line 21
    .line 22
    if-nez v0, :cond_1e

    .line 23
    .line 24
    iget-object p0, p0, Lgl0;->f:Lqq0;

    .line 25
    .line 26
    invoke-interface {p0}, Lqq0;->v()Z

    .line 27
    .line 28
    .line 29
    move-result p0

    .line 30
    return p0

    .line 31
    :cond_1e
    const-string p0, "Attempted to use statement on a different thread"

    .line 32
    .line 33
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw v1

    .line 37
    :cond_24
    const-string p0, "Statement is recycled"

    .line 38
    .line 39
    invoke-static {v2, p0}, Lhh1;->H(ILjava/lang/String;)V

    .line 40
    .line 41
    .line 42
    throw v1
.end method
