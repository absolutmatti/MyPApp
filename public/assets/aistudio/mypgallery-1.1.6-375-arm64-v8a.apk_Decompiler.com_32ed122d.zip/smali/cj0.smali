###### Class defpackage.cj0 (cj0)
.class public final Lcj0;
.super Lt51;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public q:[Lxi0;

.field public r:I

.field public s:[I

.field public t:I

.field public u:[Ljava/lang/Object;

.field public v:I

.field public w:I

.field public x:I


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    const/16 v0, 0x10

    .line 5
    .line 6
    new-array v1, v0, [Lxi0;

    .line 7
    .line 8
    iput-object v1, p0, Lcj0;->q:[Lxi0;

    .line 9
    .line 10
    new-array v1, v0, [I

    .line 11
    .line 12
    iput-object v1, p0, Lcj0;->s:[I

    .line 13
    .line 14
    new-array v0, v0, [Ljava/lang/Object;

    .line 15
    .line 16
    iput-object v0, p0, Lcj0;->u:[Ljava/lang/Object;

    .line 17
    .line 18
    return-void
.end method

.method public static final U(Lcj0;I)I
    .registers 2

    .line 1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_7

    .line 5
    .line 6
    const/4 p0, 0x0

    .line 7
    return p0

    .line 8
    :cond_7
    rsub-int/lit8 p0, p1, 0x20

    .line 9
    .line 10
    const/4 p1, -0x1

    .line 11
    ushr-int p0, p1, p0

    .line 12
    .line 13
    return p0
.end method


# virtual methods
.method public final V()V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcj0;->r:I

    .line 3
    .line 4
    iput v0, p0, Lcj0;->t:I

    .line 5
    .line 6
    iget-object v1, p0, Lcj0;->u:[Ljava/lang/Object;

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    iget v3, p0, Lcj0;->v:I

    .line 10
    .line 11
    invoke-static {v1, v0, v3, v2}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 12
    .line 13
    .line 14
    iput v0, p0, Lcj0;->v:I

    .line 15
    .line 16
    return-void
.end method

.method public final W(Lt8;Loy0;Lzf;)V
    .registers 9

    .line 1
    invoke-virtual {p0}, Lcj0;->Y()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_42

    .line 6
    .line 7
    new-instance v0, Lcd;

    .line 8
    .line 9
    invoke-direct {v0, p0}, Lcd;-><init>(Lcj0;)V

    .line 10
    .line 11
    .line 12
    iget-object v1, v0, Lcd;->e:Ljava/lang/Object;

    .line 13
    .line 14
    check-cast v1, Lcj0;

    .line 15
    .line 16
    :goto_f
    iget-object v2, v1, Lcj0;->q:[Lxi0;

    .line 17
    .line 18
    iget v3, v0, Lcd;->b:I

    .line 19
    .line 20
    aget-object v2, v2, v3

    .line 21
    .line 22
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    .line 24
    .line 25
    invoke-virtual {v2, v0, p1, p2, p3}, Lxi0;->a(Lcd;Lt8;Loy0;Lzf;)V

    .line 26
    .line 27
    .line 28
    iget v2, v0, Lcd;->b:I

    .line 29
    .line 30
    iget v3, v1, Lcj0;->r:I

    .line 31
    .line 32
    if-lt v2, v3, :cond_22

    .line 33
    .line 34
    goto :goto_42

    .line 35
    :cond_22
    iget-object v3, v1, Lcj0;->q:[Lxi0;

    .line 36
    .line 37
    aget-object v2, v3, v2

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    iget v3, v0, Lcd;->c:I

    .line 43
    .line 44
    iget v4, v2, Lxi0;->a:I

    .line 45
    .line 46
    add-int/2addr v3, v4

    .line 47
    iput v3, v0, Lcd;->c:I

    .line 48
    .line 49
    iget v3, v0, Lcd;->d:I

    .line 50
    .line 51
    iget v2, v2, Lxi0;->b:I

    .line 52
    .line 53
    add-int/2addr v3, v2

    .line 54
    iput v3, v0, Lcd;->d:I

    .line 55
    .line 56
    iget v2, v0, Lcd;->b:I

    .line 57
    .line 58
    add-int/lit8 v2, v2, 0x1

    .line 59
    .line 60
    iput v2, v0, Lcd;->b:I

    .line 61
    .line 62
    iget v3, v1, Lcj0;->r:I

    .line 63
    .line 64
    if-ge v2, v3, :cond_42

    .line 65
    .line 66
    goto :goto_f

    .line 67
    :cond_42
    :goto_42
    invoke-virtual {p0}, Lcj0;->V()V

    .line 68
    .line 69
    .line 70
    return-void
.end method

.method public final X()Z
    .registers 1

    .line 1
    iget p0, p0, Lcj0;->r:I

    .line 2
    .line 3
    if-nez p0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_6
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public final Y()Z
    .registers 1

    .line 1
    iget p0, p0, Lcj0;->r:I

    .line 2
    .line 3
    if-eqz p0, :cond_6

    .line 4
    .line 5
    const/4 p0, 0x1

    .line 6
    return p0

    .line 7
    :cond_6
    const/4 p0, 0x0

    .line 8
    return p0
.end method

.method public final Z()Lxi0;
    .registers 2

    .line 1
    iget-object v0, p0, Lcj0;->q:[Lxi0;

    .line 2
    .line 3
    iget p0, p0, Lcj0;->r:I

    .line 4
    .line 5
    add-int/lit8 p0, p0, -0x1

    .line 6
    .line 7
    aget-object p0, v0, p0

    .line 8
    .line 9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    return-object p0
.end method

.method public final a0(Lxi0;)V
    .registers 5

    .line 1
    iget v0, p1, Lxi0;->a:I

    .line 2
    .line 3
    iget v1, p1, Lxi0;->b:I

    .line 4
    .line 5
    if-nez v0, :cond_c

    .line 6
    .line 7
    if-nez v1, :cond_c

    .line 8
    .line 9
    invoke-virtual {p0, p1}, Lcj0;->b0(Lxi0;)V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    new-instance p0, Ljava/lang/StringBuilder;

    .line 14
    .line 15
    const-string v2, "Cannot push "

    .line 16
    .line 17
    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string p1, " without arguments because it expects "

    .line 24
    .line 25
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 29
    .line 30
    .line 31
    const-string p1, " ints and "

    .line 32
    .line 33
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    const-string p1, " objects."

    .line 40
    .line 41
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 42
    .line 43
    .line 44
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-static {p0}, Lfo0;->Q(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    const/4 p0, 0x0

    .line 52
    throw p0
.end method

.method public final b0(Lxi0;)V
    .registers 8

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Lcj0;->w:I

    .line 3
    .line 4
    iput v0, p0, Lcj0;->x:I

    .line 5
    .line 6
    iget v0, p0, Lcj0;->r:I

    .line 7
    .line 8
    iget-object v1, p0, Lcj0;->q:[Lxi0;

    .line 9
    .line 10
    array-length v2, v1

    .line 11
    const/16 v3, 0x400

    .line 12
    .line 13
    if-ne v0, v2, :cond_1c

    .line 14
    .line 15
    if-le v0, v3, :cond_12

    .line 16
    .line 17
    move v2, v3

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    move v2, v0

    .line 20
    :goto_13
    add-int/2addr v0, v2

    .line 21
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    check-cast v0, [Lxi0;

    .line 26
    .line 27
    iput-object v0, p0, Lcj0;->q:[Lxi0;

    .line 28
    .line 29
    :cond_1c
    iget v0, p0, Lcj0;->t:I

    .line 30
    .line 31
    iget v1, p1, Lxi0;->a:I

    .line 32
    .line 33
    iget v2, p1, Lxi0;->b:I

    .line 34
    .line 35
    add-int/2addr v0, v1

    .line 36
    iget-object v1, p0, Lcj0;->s:[I

    .line 37
    .line 38
    array-length v4, v1

    .line 39
    if-le v0, v4, :cond_38

    .line 40
    .line 41
    if-le v4, v3, :cond_2c

    .line 42
    .line 43
    move v5, v3

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    move v5, v4

    .line 46
    :goto_2d
    add-int/2addr v4, v5

    .line 47
    if-ge v4, v0, :cond_31

    .line 48
    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v0, v4

    .line 51
    :goto_32
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([II)[I

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    iput-object v0, p0, Lcj0;->s:[I

    .line 56
    .line 57
    :cond_38
    iget v0, p0, Lcj0;->v:I

    .line 58
    .line 59
    add-int/2addr v0, v2

    .line 60
    iget-object v1, p0, Lcj0;->u:[Ljava/lang/Object;

    .line 61
    .line 62
    array-length v4, v1

    .line 63
    if-le v0, v4, :cond_4f

    .line 64
    .line 65
    if-le v4, v3, :cond_43

    .line 66
    .line 67
    goto :goto_44

    .line 68
    :cond_43
    move v3, v4

    .line 69
    :goto_44
    add-int/2addr v4, v3

    .line 70
    if-ge v4, v0, :cond_48

    .line 71
    .line 72
    goto :goto_49

    .line 73
    :cond_48
    move v0, v4

    .line 74
    :goto_49
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 75
    .line 76
    .line 77
    move-result-object v0

    .line 78
    iput-object v0, p0, Lcj0;->u:[Ljava/lang/Object;

    .line 79
    .line 80
    :cond_4f
    iget-object v0, p0, Lcj0;->q:[Lxi0;

    .line 81
    .line 82
    iget v1, p0, Lcj0;->r:I

    .line 83
    .line 84
    add-int/lit8 v3, v1, 0x1

    .line 85
    .line 86
    iput v3, p0, Lcj0;->r:I

    .line 87
    .line 88
    aput-object p1, v0, v1

    .line 89
    .line 90
    iget v0, p0, Lcj0;->t:I

    .line 91
    .line 92
    iget p1, p1, Lxi0;->a:I

    .line 93
    .line 94
    add-int/2addr v0, p1

    .line 95
    iput v0, p0, Lcj0;->t:I

    .line 96
    .line 97
    iget p1, p0, Lcj0;->v:I

    .line 98
    .line 99
    add-int/2addr p1, v2

    .line 100
    iput p1, p0, Lcj0;->v:I

    .line 101
    .line 102
    return-void
.end method
