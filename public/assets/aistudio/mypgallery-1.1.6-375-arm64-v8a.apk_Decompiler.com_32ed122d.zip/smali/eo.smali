###### Class defpackage.eo (eo)
.class public final Leo;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lyh;


# instance fields
.field public final synthetic f:Lyh;

.field public final g:Ljava/lang/Throwable;


# direct methods
.method public constructor <init>(Lyh;Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Leo;->f:Lyh;

    .line 5
    .line 6
    iput-object p2, p0, Leo;->g:Ljava/lang/Throwable;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final k(Ljava/lang/Object;Lsz;)Ljava/lang/Object;
    .registers 3

    .line 1
    iget-object p0, p0, Leo;->f:Lyh;

    .line 2
    .line 3
    invoke-interface {p0, p1, p2}, Lyh;->k(Ljava/lang/Object;Lsz;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final n(Lyh;)Lyh;
    .registers 2

    .line 1
    iget-object p0, p0, Leo;->f:Lyh;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lyh;->n(Lyh;)Lyh;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final q(Lxh;)Lwh;
    .registers 2

    .line 1
    iget-object p0, p0, Leo;->f:Lyh;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lyh;->q(Lxh;)Lwh;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final u(Lxh;)Lyh;
    .registers 2

    .line 1
    iget-object p0, p0, Leo;->f:Lyh;

    .line 2
    .line 3
    invoke-interface {p0, p1}, Lyh;->u(Lxh;)Lyh;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
