###### Class defpackage.j4 (j4)
.class public final Lj4;
.super Li;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lwh;


# instance fields
.field private volatile _preHandler:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 2

    .line 1
    sget-object v0, Ls10;->j:Ls10;

    .line 2
    .line 3
    invoke-direct {p0, v0}, Li;-><init>(Lxh;)V

    .line 4
    .line 5
    .line 6
    iput-object p0, p0, Lj4;->_preHandler:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method
