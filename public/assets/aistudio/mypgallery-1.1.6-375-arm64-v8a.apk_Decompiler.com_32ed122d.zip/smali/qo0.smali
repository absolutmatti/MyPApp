###### Class defpackage.qo0 (qo0)
.class public final Lqo0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final u:Le01;

.field public static final v:Ljava/util/concurrent/atomic/AtomicReference;


# instance fields
.field public final a:Lxa;

.field public final b:Ljava/lang/Object;

.field public c:Lp50;

.field public d:Ljava/lang/Throwable;

.field public final e:Ljava/util/ArrayList;

.field public f:Ljava/util/List;

.field public g:Lvf0;

.field public final h:Lxf0;

.field public final i:Ljava/util/ArrayList;

.field public final j:Ljava/util/ArrayList;

.field public final k:Ljava/util/LinkedHashMap;

.field public final l:Ljava/util/LinkedHashMap;

.field public m:Ljava/util/ArrayList;

.field public n:Ljava/util/LinkedHashSet;

.field public o:Lgc;

.field public p:Z

.field public q:Lnw;

.field public final r:Le01;

.field public final s:Lr50;

.field public final t:Ls10;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    sget-object v0, Lzj0;->i:Lzj0;

    .line 2
    .line 3
    invoke-static {v0}, Lr30;->b(Ljava/lang/Object;)Le01;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lqo0;->u:Le01;

    .line 8
    .line 9
    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    .line 10
    .line 11
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 12
    .line 13
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    .line 14
    .line 15
    .line 16
    sput-object v0, Lqo0;->v:Ljava/util/concurrent/atomic/AtomicReference;

    .line 17
    .line 18
    return-void
.end method

.method public constructor <init>(Lyh;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Lxa;

    .line 5
    .line 6
    new-instance v1, Lsj0;

    .line 7
    .line 8
    const/4 v2, 0x1

    .line 9
    invoke-direct {v1, v2, p0}, Lsj0;-><init>(ILjava/lang/Object;)V

    .line 10
    .line 11
    .line 12
    invoke-direct {v0, v1}, Lxa;-><init>(Lsj0;)V

    .line 13
    .line 14
    .line 15
    iput-object v0, p0, Lqo0;->a:Lxa;

    .line 16
    .line 17
    new-instance v1, Ljava/lang/Object;

    .line 18
    .line 19
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    iput-object v1, p0, Lqo0;->b:Ljava/lang/Object;

    .line 23
    .line 24
    new-instance v1, Ljava/util/ArrayList;

    .line 25
    .line 26
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 27
    .line 28
    .line 29
    iput-object v1, p0, Lqo0;->e:Ljava/util/ArrayList;

    .line 30
    .line 31
    new-instance v1, Lvf0;

    .line 32
    .line 33
    invoke-direct {v1}, Lvf0;-><init>()V

    .line 34
    .line 35
    .line 36
    iput-object v1, p0, Lqo0;->g:Lvf0;

    .line 37
    .line 38
    new-instance v1, Lxf0;

    .line 39
    .line 40
    const/16 v2, 0x10

    .line 41
    .line 42
    new-array v2, v2, [Lag;

    .line 43
    .line 44
    invoke-direct {v1, v2}, Lxf0;-><init>([Ljava/lang/Object;)V

    .line 45
    .line 46
    .line 47
    iput-object v1, p0, Lqo0;->h:Lxf0;

    .line 48
    .line 49
    new-instance v1, Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 52
    .line 53
    .line 54
    iput-object v1, p0, Lqo0;->i:Ljava/util/ArrayList;

    .line 55
    .line 56
    new-instance v1, Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 59
    .line 60
    .line 61
    iput-object v1, p0, Lqo0;->j:Ljava/util/ArrayList;

    .line 62
    .line 63
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 64
    .line 65
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 66
    .line 67
    .line 68
    iput-object v1, p0, Lqo0;->k:Ljava/util/LinkedHashMap;

    .line 69
    .line 70
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 71
    .line 72
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 73
    .line 74
    .line 75
    iput-object v1, p0, Lqo0;->l:Ljava/util/LinkedHashMap;

    .line 76
    .line 77
    sget-object v1, Llo0;->h:Llo0;

    .line 78
    .line 79
    invoke-static {v1}, Lr30;->b(Ljava/lang/Object;)Le01;

    .line 80
    .line 81
    .line 82
    move-result-object v1

    .line 83
    iput-object v1, p0, Lqo0;->r:Le01;

    .line 84
    .line 85
    sget-object v1, Liq0;->j:Liq0;

    .line 86
    .line 87
    invoke-interface {p1, v1}, Lyh;->q(Lxh;)Lwh;

    .line 88
    .line 89
    .line 90
    move-result-object v1

    .line 91
    check-cast v1, Lp50;

    .line 92
    .line 93
    new-instance v2, Lr50;

    .line 94
    .line 95
    invoke-direct {v2, v1}, Lr50;-><init>(Lp50;)V

    .line 96
    .line 97
    .line 98
    new-instance v1, Lh10;

    .line 99
    .line 100
    const/4 v3, 0x2

    .line 101
    invoke-direct {v1, v3, p0}, Lh10;-><init>(ILjava/lang/Object;)V

    .line 102
    .line 103
    .line 104
    invoke-virtual {v2, v1}, Ly50;->t(Lqz;)Lwn;

    .line 105
    .line 106
    .line 107
    iput-object v2, p0, Lqo0;->s:Lr50;

    .line 108
    .line 109
    invoke-interface {p1, v0}, Lyh;->n(Lyh;)Lyh;

    .line 110
    .line 111
    .line 112
    move-result-object p1

    .line 113
    invoke-interface {p1, v2}, Lyh;->n(Lyh;)Lyh;

    .line 114
    .line 115
    .line 116
    new-instance p1, Ls10;

    .line 117
    .line 118
    const/16 v0, 0x1c

    .line 119
    .line 120
    invoke-direct {p1, v0}, Ls10;-><init>(I)V

    .line 121
    .line 122
    .line 123
    iput-object p1, p0, Lqo0;->t:Ls10;

    .line 124
    .line 125
    return-void
.end method

.method public static final a(Lqo0;Lag;Lvf0;)Lag;
    .registers 9

    .line 1
    iget-object v0, p1, Lag;->q:Lwf;

    .line 2
    .line 3
    iget-boolean v0, v0, Lwf;->x:Z

    .line 4
    .line 5
    const/4 v1, 0x0

    .line 6
    if-nez v0, :cond_80

    .line 7
    .line 8
    iget-object p0, p0, Lqo0;->n:Ljava/util/LinkedHashSet;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    if-eqz p0, :cond_14

    .line 12
    .line 13
    invoke-interface {p0, p1}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-ne p0, v0, :cond_14

    .line 18
    .line 19
    goto/16 :goto_80

    .line 20
    .line 21
    :cond_14
    new-instance p0, Lh10;

    .line 22
    .line 23
    const/4 v2, 0x3

    .line 24
    invoke-direct {p0, v2, p1}, Lh10;-><init>(ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    new-instance v3, Lwa;

    .line 28
    .line 29
    invoke-direct {v3, p1, v2, p2}, Lwa;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 30
    .line 31
    .line 32
    invoke-static {}, Lbz0;->f()Lwf0;

    .line 33
    .line 34
    .line 35
    move-result-object v2

    .line 36
    instance-of v4, v2, Lwf0;

    .line 37
    .line 38
    if-eqz v4, :cond_28

    .line 39
    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move-object v2, v1

    .line 42
    :goto_29
    if-eqz v2, :cond_7b

    .line 43
    .line 44
    invoke-virtual {v2, p0, v3}, Lwf0;->j(Lh10;Lwa;)Lwf0;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    if-eqz p0, :cond_7b

    .line 49
    .line 50
    :try_start_31
    sget-object v2, Lbz0;->a:Ld8;

    .line 51
    .line 52
    invoke-virtual {v2}, Ld8;->j()Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object v3

    .line 56
    check-cast v3, Lwf0;

    .line 57
    .line 58
    invoke-virtual {v2, p0}, Ld8;->y(Ljava/lang/Object;)V
    :try_end_3c
    .catchall {:try_start_31 .. :try_end_3c} :catchall_71

    .line 59
    .line 60
    .line 61
    if-eqz p2, :cond_64

    .line 62
    .line 63
    :try_start_3e
    invoke-virtual {p2}, Lvf0;->h()Z

    .line 64
    .line 65
    .line 66
    move-result v2

    .line 67
    if-ne v2, v0, :cond_64

    .line 68
    .line 69
    new-instance v2, Lmo0;

    .line 70
    .line 71
    const/4 v4, 0x0

    .line 72
    invoke-direct {v2, p2, v4, p1}, Lmo0;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 73
    .line 74
    .line 75
    iget-object p2, p1, Lag;->q:Lwf;

    .line 76
    .line 77
    iget-boolean v5, p2, Lwf;->x:Z

    .line 78
    .line 79
    if-nez v5, :cond_5c

    .line 80
    .line 81
    iput-boolean v0, p2, Lwf;->x:Z
    :try_end_52
    .catchall {:try_start_3e .. :try_end_52} :catchall_62

    .line 82
    .line 83
    :try_start_52
    invoke-virtual {v2}, Lmo0;->a()Ljava/lang/Object;
    :try_end_55
    .catchall {:try_start_52 .. :try_end_55} :catchall_58

    .line 84
    .line 85
    .line 86
    :try_start_55
    iput-boolean v4, p2, Lwf;->x:Z

    .line 87
    .line 88
    goto :goto_64

    .line 89
    :catchall_58
    move-exception p1

    .line 90
    iput-boolean v4, p2, Lwf;->x:Z

    .line 91
    .line 92
    throw p1

    .line 93
    :cond_5c
    const-string p1, "Preparing a composition while composing is not supported"

    .line 94
    .line 95
    invoke-static {p1}, Lt51;->g(Ljava/lang/String;)V

    .line 96
    .line 97
    .line 98
    throw v1

    .line 99
    :catchall_62
    move-exception p1

    .line 100
    goto :goto_73

    .line 101
    :cond_64
    :goto_64
    invoke-virtual {p1}, Lag;->q()Z

    .line 102
    .line 103
    .line 104
    move-result p2
    :try_end_68
    .catchall {:try_start_55 .. :try_end_68} :catchall_62

    .line 105
    :try_start_68
    invoke-static {v3}, Lwf0;->i(Lwf0;)V
    :try_end_6b
    .catchall {:try_start_68 .. :try_end_6b} :catchall_71

    .line 106
    .line 107
    .line 108
    invoke-static {p0}, Lqo0;->c(Lwf0;)V

    .line 109
    .line 110
    .line 111
    if-eqz p2, :cond_80

    .line 112
    .line 113
    return-object p1

    .line 114
    :catchall_71
    move-exception p1

    .line 115
    goto :goto_77

    .line 116
    :goto_73
    :try_start_73
    invoke-static {v3}, Lwf0;->i(Lwf0;)V

    .line 117
    .line 118
    .line 119
    throw p1
    :try_end_77
    .catchall {:try_start_73 .. :try_end_77} :catchall_71

    .line 120
    :goto_77
    invoke-static {p0}, Lqo0;->c(Lwf0;)V

    .line 121
    .line 122
    .line 123
    throw p1

    .line 124
    :cond_7b
    const-string p0, "Cannot create a mutable snapshot of an read-only snapshot"

    .line 125
    .line 126
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 127
    .line 128
    .line 129
    :cond_80
    :goto_80
    return-object v1
.end method

.method public static final b(Lqo0;)Z
    .registers 9

    .line 1
    iget-object v0, p0, Lqo0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lqo0;->g:Lvf0;

    .line 5
    .line 6
    invoke-virtual {v1}, Lvf0;->g()Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x1

    .line 11
    const/4 v3, 0x0

    .line 12
    if-eqz v1, :cond_1e

    .line 13
    .line 14
    iget-object v1, p0, Lqo0;->h:Lxf0;

    .line 15
    .line 16
    iget v1, v1, Lxf0;->g:I

    .line 17
    .line 18
    if-eqz v1, :cond_14

    .line 19
    .line 20
    goto :goto_1c

    .line 21
    :cond_14
    invoke-virtual {p0}, Lqo0;->e()Z

    .line 22
    .line 23
    .line 24
    move-result p0
    :try_end_18
    .catchall {:try_start_3 .. :try_end_18} :catchall_b6

    .line 25
    if-eqz p0, :cond_1b

    .line 26
    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    move v2, v3

    .line 29
    :goto_1c
    monitor-exit v0

    .line 30
    return v2

    .line 31
    :cond_1e
    :try_start_1e
    iget-object v1, p0, Lqo0;->g:Lvf0;

    .line 32
    .line 33
    new-instance v4, Lyr0;

    .line 34
    .line 35
    invoke-direct {v4, v1}, Lyr0;-><init>(Lvf0;)V

    .line 36
    .line 37
    .line 38
    new-instance v1, Lvf0;

    .line 39
    .line 40
    invoke-direct {v1}, Lvf0;-><init>()V

    .line 41
    .line 42
    .line 43
    iput-object v1, p0, Lqo0;->g:Lvf0;
    :try_end_2c
    .catchall {:try_start_1e .. :try_end_2c} :catchall_b6

    .line 44
    .line 45
    monitor-exit v0

    .line 46
    iget-object v0, p0, Lqo0;->b:Ljava/lang/Object;

    .line 47
    .line 48
    monitor-enter v0

    .line 49
    :try_start_30
    invoke-virtual {p0}, Lqo0;->g()Ljava/util/List;

    .line 50
    .line 51
    .line 52
    move-result-object v1
    :try_end_34
    .catchall {:try_start_30 .. :try_end_34} :catchall_b3

    .line 53
    monitor-exit v0

    .line 54
    :try_start_35
    invoke-interface {v1}, Ljava/util/List;->size()I

    .line 55
    .line 56
    .line 57
    move-result v0

    .line 58
    move v5, v3

    .line 59
    :goto_3a
    if-ge v5, v0, :cond_5a

    .line 60
    .line 61
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 62
    .line 63
    .line 64
    move-result-object v6

    .line 65
    check-cast v6, Lag;

    .line 66
    .line 67
    invoke-virtual {v6, v4}, Lag;->r(Lyr0;)V

    .line 68
    .line 69
    .line 70
    iget-object v6, p0, Lqo0;->r:Le01;

    .line 71
    .line 72
    invoke-virtual {v6}, Le01;->h()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v6

    .line 76
    check-cast v6, Llo0;

    .line 77
    .line 78
    sget-object v7, Llo0;->g:Llo0;

    .line 79
    .line 80
    invoke-virtual {v6, v7}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 81
    .line 82
    .line 83
    move-result v6

    .line 84
    if-lez v6, :cond_5a

    .line 85
    .line 86
    add-int/lit8 v5, v5, 0x1

    .line 87
    .line 88
    goto :goto_3a

    .line 89
    :catchall_58
    move-exception v0

    .line 90
    goto :goto_8f

    .line 91
    :cond_5a
    iget-object v0, p0, Lqo0;->b:Ljava/lang/Object;

    .line 92
    .line 93
    monitor-enter v0
    :try_end_5d
    .catchall {:try_start_35 .. :try_end_5d} :catchall_58

    .line 94
    :try_start_5d
    new-instance v1, Lvf0;

    .line 95
    .line 96
    invoke-direct {v1}, Lvf0;-><init>()V

    .line 97
    .line 98
    .line 99
    iput-object v1, p0, Lqo0;->g:Lvf0;

    .line 100
    .line 101
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_66
    .catchall {:try_start_5d .. :try_end_66} :catchall_8c

    .line 102
    .line 103
    :try_start_66
    monitor-exit v0
    :try_end_67
    .catchall {:try_start_66 .. :try_end_67} :catchall_58

    .line 104
    iget-object v0, p0, Lqo0;->b:Ljava/lang/Object;

    .line 105
    .line 106
    monitor-enter v0

    .line 107
    :try_start_6a
    invoke-virtual {p0}, Lqo0;->d()Lec;

    .line 108
    .line 109
    .line 110
    move-result-object v1

    .line 111
    if-nez v1, :cond_81

    .line 112
    .line 113
    iget-object v1, p0, Lqo0;->h:Lxf0;

    .line 114
    .line 115
    iget v1, v1, Lxf0;->g:I

    .line 116
    .line 117
    if-eqz v1, :cond_77

    .line 118
    .line 119
    goto :goto_7f

    .line 120
    :cond_77
    invoke-virtual {p0}, Lqo0;->e()Z

    .line 121
    .line 122
    .line 123
    move-result p0
    :try_end_7b
    .catchall {:try_start_6a .. :try_end_7b} :catchall_89

    .line 124
    if-eqz p0, :cond_7e

    .line 125
    .line 126
    goto :goto_7f

    .line 127
    :cond_7e
    move v2, v3

    .line 128
    :goto_7f
    monitor-exit v0

    .line 129
    return v2

    .line 130
    :cond_81
    :try_start_81
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 131
    .line 132
    const-string v1, "called outside of runRecomposeAndApplyChanges"

    .line 133
    .line 134
    invoke-direct {p0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    throw p0
    :try_end_89
    .catchall {:try_start_81 .. :try_end_89} :catchall_89

    .line 138
    :catchall_89
    move-exception p0

    .line 139
    monitor-exit v0

    .line 140
    throw p0

    .line 141
    :catchall_8c
    move-exception v1

    .line 142
    :try_start_8d
    monitor-exit v0

    .line 143
    throw v1
    :try_end_8f
    .catchall {:try_start_8d .. :try_end_8f} :catchall_58

    .line 144
    :goto_8f
    iget-object v1, p0, Lqo0;->b:Ljava/lang/Object;

    .line 145
    .line 146
    monitor-enter v1

    .line 147
    :try_start_92
    iget-object p0, p0, Lqo0;->g:Lvf0;

    .line 148
    .line 149
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 150
    .line 151
    .line 152
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    :goto_9b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 157
    .line 158
    .line 159
    move-result v3

    .line 160
    if-eqz v3, :cond_ae

    .line 161
    .line 162
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    move-result-object v3

    .line 166
    invoke-virtual {p0, v3}, Lvf0;->d(Ljava/lang/Object;)I

    .line 167
    .line 168
    .line 169
    move-result v4

    .line 170
    iget-object v5, p0, Lvf0;->b:[Ljava/lang/Object;

    .line 171
    .line 172
    aput-object v3, v5, v4
    :try_end_ad
    .catchall {:try_start_92 .. :try_end_ad} :catchall_b0

    .line 173
    .line 174
    goto :goto_9b

    .line 175
    :cond_ae
    monitor-exit v1

    .line 176
    throw v0

    .line 177
    :catchall_b0
    move-exception p0

    .line 178
    monitor-exit v1

    .line 179
    throw p0

    .line 180
    :catchall_b3
    move-exception p0

    .line 181
    monitor-exit v0

    .line 182
    throw p0

    .line 183
    :catchall_b6
    move-exception p0

    .line 184
    monitor-exit v0

    .line 185
    throw p0
.end method

.method public static c(Lwf0;)V
    .registers 3

    .line 1
    :try_start_0
    invoke-virtual {p0}, Lwf0;->b()Ln40;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    instance-of v0, v0, Lwy0;
    :try_end_6
    .catchall {:try_start_0 .. :try_end_6} :catchall_14

    .line 6
    .line 7
    if-nez v0, :cond_c

    .line 8
    .line 9
    invoke-virtual {p0}, Lwf0;->c()V

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    :try_start_c
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    const-string v1, "Unsupported concurrent change during composition. A state object was modified by composition as well as being modified outside composition."

    .line 16
    .line 17
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 18
    .line 19
    .line 20
    throw v0
    :try_end_14
    .catchall {:try_start_c .. :try_end_14} :catchall_14

    .line 21
    :catchall_14
    move-exception v0

    .line 22
    invoke-virtual {p0}, Lwf0;->c()V

    .line 23
    .line 24
    .line 25
    throw v0
.end method


# virtual methods
.method public final d()Lec;
    .registers 9

    .line 1
    iget-object v0, p0, Lqo0;->r:Le01;

    .line 2
    .line 3
    invoke-virtual {v0}, Le01;->h()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    check-cast v1, Llo0;

    .line 8
    .line 9
    sget-object v2, Llo0;->g:Llo0;

    .line 10
    .line 11
    invoke-virtual {v1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    iget-object v2, p0, Lqo0;->j:Ljava/util/ArrayList;

    .line 16
    .line 17
    iget-object v3, p0, Lqo0;->i:Ljava/util/ArrayList;

    .line 18
    .line 19
    iget-object v4, p0, Lqo0;->h:Lxf0;

    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    if-gtz v1, :cond_3e

    .line 23
    .line 24
    iget-object v0, p0, Lqo0;->e:Ljava/util/ArrayList;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 27
    .line 28
    .line 29
    sget-object v0, Luq;->f:Luq;

    .line 30
    .line 31
    iput-object v0, p0, Lqo0;->f:Ljava/util/List;

    .line 32
    .line 33
    new-instance v0, Lvf0;

    .line 34
    .line 35
    invoke-direct {v0}, Lvf0;-><init>()V

    .line 36
    .line 37
    .line 38
    iput-object v0, p0, Lqo0;->g:Lvf0;

    .line 39
    .line 40
    invoke-virtual {v4}, Lxf0;->c()V

    .line 41
    .line 42
    .line 43
    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    .line 44
    .line 45
    .line 46
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 47
    .line 48
    .line 49
    iput-object v5, p0, Lqo0;->m:Ljava/util/ArrayList;

    .line 50
    .line 51
    iget-object v0, p0, Lqo0;->o:Lgc;

    .line 52
    .line 53
    if-eqz v0, :cond_39

    .line 54
    .line 55
    invoke-virtual {v0, v5}, Lgc;->n(Ljava/lang/Throwable;)Z

    .line 56
    .line 57
    .line 58
    :cond_39
    iput-object v5, p0, Lqo0;->o:Lgc;

    .line 59
    .line 60
    iput-object v5, p0, Lqo0;->q:Lnw;

    .line 61
    .line 62
    return-object v5

    .line 63
    :cond_3e
    iget-object v1, p0, Lqo0;->q:Lnw;

    .line 64
    .line 65
    sget-object v6, Llo0;->k:Llo0;

    .line 66
    .line 67
    sget-object v7, Llo0;->h:Llo0;

    .line 68
    .line 69
    if-eqz v1, :cond_47

    .line 70
    .line 71
    goto :goto_82

    .line 72
    :cond_47
    iget-object v1, p0, Lqo0;->c:Lp50;

    .line 73
    .line 74
    if-nez v1, :cond_5e

    .line 75
    .line 76
    new-instance v1, Lvf0;

    .line 77
    .line 78
    invoke-direct {v1}, Lvf0;-><init>()V

    .line 79
    .line 80
    .line 81
    iput-object v1, p0, Lqo0;->g:Lvf0;

    .line 82
    .line 83
    invoke-virtual {v4}, Lxf0;->c()V

    .line 84
    .line 85
    .line 86
    invoke-virtual {p0}, Lqo0;->e()Z

    .line 87
    .line 88
    .line 89
    move-result v1

    .line 90
    if-eqz v1, :cond_82

    .line 91
    .line 92
    sget-object v7, Llo0;->i:Llo0;

    .line 93
    .line 94
    goto :goto_82

    .line 95
    :cond_5e
    iget v1, v4, Lxf0;->g:I

    .line 96
    .line 97
    if-eqz v1, :cond_63

    .line 98
    .line 99
    goto :goto_81

    .line 100
    :cond_63
    iget-object v1, p0, Lqo0;->g:Lvf0;

    .line 101
    .line 102
    invoke-virtual {v1}, Lvf0;->h()Z

    .line 103
    .line 104
    .line 105
    move-result v1

    .line 106
    if-nez v1, :cond_81

    .line 107
    .line 108
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 109
    .line 110
    .line 111
    move-result v1

    .line 112
    if-eqz v1, :cond_81

    .line 113
    .line 114
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 115
    .line 116
    .line 117
    move-result v1

    .line 118
    if-eqz v1, :cond_81

    .line 119
    .line 120
    invoke-virtual {p0}, Lqo0;->e()Z

    .line 121
    .line 122
    .line 123
    move-result v1

    .line 124
    if-eqz v1, :cond_7e

    .line 125
    .line 126
    goto :goto_81

    .line 127
    :cond_7e
    sget-object v7, Llo0;->j:Llo0;

    .line 128
    .line 129
    goto :goto_82

    .line 130
    :cond_81
    :goto_81
    move-object v7, v6

    .line 131
    :cond_82
    :goto_82
    invoke-virtual {v0, v5, v7}, Le01;->k(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 132
    .line 133
    .line 134
    if-ne v7, v6, :cond_8c

    .line 135
    .line 136
    iget-object v0, p0, Lqo0;->o:Lgc;

    .line 137
    .line 138
    iput-object v5, p0, Lqo0;->o:Lgc;

    .line 139
    .line 140
    return-object v0

    .line 141
    :cond_8c
    return-object v5
.end method

.method public final e()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lqo0;->a:Lxa;

    .line 2
    .line 3
    iget-object p0, p0, Lxa;->k:Ll9;

    .line 4
    .line 5
    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    if-eqz p0, :cond_c

    .line 10
    .line 11
    const/4 p0, 0x1

    .line 12
    return p0

    .line 13
    :cond_c
    const/4 p0, 0x0

    .line 14
    return p0
.end method

.method public final f()Z
    .registers 5

    .line 1
    iget-object v0, p0, Lqo0;->b:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lqo0;->g:Lvf0;

    .line 5
    .line 6
    invoke-virtual {v1}, Lvf0;->h()Z

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x1

    .line 11
    if-nez v1, :cond_23

    .line 12
    .line 13
    iget-object v1, p0, Lqo0;->h:Lxf0;

    .line 14
    .line 15
    iget v1, v1, Lxf0;->g:I

    .line 16
    .line 17
    const/4 v3, 0x0

    .line 18
    if-eqz v1, :cond_15

    .line 19
    .line 20
    move v1, v2

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v1, v3

    .line 23
    :goto_16
    if-nez v1, :cond_23

    .line 24
    .line 25
    invoke-virtual {p0}, Lqo0;->e()Z

    .line 26
    .line 27
    .line 28
    move-result p0
    :try_end_1c
    .catchall {:try_start_3 .. :try_end_1c} :catchall_21

    .line 29
    if-eqz p0, :cond_1f

    .line 30
    .line 31
    goto :goto_23

    .line 32
    :cond_1f
    move v2, v3

    .line 33
    goto :goto_23

    .line 34
    :catchall_21
    move-exception p0

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    :goto_23
    monitor-exit v0

    .line 37
    return v2

    .line 38
    :goto_25
    monitor-exit v0

    .line 39
    throw p0
.end method

.method public final g()Ljava/util/List;
    .registers 3

    .line 1
    iget-object v0, p0, Lqo0;->f:Ljava/util/List;

    .line 2
    .line 3
    if-nez v0, :cond_17

    .line 4
    .line 5
    iget-object v0, p0, Lqo0;->e:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_f

    .line 12
    .line 13
    sget-object v0, Luq;->f:Luq;

    .line 14
    .line 15
    goto :goto_15

    .line 16
    :cond_f
    new-instance v1, Ljava/util/ArrayList;

    .line 17
    .line 18
    invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 19
    .line 20
    .line 21
    move-object v0, v1

    .line 22
    :goto_15
    iput-object v0, p0, Lqo0;->f:Ljava/util/List;

    .line 23
    .line 24
    :cond_17
    return-object v0
.end method

.method public final h(Ljava/util/List;Lvf0;)Ljava/util/List;
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    new-instance v1, Ljava/util/HashMap;

    .line 4
    .line 5
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 6
    .line 7
    .line 8
    move-result v2

    .line 9
    invoke-direct {v1, v2}, Ljava/util/HashMap;-><init>(I)V

    .line 10
    .line 11
    .line 12
    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    .line 13
    .line 14
    .line 15
    move-result v2

    .line 16
    const/4 v3, 0x0

    .line 17
    move v4, v3

    .line 18
    :goto_11
    const/4 v5, 0x0

    .line 19
    if-ge v4, v2, :cond_36

    .line 20
    .line 21
    move-object/from16 v6, p1

    .line 22
    .line 23
    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 24
    .line 25
    .line 26
    move-result-object v7

    .line 27
    move-object v8, v7

    .line 28
    check-cast v8, Lbf0;

    .line 29
    .line 30
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 31
    .line 32
    .line 33
    invoke-virtual {v1, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v8

    .line 37
    if-nez v8, :cond_2e

    .line 38
    .line 39
    new-instance v8, Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v1, v5, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    :cond_2e
    check-cast v8, Ljava/util/ArrayList;

    .line 48
    .line 49
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 50
    .line 51
    .line 52
    add-int/lit8 v4, v4, 0x1

    .line 53
    .line 54
    goto :goto_11

    .line 55
    :cond_36
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 56
    .line 57
    .line 58
    move-result-object v2

    .line 59
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 60
    .line 61
    .line 62
    move-result-object v2

    .line 63
    :goto_3e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 64
    .line 65
    .line 66
    move-result v4

    .line 67
    if-eqz v4, :cond_180

    .line 68
    .line 69
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    check-cast v4, Ljava/util/Map$Entry;

    .line 74
    .line 75
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 76
    .line 77
    .line 78
    move-result-object v6

    .line 79
    check-cast v6, Lag;

    .line 80
    .line 81
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 82
    .line 83
    .line 84
    move-result-object v4

    .line 85
    check-cast v4, Ljava/util/List;

    .line 86
    .line 87
    iget-object v7, v6, Lag;->q:Lwf;

    .line 88
    .line 89
    iget-boolean v7, v7, Lwf;->x:Z

    .line 90
    .line 91
    xor-int/lit8 v7, v7, 0x1

    .line 92
    .line 93
    invoke-static {v7}, Lt51;->N(Z)V

    .line 94
    .line 95
    .line 96
    new-instance v7, Lh10;

    .line 97
    .line 98
    const/4 v8, 0x3

    .line 99
    invoke-direct {v7, v8, v6}, Lh10;-><init>(ILjava/lang/Object;)V

    .line 100
    .line 101
    .line 102
    new-instance v9, Lwa;

    .line 103
    .line 104
    move-object/from16 v10, p2

    .line 105
    .line 106
    invoke-direct {v9, v6, v8, v10}, Lwa;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 107
    .line 108
    .line 109
    invoke-static {}, Lbz0;->f()Lwf0;

    .line 110
    .line 111
    .line 112
    move-result-object v8

    .line 113
    instance-of v11, v8, Lwf0;

    .line 114
    .line 115
    if-eqz v11, :cond_75

    .line 116
    .line 117
    goto :goto_76

    .line 118
    :cond_75
    move-object v8, v5

    .line 119
    :goto_76
    if-eqz v8, :cond_178

    .line 120
    .line 121
    invoke-virtual {v8, v7, v9}, Lwf0;->j(Lh10;Lwa;)Lwf0;

    .line 122
    .line 123
    .line 124
    move-result-object v7

    .line 125
    if-eqz v7, :cond_178

    .line 126
    .line 127
    :try_start_7e
    sget-object v8, Lbz0;->a:Ld8;

    .line 128
    .line 129
    invoke-virtual {v8}, Ld8;->j()Ljava/lang/Object;

    .line 130
    .line 131
    .line 132
    move-result-object v9

    .line 133
    check-cast v9, Lwf0;

    .line 134
    .line 135
    invoke-virtual {v8, v7}, Ld8;->y(Ljava/lang/Object;)V
    :try_end_89
    .catchall {:try_start_7e .. :try_end_89} :catchall_16c

    .line 136
    .line 137
    .line 138
    :try_start_89
    iget-object v8, v0, Lqo0;->b:Ljava/lang/Object;

    .line 139
    .line 140
    monitor-enter v8
    :try_end_8c
    .catchall {:try_start_89 .. :try_end_8c} :catchall_128

    .line 141
    :try_start_8c
    new-instance v11, Ljava/util/ArrayList;

    .line 142
    .line 143
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 144
    .line 145
    .line 146
    move-result v12

    .line 147
    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 148
    .line 149
    .line 150
    invoke-interface {v4}, Ljava/util/List;->size()I

    .line 151
    .line 152
    .line 153
    move-result v12

    .line 154
    move v13, v3

    .line 155
    :goto_9a
    if-ge v13, v12, :cond_e0

    .line 156
    .line 157
    invoke-interface {v4, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v14

    .line 161
    check-cast v14, Lbf0;

    .line 162
    .line 163
    iget-object v15, v0, Lqo0;->k:Ljava/util/LinkedHashMap;

    .line 164
    .line 165
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v15, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 169
    .line 170
    .line 171
    move-result-object v16

    .line 172
    move-object/from16 v5, v16

    .line 173
    .line 174
    check-cast v5, Ljava/util/List;

    .line 175
    .line 176
    if-eqz v5, :cond_d0

    .line 177
    .line 178
    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    .line 179
    .line 180
    .line 181
    move-result v16

    .line 182
    if-nez v16, :cond_c8

    .line 183
    .line 184
    invoke-interface {v5, v3}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 185
    .line 186
    .line 187
    move-result-object v16

    .line 188
    invoke-interface {v5}, Ljava/util/List;->isEmpty()Z

    .line 189
    .line 190
    .line 191
    move-result v5

    .line 192
    if-eqz v5, :cond_c5

    .line 193
    .line 194
    const/4 v5, 0x0

    .line 195
    invoke-interface {v15, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    :cond_c5
    move-object/from16 v5, v16

    .line 199
    .line 200
    goto :goto_d1

    .line 201
    :cond_c8
    new-instance v0, Ljava/util/NoSuchElementException;

    .line 202
    .line 203
    const-string v1, "List is empty."

    .line 204
    .line 205
    invoke-direct {v0, v1}, Ljava/util/NoSuchElementException;-><init>(Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    throw v0

    .line 209
    :cond_d0
    const/4 v5, 0x0

    .line 210
    :goto_d1
    new-instance v15, Lkj0;

    .line 211
    .line 212
    invoke-direct {v15, v14, v5}, Lkj0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    invoke-virtual {v11, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_d9
    .catchall {:try_start_8c .. :try_end_d9} :catchall_dd

    .line 216
    .line 217
    .line 218
    add-int/lit8 v13, v13, 0x1

    .line 219
    .line 220
    const/4 v5, 0x0

    .line 221
    goto :goto_9a

    .line 222
    :catchall_dd
    move-exception v0

    .line 223
    goto/16 :goto_16e

    .line 224
    .line 225
    :cond_e0
    :try_start_e0
    monitor-exit v8

    .line 226
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 227
    .line 228
    .line 229
    move-result v4

    .line 230
    move v5, v3

    .line 231
    :goto_e6
    if-ge v5, v4, :cond_15e

    .line 232
    .line 233
    invoke-virtual {v11, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 234
    .line 235
    .line 236
    move-result-object v8

    .line 237
    check-cast v8, Lkj0;

    .line 238
    .line 239
    iget-object v8, v8, Lkj0;->g:Ljava/lang/Object;

    .line 240
    .line 241
    if-nez v8, :cond_f5

    .line 242
    .line 243
    add-int/lit8 v5, v5, 0x1

    .line 244
    .line 245
    goto :goto_e6

    .line 246
    :cond_f5
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 247
    .line 248
    .line 249
    move-result v4

    .line 250
    move v5, v3

    .line 251
    :goto_fa
    if-ge v5, v4, :cond_15e

    .line 252
    .line 253
    invoke-virtual {v11, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 254
    .line 255
    .line 256
    move-result-object v8

    .line 257
    check-cast v8, Lkj0;

    .line 258
    .line 259
    iget-object v8, v8, Lkj0;->g:Ljava/lang/Object;

    .line 260
    .line 261
    if-eqz v8, :cond_109

    .line 262
    .line 263
    add-int/lit8 v5, v5, 0x1

    .line 264
    .line 265
    goto :goto_fa

    .line 266
    :cond_109
    new-instance v4, Ljava/util/ArrayList;

    .line 267
    .line 268
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 269
    .line 270
    .line 271
    move-result v5

    .line 272
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 273
    .line 274
    .line 275
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 276
    .line 277
    .line 278
    move-result v5

    .line 279
    move v8, v3

    .line 280
    :goto_117
    if-ge v8, v5, :cond_12d

    .line 281
    .line 282
    invoke-virtual {v11, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object v12

    .line 286
    check-cast v12, Lkj0;

    .line 287
    .line 288
    iget-object v13, v12, Lkj0;->g:Ljava/lang/Object;

    .line 289
    .line 290
    if-nez v13, :cond_12a

    .line 291
    .line 292
    iget-object v12, v12, Lkj0;->f:Ljava/lang/Object;

    .line 293
    .line 294
    check-cast v12, Lbf0;

    .line 295
    .line 296
    goto :goto_12a

    .line 297
    :catchall_128
    move-exception v0

    .line 298
    goto :goto_170

    .line 299
    :cond_12a
    :goto_12a
    add-int/lit8 v8, v8, 0x1

    .line 300
    .line 301
    goto :goto_117

    .line 302
    :cond_12d
    iget-object v5, v0, Lqo0;->b:Ljava/lang/Object;

    .line 303
    .line 304
    monitor-enter v5
    :try_end_130
    .catchall {:try_start_e0 .. :try_end_130} :catchall_128

    .line 305
    :try_start_130
    iget-object v8, v0, Lqo0;->j:Ljava/util/ArrayList;

    .line 306
    .line 307
    invoke-static {v8, v4}, Lke;->N(Ljava/util/ArrayList;Ljava/lang/Iterable;)V

    .line 308
    .line 309
    .line 310
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_137
    .catchall {:try_start_130 .. :try_end_137} :catchall_15b

    .line 311
    .line 312
    :try_start_137
    monitor-exit v5

    .line 313
    new-instance v4, Ljava/util/ArrayList;

    .line 314
    .line 315
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 316
    .line 317
    .line 318
    move-result v5

    .line 319
    invoke-direct {v4, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 320
    .line 321
    .line 322
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 323
    .line 324
    .line 325
    move-result v5

    .line 326
    move v8, v3

    .line 327
    :goto_146
    if-ge v8, v5, :cond_159

    .line 328
    .line 329
    invoke-virtual {v11, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 330
    .line 331
    .line 332
    move-result-object v12

    .line 333
    move-object v13, v12

    .line 334
    check-cast v13, Lkj0;

    .line 335
    .line 336
    iget-object v13, v13, Lkj0;->g:Ljava/lang/Object;

    .line 337
    .line 338
    if-eqz v13, :cond_156

    .line 339
    .line 340
    invoke-virtual {v4, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 341
    .line 342
    .line 343
    :cond_156
    add-int/lit8 v8, v8, 0x1

    .line 344
    .line 345
    goto :goto_146

    .line 346
    :cond_159
    move-object v11, v4

    .line 347
    goto :goto_15e

    .line 348
    :catchall_15b
    move-exception v0

    .line 349
    monitor-exit v5

    .line 350
    throw v0

    .line 351
    :cond_15e
    :goto_15e
    invoke-virtual {v6, v11}, Lag;->l(Ljava/util/ArrayList;)V

    .line 352
    .line 353
    .line 354
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_163
    .catchall {:try_start_137 .. :try_end_163} :catchall_128

    .line 355
    .line 356
    :try_start_163
    invoke-static {v9}, Lwf0;->i(Lwf0;)V
    :try_end_166
    .catchall {:try_start_163 .. :try_end_166} :catchall_16c

    .line 357
    .line 358
    .line 359
    invoke-static {v7}, Lqo0;->c(Lwf0;)V

    .line 360
    .line 361
    .line 362
    const/4 v5, 0x0

    .line 363
    goto/16 :goto_3e

    .line 364
    .line 365
    :catchall_16c
    move-exception v0

    .line 366
    goto :goto_174

    .line 367
    :goto_16e
    :try_start_16e
    monitor-exit v8

    .line 368
    throw v0
    :try_end_170
    .catchall {:try_start_16e .. :try_end_170} :catchall_128

    .line 369
    :goto_170
    :try_start_170
    invoke-static {v9}, Lwf0;->i(Lwf0;)V

    .line 370
    .line 371
    .line 372
    throw v0
    :try_end_174
    .catchall {:try_start_170 .. :try_end_174} :catchall_16c

    .line 373
    :goto_174
    invoke-static {v7}, Lqo0;->c(Lwf0;)V

    .line 374
    .line 375
    .line 376
    throw v0

    .line 377
    :cond_178
    const-string v0, "Cannot create a mutable snapshot of an read-only snapshot"

    .line 378
    .line 379
    invoke-static {v0}, Lm0;->g(Ljava/lang/String;)V

    .line 380
    .line 381
    .line 382
    const/16 v17, 0x0

    .line 383
    .line 384
    return-object v17

    .line 385
    :cond_180
    invoke-virtual {v1}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    .line 386
    .line 387
    .line 388
    move-result-object v0

    .line 389
    check-cast v0, Ljava/lang/Iterable;

    .line 390
    .line 391
    invoke-static {v0}, Lfe;->e0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 392
    .line 393
    .line 394
    move-result-object v0

    .line 395
    return-object v0
.end method

.method public final i(Ljava/lang/Exception;Lag;)V
    .registers 7

    .line 1
    sget-object v0, Lqo0;->v:Ljava/util/concurrent/atomic/AtomicReference;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Ljava/lang/Boolean;

    .line 8
    .line 9
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/16 v1, 0x1a

    .line 14
    .line 15
    if-eqz v0, :cond_56

    .line 16
    .line 17
    instance-of v0, p1, Ltf;

    .line 18
    .line 19
    if-nez v0, :cond_56

    .line 20
    .line 21
    iget-object v0, p0, Lqo0;->b:Ljava/lang/Object;

    .line 22
    .line 23
    monitor-enter v0

    .line 24
    :try_start_17
    const-string v2, "Error was captured in composition while live edit was enabled."

    .line 25
    .line 26
    sget v3, Lq3;->b:I

    .line 27
    .line 28
    const-string v3, "ComposeInternal"

    .line 29
    .line 30
    invoke-static {v3, v2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 31
    .line 32
    .line 33
    iget-object v2, p0, Lqo0;->i:Ljava/util/ArrayList;

    .line 34
    .line 35
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 36
    .line 37
    .line 38
    iget-object v2, p0, Lqo0;->h:Lxf0;

    .line 39
    .line 40
    invoke-virtual {v2}, Lxf0;->c()V

    .line 41
    .line 42
    .line 43
    new-instance v2, Lvf0;

    .line 44
    .line 45
    invoke-direct {v2}, Lvf0;-><init>()V

    .line 46
    .line 47
    .line 48
    iput-object v2, p0, Lqo0;->g:Lvf0;

    .line 49
    .line 50
    iget-object v2, p0, Lqo0;->j:Ljava/util/ArrayList;

    .line 51
    .line 52
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 53
    .line 54
    .line 55
    iget-object v2, p0, Lqo0;->k:Ljava/util/LinkedHashMap;

    .line 56
    .line 57
    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    .line 58
    .line 59
    .line 60
    iget-object v2, p0, Lqo0;->l:Ljava/util/LinkedHashMap;

    .line 61
    .line 62
    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->clear()V

    .line 63
    .line 64
    .line 65
    new-instance v2, Lnw;

    .line 66
    .line 67
    invoke-direct {v2, v1, p1}, Lnw;-><init>(ILjava/lang/Object;)V

    .line 68
    .line 69
    .line 70
    iput-object v2, p0, Lqo0;->q:Lnw;

    .line 71
    .line 72
    if-eqz p2, :cond_4f

    .line 73
    .line 74
    invoke-virtual {p0, p2}, Lqo0;->j(Lag;)V

    .line 75
    .line 76
    .line 77
    goto :goto_4f

    .line 78
    :catchall_4d
    move-exception p0

    .line 79
    goto :goto_54

    .line 80
    :cond_4f
    :goto_4f
    invoke-virtual {p0}, Lqo0;->d()Lec;
    :try_end_52
    .catchall {:try_start_17 .. :try_end_52} :catchall_4d

    .line 81
    .line 82
    .line 83
    monitor-exit v0

    .line 84
    return-void

    .line 85
    :goto_54
    monitor-exit v0

    .line 86
    throw p0

    .line 87
    :cond_56
    iget-object p2, p0, Lqo0;->b:Ljava/lang/Object;

    .line 88
    .line 89
    monitor-enter p2

    .line 90
    :try_start_59
    iget-object v0, p0, Lqo0;->q:Lnw;

    .line 91
    .line 92
    if-nez v0, :cond_6a

    .line 93
    .line 94
    new-instance v0, Lnw;

    .line 95
    .line 96
    invoke-direct {v0, v1, p1}, Lnw;-><init>(ILjava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    iput-object v0, p0, Lqo0;->q:Lnw;

    .line 100
    .line 101
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_66
    .catchall {:try_start_59 .. :try_end_66} :catchall_68

    .line 102
    .line 103
    monitor-exit p2

    .line 104
    throw p1

    .line 105
    :catchall_68
    move-exception p0

    .line 106
    goto :goto_6f

    .line 107
    :cond_6a
    :try_start_6a
    iget-object p0, v0, Lnw;->g:Ljava/lang/Object;

    .line 108
    .line 109
    check-cast p0, Ljava/lang/Exception;

    .line 110
    .line 111
    throw p0
    :try_end_6f
    .catchall {:try_start_6a .. :try_end_6f} :catchall_68

    .line 112
    :goto_6f
    monitor-exit p2

    .line 113
    throw p0
.end method

.method public final j(Lag;)V
    .registers 4

    .line 1
    iget-object v0, p0, Lqo0;->m:Ljava/util/ArrayList;

    .line 2
    .line 3
    if-nez v0, :cond_b

    .line 4
    .line 5
    new-instance v0, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lqo0;->m:Ljava/util/ArrayList;

    .line 11
    .line 12
    :cond_b
    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    .line 13
    .line 14
    .line 15
    move-result v1

    .line 16
    if-nez v1, :cond_14

    .line 17
    .line 18
    invoke-interface {v0, p1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    :cond_14
    iget-object v0, p0, Lqo0;->e:Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    const/4 p1, 0x0

    .line 27
    iput-object p1, p0, Lqo0;->f:Ljava/util/List;

    .line 28
    .line 29
    return-void
.end method
