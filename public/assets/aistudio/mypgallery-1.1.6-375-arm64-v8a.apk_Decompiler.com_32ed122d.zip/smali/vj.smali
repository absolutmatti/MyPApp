###### Class defpackage.vj (vj)
.class public final Lvj;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Lja;

.field public final b:Luj;


# direct methods
.method public constructor <init>(Lja;Luj;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lvj;->a:Lja;

    .line 5
    .line 6
    iput-object p2, p0, Lvj;->b:Luj;

    .line 7
    .line 8
    return-void
.end method
