###### Class defpackage.jf (jf)
.class public final synthetic Ljf;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;

.field public final synthetic h:I

.field public final synthetic i:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 14
    iput p2, p0, Ljf;->f:I

    iput-object p3, p0, Ljf;->g:Ljava/lang/Object;

    iput p1, p0, Ljf;->h:I

    iput-object p4, p0, Ljf;->i:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcom/mypg/mypgallery/dpi/DpiWorkerService;Landroid/os/Messenger;I)V
    .registers 5

    .line 1
    const/4 v0, 0x4

    .line 2
    iput v0, p0, Ljf;->f:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Ljf;->g:Ljava/lang/Object;

    .line 8
    .line 9
    iput-object p2, p0, Ljf;->i:Ljava/lang/Object;

    .line 10
    .line 11
    iput p3, p0, Ljf;->h:I

    .line 12
    .line 13
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 8

    .line 1
    iget v0, p0, Ljf;->f:I

    .line 2
    .line 3
    iget v1, p0, Ljf;->h:I

    .line 4
    .line 5
    iget-object v2, p0, Ljf;->i:Ljava/lang/Object;

    .line 6
    .line 7
    iget-object p0, p0, Ljf;->g:Ljava/lang/Object;

    .line 8
    .line 9
    packed-switch v0, :pswitch_data_c2

    .line 10
    .line 11
    .line 12
    check-cast p0, Lcom/mypg/mypgallery/dpi/DpiWorkerService;

    .line 13
    .line 14
    check-cast v2, Landroid/os/Messenger;

    .line 15
    .line 16
    sget v0, Lcom/mypg/mypgallery/dpi/DpiWorkerService;->h:I

    .line 17
    .line 18
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 19
    .line 20
    .line 21
    move-result-wide v3

    .line 22
    const-wide/16 v5, 0xbb8

    .line 23
    .line 24
    add-long/2addr v3, v5

    .line 25
    :goto_18
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 26
    .line 27
    .line 28
    move-result-wide v5

    .line 29
    cmp-long v0, v5, v3

    .line 30
    .line 31
    if-gez v0, :cond_51

    .line 32
    .line 33
    iget-object v0, p0, Lcom/mypg/mypgallery/dpi/DpiWorkerService;->f:Ljava/lang/Thread;

    .line 34
    .line 35
    if-eqz v0, :cond_51

    .line 36
    .line 37
    invoke-virtual {v0}, Ljava/lang/Thread;->isAlive()Z

    .line 38
    .line 39
    .line 40
    move-result v0

    .line 41
    const/4 v5, 0x1

    .line 42
    if-ne v0, v5, :cond_51

    .line 43
    .line 44
    :try_start_2b
    new-instance v0, Ljava/net/Socket;

    .line 45
    .line 46
    invoke-direct {v0}, Ljava/net/Socket;-><init>()V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2b .. :try_end_30} :catch_4b

    .line 47
    .line 48
    .line 49
    :try_start_30
    new-instance v5, Ljava/net/InetSocketAddress;

    .line 50
    .line 51
    const-string v6, "127.0.0.1"

    .line 52
    .line 53
    invoke-direct {v5, v6, v1}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    .line 54
    .line 55
    .line 56
    const/16 v6, 0xc8

    .line 57
    .line 58
    invoke-virtual {v0, v5, v6}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    .line 59
    .line 60
    .line 61
    sget-object v5, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_3e
    .catchall {:try_start_30 .. :try_end_3e} :catchall_44

    .line 62
    .line 63
    :try_start_3e
    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_41
    .catch Ljava/lang/Exception; {:try_start_3e .. :try_end_41} :catch_4b

    .line 64
    .line 65
    .line 66
    const/16 p0, 0xa

    .line 67
    .line 68
    goto :goto_53

    .line 69
    :catchall_44
    move-exception v5

    .line 70
    :try_start_45
    throw v5
    :try_end_46
    .catchall {:try_start_45 .. :try_end_46} :catchall_46

    .line 71
    :catchall_46
    move-exception v6

    .line 72
    :try_start_47
    invoke-static {v0, v5}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 73
    .line 74
    .line 75
    throw v6
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_47 .. :try_end_4b} :catch_4b

    .line 76
    :catch_4b
    const-wide/16 v5, 0x32

    .line 77
    .line 78
    invoke-static {v5, v6}, Ljava/lang/Thread;->sleep(J)V

    .line 79
    .line 80
    .line 81
    goto :goto_18

    .line 82
    :cond_51
    const/16 p0, 0xb

    .line 83
    .line 84
    :goto_53
    invoke-static {v2, p0}, Lcom/mypg/mypgallery/dpi/DpiWorkerService;->a(Landroid/os/Messenger;I)V

    .line 85
    .line 86
    .line 87
    return-void

    .line 88
    :pswitch_57
    check-cast p0, Lxm;

    .line 89
    .line 90
    iget-object p0, p0, Lxm;->c:Ljava/lang/Object;

    .line 91
    .line 92
    check-cast p0, Lvm0;

    .line 93
    .line 94
    invoke-interface {p0, v1, v2}, Lvm0;->d(ILjava/lang/Object;)V

    .line 95
    .line 96
    .line 97
    return-void

    .line 98
    :pswitch_61
    check-cast p0, Lyq;

    .line 99
    .line 100
    check-cast v2, Landroid/os/Bundle;

    .line 101
    .line 102
    invoke-interface {p0, v1, v2}, Lyq;->onGreatestScrollPercentageIncreased(ILandroid/os/Bundle;)V

    .line 103
    .line 104
    .line 105
    return-void

    .line 106
    :pswitch_69
    check-cast p0, Lkf;

    .line 107
    .line 108
    check-cast v2, Landroid/content/IntentSender$SendIntentException;

    .line 109
    .line 110
    new-instance v0, Landroid/content/Intent;

    .line 111
    .line 112
    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    .line 113
    .line 114
    .line 115
    const-string v3, "androidx.activity.result.contract.action.INTENT_SENDER_REQUEST"

    .line 116
    .line 117
    invoke-virtual {v0, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 118
    .line 119
    .line 120
    move-result-object v0

    .line 121
    const-string v3, "androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION"

    .line 122
    .line 123
    invoke-virtual {v0, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    .line 124
    .line 125
    .line 126
    move-result-object v0

    .line 127
    const/4 v2, 0x0

    .line 128
    invoke-virtual {p0, v1, v2, v0}, Lp3;->a(IILandroid/content/Intent;)Z

    .line 129
    .line 130
    .line 131
    return-void

    .line 132
    :pswitch_83
    check-cast p0, Lkf;

    .line 133
    .line 134
    check-cast v2, Ldb0;

    .line 135
    .line 136
    iget-object v0, v2, Ldb0;->g:Ljava/lang/Object;

    .line 137
    .line 138
    iget-object v2, p0, Lp3;->a:Ljava/util/LinkedHashMap;

    .line 139
    .line 140
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 141
    .line 142
    .line 143
    move-result-object v1

    .line 144
    invoke-virtual {v2, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v1

    .line 148
    check-cast v1, Ljava/lang/String;

    .line 149
    .line 150
    if-nez v1, :cond_98

    .line 151
    .line 152
    goto :goto_c0

    .line 153
    :cond_98
    iget-object v2, p0, Lp3;->e:Ljava/util/LinkedHashMap;

    .line 154
    .line 155
    invoke-virtual {v2, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v2

    .line 159
    check-cast v2, Ll3;

    .line 160
    .line 161
    if-eqz v2, :cond_a5

    .line 162
    .line 163
    iget-object v3, v2, Ll3;->a:Lg3;

    .line 164
    .line 165
    goto :goto_a6

    .line 166
    :cond_a5
    const/4 v3, 0x0

    .line 167
    :goto_a6
    if-nez v3, :cond_b3

    .line 168
    .line 169
    iget-object v2, p0, Lp3;->g:Landroid/os/Bundle;

    .line 170
    .line 171
    invoke-virtual {v2, v1}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 172
    .line 173
    .line 174
    iget-object p0, p0, Lp3;->f:Ljava/util/LinkedHashMap;

    .line 175
    .line 176
    invoke-interface {p0, v1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 177
    .line 178
    .line 179
    goto :goto_c0

    .line 180
    :cond_b3
    iget-object v2, v2, Ll3;->a:Lg3;

    .line 181
    .line 182
    iget-object p0, p0, Lp3;->d:Ljava/util/ArrayList;

    .line 183
    .line 184
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 185
    .line 186
    .line 187
    move-result p0

    .line 188
    if-eqz p0, :cond_c0

    .line 189
    .line 190
    invoke-interface {v2, v0}, Lg3;->a(Ljava/lang/Object;)V

    .line 191
    .line 192
    .line 193
    :cond_c0
    :goto_c0
    return-void

    .line 194
    nop

    .line 195
    :pswitch_data_c2
    .packed-switch 0x0
        :pswitch_83
        :pswitch_69
        :pswitch_61
        :pswitch_57
    .end packed-switch
.end method
