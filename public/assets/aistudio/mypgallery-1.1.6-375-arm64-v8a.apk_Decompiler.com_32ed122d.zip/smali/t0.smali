###### Class defpackage.t0 (t0)
.class public abstract Lt0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# direct methods
.method public static a(Landroid/content/res/Configuration;)Z
    .registers 2

    .line 1
    invoke-static {p0}, Ls0;->a(Landroid/content/res/Configuration;)I

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    const v0, 0x7fffffff

    .line 6
    .line 7
    .line 8
    if-eq p0, v0, :cond_f

    .line 9
    .line 10
    const/16 v0, 0x12c

    .line 11
    .line 12
    if-lt p0, v0, :cond_f

    .line 13
    .line 14
    const/4 p0, 0x1

    .line 15
    return p0

    .line 16
    :cond_f
    const/4 p0, 0x0

    .line 17
    return p0
.end method
