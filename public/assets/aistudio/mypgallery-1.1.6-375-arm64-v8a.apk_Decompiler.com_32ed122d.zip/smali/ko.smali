###### Class defpackage.ko (ko)
.class public final synthetic Lko;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lqe0;

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lqe0;Ljava/lang/Object;I)V
    .registers 4

    .line 1
    iput p3, p0, Lko;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Lko;->g:Lqe0;

    .line 4
    .line 5
    iput-object p2, p0, Lko;->h:Ljava/lang/Object;

    .line 6
    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .line 1
    iget v0, p0, Lko;->f:I

    .line 2
    .line 3
    iget-object v1, p0, Lko;->h:Ljava/lang/Object;

    .line 4
    .line 5
    iget-object p0, p0, Lko;->g:Lqe0;

    .line 6
    .line 7
    packed-switch v0, :pswitch_data_12

    .line 8
    .line 9
    .line 10
    invoke-virtual {p0, v1}, Lqe0;->success(Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    return-void

    .line 14
    :pswitch_d
    invoke-virtual {p0, v1}, Lqe0;->success(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    nop

    .line 19
    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_d
    .end packed-switch
.end method
