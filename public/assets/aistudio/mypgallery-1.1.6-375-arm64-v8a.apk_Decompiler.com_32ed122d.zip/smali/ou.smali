###### Class defpackage.ou (ou)
.class public final Lou;
.super Lsh;


# instance fields
.field public synthetic i:Ljava/lang/Object;

.field public j:I

.field public final synthetic k:Lku;

.field public l:Lfu;

.field public m:Ljava/lang/Throwable;

.field public n:I

.field public o:I

.field public p:J


# direct methods
.method public constructor <init>(Lku;Lkotlin/coroutines/Continuation;)V
    .registers 3

    .line 1
    iput-object p1, p0, Lou;->k:Lku;

    .line 2
    .line 3
    invoke-direct {p0, p2}, Lsh;-><init>(Lkotlin/coroutines/Continuation;)V

    .line 4
    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    iput-object p1, p0, Lou;->i:Ljava/lang/Object;

    .line 2
    .line 3
    iget p1, p0, Lou;->j:I

    .line 4
    .line 5
    const/high16 v0, -0x80000000

    .line 6
    .line 7
    or-int/2addr p1, v0

    .line 8
    iput p1, p0, Lou;->j:I

    .line 9
    .line 10
    iget-object p1, p0, Lou;->k:Lku;

    .line 11
    .line 12
    const/4 v0, 0x0

    .line 13
    invoke-virtual {p1, v0, p0}, Lku;->c(Lfu;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method
