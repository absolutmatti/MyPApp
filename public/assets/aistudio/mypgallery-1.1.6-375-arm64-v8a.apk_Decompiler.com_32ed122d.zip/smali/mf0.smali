###### Class defpackage.mf0 (mf0)
.class public Lmf0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final k:Ljava/lang/Object;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Lfr0;

.field public c:I

.field public d:Z

.field public volatile e:Ljava/lang/Object;

.field public volatile f:Ljava/lang/Object;

.field public g:I

.field public h:Z

.field public i:Z

.field public final j:Lo9;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Ljava/lang/Object;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    sput-object v0, Lmf0;->k:Ljava/lang/Object;

    .line 7
    .line 8
    return-void
.end method

.method public constructor <init>()V
    .registers 4

    .line 40
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 41
    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lmf0;->a:Ljava/lang/Object;

    .line 42
    new-instance v0, Lfr0;

    invoke-direct {v0}, Lfr0;-><init>()V

    iput-object v0, p0, Lmf0;->b:Lfr0;

    const/4 v0, 0x0

    .line 43
    iput v0, p0, Lmf0;->c:I

    .line 44
    sget-object v0, Lmf0;->k:Ljava/lang/Object;

    iput-object v0, p0, Lmf0;->f:Ljava/lang/Object;

    .line 45
    new-instance v1, Lo9;

    const/4 v2, 0x6

    invoke-direct {v1, v2, p0}, Lo9;-><init>(ILjava/lang/Object;)V

    iput-object v1, p0, Lmf0;->j:Lo9;

    .line 46
    iput-object v0, p0, Lmf0;->e:Ljava/lang/Object;

    const/4 v0, -0x1

    .line 47
    iput v0, p0, Lmf0;->g:I

    return-void
.end method

.method public constructor <init>(I)V
    .registers 5

    .line 1
    sget-object p1, Lyi0;->b:Lsi0;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    new-instance v0, Ljava/lang/Object;

    .line 7
    .line 8
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object v0, p0, Lmf0;->a:Ljava/lang/Object;

    .line 12
    .line 13
    new-instance v0, Lfr0;

    .line 14
    .line 15
    invoke-direct {v0}, Lfr0;-><init>()V

    .line 16
    .line 17
    .line 18
    iput-object v0, p0, Lmf0;->b:Lfr0;

    .line 19
    .line 20
    const/4 v0, 0x0

    .line 21
    iput v0, p0, Lmf0;->c:I

    .line 22
    .line 23
    sget-object v1, Lmf0;->k:Ljava/lang/Object;

    .line 24
    .line 25
    iput-object v1, p0, Lmf0;->f:Ljava/lang/Object;

    .line 26
    .line 27
    new-instance v1, Lo9;

    .line 28
    .line 29
    const/4 v2, 0x6

    .line 30
    invoke-direct {v1, v2, p0}, Lo9;-><init>(ILjava/lang/Object;)V

    .line 31
    .line 32
    .line 33
    iput-object v1, p0, Lmf0;->j:Lo9;

    .line 34
    .line 35
    iput-object p1, p0, Lmf0;->e:Ljava/lang/Object;

    .line 36
    .line 37
    iput v0, p0, Lmf0;->g:I

    .line 38
    .line 39
    return-void
.end method

.method public static a(Ljava/lang/String;)V
    .registers 3

    .line 1
    invoke-static {}, Lx8;->Y()Lx8;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-object v0, v0, Lx8;->h:Llm;

    .line 6
    .line 7
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 19
    .line 20
    .line 21
    move-result-object v1

    .line 22
    if-ne v0, v1, :cond_18

    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    const-string v0, "Cannot invoke "

    .line 26
    .line 27
    const-string v1, " on a background thread"

    .line 28
    .line 29
    invoke-static {v0, p0, v1}, Lzi0;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 30
    .line 31
    .line 32
    move-result-object p0

    .line 33
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    return-void
.end method


# virtual methods
.method public final b(Lfa0;)V
    .registers 4

    .line 1
    iget-boolean v0, p1, Lfa0;->b:Z

    .line 2
    .line 3
    if-nez v0, :cond_5

    .line 4
    .line 5
    goto :goto_3b

    .line 6
    :cond_5
    iget v0, p1, Lfa0;->c:I

    .line 7
    .line 8
    iget v1, p0, Lmf0;->g:I

    .line 9
    .line 10
    if-lt v0, v1, :cond_c

    .line 11
    .line 12
    goto :goto_3b

    .line 13
    :cond_c
    iput v1, p1, Lfa0;->c:I

    .line 14
    .line 15
    iget-object p1, p1, Lfa0;->a:Ldb0;

    .line 16
    .line 17
    iget-object p0, p0, Lmf0;->e:Ljava/lang/Object;

    .line 18
    .line 19
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 20
    .line 21
    .line 22
    check-cast p0, Lp80;

    .line 23
    .line 24
    iget-object p1, p1, Ldb0;->g:Ljava/lang/Object;

    .line 25
    .line 26
    check-cast p1, Len;

    .line 27
    .line 28
    if-eqz p0, :cond_3b

    .line 29
    .line 30
    iget-boolean p0, p1, Len;->c0:Z

    .line 31
    .line 32
    if-nez p0, :cond_22

    .line 33
    .line 34
    goto :goto_3b

    .line 35
    :cond_22
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 36
    .line 37
    new-instance v0, Ljava/lang/StringBuilder;

    .line 38
    .line 39
    const-string v1, "Fragment "

    .line 40
    .line 41
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    const-string p1, " did not return a View from onCreateView() or this was called before onCreateView()."

    .line 48
    .line 49
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 53
    .line 54
    .line 55
    move-result-object p1

    .line 56
    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 57
    .line 58
    .line 59
    throw p0

    .line 60
    :cond_3b
    :goto_3b
    return-void
.end method

.method public final c(Lfa0;)V
    .registers 6

    .line 1
    iget-boolean v0, p0, Lmf0;->h:Z

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_8

    .line 5
    .line 6
    iput-boolean v1, p0, Lmf0;->i:Z

    .line 7
    .line 8
    return-void

    .line 9
    :cond_8
    iput-boolean v1, p0, Lmf0;->h:Z

    .line 10
    .line 11
    :cond_a
    const/4 v0, 0x0

    .line 12
    iput-boolean v0, p0, Lmf0;->i:Z

    .line 13
    .line 14
    if-eqz p1, :cond_14

    .line 15
    .line 16
    invoke-virtual {p0, p1}, Lmf0;->b(Lfa0;)V

    .line 17
    .line 18
    .line 19
    const/4 p1, 0x0

    .line 20
    goto :goto_3e

    .line 21
    :cond_14
    iget-object v1, p0, Lmf0;->b:Lfr0;

    .line 22
    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    .line 25
    .line 26
    new-instance v2, Ldr0;

    .line 27
    .line 28
    invoke-direct {v2, v1}, Ldr0;-><init>(Lfr0;)V

    .line 29
    .line 30
    .line 31
    iget-object v1, v1, Lfr0;->h:Ljava/util/WeakHashMap;

    .line 32
    .line 33
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 34
    .line 35
    invoke-virtual {v1, v2, v3}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    :cond_25
    invoke-virtual {v2}, Ldr0;->hasNext()Z

    .line 39
    .line 40
    .line 41
    move-result v1

    .line 42
    if-eqz v1, :cond_3e

    .line 43
    .line 44
    invoke-virtual {v2}, Ldr0;->next()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    check-cast v1, Ljava/util/Map$Entry;

    .line 49
    .line 50
    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object v1

    .line 54
    check-cast v1, Lfa0;

    .line 55
    .line 56
    invoke-virtual {p0, v1}, Lmf0;->b(Lfa0;)V

    .line 57
    .line 58
    .line 59
    iget-boolean v1, p0, Lmf0;->i:Z

    .line 60
    .line 61
    if-eqz v1, :cond_25

    .line 62
    .line 63
    :cond_3e
    :goto_3e
    iget-boolean v1, p0, Lmf0;->i:Z

    .line 64
    .line 65
    if-nez v1, :cond_a

    .line 66
    .line 67
    iput-boolean v0, p0, Lmf0;->h:Z

    .line 68
    .line 69
    return-void
.end method

.method public final d(Lrl;)V
    .registers 5

    .line 1
    iget-object v0, p0, Lmf0;->a:Ljava/lang/Object;

    .line 2
    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Lmf0;->f:Ljava/lang/Object;

    .line 5
    .line 6
    sget-object v2, Lmf0;->k:Ljava/lang/Object;

    .line 7
    .line 8
    if-ne v1, v2, :cond_b

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 v1, 0x0

    .line 13
    :goto_c
    iput-object p1, p0, Lmf0;->f:Ljava/lang/Object;

    .line 14
    .line 15
    monitor-exit v0
    :try_end_f
    .catchall {:try_start_3 .. :try_end_f} :catchall_3c

    .line 16
    if-nez v1, :cond_12

    .line 17
    .line 18
    return-void

    .line 19
    :cond_12
    invoke-static {}, Lx8;->Y()Lx8;

    .line 20
    .line 21
    .line 22
    move-result-object p1

    .line 23
    iget-object p0, p0, Lmf0;->j:Lo9;

    .line 24
    .line 25
    iget-object p1, p1, Lx8;->h:Llm;

    .line 26
    .line 27
    iget-object v0, p1, Llm;->j:Landroid/os/Handler;

    .line 28
    .line 29
    if-nez v0, :cond_36

    .line 30
    .line 31
    iget-object v0, p1, Llm;->h:Ljava/lang/Object;

    .line 32
    .line 33
    monitor-enter v0

    .line 34
    :try_start_21
    iget-object v1, p1, Llm;->j:Landroid/os/Handler;

    .line 35
    .line 36
    if-nez v1, :cond_32

    .line 37
    .line 38
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    invoke-static {v1}, Landroid/os/Handler;->createAsync(Landroid/os/Looper;)Landroid/os/Handler;

    .line 43
    .line 44
    .line 45
    move-result-object v1

    .line 46
    iput-object v1, p1, Llm;->j:Landroid/os/Handler;

    .line 47
    .line 48
    goto :goto_32

    .line 49
    :catchall_30
    move-exception p0

    .line 50
    goto :goto_34

    .line 51
    :cond_32
    :goto_32
    monitor-exit v0

    .line 52
    goto :goto_36

    .line 53
    :goto_34
    monitor-exit v0
    :try_end_35
    .catchall {:try_start_21 .. :try_end_35} :catchall_30

    .line 54
    throw p0

    .line 55
    :cond_36
    :goto_36
    iget-object p1, p1, Llm;->j:Landroid/os/Handler;

    .line 56
    .line 57
    invoke-virtual {p1, p0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 58
    .line 59
    .line 60
    return-void

    .line 61
    :catchall_3c
    move-exception p0

    .line 62
    :try_start_3d
    monitor-exit v0
    :try_end_3e
    .catchall {:try_start_3d .. :try_end_3e} :catchall_3c

    .line 63
    throw p0
.end method

.method public final e(Ljava/lang/Object;)V
    .registers 3

    .line 1
    const-string v0, "setValue"

    .line 2
    .line 3
    invoke-static {v0}, Lmf0;->a(Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lmf0;->g:I

    .line 7
    .line 8
    add-int/lit8 v0, v0, 0x1

    .line 9
    .line 10
    iput v0, p0, Lmf0;->g:I

    .line 11
    .line 12
    iput-object p1, p0, Lmf0;->e:Ljava/lang/Object;

    .line 13
    .line 14
    const/4 p1, 0x0

    .line 15
    invoke-virtual {p0, p1}, Lmf0;->c(Lfa0;)V

    .line 16
    .line 17
    .line 18
    return-void
.end method
