###### Class defpackage.nk (nk)
.class public final Lnk;
.super Lc21;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lsz;


# instance fields
.field public final synthetic j:I

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V
    .registers 5

    .line 1
    iput p4, p0, Lnk;->j:I

    .line 2
    .line 3
    iput-object p1, p0, Lnk;->k:Ljava/lang/Object;

    .line 4
    .line 5
    iput-object p2, p0, Lnk;->l:Ljava/lang/Object;

    .line 6
    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, Lc21;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V
    .registers 4

    .line 12
    iput p3, p0, Lnk;->j:I

    iput-object p1, p0, Lnk;->l:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lc21;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget v0, p0, Lnk;->j:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_6c

    .line 4
    .line 5
    .line 6
    check-cast p1, Lpf0;

    .line 7
    .line 8
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lnk;->k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    check-cast p0, Lnk;

    .line 15
    .line 16
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lnk;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16
    check-cast p1, Lhi;

    .line 24
    .line 25
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 26
    .line 27
    invoke-virtual {p0, p1, p2}, Lnk;->k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Lnk;

    .line 32
    .line 33
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 34
    .line 35
    invoke-virtual {p0, p1}, Lnk;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    return-object p0

    .line 40
    :pswitch_27
    check-cast p1, Lhi;

    .line 41
    .line 42
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 43
    .line 44
    invoke-virtual {p0, p1, p2}, Lnk;->k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    check-cast p0, Lnk;

    .line 49
    .line 50
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 51
    .line 52
    invoke-virtual {p0, p1}, Lnk;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    return-object p0

    .line 57
    :pswitch_38
    check-cast p1, Lhi;

    .line 58
    .line 59
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 60
    .line 61
    invoke-virtual {p0, p1, p2}, Lnk;->k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    check-cast p0, Lnk;

    .line 66
    .line 67
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 68
    .line 69
    invoke-virtual {p0, p1}, Lnk;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    return-object p0

    .line 74
    :pswitch_49
    check-cast p1, Lpf0;

    .line 75
    .line 76
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 77
    .line 78
    invoke-virtual {p0, p1, p2}, Lnk;->k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    check-cast p0, Lnk;

    .line 83
    .line 84
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 85
    .line 86
    invoke-virtual {p0, p1}, Lnk;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    return-object p0

    .line 91
    :pswitch_5a
    check-cast p1, Lc01;

    .line 92
    .line 93
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 94
    .line 95
    invoke-virtual {p0, p1, p2}, Lnk;->k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    check-cast p0, Lnk;

    .line 100
    .line 101
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 102
    .line 103
    invoke-virtual {p0, p1}, Lnk;->n(Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    return-object p0

    .line 108
    nop

    .line 109
    :pswitch_data_6c
    .packed-switch 0x0
        :pswitch_5a
        :pswitch_49
        :pswitch_38
        :pswitch_27
        :pswitch_16
    .end packed-switch
.end method

.method public final k(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 5

    .line 1
    iget v0, p0, Lnk;->j:I

    .line 2
    .line 3
    iget-object v1, p0, Lnk;->l:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_4e

    .line 6
    .line 7
    .line 8
    new-instance p0, Lnk;

    .line 9
    .line 10
    check-cast v1, Ljava/util/List;

    .line 11
    .line 12
    const/4 v0, 0x5

    .line 13
    invoke-direct {p0, v1, p2, v0}, Lnk;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 14
    .line 15
    .line 16
    iput-object p1, p0, Lnk;->k:Ljava/lang/Object;

    .line 17
    .line 18
    return-object p0

    .line 19
    :pswitch_12
    new-instance p1, Lnk;

    .line 20
    .line 21
    iget-object p0, p0, Lnk;->k:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast p0, Lzf;

    .line 24
    .line 25
    check-cast v1, Ljava/util/Map;

    .line 26
    .line 27
    const/4 v0, 0x4

    .line 28
    invoke-direct {p1, p0, v1, p2, v0}, Lnk;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 29
    .line 30
    .line 31
    return-object p1

    .line 32
    :pswitch_1f
    new-instance p0, Lnk;

    .line 33
    .line 34
    check-cast v1, Lsz;

    .line 35
    .line 36
    const/4 v0, 0x3

    .line 37
    invoke-direct {p0, v1, p2, v0}, Lnk;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 38
    .line 39
    .line 40
    iput-object p1, p0, Lnk;->k:Ljava/lang/Object;

    .line 41
    .line 42
    return-object p0

    .line 43
    :pswitch_2a
    new-instance p1, Lnk;

    .line 44
    .line 45
    iget-object p0, p0, Lnk;->k:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast p0, Ld80;

    .line 48
    .line 49
    check-cast v1, Ljava/lang/String;

    .line 50
    .line 51
    const/4 v0, 0x2

    .line 52
    invoke-direct {p1, p0, v1, p2, v0}, Lnk;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 53
    .line 54
    .line 55
    return-object p1

    .line 56
    :pswitch_37
    new-instance p0, Lnk;

    .line 57
    .line 58
    check-cast v1, Ljava/util/Set;

    .line 59
    .line 60
    const/4 v0, 0x1

    .line 61
    invoke-direct {p0, v1, p2, v0}, Lnk;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 62
    .line 63
    .line 64
    iput-object p1, p0, Lnk;->k:Ljava/lang/Object;

    .line 65
    .line 66
    return-object p0

    .line 67
    :pswitch_42
    new-instance p0, Lnk;

    .line 68
    .line 69
    check-cast v1, Lc01;

    .line 70
    .line 71
    const/4 v0, 0x0

    .line 72
    invoke-direct {p0, v1, p2, v0}, Lnk;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 73
    .line 74
    .line 75
    iput-object p1, p0, Lnk;->k:Ljava/lang/Object;

    .line 76
    .line 77
    return-object p0

    .line 78
    nop

    .line 79
    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_42
        :pswitch_37
        :pswitch_2a
        :pswitch_1f
        :pswitch_12
    .end packed-switch
.end method

.method public final n(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget v1, v0, Lnk;->j:I

    .line 4
    .line 5
    const/4 v3, 0x0

    .line 6
    iget-object v5, v0, Lnk;->l:Ljava/lang/Object;

    .line 7
    .line 8
    packed-switch v1, :pswitch_data_4f6

    .line 9
    .line 10
    .line 11
    iget-object v0, v0, Lnk;->k:Ljava/lang/Object;

    .line 12
    .line 13
    check-cast v0, Lpf0;

    .line 14
    .line 15
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    invoke-static/range {p1 .. p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    check-cast v5, Ljava/util/List;

    .line 22
    .line 23
    if-eqz v5, :cond_3c

    .line 24
    .line 25
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 26
    .line 27
    .line 28
    move-result-object v1

    .line 29
    :goto_1c
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    if-eqz v2, :cond_44

    .line 34
    .line 35
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, Ljava/lang/String;

    .line 40
    .line 41
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    .line 43
    .line 44
    new-instance v3, Lwl0;

    .line 45
    .line 46
    invoke-direct {v3, v2}, Lwl0;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    invoke-virtual {v0}, Lpf0;->b()V

    .line 53
    .line 54
    .line 55
    iget-object v2, v0, Lpf0;->a:Ljava/util/LinkedHashMap;

    .line 56
    .line 57
    invoke-interface {v2, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    goto :goto_1c

    .line 61
    :cond_3c
    invoke-virtual {v0}, Lpf0;->b()V

    .line 62
    .line 63
    .line 64
    iget-object v0, v0, Lpf0;->a:Ljava/util/LinkedHashMap;

    .line 65
    .line 66
    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->clear()V

    .line 67
    .line 68
    .line 69
    :cond_44
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 70
    .line 71
    return-object v0

    .line 72
    :pswitch_47
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    invoke-static/range {p1 .. p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 76
    .line 77
    .line 78
    iget-object v0, v0, Lnk;->k:Ljava/lang/Object;

    .line 79
    .line 80
    check-cast v0, Lzf;

    .line 81
    .line 82
    check-cast v5, Ljava/util/Map;

    .line 83
    .line 84
    iget-object v1, v0, Lzf;->a:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v1, Landroid/content/Context;

    .line 87
    .line 88
    invoke-virtual {v0}, Lzf;->e()Ljava/io/File;

    .line 89
    .line 90
    .line 91
    move-result-object v6

    .line 92
    invoke-virtual {v6}, Ljava/io/File;->listFiles()[Ljava/io/File;

    .line 93
    .line 94
    .line 95
    move-result-object v7

    .line 96
    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    .line 97
    .line 98
    .line 99
    move-result v8

    .line 100
    if-eqz v8, :cond_7a

    .line 101
    .line 102
    if-eqz v7, :cond_7a

    .line 103
    .line 104
    array-length v8, v7

    .line 105
    if-nez v8, :cond_6b

    .line 106
    .line 107
    goto :goto_7a

    .line 108
    :cond_6b
    array-length v8, v7

    .line 109
    const/4 v9, 0x0

    .line 110
    :goto_6d
    if-ge v9, v8, :cond_77

    .line 111
    .line 112
    aget-object v10, v7, v9

    .line 113
    .line 114
    invoke-virtual {v10}, Ljava/io/File;->delete()Z

    .line 115
    .line 116
    .line 117
    add-int/lit8 v9, v9, 0x1

    .line 118
    .line 119
    goto :goto_6d

    .line 120
    :cond_77
    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    .line 121
    .line 122
    .line 123
    :cond_7a
    :goto_7a
    const-string v6, "text"

    .line 124
    .line 125
    invoke-interface {v5, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 126
    .line 127
    .line 128
    move-result-object v6

    .line 129
    check-cast v6, Ljava/lang/String;

    .line 130
    .line 131
    const-string v7, "uri"

    .line 132
    .line 133
    invoke-interface {v5, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object v7

    .line 137
    check-cast v7, Ljava/lang/String;

    .line 138
    .line 139
    const-string v8, "subject"

    .line 140
    .line 141
    invoke-interface {v5, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v8

    .line 145
    check-cast v8, Ljava/lang/String;

    .line 146
    .line 147
    const-string v9, "title"

    .line 148
    .line 149
    invoke-interface {v5, v9}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v9

    .line 153
    check-cast v9, Ljava/lang/String;

    .line 154
    .line 155
    const-string v10, "paths"

    .line 156
    .line 157
    invoke-interface {v5, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 158
    .line 159
    .line 160
    move-result-object v10

    .line 161
    check-cast v10, Ljava/util/List;

    .line 162
    .line 163
    if-eqz v10, :cond_bf

    .line 164
    .line 165
    new-instance v11, Ljava/util/ArrayList;

    .line 166
    .line 167
    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    .line 168
    .line 169
    .line 170
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 171
    .line 172
    .line 173
    move-result-object v10

    .line 174
    :cond_ad
    :goto_ad
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 175
    .line 176
    .line 177
    move-result v12

    .line 178
    if-eqz v12, :cond_c0

    .line 179
    .line 180
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 181
    .line 182
    .line 183
    move-result-object v12

    .line 184
    instance-of v13, v12, Ljava/lang/String;

    .line 185
    .line 186
    if-eqz v13, :cond_ad

    .line 187
    .line 188
    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 189
    .line 190
    .line 191
    goto :goto_ad

    .line 192
    :cond_bf
    move-object v11, v3

    .line 193
    :cond_c0
    const-string v10, "mimeTypes"

    .line 194
    .line 195
    invoke-interface {v5, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    .line 197
    .line 198
    move-result-object v5

    .line 199
    check-cast v5, Ljava/util/List;

    .line 200
    .line 201
    if-eqz v5, :cond_e5

    .line 202
    .line 203
    new-instance v10, Ljava/util/ArrayList;

    .line 204
    .line 205
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 206
    .line 207
    .line 208
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 209
    .line 210
    .line 211
    move-result-object v5

    .line 212
    :cond_d3
    :goto_d3
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 213
    .line 214
    .line 215
    move-result v12

    .line 216
    if-eqz v12, :cond_e6

    .line 217
    .line 218
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 219
    .line 220
    .line 221
    move-result-object v12

    .line 222
    instance-of v13, v12, Ljava/lang/String;

    .line 223
    .line 224
    if-eqz v13, :cond_d3

    .line 225
    .line 226
    invoke-virtual {v10, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 227
    .line 228
    .line 229
    goto :goto_d3

    .line 230
    :cond_e5
    move-object v10, v3

    .line 231
    :cond_e6
    if-eqz v11, :cond_1d0

    .line 232
    .line 233
    new-instance v5, Ljava/util/ArrayList;

    .line 234
    .line 235
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 236
    .line 237
    .line 238
    move-result v12

    .line 239
    invoke-direct {v5, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 243
    .line 244
    .line 245
    move-result v12

    .line 246
    const/4 v13, 0x0

    .line 247
    :goto_f6
    if-ge v13, v12, :cond_1cf

    .line 248
    .line 249
    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 250
    .line 251
    .line 252
    move-result-object v14

    .line 253
    add-int/lit8 v13, v13, 0x1

    .line 254
    .line 255
    check-cast v14, Ljava/lang/String;

    .line 256
    .line 257
    new-instance v15, Ljava/io/File;

    .line 258
    .line 259
    invoke-direct {v15, v14}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    .line 260
    .line 261
    .line 262
    :try_start_105
    invoke-virtual {v15}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 263
    .line 264
    .line 265
    move-result-object v14

    .line 266
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 267
    .line 268
    .line 269
    invoke-virtual {v0}, Lzf;->e()Ljava/io/File;

    .line 270
    .line 271
    .line 272
    move-result-object v16

    .line 273
    invoke-virtual/range {v16 .. v16}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 274
    .line 275
    .line 276
    move-result-object v2

    .line 277
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 278
    .line 279
    .line 280
    invoke-virtual {v14, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 281
    .line 282
    .line 283
    move-result v2
    :try_end_11b
    .catch Ljava/io/IOException; {:try_start_105 .. :try_end_11b} :catch_11c

    .line 284
    goto :goto_11d

    .line 285
    :catch_11c
    const/4 v2, 0x0

    .line 286
    :goto_11d
    if-nez v2, :cond_1b9

    .line 287
    .line 288
    invoke-virtual {v0}, Lzf;->e()Ljava/io/File;

    .line 289
    .line 290
    .line 291
    move-result-object v2

    .line 292
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    .line 293
    .line 294
    .line 295
    move-result v14

    .line 296
    if-nez v14, :cond_12c

    .line 297
    .line 298
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 299
    .line 300
    .line 301
    :cond_12c
    new-instance v14, Ljava/io/File;

    .line 302
    .line 303
    invoke-virtual {v15}, Ljava/io/File;->getName()Ljava/lang/String;

    .line 304
    .line 305
    .line 306
    move-result-object v4

    .line 307
    invoke-direct {v14, v2, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 308
    .line 309
    .line 310
    invoke-virtual {v15}, Ljava/io/File;->exists()Z

    .line 311
    .line 312
    .line 313
    move-result v2

    .line 314
    if-eqz v2, :cond_1b1

    .line 315
    .line 316
    invoke-virtual {v14}, Ljava/io/File;->exists()Z

    .line 317
    .line 318
    .line 319
    move-result v2

    .line 320
    if-eqz v2, :cond_150

    .line 321
    .line 322
    invoke-virtual {v14}, Ljava/io/File;->delete()Z

    .line 323
    .line 324
    .line 325
    move-result v2

    .line 326
    if-eqz v2, :cond_148

    .line 327
    .line 328
    goto :goto_150

    .line 329
    :cond_148
    new-instance v0, Lct;

    .line 330
    .line 331
    const-string v1, "Tried to overwrite the destination, but failed to delete it."

    .line 332
    .line 333
    invoke-direct {v0, v15, v14, v1}, Lae;-><init>(Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V

    .line 334
    .line 335
    .line 336
    throw v0

    .line 337
    :cond_150
    :goto_150
    invoke-virtual {v15}, Ljava/io/File;->isDirectory()Z

    .line 338
    .line 339
    .line 340
    move-result v2

    .line 341
    if-eqz v2, :cond_165

    .line 342
    .line 343
    invoke-virtual {v14}, Ljava/io/File;->mkdirs()Z

    .line 344
    .line 345
    .line 346
    move-result v2

    .line 347
    if-eqz v2, :cond_15d

    .line 348
    .line 349
    goto :goto_185

    .line 350
    :cond_15d
    new-instance v0, Lae;

    .line 351
    .line 352
    const-string v1, "Failed to create target directory."

    .line 353
    .line 354
    invoke-direct {v0, v15, v14, v1}, Lae;-><init>(Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V

    .line 355
    .line 356
    .line 357
    throw v0

    .line 358
    :cond_165
    invoke-virtual {v14}, Ljava/io/File;->getParentFile()Ljava/io/File;

    .line 359
    .line 360
    .line 361
    move-result-object v2

    .line 362
    if-eqz v2, :cond_16e

    .line 363
    .line 364
    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    .line 365
    .line 366
    .line 367
    :cond_16e
    new-instance v2, Ljava/io/FileInputStream;

    .line 368
    .line 369
    invoke-direct {v2, v15}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    .line 370
    .line 371
    .line 372
    :try_start_173
    new-instance v4, Ljava/io/FileOutputStream;

    .line 373
    .line 374
    invoke-direct {v4, v14}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_178
    .catchall {:try_start_173 .. :try_end_178} :catchall_1a0

    .line 375
    .line 376
    .line 377
    const/16 v15, 0x2000

    .line 378
    .line 379
    :try_start_17a
    invoke-static {v2, v4, v15}, Lt51;->j(Ljava/io/InputStream;Ljava/io/OutputStream;I)J

    .line 380
    .line 381
    .line 382
    sget-object v15, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_17f
    .catchall {:try_start_17a .. :try_end_17f} :catchall_1a3

    .line 383
    .line 384
    :try_start_17f
    invoke-virtual {v4}, Ljava/io/FileOutputStream;->close()V
    :try_end_182
    .catchall {:try_start_17f .. :try_end_182} :catchall_1a0

    .line 385
    .line 386
    .line 387
    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    .line 388
    .line 389
    .line 390
    :goto_185
    iget-object v2, v0, Lzf;->b:Ljava/lang/Object;

    .line 391
    .line 392
    check-cast v2, Landroid/app/Activity;

    .line 393
    .line 394
    if-eqz v2, :cond_18c

    .line 395
    .line 396
    goto :goto_18d

    .line 397
    :cond_18c
    move-object v2, v1

    .line 398
    :goto_18d
    iget-object v4, v0, Lzf;->f:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast v4, Lk21;

    .line 401
    .line 402
    invoke-virtual {v4}, Lk21;->getValue()Ljava/lang/Object;

    .line 403
    .line 404
    .line 405
    move-result-object v4

    .line 406
    check-cast v4, Ljava/lang/String;

    .line 407
    .line 408
    invoke-static {v2, v4, v14}, Lft;->getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    .line 409
    .line 410
    .line 411
    move-result-object v2

    .line 412
    invoke-virtual {v5, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 413
    .line 414
    .line 415
    goto/16 :goto_f6

    .line 416
    .line 417
    :catchall_1a0
    move-exception v0

    .line 418
    move-object v1, v0

    .line 419
    goto :goto_1ab

    .line 420
    :catchall_1a3
    move-exception v0

    .line 421
    move-object v1, v0

    .line 422
    :try_start_1a5
    throw v1
    :try_end_1a6
    .catchall {:try_start_1a5 .. :try_end_1a6} :catchall_1a6

    .line 423
    :catchall_1a6
    move-exception v0

    .line 424
    :try_start_1a7
    invoke-static {v4, v1}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 425
    .line 426
    .line 427
    throw v0
    :try_end_1ab
    .catchall {:try_start_1a7 .. :try_end_1ab} :catchall_1a0

    .line 428
    :goto_1ab
    :try_start_1ab
    throw v1
    :try_end_1ac
    .catchall {:try_start_1ab .. :try_end_1ac} :catchall_1ac

    .line 429
    :catchall_1ac
    move-exception v0

    .line 430
    invoke-static {v2, v1}, Lt51;->f(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .line 431
    .line 432
    .line 433
    throw v0

    .line 434
    :cond_1b1
    new-instance v0, Lct;

    .line 435
    .line 436
    const-string v1, "The source file doesn\'t exist."

    .line 437
    .line 438
    invoke-direct {v0, v15, v3, v1}, Lae;-><init>(Ljava/io/File;Ljava/io/File;Ljava/lang/String;)V

    .line 439
    .line 440
    .line 441
    throw v0

    .line 442
    :cond_1b9
    new-instance v1, Ljava/io/IOException;

    .line 443
    .line 444
    invoke-virtual {v0}, Lzf;->e()Ljava/io/File;

    .line 445
    .line 446
    .line 447
    move-result-object v0

    .line 448
    invoke-virtual {v0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    .line 449
    .line 450
    .line 451
    move-result-object v0

    .line 452
    const-string v2, "Shared file can not be located in \'"

    .line 453
    .line 454
    const-string v3, "\'"

    .line 455
    .line 456
    invoke-static {v2, v0, v3}, Lzi0;->p(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 457
    .line 458
    .line 459
    move-result-object v0

    .line 460
    invoke-direct {v1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 461
    .line 462
    .line 463
    throw v1

    .line 464
    :cond_1cf
    move-object v3, v5

    .line 465
    :cond_1d0
    new-instance v2, Landroid/content/Intent;

    .line 466
    .line 467
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 468
    .line 469
    .line 470
    const-string v4, "android.intent.extra.TITLE"

    .line 471
    .line 472
    const-string v5, "android.intent.extra.SUBJECT"

    .line 473
    .line 474
    const-string v11, "android.intent.extra.TEXT"

    .line 475
    .line 476
    const-string v12, "android.intent.action.SEND"

    .line 477
    .line 478
    if-nez v3, :cond_214

    .line 479
    .line 480
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 481
    .line 482
    .line 483
    const-string v10, "text/plain"

    .line 484
    .line 485
    invoke-virtual {v2, v10}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 486
    .line 487
    .line 488
    if-nez v7, :cond_1ea

    .line 489
    .line 490
    goto :goto_1eb

    .line 491
    :cond_1ea
    move-object v6, v7

    .line 492
    :goto_1eb
    invoke-virtual {v2, v11, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 493
    .line 494
    .line 495
    if-eqz v8, :cond_1f9

    .line 496
    .line 497
    invoke-static {v8}, Ls01;->j0(Ljava/lang/CharSequence;)Z

    .line 498
    .line 499
    .line 500
    move-result v6

    .line 501
    if-eqz v6, :cond_1f7

    .line 502
    .line 503
    goto :goto_1f9

    .line 504
    :cond_1f7
    const/4 v6, 0x0

    .line 505
    goto :goto_1fa

    .line 506
    :cond_1f9
    :goto_1f9
    const/4 v6, 0x1

    .line 507
    :goto_1fa
    if-nez v6, :cond_1ff

    .line 508
    .line 509
    invoke-virtual {v2, v5, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 510
    .line 511
    .line 512
    :cond_1ff
    if-eqz v9, :cond_20b

    .line 513
    .line 514
    invoke-static {v9}, Ls01;->j0(Ljava/lang/CharSequence;)Z

    .line 515
    .line 516
    .line 517
    move-result v5

    .line 518
    if-eqz v5, :cond_208

    .line 519
    .line 520
    goto :goto_20b

    .line 521
    :cond_208
    const/16 v16, 0x0

    .line 522
    .line 523
    goto :goto_20d

    .line 524
    :cond_20b
    :goto_20b
    const/16 v16, 0x1

    .line 525
    .line 526
    :goto_20d
    if-nez v16, :cond_2f0

    .line 527
    .line 528
    invoke-virtual {v2, v4, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 529
    .line 530
    .line 531
    goto/16 :goto_2f0

    .line 532
    .line 533
    :cond_214
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 534
    .line 535
    .line 536
    move-result v7

    .line 537
    if-nez v7, :cond_360

    .line 538
    .line 539
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 540
    .line 541
    .line 542
    move-result v7

    .line 543
    const-string v13, "android.intent.extra.STREAM"

    .line 544
    .line 545
    const-string v14, "*/*"

    .line 546
    .line 547
    const/4 v15, 0x1

    .line 548
    if-ne v7, v15, :cond_24b

    .line 549
    .line 550
    if-eqz v10, :cond_230

    .line 551
    .line 552
    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    .line 553
    .line 554
    .line 555
    move-result v7

    .line 556
    if-eqz v7, :cond_22e

    .line 557
    .line 558
    goto :goto_230

    .line 559
    :cond_22e
    const/4 v7, 0x0

    .line 560
    goto :goto_231

    .line 561
    :cond_230
    :goto_230
    const/4 v7, 0x1

    .line 562
    :goto_231
    if-nez v7, :cond_23a

    .line 563
    .line 564
    invoke-static {v10}, Lfe;->R(Ljava/util/List;)Ljava/lang/Object;

    .line 565
    .line 566
    .line 567
    move-result-object v7

    .line 568
    move-object v14, v7

    .line 569
    check-cast v14, Ljava/lang/String;

    .line 570
    .line 571
    :cond_23a
    invoke-virtual {v2, v12}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 572
    .line 573
    .line 574
    invoke-virtual {v2, v14}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 575
    .line 576
    .line 577
    invoke-static {v3}, Lfe;->R(Ljava/util/List;)Ljava/lang/Object;

    .line 578
    .line 579
    .line 580
    move-result-object v7

    .line 581
    check-cast v7, Landroid/os/Parcelable;

    .line 582
    .line 583
    invoke-virtual {v2, v13, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    .line 584
    .line 585
    .line 586
    goto/16 :goto_2b9

    .line 587
    .line 588
    :cond_24b
    const-string v7, "android.intent.action.SEND_MULTIPLE"

    .line 589
    .line 590
    invoke-virtual {v2, v7}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 591
    .line 592
    .line 593
    if-eqz v10, :cond_2b0

    .line 594
    .line 595
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    .line 596
    .line 597
    .line 598
    move-result v7

    .line 599
    if-nez v7, :cond_2b0

    .line 600
    .line 601
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 602
    .line 603
    .line 604
    move-result v7

    .line 605
    const/4 v15, 0x1

    .line 606
    if-ne v7, v15, :cond_267

    .line 607
    .line 608
    invoke-static {v10}, Lfe;->R(Ljava/util/List;)Ljava/lang/Object;

    .line 609
    .line 610
    .line 611
    move-result-object v7

    .line 612
    move-object v14, v7

    .line 613
    check-cast v14, Ljava/lang/String;

    .line 614
    .line 615
    goto :goto_2b3

    .line 616
    :cond_267
    invoke-static {v10}, Lfe;->R(Ljava/util/List;)Ljava/lang/Object;

    .line 617
    .line 618
    .line 619
    move-result-object v7

    .line 620
    check-cast v7, Ljava/lang/String;

    .line 621
    .line 622
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 623
    .line 624
    .line 625
    move-result v12

    .line 626
    sub-int/2addr v12, v15

    .line 627
    if-gt v15, v12, :cond_2ae

    .line 628
    .line 629
    move-object/from16 p0, v14

    .line 630
    .line 631
    const/4 v15, 0x1

    .line 632
    :goto_277
    invoke-interface {v10, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 633
    .line 634
    .line 635
    move-result-object v14

    .line 636
    invoke-static {v7, v14}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 637
    .line 638
    .line 639
    move-result v14

    .line 640
    if-nez v14, :cond_2a9

    .line 641
    .line 642
    invoke-static {v7}, Lzf;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 643
    .line 644
    .line 645
    move-result-object v7

    .line 646
    invoke-interface {v10, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 647
    .line 648
    .line 649
    move-result-object v14

    .line 650
    check-cast v14, Ljava/lang/String;

    .line 651
    .line 652
    invoke-static {v14}, Lzf;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 653
    .line 654
    .line 655
    move-result-object v14

    .line 656
    invoke-virtual {v7, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 657
    .line 658
    .line 659
    move-result v7

    .line 660
    if-eqz v7, :cond_2a6

    .line 661
    .line 662
    invoke-interface {v10, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 663
    .line 664
    .line 665
    move-result-object v7

    .line 666
    check-cast v7, Ljava/lang/String;

    .line 667
    .line 668
    invoke-static {v7}, Lzf;->d(Ljava/lang/String;)Ljava/lang/String;

    .line 669
    .line 670
    .line 671
    move-result-object v7

    .line 672
    const-string v14, "/*"

    .line 673
    .line 674
    invoke-virtual {v7, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 675
    .line 676
    .line 677
    move-result-object v7

    .line 678
    goto :goto_2a9

    .line 679
    :cond_2a6
    :goto_2a6
    move-object/from16 v14, p0

    .line 680
    .line 681
    goto :goto_2b3

    .line 682
    :cond_2a9
    :goto_2a9
    if-eq v15, v12, :cond_2ae

    .line 683
    .line 684
    add-int/lit8 v15, v15, 0x1

    .line 685
    .line 686
    goto :goto_277

    .line 687
    :cond_2ae
    move-object v14, v7

    .line 688
    goto :goto_2b3

    .line 689
    :cond_2b0
    move-object/from16 p0, v14

    .line 690
    .line 691
    goto :goto_2a6

    .line 692
    :goto_2b3
    invoke-virtual {v2, v14}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    .line 693
    .line 694
    .line 695
    invoke-virtual {v2, v13, v3}, Landroid/content/Intent;->putParcelableArrayListExtra(Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;

    .line 696
    .line 697
    .line 698
    :goto_2b9
    if-eqz v6, :cond_2c4

    .line 699
    .line 700
    invoke-static {v6}, Ls01;->j0(Ljava/lang/CharSequence;)Z

    .line 701
    .line 702
    .line 703
    move-result v7

    .line 704
    if-eqz v7, :cond_2c2

    .line 705
    .line 706
    goto :goto_2c4

    .line 707
    :cond_2c2
    const/4 v7, 0x0

    .line 708
    goto :goto_2c5

    .line 709
    :cond_2c4
    :goto_2c4
    const/4 v7, 0x1

    .line 710
    :goto_2c5
    if-nez v7, :cond_2ca

    .line 711
    .line 712
    invoke-virtual {v2, v11, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 713
    .line 714
    .line 715
    :cond_2ca
    if-eqz v8, :cond_2d5

    .line 716
    .line 717
    invoke-static {v8}, Ls01;->j0(Ljava/lang/CharSequence;)Z

    .line 718
    .line 719
    .line 720
    move-result v6

    .line 721
    if-eqz v6, :cond_2d3

    .line 722
    .line 723
    goto :goto_2d5

    .line 724
    :cond_2d3
    const/4 v6, 0x0

    .line 725
    goto :goto_2d6

    .line 726
    :cond_2d5
    :goto_2d5
    const/4 v6, 0x1

    .line 727
    :goto_2d6
    if-nez v6, :cond_2db

    .line 728
    .line 729
    invoke-virtual {v2, v5, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 730
    .line 731
    .line 732
    :cond_2db
    if-eqz v9, :cond_2e6

    .line 733
    .line 734
    invoke-static {v9}, Ls01;->j0(Ljava/lang/CharSequence;)Z

    .line 735
    .line 736
    .line 737
    move-result v5

    .line 738
    if-eqz v5, :cond_2e4

    .line 739
    .line 740
    goto :goto_2e6

    .line 741
    :cond_2e4
    const/4 v5, 0x0

    .line 742
    goto :goto_2e7

    .line 743
    :cond_2e6
    :goto_2e6
    const/4 v5, 0x1

    .line 744
    :goto_2e7
    if-nez v5, :cond_2ec

    .line 745
    .line 746
    invoke-virtual {v2, v4, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 747
    .line 748
    .line 749
    :cond_2ec
    const/4 v15, 0x1

    .line 750
    invoke-virtual {v2, v15}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 751
    .line 752
    .line 753
    :cond_2f0
    :goto_2f0
    new-instance v4, Landroid/content/Intent;

    .line 754
    .line 755
    const-class v5, Ldev/fluttercommunity/plus/share/SharePlusPendingIntent;

    .line 756
    .line 757
    invoke-direct {v4, v1, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 758
    .line 759
    .line 760
    iget-object v5, v0, Lzf;->g:Ljava/lang/Object;

    .line 761
    .line 762
    check-cast v5, Lk21;

    .line 763
    .line 764
    invoke-virtual {v5}, Lk21;->getValue()Ljava/lang/Object;

    .line 765
    .line 766
    .line 767
    move-result-object v5

    .line 768
    check-cast v5, Ljava/lang/Number;

    .line 769
    .line 770
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 771
    .line 772
    .line 773
    move-result v5

    .line 774
    const/high16 v6, 0x8000000

    .line 775
    .line 776
    or-int/2addr v5, v6

    .line 777
    const/4 v6, 0x0

    .line 778
    invoke-static {v1, v6, v4, v5}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 779
    .line 780
    .line 781
    move-result-object v4

    .line 782
    invoke-virtual {v4}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    .line 783
    .line 784
    .line 785
    move-result-object v4

    .line 786
    invoke-static {v2, v9, v4}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;Landroid/content/IntentSender;)Landroid/content/Intent;

    .line 787
    .line 788
    .line 789
    move-result-object v2

    .line 790
    if-eqz v3, :cond_35c

    .line 791
    .line 792
    iget-object v4, v0, Lzf;->b:Ljava/lang/Object;

    .line 793
    .line 794
    check-cast v4, Landroid/app/Activity;

    .line 795
    .line 796
    if-eqz v4, :cond_31e

    .line 797
    .line 798
    goto :goto_31f

    .line 799
    :cond_31e
    move-object v4, v1

    .line 800
    :goto_31f
    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 801
    .line 802
    .line 803
    move-result-object v4

    .line 804
    const/high16 v5, 0x10000

    .line 805
    .line 806
    invoke-virtual {v4, v2, v5}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    .line 807
    .line 808
    .line 809
    move-result-object v4

    .line 810
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 811
    .line 812
    .line 813
    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 814
    .line 815
    .line 816
    move-result-object v4

    .line 817
    :cond_330
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 818
    .line 819
    .line 820
    move-result v5

    .line 821
    if-eqz v5, :cond_35c

    .line 822
    .line 823
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 824
    .line 825
    .line 826
    move-result-object v5

    .line 827
    check-cast v5, Landroid/content/pm/ResolveInfo;

    .line 828
    .line 829
    iget-object v5, v5, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    .line 830
    .line 831
    iget-object v5, v5, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    .line 832
    .line 833
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 834
    .line 835
    .line 836
    move-result v6

    .line 837
    const/4 v7, 0x0

    .line 838
    :goto_345
    if-ge v7, v6, :cond_330

    .line 839
    .line 840
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 841
    .line 842
    .line 843
    move-result-object v8

    .line 844
    add-int/lit8 v7, v7, 0x1

    .line 845
    .line 846
    check-cast v8, Landroid/net/Uri;

    .line 847
    .line 848
    iget-object v9, v0, Lzf;->b:Ljava/lang/Object;

    .line 849
    .line 850
    check-cast v9, Landroid/app/Activity;

    .line 851
    .line 852
    if-eqz v9, :cond_356

    .line 853
    .line 854
    goto :goto_357

    .line 855
    :cond_356
    move-object v9, v1

    .line 856
    :goto_357
    const/4 v10, 0x3

    .line 857
    invoke-virtual {v9, v5, v8, v10}, Landroid/content/Context;->grantUriPermission(Ljava/lang/String;Landroid/net/Uri;I)V

    .line 858
    .line 859
    .line 860
    goto :goto_345

    .line 861
    :cond_35c
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 862
    .line 863
    .line 864
    return-object v2

    .line 865
    :cond_360
    new-instance v0, Ljava/io/IOException;

    .line 866
    .line 867
    const-string v1, "Error sharing files: No files found"

    .line 868
    .line 869
    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .line 870
    .line 871
    .line 872
    throw v0

    .line 873
    :pswitch_368
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 874
    .line 875
    .line 876
    invoke-static/range {p1 .. p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 877
    .line 878
    .line 879
    iget-object v0, v0, Lnk;->k:Ljava/lang/Object;

    .line 880
    .line 881
    check-cast v0, Lhi;

    .line 882
    .line 883
    invoke-interface {v0}, Lhi;->b()Lyh;

    .line 884
    .line 885
    .line 886
    move-result-object v0

    .line 887
    sget-object v1, Lmp;->h:Lmp;

    .line 888
    .line 889
    invoke-interface {v0, v1}, Lyh;->q(Lxh;)Lwh;

    .line 890
    .line 891
    .line 892
    move-result-object v0

    .line 893
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 894
    .line 895
    .line 896
    check-cast v0, Lbi;

    .line 897
    .line 898
    invoke-static {}, Lsa;->a()Lue;

    .line 899
    .line 900
    .line 901
    move-result-object v2

    .line 902
    new-instance v4, Lpc;

    .line 903
    .line 904
    check-cast v5, Lsz;

    .line 905
    .line 906
    const/16 v6, 0x9

    .line 907
    .line 908
    invoke-direct {v4, v2, v5, v3, v6}, Lpc;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 909
    .line 910
    .line 911
    sget-object v5, Lsq;->f:Lsq;

    .line 912
    .line 913
    const/4 v15, 0x1

    .line 914
    invoke-static {v5, v0, v15}, Lrl;->D(Lyh;Lyh;Z)Lyh;

    .line 915
    .line 916
    .line 917
    move-result-object v5

    .line 918
    sget-object v6, Ltn;->a:Lam;

    .line 919
    .line 920
    if-eq v5, v6, :cond_3a3

    .line 921
    .line 922
    invoke-interface {v5, v1}, Lyh;->q(Lxh;)Lwh;

    .line 923
    .line 924
    .line 925
    move-result-object v1

    .line 926
    if-nez v1, :cond_3a3

    .line 927
    .line 928
    invoke-interface {v5, v6}, Lyh;->n(Lyh;)Lyh;

    .line 929
    .line 930
    .line 931
    move-result-object v5

    .line 932
    :cond_3a3
    new-instance v1, Lvz0;

    .line 933
    .line 934
    invoke-direct {v1, v5, v15}, Lh;-><init>(Lyh;Z)V

    .line 935
    .line 936
    .line 937
    sget-object v5, Lji;->i:Lji;

    .line 938
    .line 939
    invoke-virtual {v1, v5, v1, v4}, Lh;->d0(Lji;Lh;Lsz;)V

    .line 940
    .line 941
    .line 942
    :catch_3ad
    invoke-virtual {v2}, Ly50;->M()Z

    .line 943
    .line 944
    .line 945
    move-result v1

    .line 946
    if-nez v1, :cond_3be

    .line 947
    .line 948
    :try_start_3b3
    new-instance v1, Lp8;

    .line 949
    .line 950
    const/4 v4, 0x5

    .line 951
    invoke-direct {v1, v2, v3, v4}, Lp8;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 952
    .line 953
    .line 954
    invoke-static {v0, v1}, Lr30;->T(Lyh;Lsz;)Ljava/lang/Object;

    .line 955
    .line 956
    .line 957
    move-result-object v3
    :try_end_3bd
    .catch Ljava/lang/InterruptedException; {:try_start_3b3 .. :try_end_3bd} :catch_3ad

    .line 958
    goto :goto_3db

    .line 959
    :cond_3be
    sget-object v0, Ly50;->f:Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;

    .line 960
    .line 961
    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 962
    .line 963
    .line 964
    move-result-object v0

    .line 965
    instance-of v1, v0, Le30;

    .line 966
    .line 967
    if-nez v1, :cond_3d6

    .line 968
    .line 969
    instance-of v1, v0, Lxe;

    .line 970
    .line 971
    if-nez v1, :cond_3d1

    .line 972
    .line 973
    invoke-static {v0}, Ln40;->Y(Ljava/lang/Object;)Ljava/lang/Object;

    .line 974
    .line 975
    .line 976
    move-result-object v3

    .line 977
    goto :goto_3db

    .line 978
    :cond_3d1
    check-cast v0, Lxe;

    .line 979
    .line 980
    iget-object v0, v0, Lxe;->a:Ljava/lang/Throwable;

    .line 981
    .line 982
    throw v0

    .line 983
    :cond_3d6
    const-string v0, "This job has not completed yet"

    .line 984
    .line 985
    invoke-static {v0}, Lm0;->g(Ljava/lang/String;)V

    .line 986
    .line 987
    .line 988
    :goto_3db
    return-object v3

    .line 989
    :pswitch_3dc
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 990
    .line 991
    .line 992
    invoke-static/range {p1 .. p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 993
    .line 994
    .line 995
    iget-object v0, v0, Lnk;->k:Ljava/lang/Object;

    .line 996
    .line 997
    check-cast v0, Ld80;

    .line 998
    .line 999
    invoke-virtual {v0}, Ld80;->a()Landroid/content/SharedPreferences;

    .line 1000
    .line 1001
    .line 1002
    move-result-object v0

    .line 1003
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    .line 1004
    .line 1005
    .line 1006
    move-result-object v0

    .line 1007
    check-cast v5, Ljava/lang/String;

    .line 1008
    .line 1009
    invoke-interface {v0, v5}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    .line 1010
    .line 1011
    .line 1012
    move-result-object v0

    .line 1013
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    .line 1014
    .line 1015
    .line 1016
    move-result v0

    .line 1017
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v0

    .line 1021
    return-object v0

    .line 1022
    :pswitch_3fd
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 1023
    .line 1024
    .line 1025
    invoke-static/range {p1 .. p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 1026
    .line 1027
    .line 1028
    iget-object v0, v0, Lnk;->k:Ljava/lang/Object;

    .line 1029
    .line 1030
    check-cast v0, Lpf0;

    .line 1031
    .line 1032
    sget-object v1, Lz00;->g:Lwl0;

    .line 1033
    .line 1034
    invoke-virtual {v0, v1}, Lpf0;->c(Lwl0;)Ljava/lang/Object;

    .line 1035
    .line 1036
    .line 1037
    move-result-object v1

    .line 1038
    check-cast v1, Ljava/util/Set;

    .line 1039
    .line 1040
    if-nez v1, :cond_413

    .line 1041
    .line 1042
    goto/16 :goto_4d0

    .line 1043
    .line 1044
    :cond_413
    move-object v2, v1

    .line 1045
    check-cast v2, Ljava/lang/Iterable;

    .line 1046
    .line 1047
    check-cast v5, Ljava/util/Set;

    .line 1048
    .line 1049
    new-instance v3, Ljava/util/ArrayList;

    .line 1050
    .line 1051
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1052
    .line 1053
    .line 1054
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1055
    .line 1056
    .line 1057
    move-result-object v4

    .line 1058
    :cond_421
    :goto_421
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1059
    .line 1060
    .line 1061
    move-result v6

    .line 1062
    if-eqz v6, :cond_438

    .line 1063
    .line 1064
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1065
    .line 1066
    .line 1067
    move-result-object v6

    .line 1068
    move-object v7, v6

    .line 1069
    check-cast v7, Ljava/lang/String;

    .line 1070
    .line 1071
    invoke-interface {v5, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1072
    .line 1073
    .line 1074
    move-result v7

    .line 1075
    if-nez v7, :cond_421

    .line 1076
    .line 1077
    invoke-virtual {v3, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1078
    .line 1079
    .line 1080
    goto :goto_421

    .line 1081
    :cond_438
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1082
    .line 1083
    .line 1084
    move-result v4

    .line 1085
    if-eqz v4, :cond_440

    .line 1086
    .line 1087
    goto/16 :goto_4d0

    .line 1088
    .line 1089
    :cond_440
    new-instance v4, Lpf0;

    .line 1090
    .line 1091
    invoke-virtual {v0}, Lpf0;->a()Ljava/util/Map;

    .line 1092
    .line 1093
    .line 1094
    move-result-object v0

    .line 1095
    new-instance v5, Ljava/util/LinkedHashMap;

    .line 1096
    .line 1097
    invoke-direct {v5, v0}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    .line 1098
    .line 1099
    .line 1100
    const/4 v6, 0x0

    .line 1101
    invoke-direct {v4, v5, v6}, Lpf0;-><init>(Ljava/util/LinkedHashMap;Z)V

    .line 1102
    .line 1103
    .line 1104
    sget-object v0, Lz00;->g:Lwl0;

    .line 1105
    .line 1106
    invoke-virtual {v3}, Ljava/util/ArrayList;->isEmpty()Z

    .line 1107
    .line 1108
    .line 1109
    move-result v5

    .line 1110
    if-eqz v5, :cond_45c

    .line 1111
    .line 1112
    invoke-static {v2}, Lfe;->h0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1113
    .line 1114
    .line 1115
    move-result-object v1

    .line 1116
    goto :goto_48b

    .line 1117
    :cond_45c
    instance-of v5, v3, Ljava/util/Set;

    .line 1118
    .line 1119
    if-eqz v5, :cond_480

    .line 1120
    .line 1121
    new-instance v1, Ljava/util/LinkedHashSet;

    .line 1122
    .line 1123
    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 1124
    .line 1125
    .line 1126
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1127
    .line 1128
    .line 1129
    move-result-object v2

    .line 1130
    :cond_469
    :goto_469
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1131
    .line 1132
    .line 1133
    move-result v5

    .line 1134
    if-eqz v5, :cond_48b

    .line 1135
    .line 1136
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1137
    .line 1138
    .line 1139
    move-result-object v5

    .line 1140
    move-object v7, v3

    .line 1141
    check-cast v7, Ljava/util/Set;

    .line 1142
    .line 1143
    invoke-interface {v7, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 1144
    .line 1145
    .line 1146
    move-result v7

    .line 1147
    if-nez v7, :cond_469

    .line 1148
    .line 1149
    invoke-interface {v1, v5}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .line 1150
    .line 1151
    .line 1152
    goto :goto_469

    .line 1153
    :cond_480
    new-instance v2, Ljava/util/LinkedHashSet;

    .line 1154
    .line 1155
    check-cast v1, Ljava/util/Collection;

    .line 1156
    .line 1157
    invoke-direct {v2, v1}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    .line 1158
    .line 1159
    .line 1160
    invoke-virtual {v2, v3}, Ljava/util/AbstractCollection;->removeAll(Ljava/util/Collection;)Z

    .line 1161
    .line 1162
    .line 1163
    move-object v1, v2

    .line 1164
    :cond_48b
    :goto_48b
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1165
    .line 1166
    .line 1167
    invoke-virtual {v4, v0, v1}, Lpf0;->d(Lwl0;Ljava/lang/Object;)V

    .line 1168
    .line 1169
    .line 1170
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 1171
    .line 1172
    .line 1173
    move-result v0

    .line 1174
    move v2, v6

    .line 1175
    :goto_496
    if-ge v2, v0, :cond_4c1

    .line 1176
    .line 1177
    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1178
    .line 1179
    .line 1180
    move-result-object v1

    .line 1181
    add-int/lit8 v2, v2, 0x1

    .line 1182
    .line 1183
    check-cast v1, Ljava/lang/String;

    .line 1184
    .line 1185
    sget-object v5, Lz00;->d:Lx00;

    .line 1186
    .line 1187
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1188
    .line 1189
    .line 1190
    new-instance v5, Ljava/lang/StringBuilder;

    .line 1191
    .line 1192
    const-string v6, "provider:"

    .line 1193
    .line 1194
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1195
    .line 1196
    .line 1197
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1198
    .line 1199
    .line 1200
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1201
    .line 1202
    .line 1203
    move-result-object v1

    .line 1204
    new-instance v5, Lwl0;

    .line 1205
    .line 1206
    invoke-direct {v5, v1}, Lwl0;-><init>(Ljava/lang/String;)V

    .line 1207
    .line 1208
    .line 1209
    invoke-virtual {v4}, Lpf0;->b()V

    .line 1210
    .line 1211
    .line 1212
    iget-object v1, v4, Lpf0;->a:Ljava/util/LinkedHashMap;

    .line 1213
    .line 1214
    invoke-interface {v1, v5}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1215
    .line 1216
    .line 1217
    goto :goto_496

    .line 1218
    :cond_4c1
    new-instance v0, Lpf0;

    .line 1219
    .line 1220
    invoke-virtual {v4}, Lpf0;->a()Ljava/util/Map;

    .line 1221
    .line 1222
    .line 1223
    move-result-object v1

    .line 1224
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 1225
    .line 1226
    invoke-direct {v2, v1}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    .line 1227
    .line 1228
    .line 1229
    const/4 v15, 0x1

    .line 1230
    invoke-direct {v0, v2, v15}, Lpf0;-><init>(Ljava/util/LinkedHashMap;Z)V

    .line 1231
    .line 1232
    .line 1233
    :goto_4d0
    return-object v0

    .line 1234
    :pswitch_4d1
    const/4 v6, 0x0

    .line 1235
    const/4 v15, 0x1

    .line 1236
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 1237
    .line 1238
    .line 1239
    invoke-static/range {p1 .. p1}, Lkotlin/a;->b(Ljava/lang/Object;)V

    .line 1240
    .line 1241
    .line 1242
    iget-object v0, v0, Lnk;->k:Ljava/lang/Object;

    .line 1243
    .line 1244
    check-cast v0, Lc01;

    .line 1245
    .line 1246
    instance-of v1, v0, Lbk;

    .line 1247
    .line 1248
    if-eqz v1, :cond_4ef

    .line 1249
    .line 1250
    check-cast v0, Lbk;

    .line 1251
    .line 1252
    iget v0, v0, Lc01;->a:I

    .line 1253
    .line 1254
    check-cast v5, Lc01;

    .line 1255
    .line 1256
    check-cast v5, Lbk;

    .line 1257
    .line 1258
    iget v1, v5, Lc01;->a:I

    .line 1259
    .line 1260
    if-gt v0, v1, :cond_4ef

    .line 1261
    .line 1262
    move v2, v15

    .line 1263
    goto :goto_4f0

    .line 1264
    :cond_4ef
    move v2, v6

    .line 1265
    :goto_4f0
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 1266
    .line 1267
    .line 1268
    move-result-object v0

    .line 1269
    return-object v0

    .line 1270
    nop

    .line 1271
    :pswitch_data_4f6
    .packed-switch 0x0
        :pswitch_4d1
        :pswitch_3fd
        :pswitch_3dc
        :pswitch_368
        :pswitch_47
    .end packed-switch
.end method
