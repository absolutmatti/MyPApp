###### Class defpackage.i (i)
.class public abstract Li;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lwh;


# instance fields
.field public final f:Lxh;


# direct methods
.method public constructor <init>(Lxh;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Li;->f:Lxh;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final getKey()Lxh;
    .registers 1

    .line 1
    iget-object p0, p0, Li;->f:Lxh;

    .line 2
    .line 3
    return-object p0
.end method

.method public final k(Ljava/lang/Object;Lsz;)Ljava/lang/Object;
    .registers 3

    .line 1
    invoke-interface {p2, p1, p0}, Lsz;->e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public final bridge n(Lyh;)Lyh;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lsa;->M(Lwh;Lyh;)Lyh;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge q(Lxh;)Lwh;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lsa;->B(Lwh;Lxh;)Lwh;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public bridge u(Lxh;)Lyh;
    .registers 2

    .line 1
    invoke-static {p0, p1}, Lsa;->K(Lwh;Lxh;)Lyh;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
