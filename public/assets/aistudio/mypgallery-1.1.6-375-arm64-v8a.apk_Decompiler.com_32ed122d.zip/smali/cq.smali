###### Class defpackage.cq (cq)
.class public final Lcq;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lo80;


# instance fields
.field public final synthetic a:Li80;


# direct methods
.method public constructor <init>(Landroidx/emoji2/text/EmojiCompatInitializer;Li80;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p2, p0, Lcq;->a:Li80;

    .line 5
    .line 6
    return-void
.end method
