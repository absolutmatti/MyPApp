###### Class defpackage.no0 (no0)
.class public final Lno0;
.super Ls60;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lsz;


# instance fields
.field public final synthetic g:Lqo0;


# direct methods
.method public constructor <init>(Lqo0;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lno0;->g:Lqo0;

    .line 2
    .line 3
    const/4 p1, 0x2

    .line 4
    invoke-direct {p0, p1}, Ls60;-><init>(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method


# virtual methods
.method public final e(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 21

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    check-cast v0, Ljava/util/Set;

    .line 4
    .line 5
    move-object/from16 v1, p2

    .line 6
    .line 7
    check-cast v1, Lwf0;

    .line 8
    .line 9
    move-object/from16 v1, p0

    .line 10
    .line 11
    iget-object v1, v1, Lno0;->g:Lqo0;

    .line 12
    .line 13
    iget-object v2, v1, Lqo0;->b:Ljava/lang/Object;

    .line 14
    .line 15
    monitor-enter v2

    .line 16
    :try_start_f
    iget-object v3, v1, Lqo0;->r:Le01;

    .line 17
    .line 18
    invoke-virtual {v3}, Le01;->h()Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    check-cast v3, Llo0;

    .line 23
    .line 24
    sget-object v4, Llo0;->j:Llo0;

    .line 25
    .line 26
    invoke-virtual {v3, v4}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 27
    .line 28
    .line 29
    move-result v3

    .line 30
    if-ltz v3, :cond_b4

    .line 31
    .line 32
    iget-object v3, v1, Lqo0;->g:Lvf0;

    .line 33
    .line 34
    instance-of v4, v0, Lyr0;

    .line 35
    .line 36
    const/4 v5, 0x0

    .line 37
    const/4 v6, 0x1

    .line 38
    if-eqz v4, :cond_85

    .line 39
    .line 40
    check-cast v0, Lyr0;

    .line 41
    .line 42
    iget-object v0, v0, Lyr0;->f:Lvf0;

    .line 43
    .line 44
    iget-object v4, v0, Lvf0;->b:[Ljava/lang/Object;

    .line 45
    .line 46
    iget-object v0, v0, Lvf0;->a:[J

    .line 47
    .line 48
    array-length v7, v0

    .line 49
    add-int/lit8 v7, v7, -0x2

    .line 50
    .line 51
    if-ltz v7, :cond_af

    .line 52
    .line 53
    move v8, v5

    .line 54
    :goto_35
    aget-wide v9, v0, v8

    .line 55
    .line 56
    not-long v11, v9

    .line 57
    const/4 v13, 0x7

    .line 58
    shl-long/2addr v11, v13

    .line 59
    and-long/2addr v11, v9

    .line 60
    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    and-long/2addr v11, v13

    .line 66
    cmp-long v11, v11, v13

    .line 67
    .line 68
    if-eqz v11, :cond_80

    .line 69
    .line 70
    sub-int v11, v8, v7

    .line 71
    .line 72
    not-int v11, v11

    .line 73
    ushr-int/lit8 v11, v11, 0x1f

    .line 74
    .line 75
    const/16 v12, 0x8

    .line 76
    .line 77
    rsub-int/lit8 v11, v11, 0x8

    .line 78
    .line 79
    move v13, v5

    .line 80
    :goto_4f
    if-ge v13, v11, :cond_7e

    .line 81
    .line 82
    const-wide/16 v14, 0xff

    .line 83
    .line 84
    and-long/2addr v14, v9

    .line 85
    const-wide/16 v16, 0x80

    .line 86
    .line 87
    cmp-long v14, v14, v16

    .line 88
    .line 89
    if-gez v14, :cond_7a

    .line 90
    .line 91
    shl-int/lit8 v14, v8, 0x3

    .line 92
    .line 93
    add-int/2addr v14, v13

    .line 94
    aget-object v14, v4, v14

    .line 95
    .line 96
    instance-of v15, v14, Lnj0;

    .line 97
    .line 98
    if-eqz v15, :cond_77

    .line 99
    .line 100
    move-object v15, v14

    .line 101
    check-cast v15, Lnj0;

    .line 102
    .line 103
    iget-object v15, v15, Lnj0;->f:Ll9;

    .line 104
    .line 105
    invoke-virtual {v15}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 106
    .line 107
    .line 108
    move-result v15

    .line 109
    and-int/2addr v15, v6

    .line 110
    if-eqz v15, :cond_71

    .line 111
    .line 112
    move v15, v6

    .line 113
    goto :goto_72

    .line 114
    :cond_71
    move v15, v5

    .line 115
    :goto_72
    if-nez v15, :cond_77

    .line 116
    .line 117
    goto :goto_7a

    .line 118
    :catchall_75
    move-exception v0

    .line 119
    goto :goto_c6

    .line 120
    :cond_77
    invoke-virtual {v3, v14}, Lvf0;->a(Ljava/lang/Object;)Z

    .line 121
    .line 122
    .line 123
    :cond_7a
    :goto_7a
    shr-long/2addr v9, v12

    .line 124
    add-int/lit8 v13, v13, 0x1

    .line 125
    .line 126
    goto :goto_4f

    .line 127
    :cond_7e
    if-ne v11, v12, :cond_af

    .line 128
    .line 129
    :cond_80
    if-eq v8, v7, :cond_af

    .line 130
    .line 131
    add-int/lit8 v8, v8, 0x1

    .line 132
    .line 133
    goto :goto_35

    .line 134
    :cond_85
    check-cast v0, Ljava/lang/Iterable;

    .line 135
    .line 136
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 137
    .line 138
    .line 139
    move-result-object v0

    .line 140
    :goto_8b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 141
    .line 142
    .line 143
    move-result v4

    .line 144
    if-eqz v4, :cond_af

    .line 145
    .line 146
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 147
    .line 148
    .line 149
    move-result-object v4

    .line 150
    instance-of v7, v4, Lnj0;

    .line 151
    .line 152
    if-eqz v7, :cond_ab

    .line 153
    .line 154
    move-object v7, v4

    .line 155
    check-cast v7, Lnj0;

    .line 156
    .line 157
    iget-object v7, v7, Lnj0;->f:Ll9;

    .line 158
    .line 159
    invoke-virtual {v7}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    .line 160
    .line 161
    .line 162
    move-result v7

    .line 163
    and-int/2addr v7, v6

    .line 164
    if-eqz v7, :cond_a7

    .line 165
    .line 166
    move v7, v6

    .line 167
    goto :goto_a8

    .line 168
    :cond_a7
    move v7, v5

    .line 169
    :goto_a8
    if-nez v7, :cond_ab

    .line 170
    .line 171
    goto :goto_8b

    .line 172
    :cond_ab
    invoke-virtual {v3, v4}, Lvf0;->a(Ljava/lang/Object;)Z

    .line 173
    .line 174
    .line 175
    goto :goto_8b

    .line 176
    :cond_af
    invoke-virtual {v1}, Lqo0;->d()Lec;

    .line 177
    .line 178
    .line 179
    move-result-object v0
    :try_end_b3
    .catchall {:try_start_f .. :try_end_b3} :catchall_75

    .line 180
    goto :goto_b5

    .line 181
    :cond_b4
    const/4 v0, 0x0

    .line 182
    :goto_b5
    monitor-exit v2

    .line 183
    if-eqz v0, :cond_c3

    .line 184
    .line 185
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 186
    .line 187
    invoke-static {v1}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v1

    .line 191
    check-cast v0, Lgc;

    .line 192
    .line 193
    invoke-virtual {v0, v1}, Lgc;->resumeWith(Ljava/lang/Object;)V

    .line 194
    .line 195
    .line 196
    :cond_c3
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 197
    .line 198
    return-object v0

    .line 199
    :goto_c6
    monitor-exit v2

    .line 200
    throw v0
.end method
