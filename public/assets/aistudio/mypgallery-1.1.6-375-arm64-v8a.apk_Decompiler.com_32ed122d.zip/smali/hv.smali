###### Class defpackage.hv (hv)
.class public final Lhv;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Liv;


# instance fields
.field public final synthetic a:Ljv;


# direct methods
.method public constructor <init>(Ljv;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lhv;->a:Ljv;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 1

    .line 1
    return-void
.end method

.method public final b()V
    .registers 6

    .line 1
    iget-object p0, p0, Lhv;->a:Ljv;

    .line 2
    .line 3
    iget-object v0, p0, Ljv;->u:Ljava/util/HashSet;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    if-eqz v1, :cond_18

    .line 14
    .line 15
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    check-cast v1, Liv;

    .line 20
    .line 21
    invoke-interface {v1}, Liv;->b()V

    .line 22
    .line 23
    .line 24
    goto :goto_8

    .line 25
    :cond_18
    iget-object v0, p0, Ljv;->r:Lio/flutter/plugin/platform/c;

    .line 26
    .line 27
    iget-object v1, v0, Lio/flutter/plugin/platform/c;->q:Landroid/util/SparseArray;

    .line 28
    .line 29
    :goto_1c
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    const/4 v3, 0x0

    .line 34
    if-lez v2, :cond_2d

    .line 35
    .line 36
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->keyAt(I)I

    .line 37
    .line 38
    .line 39
    move-result v2

    .line 40
    iget-object v3, v0, Lio/flutter/plugin/platform/c;->B:Lio/flutter/plugin/platform/b;

    .line 41
    .line 42
    invoke-virtual {v3, v2}, Lio/flutter/plugin/platform/b;->n(I)V

    .line 43
    .line 44
    .line 45
    goto :goto_1c

    .line 46
    :cond_2d
    iget-object v0, p0, Ljv;->s:Lal0;

    .line 47
    .line 48
    iget-object v1, v0, Lal0;->n:Landroid/util/SparseArray;

    .line 49
    .line 50
    :goto_31
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-lez v2, :cond_41

    .line 55
    .line 56
    invoke-virtual {v1, v3}, Landroid/util/SparseArray;->keyAt(I)I

    .line 57
    .line 58
    .line 59
    move-result v2

    .line 60
    iget-object v4, v0, Lal0;->v:Lnw;

    .line 61
    .line 62
    invoke-virtual {v4, v2}, Lnw;->j(I)V

    .line 63
    .line 64
    .line 65
    goto :goto_31

    .line 66
    :cond_41
    iget-object p0, p0, Ljv;->j:Lr5;

    .line 67
    .line 68
    const/4 v0, 0x0

    .line 69
    iput-object v0, p0, Lr5;->f:Ljava/lang/Object;

    .line 70
    .line 71
    return-void
.end method
