###### Class defpackage.bh1 (bh1)
.class public final Lbh1;
.super Lch1;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final transient h:I

.field public final transient i:I

.field public final synthetic j:Lch1;


# direct methods
.method public constructor <init>(Lch1;II)V
    .registers 4

    .line 1
    iput-object p1, p0, Lbh1;->j:Lch1;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/util/AbstractCollection;-><init>()V

    .line 4
    .line 5
    .line 6
    iput p2, p0, Lbh1;->h:I

    .line 7
    .line 8
    iput p3, p0, Lbh1;->i:I

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final f()[Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Lbh1;->j:Lch1;

    .line 2
    .line 3
    invoke-virtual {p0}, Lxg1;->f()[Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method

.method public final g()I
    .registers 2

    .line 1
    iget-object v0, p0, Lbh1;->j:Lch1;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxg1;->g()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget p0, p0, Lbh1;->h:I

    .line 8
    .line 9
    add-int/2addr v0, p0

    .line 10
    return v0
.end method

.method public final get(I)Ljava/lang/Object;
    .registers 3

    .line 1
    iget v0, p0, Lbh1;->i:I

    .line 2
    .line 3
    invoke-static {p1, v0}, Lr30;->h0(II)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lbh1;->h:I

    .line 7
    .line 8
    add-int/2addr p1, v0

    .line 9
    iget-object p0, p0, Lbh1;->j:Lch1;

    .line 10
    .line 11
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object p0

    .line 15
    return-object p0
.end method

.method public final h()I
    .registers 3

    .line 1
    iget-object v0, p0, Lbh1;->j:Lch1;

    .line 2
    .line 3
    invoke-virtual {v0}, Lxg1;->g()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    iget v1, p0, Lbh1;->h:I

    .line 8
    .line 9
    add-int/2addr v0, v1

    .line 10
    iget p0, p0, Lbh1;->i:I

    .line 11
    .line 12
    add-int/2addr v0, p0

    .line 13
    return v0
.end method

.method public final k(II)Lch1;
    .registers 4

    .line 1
    iget v0, p0, Lbh1;->i:I

    .line 2
    .line 3
    invoke-static {p1, p2, v0}, Lr30;->i0(III)V

    .line 4
    .line 5
    .line 6
    iget v0, p0, Lbh1;->h:I

    .line 7
    .line 8
    add-int/2addr p1, v0

    .line 9
    add-int/2addr p2, v0

    .line 10
    iget-object p0, p0, Lbh1;->j:Lch1;

    .line 11
    .line 12
    invoke-virtual {p0, p1, p2}, Lch1;->k(II)Lch1;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method

.method public final size()I
    .registers 1

    .line 1
    iget p0, p0, Lbh1;->i:I

    .line 2
    .line 3
    return p0
.end method

.method public final bridge synthetic subList(II)Ljava/util/List;
    .registers 3

    .line 1
    invoke-virtual {p0, p1, p2}, Lbh1;->k(II)Lch1;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
