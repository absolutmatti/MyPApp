###### Class defpackage.sh0 (sh0)
.class public final Lsh0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:Lb9;

.field public c:Liy;

.field public final d:Landroid/window/OnBackInvokedCallback;

.field public e:Landroid/window/OnBackInvokedDispatcher;

.field public f:Z

.field public g:Z


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lsh0;->a:Ljava/lang/Runnable;

    .line 5
    .line 6
    new-instance p1, Lb9;

    .line 7
    .line 8
    invoke-direct {p1}, Lb9;-><init>()V

    .line 9
    .line 10
    .line 11
    iput-object p1, p0, Lsh0;->b:Lb9;

    .line 12
    .line 13
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 14
    .line 15
    const/16 v0, 0x21

    .line 16
    .line 17
    if-lt p1, v0, :cond_41

    .line 18
    .line 19
    const/16 v0, 0x22

    .line 20
    .line 21
    if-lt p1, v0, :cond_33

    .line 22
    .line 23
    new-instance p1, Lkh0;

    .line 24
    .line 25
    const/4 v0, 0x0

    .line 26
    invoke-direct {p1, p0, v0}, Lkh0;-><init>(Lsh0;I)V

    .line 27
    .line 28
    .line 29
    new-instance v1, Lkh0;

    .line 30
    .line 31
    const/4 v2, 0x1

    .line 32
    invoke-direct {v1, p0, v2}, Lkh0;-><init>(Lsh0;I)V

    .line 33
    .line 34
    .line 35
    new-instance v3, Llh0;

    .line 36
    .line 37
    invoke-direct {v3, p0, v0}, Llh0;-><init>(Lsh0;I)V

    .line 38
    .line 39
    .line 40
    new-instance v0, Llh0;

    .line 41
    .line 42
    invoke-direct {v0, p0, v2}, Llh0;-><init>(Lsh0;I)V

    .line 43
    .line 44
    .line 45
    sget-object v2, Loh0;->a:Loh0;

    .line 46
    .line 47
    invoke-virtual {v2, p1, v1, v3, v0}, Loh0;->a(Lqz;Lqz;Loz;Loz;)Landroid/window/OnBackInvokedCallback;

    .line 48
    .line 49
    .line 50
    move-result-object p1

    .line 51
    goto :goto_3f

    .line 52
    :cond_33
    new-instance p1, Llh0;

    .line 53
    .line 54
    const/4 v0, 0x2

    .line 55
    invoke-direct {p1, p0, v0}, Llh0;-><init>(Lsh0;I)V

    .line 56
    .line 57
    .line 58
    sget-object v0, Lmh0;->a:Lmh0;

    .line 59
    .line 60
    invoke-virtual {v0, p1}, Lmh0;->a(Loz;)Landroid/window/OnBackInvokedCallback;

    .line 61
    .line 62
    .line 63
    move-result-object p1

    .line 64
    :goto_3f
    iput-object p1, p0, Lsh0;->d:Landroid/window/OnBackInvokedCallback;

    .line 65
    .line 66
    :cond_41
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 5

    .line 1
    iget-object v0, p0, Lsh0;->c:Liy;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_25

    .line 5
    .line 6
    iget-object v0, p0, Lsh0;->b:Lb9;

    .line 7
    .line 8
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    invoke-interface {v0, v2}, Ljava/util/List;->listIterator(I)Ljava/util/ListIterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :cond_f
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_21

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    move-object v3, v2

    .line 27
    check-cast v3, Liy;

    .line 28
    .line 29
    iget-boolean v3, v3, Liy;->a:Z

    .line 30
    .line 31
    if-eqz v3, :cond_f

    .line 32
    .line 33
    goto :goto_22

    .line 34
    :cond_21
    move-object v2, v1

    .line 35
    :goto_22
    move-object v0, v2

    .line 36
    check-cast v0, Liy;

    .line 37
    .line 38
    :cond_25
    iput-object v1, p0, Lsh0;->c:Liy;

    .line 39
    .line 40
    if-eqz v0, :cond_2c

    .line 41
    .line 42
    invoke-virtual {v0}, Liy;->a()V

    .line 43
    .line 44
    .line 45
    :cond_2c
    return-void
.end method

.method public final b()V
    .registers 14

    .line 1
    iget-object v0, p0, Lsh0;->c:Liy;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-nez v0, :cond_25

    .line 5
    .line 6
    iget-object v0, p0, Lsh0;->b:Lb9;

    .line 7
    .line 8
    invoke-virtual {v0}, Lb9;->f()I

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    invoke-virtual {v0, v2}, Ljava/util/AbstractList;->listIterator(I)Ljava/util/ListIterator;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    :cond_f
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 17
    .line 18
    .line 19
    move-result v2

    .line 20
    if-eqz v2, :cond_21

    .line 21
    .line 22
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 23
    .line 24
    .line 25
    move-result-object v2

    .line 26
    move-object v3, v2

    .line 27
    check-cast v3, Liy;

    .line 28
    .line 29
    iget-boolean v3, v3, Liy;->a:Z

    .line 30
    .line 31
    if-eqz v3, :cond_f

    .line 32
    .line 33
    goto :goto_22

    .line 34
    :cond_21
    move-object v2, v1

    .line 35
    :goto_22
    move-object v0, v2

    .line 36
    check-cast v0, Liy;

    .line 37
    .line 38
    :cond_25
    iput-object v1, p0, Lsh0;->c:Liy;

    .line 39
    .line 40
    if-eqz v0, :cond_187

    .line 41
    .line 42
    iget-object p0, v0, Liy;->d:Lqy;

    .line 43
    .line 44
    const/4 v0, 0x3

    .line 45
    invoke-static {v0}, Lqy;->J(I)Z

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    const-string v3, "FragmentManager"

    .line 50
    .line 51
    if-eqz v2, :cond_45

    .line 52
    .line 53
    new-instance v2, Ljava/lang/StringBuilder;

    .line 54
    .line 55
    const-string v4, "handleOnBackPressed. PREDICTIVE_BACK = true fragment manager "

    .line 56
    .line 57
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 58
    .line 59
    .line 60
    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v2

    .line 67
    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 68
    .line 69
    .line 70
    :cond_45
    iget-object v2, p0, Lqy;->i:Liy;

    .line 71
    .line 72
    iget-object v4, p0, Lqy;->m:Ljava/util/ArrayList;

    .line 73
    .line 74
    const/4 v5, 0x1

    .line 75
    invoke-virtual {p0, v5}, Lqy;->A(Z)Z

    .line 76
    .line 77
    .line 78
    iget-object v6, p0, Lqy;->h:Lr9;

    .line 79
    .line 80
    if-eqz v6, :cond_163

    .line 81
    .line 82
    invoke-virtual {v4}, Ljava/util/ArrayList;->isEmpty()Z

    .line 83
    .line 84
    .line 85
    move-result v6

    .line 86
    const/4 v7, 0x0

    .line 87
    if-nez v6, :cond_88

    .line 88
    .line 89
    new-instance v6, Ljava/util/LinkedHashSet;

    .line 90
    .line 91
    iget-object v8, p0, Lqy;->h:Lr9;

    .line 92
    .line 93
    invoke-static {v8}, Lqy;->E(Lr9;)Ljava/util/HashSet;

    .line 94
    .line 95
    .line 96
    move-result-object v8

    .line 97
    invoke-direct {v6, v8}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    .line 98
    .line 99
    .line 100
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 101
    .line 102
    .line 103
    move-result v8

    .line 104
    move v9, v7

    .line 105
    :goto_68
    if-ge v9, v8, :cond_88

    .line 106
    .line 107
    invoke-virtual {v4, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 108
    .line 109
    .line 110
    move-result-object v10

    .line 111
    add-int/lit8 v9, v9, 0x1

    .line 112
    .line 113
    if-nez v10, :cond_84

    .line 114
    .line 115
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 116
    .line 117
    .line 118
    move-result-object v10

    .line 119
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 120
    .line 121
    .line 122
    move-result v11

    .line 123
    if-nez v11, :cond_7d

    .line 124
    .line 125
    goto :goto_68

    .line 126
    :cond_7d
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 127
    .line 128
    .line 129
    move-result-object p0

    .line 130
    check-cast p0, Lvx;

    .line 131
    .line 132
    throw v1

    .line 133
    :cond_84
    invoke-static {}, Lm0;->o()V

    .line 134
    .line 135
    .line 136
    return-void

    .line 137
    :cond_88
    iget-object v4, p0, Lqy;->h:Lr9;

    .line 138
    .line 139
    iget-object v4, v4, Lr9;->a:Ljava/util/ArrayList;

    .line 140
    .line 141
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 142
    .line 143
    .line 144
    move-result v6

    .line 145
    move v8, v7

    .line 146
    :cond_91
    :goto_91
    if-ge v8, v6, :cond_a2

    .line 147
    .line 148
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 149
    .line 150
    .line 151
    move-result-object v9

    .line 152
    add-int/lit8 v8, v8, 0x1

    .line 153
    .line 154
    check-cast v9, Lbz;

    .line 155
    .line 156
    iget-object v9, v9, Lbz;->b:Lvx;

    .line 157
    .line 158
    if-eqz v9, :cond_91

    .line 159
    .line 160
    iput-boolean v7, v9, Lvx;->r:Z

    .line 161
    .line 162
    goto :goto_91

    .line 163
    :cond_a2
    new-instance v4, Ljava/util/ArrayList;

    .line 164
    .line 165
    iget-object v6, p0, Lqy;->h:Lr9;

    .line 166
    .line 167
    invoke-static {v6}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    .line 168
    .line 169
    .line 170
    move-result-object v6

    .line 171
    invoke-direct {v4, v6}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {p0, v7, v5, v4}, Lqy;->f(IILjava/util/ArrayList;)Ljava/util/HashSet;

    .line 175
    .line 176
    .line 177
    move-result-object v4

    .line 178
    invoke-virtual {v4}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 179
    .line 180
    .line 181
    move-result-object v4

    .line 182
    :goto_b5
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 183
    .line 184
    .line 185
    move-result v5

    .line 186
    if-eqz v5, :cond_137

    .line 187
    .line 188
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object v5

    .line 192
    check-cast v5, Ljm;

    .line 193
    .line 194
    iget-object v6, v5, Ljm;->c:Ljava/util/ArrayList;

    .line 195
    .line 196
    invoke-static {v0}, Lqy;->J(I)Z

    .line 197
    .line 198
    .line 199
    move-result v8

    .line 200
    if-eqz v8, :cond_ce

    .line 201
    .line 202
    const-string v8, "SpecialEffectsController: Completing Back "

    .line 203
    .line 204
    invoke-static {v3, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 205
    .line 206
    .line 207
    :cond_ce
    invoke-virtual {v5, v6}, Ljm;->f(Ljava/util/List;)V

    .line 208
    .line 209
    .line 210
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 211
    .line 212
    .line 213
    new-instance v8, Ljava/util/ArrayList;

    .line 214
    .line 215
    invoke-direct {v8}, Ljava/util/ArrayList;-><init>()V

    .line 216
    .line 217
    .line 218
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 219
    .line 220
    .line 221
    move-result-object v9

    .line 222
    :goto_dd
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    .line 223
    .line 224
    .line 225
    move-result v10

    .line 226
    if-eqz v10, :cond_f0

    .line 227
    .line 228
    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 229
    .line 230
    .line 231
    move-result-object v10

    .line 232
    check-cast v10, Ljz0;

    .line 233
    .line 234
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 235
    .line 236
    .line 237
    invoke-static {v8, v1}, Lke;->N(Ljava/util/ArrayList;Ljava/lang/Iterable;)V

    .line 238
    .line 239
    .line 240
    goto :goto_dd

    .line 241
    :cond_f0
    invoke-static {v8}, Lfe;->h0(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 242
    .line 243
    .line 244
    move-result-object v8

    .line 245
    check-cast v8, Ljava/lang/Iterable;

    .line 246
    .line 247
    invoke-static {v8}, Lfe;->e0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 248
    .line 249
    .line 250
    move-result-object v8

    .line 251
    invoke-interface {v8}, Ljava/util/List;->size()I

    .line 252
    .line 253
    .line 254
    move-result v9

    .line 255
    move v10, v7

    .line 256
    :goto_ff
    if-ge v10, v9, :cond_10f

    .line 257
    .line 258
    invoke-interface {v8, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 259
    .line 260
    .line 261
    move-result-object v11

    .line 262
    check-cast v11, Liz0;

    .line 263
    .line 264
    iget-object v12, v5, Ljm;->a:Landroid/view/ViewGroup;

    .line 265
    .line 266
    invoke-virtual {v11, v12}, Liz0;->a(Landroid/view/ViewGroup;)V

    .line 267
    .line 268
    .line 269
    add-int/lit8 v10, v10, 0x1

    .line 270
    .line 271
    goto :goto_ff

    .line 272
    :cond_10f
    invoke-interface {v6}, Ljava/util/List;->size()I

    .line 273
    .line 274
    .line 275
    move-result v8

    .line 276
    move v9, v7

    .line 277
    :goto_114
    if-ge v9, v8, :cond_122

    .line 278
    .line 279
    invoke-interface {v6, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 280
    .line 281
    .line 282
    move-result-object v10

    .line 283
    check-cast v10, Ljz0;

    .line 284
    .line 285
    invoke-virtual {v5, v10}, Ljm;->a(Ljz0;)V

    .line 286
    .line 287
    .line 288
    add-int/lit8 v9, v9, 0x1

    .line 289
    .line 290
    goto :goto_114

    .line 291
    :cond_122
    invoke-static {v6}, Lfe;->e0(Ljava/lang/Iterable;)Ljava/util/List;

    .line 292
    .line 293
    .line 294
    move-result-object v5

    .line 295
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 296
    .line 297
    .line 298
    move-result v6

    .line 299
    if-gtz v6, :cond_12d

    .line 300
    .line 301
    goto :goto_b5

    .line 302
    :cond_12d
    invoke-interface {v5, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 303
    .line 304
    .line 305
    move-result-object p0

    .line 306
    check-cast p0, Ljz0;

    .line 307
    .line 308
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 309
    .line 310
    .line 311
    throw v1

    .line 312
    :cond_137
    iput-object v1, p0, Lqy;->h:Lr9;

    .line 313
    .line 314
    invoke-virtual {p0}, Lqy;->e0()V

    .line 315
    .line 316
    .line 317
    invoke-static {v0}, Lqy;->J(I)Z

    .line 318
    .line 319
    .line 320
    move-result v0

    .line 321
    if-eqz v0, :cond_162

    .line 322
    .line 323
    const-string v0, "Op is being set to null"

    .line 324
    .line 325
    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 326
    .line 327
    .line 328
    new-instance v0, Ljava/lang/StringBuilder;

    .line 329
    .line 330
    const-string v1, "OnBackPressedCallback enabled="

    .line 331
    .line 332
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    iget-boolean v1, v2, Liy;->a:Z

    .line 336
    .line 337
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 338
    .line 339
    .line 340
    const-string v1, " for  FragmentManager "

    .line 341
    .line 342
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 346
    .line 347
    .line 348
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 349
    .line 350
    .line 351
    move-result-object p0

    .line 352
    invoke-static {v3, p0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 353
    .line 354
    .line 355
    :cond_162
    return-void

    .line 356
    :cond_163
    iget-boolean v1, v2, Liy;->a:Z

    .line 357
    .line 358
    if-eqz v1, :cond_176

    .line 359
    .line 360
    invoke-static {v0}, Lqy;->J(I)Z

    .line 361
    .line 362
    .line 363
    move-result v0

    .line 364
    if-eqz v0, :cond_172

    .line 365
    .line 366
    const-string v0, "Calling popBackStackImmediate via onBackPressed callback"

    .line 367
    .line 368
    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 369
    .line 370
    .line 371
    :cond_172
    invoke-virtual {p0}, Lqy;->Q()Z

    .line 372
    .line 373
    .line 374
    return-void

    .line 375
    :cond_176
    invoke-static {v0}, Lqy;->J(I)Z

    .line 376
    .line 377
    .line 378
    move-result v0

    .line 379
    if-eqz v0, :cond_181

    .line 380
    .line 381
    const-string v0, "Calling onBackPressed via onBackPressed callback"

    .line 382
    .line 383
    invoke-static {v3, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 384
    .line 385
    .line 386
    :cond_181
    iget-object p0, p0, Lqy;->g:Lsh0;

    .line 387
    .line 388
    invoke-virtual {p0}, Lsh0;->b()V

    .line 389
    .line 390
    .line 391
    return-void

    .line 392
    :cond_187
    iget-object p0, p0, Lsh0;->a:Ljava/lang/Runnable;

    .line 393
    .line 394
    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    .line 395
    .line 396
    .line 397
    return-void
.end method

.method public final c(Z)V
    .registers 7

    .line 1
    iget-object v0, p0, Lsh0;->e:Landroid/window/OnBackInvokedDispatcher;

    .line 2
    .line 3
    if-eqz v0, :cond_23

    .line 4
    .line 5
    iget-object v1, p0, Lsh0;->d:Landroid/window/OnBackInvokedCallback;

    .line 6
    .line 7
    if-eqz v1, :cond_23

    .line 8
    .line 9
    const/4 v2, 0x0

    .line 10
    sget-object v3, Lmh0;->a:Lmh0;

    .line 11
    .line 12
    if-eqz p1, :cond_18

    .line 13
    .line 14
    iget-boolean v4, p0, Lsh0;->f:Z

    .line 15
    .line 16
    if-nez v4, :cond_18

    .line 17
    .line 18
    invoke-virtual {v3, v0, v2, v1}, Lmh0;->b(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    const/4 p1, 0x1

    .line 22
    iput-boolean p1, p0, Lsh0;->f:Z

    .line 23
    .line 24
    return-void

    .line 25
    :cond_18
    if-nez p1, :cond_23

    .line 26
    .line 27
    iget-boolean p1, p0, Lsh0;->f:Z

    .line 28
    .line 29
    if-eqz p1, :cond_23

    .line 30
    .line 31
    invoke-virtual {v3, v0, v1}, Lmh0;->c(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 32
    .line 33
    .line 34
    iput-boolean v2, p0, Lsh0;->f:Z

    .line 35
    .line 36
    :cond_23
    return-void
.end method

.method public final d()V
    .registers 5

    .line 1
    iget-boolean v0, p0, Lsh0;->g:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    iget-object v2, p0, Lsh0;->b:Lb9;

    .line 5
    .line 6
    if-eqz v2, :cond_e

    .line 7
    .line 8
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 9
    .line 10
    .line 11
    move-result v3

    .line 12
    if-eqz v3, :cond_e

    .line 13
    .line 14
    goto :goto_23

    .line 15
    :cond_e
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v2

    .line 19
    :cond_12
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v3

    .line 23
    if-eqz v3, :cond_23

    .line 24
    .line 25
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v3

    .line 29
    check-cast v3, Liy;

    .line 30
    .line 31
    iget-boolean v3, v3, Liy;->a:Z

    .line 32
    .line 33
    if-eqz v3, :cond_12

    .line 34
    .line 35
    const/4 v1, 0x1

    .line 36
    :cond_23
    :goto_23
    iput-boolean v1, p0, Lsh0;->g:Z

    .line 37
    .line 38
    if-eq v1, v0, :cond_30

    .line 39
    .line 40
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 41
    .line 42
    const/16 v2, 0x21

    .line 43
    .line 44
    if-lt v0, v2, :cond_30

    .line 45
    .line 46
    invoke-virtual {p0, v1}, Lsh0;->c(Z)V

    .line 47
    .line 48
    .line 49
    :cond_30
    return-void
.end method
