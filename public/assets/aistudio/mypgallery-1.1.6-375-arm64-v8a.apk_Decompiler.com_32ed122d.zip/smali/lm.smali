###### Class defpackage.lm (lm)
.class public final Llm;
.super Lfo0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final h:Ljava/lang/Object;

.field public final i:Ljava/util/concurrent/ExecutorService;

.field public volatile j:Landroid/os/Handler;


# direct methods
.method public constructor <init>()V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    new-instance v0, Ljava/lang/Object;

    .line 5
    .line 6
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 7
    .line 8
    .line 9
    iput-object v0, p0, Llm;->h:Ljava/lang/Object;

    .line 10
    .line 11
    new-instance v0, Lkm;

    .line 12
    .line 13
    invoke-direct {v0}, Lkm;-><init>()V

    .line 14
    .line 15
    .line 16
    const/4 v1, 0x4

    .line 17
    invoke-static {v1, v0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, Llm;->i:Ljava/util/concurrent/ExecutorService;

    .line 22
    .line 23
    return-void
.end method
