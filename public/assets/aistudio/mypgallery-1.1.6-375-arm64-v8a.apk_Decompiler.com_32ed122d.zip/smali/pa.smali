###### Class defpackage.pa (pa)
.class public abstract Lpa;
.super Lw;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/RandomAccess;
.implements Lgm0;


# virtual methods
.method public abstract g(Z)V
.end method

.method public abstract h(I)V
.end method
