###### Class defpackage.d10 (d10)
.class public interface abstract Ld10;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# virtual methods
.method public abstract a(Lqz;)Z
.end method

.method public abstract b(Ljava/lang/Object;Lsz;)Ljava/lang/Object;
.end method

.method public abstract c(Lzh;)Z
.end method

.method public d(Ld10;)Ld10;
    .registers 3

    .line 1
    sget-object v0, Lb10;->a:Lb10;

    .line 2
    .line 3
    if-ne p1, v0, :cond_5

    .line 4
    .line 5
    return-object p0

    .line 6
    :cond_5
    new-instance v0, Lse;

    .line 7
    .line 8
    invoke-direct {v0, p0, p1}, Lse;-><init>(Ld10;Ld10;)V

    .line 9
    .line 10
    .line 11
    return-object v0
.end method
