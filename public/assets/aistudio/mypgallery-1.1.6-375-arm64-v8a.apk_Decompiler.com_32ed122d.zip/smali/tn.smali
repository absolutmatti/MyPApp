###### Class defpackage.tn (tn)
.class public abstract Ltn;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Lam;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Lam;->i:Lam;

    .line 2
    .line 3
    sput-object v0, Ltn;->a:Lam;

    .line 4
    .line 5
    sget v0, Lc61;->h:I

    .line 6
    .line 7
    return-void
.end method
