###### Class defpackage.y81 (y81)
.class public final synthetic Ly81;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lyh0;


# virtual methods
.method public final a(Lmh;)Lmh;
    .registers 2

    .line 1
    return-object p1
.end method
