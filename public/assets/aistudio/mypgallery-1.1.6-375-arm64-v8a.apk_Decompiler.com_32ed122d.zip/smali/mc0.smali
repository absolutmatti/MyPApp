###### Class defpackage.mc0 (mc0)
.class public Lmc0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lfw;
.implements Lre0;


# instance fields
.field public f:Lte0;

.field public g:Ld8;


# virtual methods
.method public final onAttachedToEngine(Lew;)V
    .registers 5

    .line 1
    new-instance v0, Lte0;

    .line 2
    .line 3
    iget-object v1, p1, Lew;->c:Lla;

    .line 4
    .line 5
    const-string v2, "com.alexmercerind/media_kit_video"

    .line 6
    .line 7
    invoke-direct {v0, v1, v2}, Lte0;-><init>(Lla;Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Lmc0;->f:Lte0;

    .line 11
    .line 12
    invoke-virtual {v0, p0}, Lte0;->b(Lre0;)V

    .line 13
    .line 14
    .line 15
    new-instance v0, Ld8;

    .line 16
    .line 17
    iget-object p1, p1, Lew;->d:Lio/flutter/embedding/engine/renderer/e;

    .line 18
    .line 19
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 20
    .line 21
    .line 22
    new-instance v1, Ljava/util/HashMap;

    .line 23
    .line 24
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 25
    .line 26
    .line 27
    iput-object v1, v0, Ld8;->f:Ljava/lang/Object;

    .line 28
    .line 29
    new-instance v1, Ljava/lang/Object;

    .line 30
    .line 31
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 32
    .line 33
    .line 34
    iput-object v1, v0, Ld8;->h:Ljava/lang/Object;

    .line 35
    .line 36
    iput-object p1, v0, Ld8;->g:Ljava/lang/Object;

    .line 37
    .line 38
    iput-object v0, p0, Lmc0;->g:Ld8;

    .line 39
    .line 40
    return-void
.end method

.method public final onDetachedFromEngine(Lew;)V
    .registers 2

    .line 1
    iget-object p0, p0, Lmc0;->f:Lte0;

    .line 2
    .line 3
    const/4 p1, 0x0

    .line 4
    invoke-virtual {p0, p1}, Lte0;->b(Lre0;)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public final onMethodCall(Loe0;Lse0;)V
    .registers 11

    .line 1
    iget-object v0, p1, Loe0;->a:Ljava/lang/String;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x1

    .line 11
    const/4 v3, 0x0

    .line 12
    const/4 v4, -0x1

    .line 13
    sparse-switch v1, :sswitch_data_234

    .line 14
    .line 15
    .line 16
    goto :goto_3b

    .line 17
    :sswitch_10
    const-string v1, "VideoOutputManager.Create"

    .line 18
    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    if-nez v0, :cond_19

    .line 24
    .line 25
    goto :goto_3b

    .line 26
    :cond_19
    const/4 v4, 0x3

    .line 27
    goto :goto_3b

    .line 28
    :sswitch_1b
    const-string v1, "Utils.IsEmulator"

    .line 29
    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 31
    .line 32
    .line 33
    move-result v0

    .line 34
    if-nez v0, :cond_24

    .line 35
    .line 36
    goto :goto_3b

    .line 37
    :cond_24
    const/4 v4, 0x2

    .line 38
    goto :goto_3b

    .line 39
    :sswitch_26
    const-string v1, "VideoOutputManager.Dispose"

    .line 40
    .line 41
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 42
    .line 43
    .line 44
    move-result v0

    .line 45
    if-nez v0, :cond_2f

    .line 46
    .line 47
    goto :goto_3b

    .line 48
    :cond_2f
    move v4, v2

    .line 49
    goto :goto_3b

    .line 50
    :sswitch_31
    const-string v1, "VideoOutputManager.SetSurfaceSize"

    .line 51
    .line 52
    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 53
    .line 54
    .line 55
    move-result v0

    .line 56
    if-nez v0, :cond_3a

    .line 57
    .line 58
    goto :goto_3b

    .line 59
    :cond_3a
    move v4, v3

    .line 60
    :goto_3b
    const/4 v0, 0x0

    .line 61
    packed-switch v4, :pswitch_data_246

    .line 62
    .line 63
    .line 64
    check-cast p2, Lqe0;

    .line 65
    .line 66
    invoke-virtual {p2}, Lqe0;->notImplemented()V

    .line 67
    .line 68
    .line 69
    return-void

    .line 70
    :pswitch_45
    const-string v1, "handle"

    .line 71
    .line 72
    invoke-virtual {p1, v1}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    check-cast v1, Ljava/lang/String;

    .line 77
    .line 78
    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 79
    .line 80
    .line 81
    move-result-wide v4

    .line 82
    const-string v1, "enableSurfaceProducer"

    .line 83
    .line 84
    invoke-virtual {p1, v1}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 85
    .line 86
    .line 87
    move-result-object p1

    .line 88
    check-cast p1, Ljava/lang/Boolean;

    .line 89
    .line 90
    iget-object v1, p0, Lmc0;->g:Ld8;

    .line 91
    .line 92
    if-eqz p1, :cond_65

    .line 93
    .line 94
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 95
    .line 96
    .line 97
    move-result p1

    .line 98
    if-eqz p1, :cond_64

    .line 99
    .line 100
    goto :goto_65

    .line 101
    :cond_64
    move v2, v3

    .line 102
    :cond_65
    :goto_65
    new-instance p1, Llc0;

    .line 103
    .line 104
    invoke-direct {p1, p0, v4, v5}, Llc0;-><init>(Lmc0;J)V

    .line 105
    .line 106
    .line 107
    const-string p0, "com.alexmercerind.media_kit_video.VideoOutputManager.create: "

    .line 108
    .line 109
    iget-object v6, v1, Ld8;->h:Ljava/lang/Object;

    .line 110
    .line 111
    monitor-enter v6

    .line 112
    :try_start_6f
    const-string v3, "VideoOutputManager"

    .line 113
    .line 114
    sget-object v7, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 115
    .line 116
    new-instance v7, Ljava/lang/StringBuilder;

    .line 117
    .line 118
    invoke-direct {v7, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v7, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 122
    .line 123
    .line 124
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 125
    .line 126
    .line 127
    move-result-object p0

    .line 128
    invoke-static {v3, p0}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 129
    .line 130
    .line 131
    iget-object p0, v1, Ld8;->f:Ljava/lang/Object;

    .line 132
    .line 133
    check-cast p0, Ljava/util/HashMap;

    .line 134
    .line 135
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 136
    .line 137
    .line 138
    move-result-object v3

    .line 139
    invoke-virtual {p0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 140
    .line 141
    .line 142
    move-result p0

    .line 143
    if-nez p0, :cond_a7

    .line 144
    .line 145
    new-instance p0, Lx81;

    .line 146
    .line 147
    iget-object v3, v1, Ld8;->g:Ljava/lang/Object;

    .line 148
    .line 149
    check-cast v3, Lio/flutter/embedding/engine/renderer/e;

    .line 150
    .line 151
    invoke-direct {p0, v3, v2, p1}, Lx81;-><init>(Lio/flutter/embedding/engine/renderer/e;ZLlc0;)V

    .line 152
    .line 153
    .line 154
    iget-object p1, v1, Ld8;->f:Ljava/lang/Object;

    .line 155
    .line 156
    check-cast p1, Ljava/util/HashMap;

    .line 157
    .line 158
    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 159
    .line 160
    .line 161
    move-result-object v1

    .line 162
    invoke-virtual {p1, v1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 163
    .line 164
    .line 165
    goto :goto_a7

    .line 166
    :catchall_a5
    move-exception p0

    .line 167
    goto :goto_ae

    .line 168
    :cond_a7
    :goto_a7
    monitor-exit v6
    :try_end_a8
    .catchall {:try_start_6f .. :try_end_a8} :catchall_a5

    .line 169
    check-cast p2, Lqe0;

    .line 170
    .line 171
    invoke-virtual {p2, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 172
    .line 173
    .line 174
    return-void

    .line 175
    :goto_ae
    :try_start_ae
    monitor-exit v6
    :try_end_af
    .catchall {:try_start_ae .. :try_end_af} :catchall_a5

    .line 176
    throw p0

    .line 177
    :pswitch_b0
    const-string p0, "google_sdk"

    .line 178
    .line 179
    const-string p1, "generic"

    .line 180
    .line 181
    :try_start_b4
    sget-object v0, Landroid/os/Build;->BRAND:Ljava/lang/String;

    .line 182
    .line 183
    invoke-virtual {v0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 184
    .line 185
    .line 186
    move-result v0

    .line 187
    if-eqz v0, :cond_c8

    .line 188
    .line 189
    sget-object v0, Landroid/os/Build;->DEVICE:Ljava/lang/String;

    .line 190
    .line 191
    invoke-virtual {v0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 192
    .line 193
    .line 194
    move-result v0

    .line 195
    if-nez v0, :cond_14f

    .line 196
    .line 197
    goto :goto_c8

    .line 198
    :catchall_c5
    move-exception p0

    .line 199
    goto/16 :goto_147

    .line 200
    .line 201
    :cond_c8
    :goto_c8
    sget-object v0, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    .line 202
    .line 203
    invoke-virtual {v0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 204
    .line 205
    .line 206
    move-result p1

    .line 207
    if-nez p1, :cond_14f

    .line 208
    .line 209
    const-string p1, "unknown"

    .line 210
    .line 211
    invoke-virtual {v0, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    .line 212
    .line 213
    .line 214
    move-result p1

    .line 215
    if-nez p1, :cond_14f

    .line 216
    .line 217
    sget-object p1, Landroid/os/Build;->HARDWARE:Ljava/lang/String;

    .line 218
    .line 219
    const-string v0, "goldfish"

    .line 220
    .line 221
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 222
    .line 223
    .line 224
    move-result v0

    .line 225
    if-nez v0, :cond_14f

    .line 226
    .line 227
    const-string v0, "ranchu"

    .line 228
    .line 229
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 230
    .line 231
    .line 232
    move-result p1

    .line 233
    if-nez p1, :cond_14f

    .line 234
    .line 235
    sget-object p1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    .line 236
    .line 237
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 238
    .line 239
    .line 240
    move-result v0

    .line 241
    if-nez v0, :cond_14f

    .line 242
    .line 243
    const-string v0, "Emulator"

    .line 244
    .line 245
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 246
    .line 247
    .line 248
    move-result v0

    .line 249
    if-nez v0, :cond_14f

    .line 250
    .line 251
    const-string v0, "Android SDK built for x86"

    .line 252
    .line 253
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 254
    .line 255
    .line 256
    move-result p1

    .line 257
    if-nez p1, :cond_14f

    .line 258
    .line 259
    sget-object p1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    .line 260
    .line 261
    const-string v0, "Genymotion"

    .line 262
    .line 263
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 264
    .line 265
    .line 266
    move-result p1

    .line 267
    if-nez p1, :cond_14f

    .line 268
    .line 269
    sget-object p1, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    .line 270
    .line 271
    const-string v0, "sdk_google"

    .line 272
    .line 273
    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 274
    .line 275
    .line 276
    move-result v0

    .line 277
    if-nez v0, :cond_14f

    .line 278
    .line 279
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 280
    .line 281
    .line 282
    move-result p0

    .line 283
    if-nez p0, :cond_14f

    .line 284
    .line 285
    const-string p0, "sdk"

    .line 286
    .line 287
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 288
    .line 289
    .line 290
    move-result p0

    .line 291
    if-nez p0, :cond_14f

    .line 292
    .line 293
    const-string p0, "sdk_x86"

    .line 294
    .line 295
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 296
    .line 297
    .line 298
    move-result p0

    .line 299
    if-nez p0, :cond_14f

    .line 300
    .line 301
    const-string p0, "vbox86p"

    .line 302
    .line 303
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 304
    .line 305
    .line 306
    move-result p0

    .line 307
    if-nez p0, :cond_14f

    .line 308
    .line 309
    const-string p0, "emulator"

    .line 310
    .line 311
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 312
    .line 313
    .line 314
    move-result p0

    .line 315
    if-nez p0, :cond_14f

    .line 316
    .line 317
    const-string p0, "simulator"

    .line 318
    .line 319
    invoke-virtual {p1, p0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 320
    .line 321
    .line 322
    move-result p0
    :try_end_142
    .catchall {:try_start_b4 .. :try_end_142} :catchall_c5

    .line 323
    if-eqz p0, :cond_145

    .line 324
    .line 325
    goto :goto_14f

    .line 326
    :cond_145
    :goto_145
    move v2, v3

    .line 327
    goto :goto_14f

    .line 328
    :goto_147
    const-string p1, "Utils"

    .line 329
    .line 330
    const-string v0, "isEmulator"

    .line 331
    .line 332
    invoke-static {p1, v0, p0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 333
    .line 334
    .line 335
    goto :goto_145

    .line 336
    :cond_14f
    :goto_14f
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 337
    .line 338
    .line 339
    move-result-object p0

    .line 340
    check-cast p2, Lqe0;

    .line 341
    .line 342
    invoke-virtual {p2, p0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 343
    .line 344
    .line 345
    return-void

    .line 346
    :pswitch_159
    const-string v1, "handle"

    .line 347
    .line 348
    invoke-virtual {p1, v1}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 349
    .line 350
    .line 351
    move-result-object p1

    .line 352
    check-cast p1, Ljava/lang/String;

    .line 353
    .line 354
    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 355
    .line 356
    .line 357
    move-result-wide v1

    .line 358
    iget-object p0, p0, Lmc0;->g:Ld8;

    .line 359
    .line 360
    const-string p1, "com.alexmercerind.media_kit_video.VideoOutputManager.dispose: "

    .line 361
    .line 362
    iget-object v3, p0, Ld8;->h:Ljava/lang/Object;

    .line 363
    .line 364
    monitor-enter v3

    .line 365
    :try_start_16c
    const-string v4, "VideoOutputManager"

    .line 366
    .line 367
    sget-object v5, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 368
    .line 369
    new-instance v5, Ljava/lang/StringBuilder;

    .line 370
    .line 371
    invoke-direct {v5, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 372
    .line 373
    .line 374
    invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 375
    .line 376
    .line 377
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 378
    .line 379
    .line 380
    move-result-object p1

    .line 381
    invoke-static {v4, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 382
    .line 383
    .line 384
    iget-object p1, p0, Ld8;->f:Ljava/lang/Object;

    .line 385
    .line 386
    check-cast p1, Ljava/util/HashMap;

    .line 387
    .line 388
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 389
    .line 390
    .line 391
    move-result-object v4

    .line 392
    invoke-virtual {p1, v4}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 393
    .line 394
    .line 395
    move-result p1

    .line 396
    if-eqz p1, :cond_1af

    .line 397
    .line 398
    iget-object p1, p0, Ld8;->f:Ljava/lang/Object;

    .line 399
    .line 400
    check-cast p1, Ljava/util/HashMap;

    .line 401
    .line 402
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 403
    .line 404
    .line 405
    move-result-object v4

    .line 406
    invoke-virtual {p1, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 407
    .line 408
    .line 409
    move-result-object p1

    .line 410
    check-cast p1, Lx81;

    .line 411
    .line 412
    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 413
    .line 414
    .line 415
    invoke-virtual {p1}, Lx81;->b()V

    .line 416
    .line 417
    .line 418
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 419
    .line 420
    check-cast p0, Ljava/util/HashMap;

    .line 421
    .line 422
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 423
    .line 424
    .line 425
    move-result-object p1

    .line 426
    invoke-virtual {p0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 427
    .line 428
    .line 429
    goto :goto_1af

    .line 430
    :catchall_1ad
    move-exception p0

    .line 431
    goto :goto_1b6

    .line 432
    :cond_1af
    :goto_1af
    monitor-exit v3
    :try_end_1b0
    .catchall {:try_start_16c .. :try_end_1b0} :catchall_1ad

    .line 433
    check-cast p2, Lqe0;

    .line 434
    .line 435
    invoke-virtual {p2, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 436
    .line 437
    .line 438
    return-void

    .line 439
    :goto_1b6
    :try_start_1b6
    monitor-exit v3
    :try_end_1b7
    .catchall {:try_start_1b6 .. :try_end_1b7} :catchall_1ad

    .line 440
    throw p0

    .line 441
    :pswitch_1b8
    const-string v1, "handle"

    .line 442
    .line 443
    invoke-virtual {p1, v1}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v1

    .line 447
    check-cast v1, Ljava/lang/String;

    .line 448
    .line 449
    invoke-static {v1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    .line 450
    .line 451
    .line 452
    move-result-wide v1

    .line 453
    const-string v3, "width"

    .line 454
    .line 455
    invoke-virtual {p1, v3}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 456
    .line 457
    .line 458
    move-result-object v3

    .line 459
    check-cast v3, Ljava/lang/String;

    .line 460
    .line 461
    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 462
    .line 463
    .line 464
    move-result v3

    .line 465
    const-string v4, "height"

    .line 466
    .line 467
    invoke-virtual {p1, v4}, Loe0;->a(Ljava/lang/String;)Ljava/lang/Object;

    .line 468
    .line 469
    .line 470
    move-result-object p1

    .line 471
    check-cast p1, Ljava/lang/String;

    .line 472
    .line 473
    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    .line 474
    .line 475
    .line 476
    move-result p1

    .line 477
    iget-object p0, p0, Lmc0;->g:Ld8;

    .line 478
    .line 479
    const-string v4, "com.alexmercerind.media_kit_video.VideoOutputManager.setSurfaceSize: "

    .line 480
    .line 481
    iget-object v5, p0, Ld8;->h:Ljava/lang/Object;

    .line 482
    .line 483
    monitor-enter v5

    .line 484
    :try_start_1e3
    const-string v6, "VideoOutputManager"

    .line 485
    .line 486
    sget-object v7, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 487
    .line 488
    new-instance v7, Ljava/lang/StringBuilder;

    .line 489
    .line 490
    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 491
    .line 492
    .line 493
    invoke-virtual {v7, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 494
    .line 495
    .line 496
    const-string v4, " "

    .line 497
    .line 498
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 499
    .line 500
    .line 501
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 502
    .line 503
    .line 504
    const-string v4, " "

    .line 505
    .line 506
    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 507
    .line 508
    .line 509
    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 510
    .line 511
    .line 512
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 513
    .line 514
    .line 515
    move-result-object v4

    .line 516
    invoke-static {v6, v4}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 517
    .line 518
    .line 519
    iget-object v4, p0, Ld8;->f:Ljava/lang/Object;

    .line 520
    .line 521
    check-cast v4, Ljava/util/HashMap;

    .line 522
    .line 523
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 524
    .line 525
    .line 526
    move-result-object v6

    .line 527
    invoke-virtual {v4, v6}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 528
    .line 529
    .line 530
    move-result v4

    .line 531
    if-eqz v4, :cond_22b

    .line 532
    .line 533
    iget-object p0, p0, Ld8;->f:Ljava/lang/Object;

    .line 534
    .line 535
    check-cast p0, Ljava/util/HashMap;

    .line 536
    .line 537
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 538
    .line 539
    .line 540
    move-result-object v1

    .line 541
    invoke-virtual {p0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 542
    .line 543
    .line 544
    move-result-object p0

    .line 545
    check-cast p0, Lx81;

    .line 546
    .line 547
    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    .line 548
    .line 549
    .line 550
    invoke-virtual {p0, v3, p1}, Lx81;->f(II)V

    .line 551
    .line 552
    .line 553
    goto :goto_22b

    .line 554
    :catchall_229
    move-exception p0

    .line 555
    goto :goto_232

    .line 556
    :cond_22b
    :goto_22b
    monitor-exit v5
    :try_end_22c
    .catchall {:try_start_1e3 .. :try_end_22c} :catchall_229

    .line 557
    check-cast p2, Lqe0;

    .line 558
    .line 559
    invoke-virtual {p2, v0}, Lqe0;->success(Ljava/lang/Object;)V

    .line 560
    .line 561
    .line 562
    return-void

    .line 563
    :goto_232
    :try_start_232
    monitor-exit v5
    :try_end_233
    .catchall {:try_start_232 .. :try_end_233} :catchall_229

    .line 564
    throw p0

    .line 565
    :sswitch_data_234
    .sparse-switch
        -0x776e2e97 -> :sswitch_31
        -0x56a8c01e -> :sswitch_26
        -0x52d32004 -> :sswitch_1b
        -0x4083d27 -> :sswitch_10
    .end sparse-switch

    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    :pswitch_data_246
    .packed-switch 0x0
        :pswitch_1b8
        :pswitch_159
        :pswitch_b0
        :pswitch_45
    .end packed-switch
.end method
