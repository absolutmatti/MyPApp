###### Class defpackage.op (op)
.class public final Lop;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final f:I


# instance fields
.field public final a:Z

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:F


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const-wide v0, 0x4014666666666667L    # 5.1000000000000005

    .line 2
    .line 3
    .line 4
    .line 5
    .line 6
    invoke-static {v0, v1}, Ljava/lang/Math;->round(D)J

    .line 7
    .line 8
    .line 9
    move-result-wide v0

    .line 10
    long-to-int v0, v0

    .line 11
    sput v0, Lop;->f:I

    .line 12
    .line 13
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 7

    .line 1
    const v0, 0x7f03016d

    .line 2
    .line 3
    .line 4
    const/4 v1, 0x0

    .line 5
    invoke-static {p1, v0, v1}, Lge1;->M(Landroid/content/Context;IZ)Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const v2, 0x7f03016c

    .line 10
    .line 11
    .line 12
    invoke-static {p1, v2}, Lge1;->L(Landroid/content/Context;I)Landroid/util/TypedValue;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    if-eqz v2, :cond_1d

    .line 17
    .line 18
    iget v3, v2, Landroid/util/TypedValue;->resourceId:I

    .line 19
    .line 20
    if-eqz v3, :cond_1a

    .line 21
    .line 22
    invoke-virtual {p1, v3}, Landroid/content/Context;->getColor(I)I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    goto :goto_1e

    .line 27
    :cond_1a
    iget v2, v2, Landroid/util/TypedValue;->data:I

    .line 28
    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move v2, v1

    .line 31
    :goto_1e
    const v3, 0x7f03016b

    .line 32
    .line 33
    .line 34
    invoke-static {p1, v3}, Lge1;->L(Landroid/content/Context;I)Landroid/util/TypedValue;

    .line 35
    .line 36
    .line 37
    move-result-object v3

    .line 38
    if-eqz v3, :cond_33

    .line 39
    .line 40
    iget v4, v3, Landroid/util/TypedValue;->resourceId:I

    .line 41
    .line 42
    if-eqz v4, :cond_30

    .line 43
    .line 44
    invoke-virtual {p1, v4}, Landroid/content/Context;->getColor(I)I

    .line 45
    .line 46
    .line 47
    move-result v3

    .line 48
    goto :goto_34

    .line 49
    :cond_30
    iget v3, v3, Landroid/util/TypedValue;->data:I

    .line 50
    .line 51
    goto :goto_34

    .line 52
    :cond_33
    move v3, v1

    .line 53
    :goto_34
    const v4, 0x7f0300f7

    .line 54
    .line 55
    .line 56
    invoke-static {p1, v4}, Lge1;->L(Landroid/content/Context;I)Landroid/util/TypedValue;

    .line 57
    .line 58
    .line 59
    move-result-object v4

    .line 60
    if-eqz v4, :cond_48

    .line 61
    .line 62
    iget v1, v4, Landroid/util/TypedValue;->resourceId:I

    .line 63
    .line 64
    if-eqz v1, :cond_46

    .line 65
    .line 66
    invoke-virtual {p1, v1}, Landroid/content/Context;->getColor(I)I

    .line 67
    .line 68
    .line 69
    move-result v1

    .line 70
    goto :goto_48

    .line 71
    :cond_46
    iget v1, v4, Landroid/util/TypedValue;->data:I

    .line 72
    .line 73
    :cond_48
    :goto_48
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 74
    .line 75
    .line 76
    move-result-object p1

    .line 77
    invoke-virtual {p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    iget p1, p1, Landroid/util/DisplayMetrics;->density:F

    .line 82
    .line 83
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 84
    .line 85
    .line 86
    iput-boolean v0, p0, Lop;->a:Z

    .line 87
    .line 88
    iput v2, p0, Lop;->b:I

    .line 89
    .line 90
    iput v3, p0, Lop;->c:I

    .line 91
    .line 92
    iput v1, p0, Lop;->d:I

    .line 93
    .line 94
    iput p1, p0, Lop;->e:F

    .line 95
    .line 96
    return-void
.end method
