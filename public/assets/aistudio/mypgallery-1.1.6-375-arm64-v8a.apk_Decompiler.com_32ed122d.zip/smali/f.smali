###### Class defpackage.f (f)
.class public final synthetic Lf;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lqz;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 10
    iput p1, p0, Lf;->f:I

    iput-object p2, p0, Lf;->g:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lag0;Lzf0;)V
    .registers 3

    .line 1
    const/4 p2, 0x4

    .line 2
    iput p2, p0, Lf;->f:I

    .line 3
    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 5
    .line 6
    .line 7
    iput-object p1, p0, Lf;->g:Ljava/lang/Object;

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lf;->f:I

    .line 2
    .line 3
    iget-object p0, p0, Lf;->g:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_98

    .line 6
    .line 7
    .line 8
    check-cast p0, Ldq0;

    .line 9
    .line 10
    check-cast p1, Lez;

    .line 11
    .line 12
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    .line 14
    .line 15
    iput-object p1, p0, Ldq0;->g:Lez;

    .line 16
    .line 17
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 18
    .line 19
    return-object p0

    .line 20
    :pswitch_13
    check-cast p0, Lag0;

    .line 21
    .line 22
    check-cast p1, Ljava/lang/Throwable;

    .line 23
    .line 24
    const/4 p1, 0x0

    .line 25
    invoke-virtual {p0, p1}, Lag0;->a(Ljava/lang/Object;)V

    .line 26
    .line 27
    .line 28
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 29
    .line 30
    return-object p0

    .line 31
    :pswitch_1e
    check-cast p0, Lcom/mypg/mypgallery/dpi/DpiVpnService;

    .line 32
    .line 33
    check-cast p1, Ljava/lang/Integer;

    .line 34
    .line 35
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 36
    .line 37
    .line 38
    move-result p1

    .line 39
    sget v0, Lcom/mypg/mypgallery/dpi/DpiVpnService;->k:I

    .line 40
    .line 41
    invoke-virtual {p0, p1}, Landroid/net/VpnService;->protect(I)Z

    .line 42
    .line 43
    .line 44
    move-result p0

    .line 45
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 46
    .line 47
    .line 48
    move-result-object p0

    .line 49
    return-object p0

    .line 50
    :pswitch_31
    check-cast p0, Lel;

    .line 51
    .line 52
    check-cast p1, Ljava/lang/Throwable;

    .line 53
    .line 54
    if-eqz p1, :cond_41

    .line 55
    .line 56
    iget-object v0, p0, Lel;->g:Lfl;

    .line 57
    .line 58
    new-instance v1, Lzt;

    .line 59
    .line 60
    invoke-direct {v1, p1}, Lzt;-><init>(Ljava/lang/Throwable;)V

    .line 61
    .line 62
    .line 63
    invoke-virtual {v0, v1}, Lfl;->c(Lc01;)V

    .line 64
    .line 65
    .line 66
    :cond_41
    iget-object p1, p0, Lel;->i:Lk21;

    .line 67
    .line 68
    iget-object p1, p1, Lk21;->g:Ljava/lang/Object;

    .line 69
    .line 70
    sget-object v0, Lmp;->n:Lmp;

    .line 71
    .line 72
    if-eq p1, v0, :cond_54

    .line 73
    .line 74
    iget-object p0, p0, Lel;->i:Lk21;

    .line 75
    .line 76
    invoke-virtual {p0}, Lk21;->getValue()Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object p0

    .line 80
    check-cast p0, Lvt;

    .line 81
    .line 82
    invoke-virtual {p0}, Lvt;->close()V

    .line 83
    .line 84
    .line 85
    :cond_54
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 86
    .line 87
    return-object p0

    .line 88
    :pswitch_57
    check-cast p0, Lvj0;

    .line 89
    .line 90
    check-cast p1, Ljava/util/Map$Entry;

    .line 91
    .line 92
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 93
    .line 94
    .line 95
    new-instance v0, Ljava/lang/StringBuilder;

    .line 96
    .line 97
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 98
    .line 99
    .line 100
    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v1

    .line 104
    const-string v2, "(this Map)"

    .line 105
    .line 106
    if-ne v1, p0, :cond_6d

    .line 107
    .line 108
    move-object v1, v2

    .line 109
    goto :goto_71

    .line 110
    :cond_6d
    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 111
    .line 112
    .line 113
    move-result-object v1

    .line 114
    :goto_71
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    const/16 v1, 0x3d

    .line 118
    .line 119
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 123
    .line 124
    .line 125
    move-result-object p1

    .line 126
    if-ne p1, p0, :cond_80

    .line 127
    .line 128
    goto :goto_84

    .line 129
    :cond_80
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 130
    .line 131
    .line 132
    move-result-object v2

    .line 133
    :goto_84
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 134
    .line 135
    .line 136
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    return-object p0

    .line 141
    :pswitch_8c
    check-cast p0, Lg;

    .line 142
    .line 143
    if-ne p1, p0, :cond_93

    .line 144
    .line 145
    const-string p0, "(this Collection)"

    .line 146
    .line 147
    goto :goto_97

    .line 148
    :cond_93
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object p0

    .line 152
    :goto_97
    return-object p0

    .line 153
    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_8c
        :pswitch_57
        :pswitch_31
        :pswitch_1e
        :pswitch_13
    .end packed-switch
.end method
