###### Class defpackage.ic1 (ic1)
.class public Lic1;
.super Lhc1;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# direct methods
.method public constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lhc1;-><init>()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public constructor <init>(Lvc1;)V
    .registers 2

    .line 5
    invoke-direct {p0, p1}, Lhc1;-><init>(Lvc1;)V

    return-void
.end method
