###### Class defpackage.yi0 (yi0)
.class public final Lyi0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Lsi0;

.field public static final b:Lsi0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Lsi0;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-direct {v0, v1}, Lsi0;-><init>(I)V

    .line 5
    .line 6
    .line 7
    sput-object v0, Lyi0;->a:Lsi0;

    .line 8
    .line 9
    new-instance v0, Lsi0;

    .line 10
    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-direct {v0, v1}, Lsi0;-><init>(I)V

    .line 13
    .line 14
    .line 15
    sput-object v0, Lyi0;->b:Lsi0;

    .line 16
    .line 17
    return-void
.end method
