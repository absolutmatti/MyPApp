###### Class defpackage.j21 (j21)
.class public abstract Lj21;
.super Landroid/view/ViewGroup;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lhg0;
.implements Lgg0;


# static fields
.field private static final ALPHA_ANIMATION_DURATION:I = 0x12c

.field private static final ANIMATE_TO_START_DURATION:I = 0xc8

.field private static final ANIMATE_TO_TRIGGER_DURATION:I = 0xc8

.field static final CIRCLE_DIAMETER:I = 0x28

.field static final CIRCLE_DIAMETER_LARGE:I = 0x38

.field private static final DECELERATE_INTERPOLATION_FACTOR:F = 2.0f

.field public static final DEFAULT:I = 0x1

.field private static final DEFAULT_CIRCLE_TARGET:I = 0x40

.field public static final DEFAULT_SLINGSHOT_DISTANCE:I = -0x1

.field private static final DRAG_RATE:F = 0.5f

.field private static final INVALID_POINTER:I = -0x1

.field public static final LARGE:I = 0x0

.field private static final LAYOUT_ATTRS:[I

.field private static final LOG_TAG:Ljava/lang/String; = "j21"

.field private static final MAX_ALPHA:I = 0xff

.field private static final MAX_PROGRESS_ANGLE:F = 0.8f

.field private static final SCALE_DOWN_DURATION:I = 0x96

.field private static final STARTING_PROGRESS_ALPHA:I = 0x4c


# instance fields
.field private mActivePointerId:I

.field private mAlphaMaxAnimation:Landroid/view/animation/Animation;

.field private mAlphaStartAnimation:Landroid/view/animation/Animation;

.field private final mAnimateToCorrectPosition:Landroid/view/animation/Animation;

.field private final mAnimateToStartPosition:Landroid/view/animation/Animation;

.field private mChildScrollUpCallback:Lg21;

.field private mCircleDiameter:I

.field mCircleView:Lbd;

.field private mCircleViewIndex:I

.field mCurrentTargetOffsetTop:I

.field mCustomSlingshotDistance:I

.field private final mDecelerateInterpolator:Landroid/view/animation/DecelerateInterpolator;

.field private mEnableLegacyRequestDisallowInterceptTouch:Z

.field protected mFrom:I

.field private mInitialDownY:F

.field private mInitialMotionY:F

.field private mIsBeingDragged:Z

.field mListener:Lh21;

.field private mMediumAnimationDuration:I

.field private mNestedScrollInProgress:Z

.field private final mNestedScrollingChildHelper:Lfg0;

.field private final mNestedScrollingParentHelper:Lig0;

.field private final mNestedScrollingV2ConsumedCompat:[I

.field mNotify:Z

.field protected mOriginalOffsetTop:I

.field private final mParentOffsetInWindow:[I

.field private final mParentScrollConsumed:[I

.field mProgress:Lgd;

.field private mRefreshListener:Landroid/view/animation/Animation$AnimationListener;

.field mRefreshing:Z

.field private mReturningToStart:Z

.field mScale:Z

.field private mScaleAnimation:Landroid/view/animation/Animation;

.field private mScaleDownAnimation:Landroid/view/animation/Animation;

.field private mScaleDownToStartAnimation:Landroid/view/animation/Animation;

.field mSpinnerOffsetEnd:I

.field mStartingScale:F

.field private mTarget:Landroid/view/View;

.field private mTotalDragDistance:F

.field private mTotalUnconsumed:F

.field private mTouchSlop:I

.field mUsingCustomStart:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    const v0, 0x101000e

    .line 2
    .line 3
    .line 4
    filled-new-array {v0}, [I

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    sput-object v0, Lj21;->LAYOUT_ATTRS:[I

    .line 9
    .line 10
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 9

    .line 1
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput-boolean v0, p0, Lj21;->mRefreshing:Z

    .line 6
    .line 7
    const/high16 v1, -0x40800000    # -1.0f

    .line 8
    .line 9
    iput v1, p0, Lj21;->mTotalDragDistance:F

    .line 10
    .line 11
    const/4 v1, 0x2

    .line 12
    new-array v2, v1, [I

    .line 13
    .line 14
    iput-object v2, p0, Lj21;->mParentScrollConsumed:[I

    .line 15
    .line 16
    new-array v2, v1, [I

    .line 17
    .line 18
    iput-object v2, p0, Lj21;->mParentOffsetInWindow:[I

    .line 19
    .line 20
    new-array v1, v1, [I

    .line 21
    .line 22
    iput-object v1, p0, Lj21;->mNestedScrollingV2ConsumedCompat:[I

    .line 23
    .line 24
    const/4 v1, -0x1

    .line 25
    iput v1, p0, Lj21;->mActivePointerId:I

    .line 26
    .line 27
    iput v1, p0, Lj21;->mCircleViewIndex:I

    .line 28
    .line 29
    new-instance v1, Ld21;

    .line 30
    .line 31
    invoke-direct {v1, p0, v0}, Ld21;-><init>(Lj21;I)V

    .line 32
    .line 33
    .line 34
    iput-object v1, p0, Lj21;->mRefreshListener:Landroid/view/animation/Animation$AnimationListener;

    .line 35
    .line 36
    new-instance v1, Lf21;

    .line 37
    .line 38
    invoke-direct {v1, p0, v0}, Lf21;-><init>(Lj21;I)V

    .line 39
    .line 40
    .line 41
    iput-object v1, p0, Lj21;->mAnimateToCorrectPosition:Landroid/view/animation/Animation;

    .line 42
    .line 43
    new-instance v1, Lf21;

    .line 44
    .line 45
    const/4 v2, 0x4

    .line 46
    invoke-direct {v1, p0, v2}, Lf21;-><init>(Lj21;I)V

    .line 47
    .line 48
    .line 49
    iput-object v1, p0, Lj21;->mAnimateToStartPosition:Landroid/view/animation/Animation;

    .line 50
    .line 51
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    .line 56
    .line 57
    .line 58
    move-result v1

    .line 59
    iput v1, p0, Lj21;->mTouchSlop:I

    .line 60
    .line 61
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 62
    .line 63
    .line 64
    move-result-object v1

    .line 65
    const v2, 0x10e0001

    .line 66
    .line 67
    .line 68
    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getInteger(I)I

    .line 69
    .line 70
    .line 71
    move-result v1

    .line 72
    iput v1, p0, Lj21;->mMediumAnimationDuration:I

    .line 73
    .line 74
    invoke-virtual {p0, v0}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 75
    .line 76
    .line 77
    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    .line 78
    .line 79
    const/high16 v2, 0x40000000    # 2.0f

    .line 80
    .line 81
    invoke-direct {v1, v2}, Landroid/view/animation/DecelerateInterpolator;-><init>(F)V

    .line 82
    .line 83
    .line 84
    iput-object v1, p0, Lj21;->mDecelerateInterpolator:Landroid/view/animation/DecelerateInterpolator;

    .line 85
    .line 86
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 87
    .line 88
    .line 89
    move-result-object v1

    .line 90
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 91
    .line 92
    .line 93
    move-result-object v1

    .line 94
    const/high16 v2, 0x42200000    # 40.0f

    .line 95
    .line 96
    iget v3, v1, Landroid/util/DisplayMetrics;->density:F

    .line 97
    .line 98
    mul-float/2addr v3, v2

    .line 99
    float-to-int v2, v3

    .line 100
    iput v2, p0, Lj21;->mCircleDiameter:I

    .line 101
    .line 102
    new-instance v2, Lbd;

    .line 103
    .line 104
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 105
    .line 106
    .line 107
    move-result-object v3

    .line 108
    invoke-direct {v2, v3}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    .line 109
    .line 110
    .line 111
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 112
    .line 113
    .line 114
    move-result-object v3

    .line 115
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 116
    .line 117
    .line 118
    move-result-object v3

    .line 119
    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 120
    .line 121
    .line 122
    move-result-object v3

    .line 123
    iget v3, v3, Landroid/util/DisplayMetrics;->density:F

    .line 124
    .line 125
    invoke-virtual {v2}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 126
    .line 127
    .line 128
    move-result-object v4

    .line 129
    sget-object v5, Lwn0;->a:[I

    .line 130
    .line 131
    invoke-virtual {v4, v5}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    .line 132
    .line 133
    .line 134
    move-result-object v4

    .line 135
    const v5, -0x50506

    .line 136
    .line 137
    .line 138
    invoke-virtual {v4, v0, v5}, Landroid/content/res/TypedArray;->getColor(II)I

    .line 139
    .line 140
    .line 141
    move-result v5

    .line 142
    iput v5, v2, Lbd;->g:I

    .line 143
    .line 144
    invoke-virtual {v4}, Landroid/content/res/TypedArray;->recycle()V

    .line 145
    .line 146
    .line 147
    new-instance v4, Landroid/graphics/drawable/ShapeDrawable;

    .line 148
    .line 149
    new-instance v5, Landroid/graphics/drawable/shapes/OvalShape;

    .line 150
    .line 151
    invoke-direct {v5}, Landroid/graphics/drawable/shapes/OvalShape;-><init>()V

    .line 152
    .line 153
    .line 154
    invoke-direct {v4, v5}, Landroid/graphics/drawable/ShapeDrawable;-><init>(Landroid/graphics/drawable/shapes/Shape;)V

    .line 155
    .line 156
    .line 157
    const/high16 v5, 0x40800000    # 4.0f

    .line 158
    .line 159
    mul-float/2addr v3, v5

    .line 160
    sget-object v5, Lj91;->a:Ljava/util/WeakHashMap;

    .line 161
    .line 162
    invoke-static {v2, v3}, Ld91;->i(Landroid/view/View;F)V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v4}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    .line 166
    .line 167
    .line 168
    move-result-object v3

    .line 169
    iget v5, v2, Lbd;->g:I

    .line 170
    .line 171
    invoke-virtual {v3, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 172
    .line 173
    .line 174
    invoke-virtual {v2, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    .line 175
    .line 176
    .line 177
    iput-object v2, p0, Lj21;->mCircleView:Lbd;

    .line 178
    .line 179
    new-instance v2, Lgd;

    .line 180
    .line 181
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 182
    .line 183
    .line 184
    move-result-object v3

    .line 185
    invoke-direct {v2, v3}, Lgd;-><init>(Landroid/content/Context;)V

    .line 186
    .line 187
    .line 188
    iput-object v2, p0, Lj21;->mProgress:Lgd;

    .line 189
    .line 190
    const/4 v3, 0x1

    .line 191
    invoke-virtual {v2, v3}, Lgd;->c(I)V

    .line 192
    .line 193
    .line 194
    iget-object v2, p0, Lj21;->mCircleView:Lbd;

    .line 195
    .line 196
    iget-object v4, p0, Lj21;->mProgress:Lgd;

    .line 197
    .line 198
    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 199
    .line 200
    .line 201
    iget-object v2, p0, Lj21;->mCircleView:Lbd;

    .line 202
    .line 203
    const/16 v4, 0x8

    .line 204
    .line 205
    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    .line 206
    .line 207
    .line 208
    iget-object v2, p0, Lj21;->mCircleView:Lbd;

    .line 209
    .line 210
    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 211
    .line 212
    .line 213
    invoke-virtual {p0, v3}, Landroid/view/ViewGroup;->setChildrenDrawingOrderEnabled(Z)V

    .line 214
    .line 215
    .line 216
    const/high16 v2, 0x42800000    # 64.0f

    .line 217
    .line 218
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 219
    .line 220
    mul-float/2addr v1, v2

    .line 221
    float-to-int v1, v1

    .line 222
    iput v1, p0, Lj21;->mSpinnerOffsetEnd:I

    .line 223
    .line 224
    int-to-float v1, v1

    .line 225
    iput v1, p0, Lj21;->mTotalDragDistance:F

    .line 226
    .line 227
    new-instance v1, Lig0;

    .line 228
    .line 229
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 230
    .line 231
    .line 232
    iput-object v1, p0, Lj21;->mNestedScrollingParentHelper:Lig0;

    .line 233
    .line 234
    new-instance v1, Lfg0;

    .line 235
    .line 236
    invoke-direct {v1, p0}, Lfg0;-><init>(Landroid/view/ViewGroup;)V

    .line 237
    .line 238
    .line 239
    iput-object v1, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 240
    .line 241
    invoke-virtual {p0, v3}, Lj21;->setNestedScrollingEnabled(Z)V

    .line 242
    .line 243
    .line 244
    iget v1, p0, Lj21;->mCircleDiameter:I

    .line 245
    .line 246
    neg-int v1, v1

    .line 247
    iput v1, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 248
    .line 249
    iput v1, p0, Lj21;->mOriginalOffsetTop:I

    .line 250
    .line 251
    const/high16 v1, 0x3f800000    # 1.0f

    .line 252
    .line 253
    invoke-virtual {p0, v1}, Lj21;->moveToStart(F)V

    .line 254
    .line 255
    .line 256
    sget-object v1, Lj21;->LAYOUT_ATTRS:[I

    .line 257
    .line 258
    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    .line 259
    .line 260
    .line 261
    move-result-object p1

    .line 262
    invoke-virtual {p1, v0, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 263
    .line 264
    .line 265
    move-result p2

    .line 266
    invoke-virtual {p0, p2}, Lj21;->setEnabled(Z)V

    .line 267
    .line 268
    .line 269
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    .line 270
    .line 271
    .line 272
    return-void
.end method

.method private setColorViewAlpha(I)V
    .registers 3

    .line 1
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    .line 8
    .line 9
    .line 10
    iget-object p0, p0, Lj21;->mProgress:Lgd;

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Lgd;->setAlpha(I)V

    .line 13
    .line 14
    .line 15
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    .line 1
    iget-object v0, p0, Lj21;->mTarget:Landroid/view/View;

    .line 2
    .line 3
    if-nez v0, :cond_1d

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    :goto_5
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    if-ge v0, v1, :cond_1d

    .line 11
    .line 12
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    iget-object v2, p0, Lj21;->mCircleView:Lbd;

    .line 17
    .line 18
    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 19
    .line 20
    .line 21
    move-result v2

    .line 22
    if-nez v2, :cond_1a

    .line 23
    .line 24
    iput-object v1, p0, Lj21;->mTarget:Landroid/view/View;

    .line 25
    .line 26
    return-void

    .line 27
    :cond_1a
    add-int/lit8 v0, v0, 0x1

    .line 28
    .line 29
    goto :goto_5

    .line 30
    :cond_1d
    return-void
.end method

.method public final b(F)V
    .registers 7

    .line 1
    iget v0, p0, Lj21;->mTotalDragDistance:F

    .line 2
    .line 3
    cmpl-float p1, p1, v0

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    if-lez p1, :cond_b

    .line 7
    .line 8
    invoke-virtual {p0, v0, v0}, Lj21;->d(ZZ)V

    .line 9
    .line 10
    .line 11
    return-void

    .line 12
    :cond_b
    const/4 p1, 0x0

    .line 13
    iput-boolean p1, p0, Lj21;->mRefreshing:Z

    .line 14
    .line 15
    iget-object v1, p0, Lj21;->mProgress:Lgd;

    .line 16
    .line 17
    iget-object v2, v1, Lgd;->f:Lfd;

    .line 18
    .line 19
    const/4 v3, 0x0

    .line 20
    iput v3, v2, Lfd;->e:F

    .line 21
    .line 22
    iput v3, v2, Lfd;->f:F

    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 25
    .line 26
    .line 27
    iget-boolean v1, p0, Lj21;->mScale:Z

    .line 28
    .line 29
    if-nez v1, :cond_24

    .line 30
    .line 31
    new-instance v2, Ld21;

    .line 32
    .line 33
    invoke-direct {v2, p0, v0}, Ld21;-><init>(Lj21;I)V

    .line 34
    .line 35
    .line 36
    goto :goto_25

    .line 37
    :cond_24
    const/4 v2, 0x0

    .line 38
    :goto_25
    iget v3, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 39
    .line 40
    if-eqz v1, :cond_52

    .line 41
    .line 42
    iput v3, p0, Lj21;->mFrom:I

    .line 43
    .line 44
    iget-object v1, p0, Lj21;->mCircleView:Lbd;

    .line 45
    .line 46
    invoke-virtual {v1}, Landroid/view/View;->getScaleX()F

    .line 47
    .line 48
    .line 49
    move-result v1

    .line 50
    iput v1, p0, Lj21;->mStartingScale:F

    .line 51
    .line 52
    new-instance v1, Lf21;

    .line 53
    .line 54
    invoke-direct {v1, p0, v0}, Lf21;-><init>(Lj21;I)V

    .line 55
    .line 56
    .line 57
    iput-object v1, p0, Lj21;->mScaleDownToStartAnimation:Landroid/view/animation/Animation;

    .line 58
    .line 59
    const-wide/16 v3, 0x96

    .line 60
    .line 61
    invoke-virtual {v1, v3, v4}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 62
    .line 63
    .line 64
    if-eqz v2, :cond_45

    .line 65
    .line 66
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 67
    .line 68
    iput-object v2, v0, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 69
    .line 70
    :cond_45
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 71
    .line 72
    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 73
    .line 74
    .line 75
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 76
    .line 77
    iget-object v1, p0, Lj21;->mScaleDownToStartAnimation:Landroid/view/animation/Animation;

    .line 78
    .line 79
    invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 80
    .line 81
    .line 82
    goto :goto_79

    .line 83
    :cond_52
    iput v3, p0, Lj21;->mFrom:I

    .line 84
    .line 85
    iget-object v0, p0, Lj21;->mAnimateToStartPosition:Landroid/view/animation/Animation;

    .line 86
    .line 87
    invoke-virtual {v0}, Landroid/view/animation/Animation;->reset()V

    .line 88
    .line 89
    .line 90
    iget-object v0, p0, Lj21;->mAnimateToStartPosition:Landroid/view/animation/Animation;

    .line 91
    .line 92
    const-wide/16 v3, 0xc8

    .line 93
    .line 94
    invoke-virtual {v0, v3, v4}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 95
    .line 96
    .line 97
    iget-object v0, p0, Lj21;->mAnimateToStartPosition:Landroid/view/animation/Animation;

    .line 98
    .line 99
    iget-object v1, p0, Lj21;->mDecelerateInterpolator:Landroid/view/animation/DecelerateInterpolator;

    .line 100
    .line 101
    invoke-virtual {v0, v1}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 102
    .line 103
    .line 104
    if-eqz v2, :cond_6d

    .line 105
    .line 106
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 107
    .line 108
    iput-object v2, v0, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 109
    .line 110
    :cond_6d
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 111
    .line 112
    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 113
    .line 114
    .line 115
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 116
    .line 117
    iget-object v1, p0, Lj21;->mAnimateToStartPosition:Landroid/view/animation/Animation;

    .line 118
    .line 119
    invoke-virtual {v0, v1}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 120
    .line 121
    .line 122
    :goto_79
    iget-object p0, p0, Lj21;->mProgress:Lgd;

    .line 123
    .line 124
    iget-object v0, p0, Lgd;->f:Lfd;

    .line 125
    .line 126
    iget-boolean v1, v0, Lfd;->n:Z

    .line 127
    .line 128
    if-eqz v1, :cond_83

    .line 129
    .line 130
    iput-boolean p1, v0, Lfd;->n:Z

    .line 131
    .line 132
    :cond_83
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 133
    .line 134
    .line 135
    return-void
.end method

.method public final c(F)V
    .registers 13

    .line 1
    iget-object v0, p0, Lj21;->mProgress:Lgd;

    .line 2
    .line 3
    iget-object v1, v0, Lgd;->f:Lfd;

    .line 4
    .line 5
    iget-boolean v2, v1, Lfd;->n:Z

    .line 6
    .line 7
    const/4 v3, 0x1

    .line 8
    if-eq v2, v3, :cond_b

    .line 9
    .line 10
    iput-boolean v3, v1, Lfd;->n:Z

    .line 11
    .line 12
    :cond_b
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 13
    .line 14
    .line 15
    iget v0, p0, Lj21;->mTotalDragDistance:F

    .line 16
    .line 17
    div-float v0, p1, v0

    .line 18
    .line 19
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    const/high16 v1, 0x3f800000    # 1.0f

    .line 24
    .line 25
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    float-to-double v2, v0

    .line 30
    const-wide v4, 0x3fd999999999999aL    # 0.4

    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    sub-double/2addr v2, v4

    .line 36
    const-wide/16 v4, 0x0

    .line 37
    .line 38
    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->max(DD)D

    .line 39
    .line 40
    .line 41
    move-result-wide v2

    .line 42
    double-to-float v2, v2

    .line 43
    const/high16 v3, 0x40a00000    # 5.0f

    .line 44
    .line 45
    mul-float/2addr v2, v3

    .line 46
    const/high16 v3, 0x40400000    # 3.0f

    .line 47
    .line 48
    div-float/2addr v2, v3

    .line 49
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    .line 50
    .line 51
    .line 52
    move-result v3

    .line 53
    iget v4, p0, Lj21;->mTotalDragDistance:F

    .line 54
    .line 55
    sub-float/2addr v3, v4

    .line 56
    iget v4, p0, Lj21;->mCustomSlingshotDistance:I

    .line 57
    .line 58
    if-lez v4, :cond_3d

    .line 59
    .line 60
    int-to-float v4, v4

    .line 61
    goto :goto_47

    .line 62
    :cond_3d
    iget-boolean v4, p0, Lj21;->mUsingCustomStart:Z

    .line 63
    .line 64
    iget v5, p0, Lj21;->mSpinnerOffsetEnd:I

    .line 65
    .line 66
    if-eqz v4, :cond_46

    .line 67
    .line 68
    iget v4, p0, Lj21;->mOriginalOffsetTop:I

    .line 69
    .line 70
    sub-int/2addr v5, v4

    .line 71
    :cond_46
    int-to-float v4, v5

    .line 72
    :goto_47
    const/high16 v5, 0x40000000    # 2.0f

    .line 73
    .line 74
    mul-float v6, v4, v5

    .line 75
    .line 76
    invoke-static {v3, v6}, Ljava/lang/Math;->min(FF)F

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    div-float/2addr v3, v4

    .line 81
    const/4 v6, 0x0

    .line 82
    invoke-static {v6, v3}, Ljava/lang/Math;->max(FF)F

    .line 83
    .line 84
    .line 85
    move-result v3

    .line 86
    const/high16 v7, 0x40800000    # 4.0f

    .line 87
    .line 88
    div-float/2addr v3, v7

    .line 89
    float-to-double v7, v3

    .line 90
    const-wide/high16 v9, 0x4000000000000000L    # 2.0

    .line 91
    .line 92
    invoke-static {v7, v8, v9, v10}, Ljava/lang/Math;->pow(DD)D

    .line 93
    .line 94
    .line 95
    move-result-wide v9

    .line 96
    sub-double/2addr v7, v9

    .line 97
    double-to-float v3, v7

    .line 98
    mul-float/2addr v3, v5

    .line 99
    mul-float v7, v4, v3

    .line 100
    .line 101
    mul-float/2addr v7, v5

    .line 102
    iget v8, p0, Lj21;->mOriginalOffsetTop:I

    .line 103
    .line 104
    mul-float/2addr v4, v0

    .line 105
    add-float/2addr v4, v7

    .line 106
    float-to-int v0, v4

    .line 107
    add-int/2addr v8, v0

    .line 108
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 109
    .line 110
    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    .line 111
    .line 112
    .line 113
    move-result v0

    .line 114
    if-eqz v0, :cond_79

    .line 115
    .line 116
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 117
    .line 118
    const/4 v4, 0x0

    .line 119
    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    .line 120
    .line 121
    .line 122
    :cond_79
    iget-boolean v0, p0, Lj21;->mScale:Z

    .line 123
    .line 124
    if-nez v0, :cond_87

    .line 125
    .line 126
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 127
    .line 128
    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleX(F)V

    .line 129
    .line 130
    .line 131
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 132
    .line 133
    invoke-virtual {v0, v1}, Landroid/view/View;->setScaleY(F)V

    .line 134
    .line 135
    .line 136
    :cond_87
    iget-boolean v0, p0, Lj21;->mScale:Z

    .line 137
    .line 138
    if-eqz v0, :cond_96

    .line 139
    .line 140
    iget v0, p0, Lj21;->mTotalDragDistance:F

    .line 141
    .line 142
    div-float v0, p1, v0

    .line 143
    .line 144
    invoke-static {v1, v0}, Ljava/lang/Math;->min(FF)F

    .line 145
    .line 146
    .line 147
    move-result v0

    .line 148
    invoke-virtual {p0, v0}, Lj21;->setAnimationProgress(F)V

    .line 149
    .line 150
    .line 151
    :cond_96
    iget v0, p0, Lj21;->mTotalDragDistance:F

    .line 152
    .line 153
    cmpg-float p1, p1, v0

    .line 154
    .line 155
    iget-object v0, p0, Lj21;->mProgress:Lgd;

    .line 156
    .line 157
    const/4 v4, 0x0

    .line 158
    const-wide/16 v9, 0x12c

    .line 159
    .line 160
    if-gez p1, :cond_d7

    .line 161
    .line 162
    iget-object p1, v0, Lgd;->f:Lfd;

    .line 163
    .line 164
    iget p1, p1, Lfd;->t:I

    .line 165
    .line 166
    const/16 v0, 0x4c

    .line 167
    .line 168
    if-le p1, v0, :cond_10c

    .line 169
    .line 170
    iget-object p1, p0, Lj21;->mAlphaStartAnimation:Landroid/view/animation/Animation;

    .line 171
    .line 172
    if-eqz p1, :cond_ba

    .line 173
    .line 174
    invoke-virtual {p1}, Landroid/view/animation/Animation;->hasStarted()Z

    .line 175
    .line 176
    .line 177
    move-result v7

    .line 178
    if-eqz v7, :cond_ba

    .line 179
    .line 180
    invoke-virtual {p1}, Landroid/view/animation/Animation;->hasEnded()Z

    .line 181
    .line 182
    .line 183
    move-result p1

    .line 184
    if-nez p1, :cond_ba

    .line 185
    .line 186
    goto :goto_10c

    .line 187
    :cond_ba
    iget-object p1, p0, Lj21;->mProgress:Lgd;

    .line 188
    .line 189
    iget-object p1, p1, Lgd;->f:Lfd;

    .line 190
    .line 191
    iget p1, p1, Lfd;->t:I

    .line 192
    .line 193
    new-instance v7, Le21;

    .line 194
    .line 195
    invoke-direct {v7, p0, p1, v0}, Le21;-><init>(Lj21;II)V

    .line 196
    .line 197
    .line 198
    invoke-virtual {v7, v9, v10}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 199
    .line 200
    .line 201
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 202
    .line 203
    iput-object v4, p1, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 204
    .line 205
    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    .line 206
    .line 207
    .line 208
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 209
    .line 210
    invoke-virtual {p1, v7}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 211
    .line 212
    .line 213
    iput-object v7, p0, Lj21;->mAlphaStartAnimation:Landroid/view/animation/Animation;

    .line 214
    .line 215
    goto :goto_10c

    .line 216
    :cond_d7
    iget-object p1, v0, Lgd;->f:Lfd;

    .line 217
    .line 218
    iget p1, p1, Lfd;->t:I

    .line 219
    .line 220
    const/16 v0, 0xff

    .line 221
    .line 222
    if-ge p1, v0, :cond_10c

    .line 223
    .line 224
    iget-object p1, p0, Lj21;->mAlphaMaxAnimation:Landroid/view/animation/Animation;

    .line 225
    .line 226
    if-eqz p1, :cond_f0

    .line 227
    .line 228
    invoke-virtual {p1}, Landroid/view/animation/Animation;->hasStarted()Z

    .line 229
    .line 230
    .line 231
    move-result v7

    .line 232
    if-eqz v7, :cond_f0

    .line 233
    .line 234
    invoke-virtual {p1}, Landroid/view/animation/Animation;->hasEnded()Z

    .line 235
    .line 236
    .line 237
    move-result p1

    .line 238
    if-nez p1, :cond_f0

    .line 239
    .line 240
    goto :goto_10c

    .line 241
    :cond_f0
    iget-object p1, p0, Lj21;->mProgress:Lgd;

    .line 242
    .line 243
    iget-object p1, p1, Lgd;->f:Lfd;

    .line 244
    .line 245
    iget p1, p1, Lfd;->t:I

    .line 246
    .line 247
    new-instance v7, Le21;

    .line 248
    .line 249
    invoke-direct {v7, p0, p1, v0}, Le21;-><init>(Lj21;II)V

    .line 250
    .line 251
    .line 252
    invoke-virtual {v7, v9, v10}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 253
    .line 254
    .line 255
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 256
    .line 257
    iput-object v4, p1, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 258
    .line 259
    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    .line 260
    .line 261
    .line 262
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 263
    .line 264
    invoke-virtual {p1, v7}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 265
    .line 266
    .line 267
    iput-object v7, p0, Lj21;->mAlphaMaxAnimation:Landroid/view/animation/Animation;

    .line 268
    .line 269
    :cond_10c
    :goto_10c
    const p1, 0x3f4ccccd    # 0.8f

    .line 270
    .line 271
    .line 272
    mul-float v0, v2, p1

    .line 273
    .line 274
    iget-object v4, p0, Lj21;->mProgress:Lgd;

    .line 275
    .line 276
    invoke-static {p1, v0}, Ljava/lang/Math;->min(FF)F

    .line 277
    .line 278
    .line 279
    move-result p1

    .line 280
    iget-object v0, v4, Lgd;->f:Lfd;

    .line 281
    .line 282
    iput v6, v0, Lfd;->e:F

    .line 283
    .line 284
    iput p1, v0, Lfd;->f:F

    .line 285
    .line 286
    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 287
    .line 288
    .line 289
    iget-object p1, p0, Lj21;->mProgress:Lgd;

    .line 290
    .line 291
    invoke-static {v1, v2}, Ljava/lang/Math;->min(FF)F

    .line 292
    .line 293
    .line 294
    move-result v0

    .line 295
    iget-object v1, p1, Lgd;->f:Lfd;

    .line 296
    .line 297
    iget v4, v1, Lfd;->p:F

    .line 298
    .line 299
    cmpl-float v4, v0, v4

    .line 300
    .line 301
    if-eqz v4, :cond_130

    .line 302
    .line 303
    iput v0, v1, Lfd;->p:F

    .line 304
    .line 305
    :cond_130
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 306
    .line 307
    .line 308
    const p1, 0x3ecccccd    # 0.4f

    .line 309
    .line 310
    .line 311
    mul-float/2addr v2, p1

    .line 312
    const/high16 p1, -0x41800000    # -0.25f

    .line 313
    .line 314
    add-float/2addr v2, p1

    .line 315
    mul-float/2addr v3, v5

    .line 316
    add-float/2addr v3, v2

    .line 317
    const/high16 p1, 0x3f000000    # 0.5f

    .line 318
    .line 319
    mul-float/2addr v3, p1

    .line 320
    iget-object p1, p0, Lj21;->mProgress:Lgd;

    .line 321
    .line 322
    iget-object v0, p1, Lgd;->f:Lfd;

    .line 323
    .line 324
    iput v3, v0, Lfd;->g:F

    .line 325
    .line 326
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 327
    .line 328
    .line 329
    iget p1, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 330
    .line 331
    sub-int/2addr v8, p1

    .line 332
    invoke-virtual {p0, v8}, Lj21;->setTargetOffsetTopAndBottom(I)V

    .line 333
    .line 334
    .line 335
    return-void
.end method

.method public canChildScrollUp()Z
    .registers 3

    .line 1
    iget-object v0, p0, Lj21;->mChildScrollUpCallback:Lg21;

    .line 2
    .line 3
    iget-object v1, p0, Lj21;->mTarget:Landroid/view/View;

    .line 4
    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    invoke-interface {v0, p0, v1}, Lg21;->canChildScrollUp(Lj21;Landroid/view/View;)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_b
    instance-of p0, v1, Landroid/widget/ListView;

    .line 13
    .line 14
    const/4 v0, -0x1

    .line 15
    if-eqz p0, :cond_17

    .line 16
    .line 17
    check-cast v1, Landroid/widget/ListView;

    .line 18
    .line 19
    invoke-virtual {v1, v0}, Landroid/widget/AbsListView;->canScrollList(I)Z

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    return p0

    .line 24
    :cond_17
    invoke-virtual {v1, v0}, Landroid/view/View;->canScrollVertically(I)Z

    .line 25
    .line 26
    .line 27
    move-result p0

    .line 28
    return p0
.end method

.method public final d(ZZ)V
    .registers 5

    .line 1
    iget-boolean v0, p0, Lj21;->mRefreshing:Z

    .line 2
    .line 3
    if-eq v0, p1, :cond_3e

    .line 4
    .line 5
    iput-boolean p2, p0, Lj21;->mNotify:Z

    .line 6
    .line 7
    invoke-virtual {p0}, Lj21;->a()V

    .line 8
    .line 9
    .line 10
    iput-boolean p1, p0, Lj21;->mRefreshing:Z

    .line 11
    .line 12
    if-eqz p1, :cond_39

    .line 13
    .line 14
    iget p1, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 15
    .line 16
    iget-object p2, p0, Lj21;->mRefreshListener:Landroid/view/animation/Animation$AnimationListener;

    .line 17
    .line 18
    iput p1, p0, Lj21;->mFrom:I

    .line 19
    .line 20
    iget-object p1, p0, Lj21;->mAnimateToCorrectPosition:Landroid/view/animation/Animation;

    .line 21
    .line 22
    invoke-virtual {p1}, Landroid/view/animation/Animation;->reset()V

    .line 23
    .line 24
    .line 25
    iget-object p1, p0, Lj21;->mAnimateToCorrectPosition:Landroid/view/animation/Animation;

    .line 26
    .line 27
    const-wide/16 v0, 0xc8

    .line 28
    .line 29
    invoke-virtual {p1, v0, v1}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 30
    .line 31
    .line 32
    iget-object p1, p0, Lj21;->mAnimateToCorrectPosition:Landroid/view/animation/Animation;

    .line 33
    .line 34
    iget-object v0, p0, Lj21;->mDecelerateInterpolator:Landroid/view/animation/DecelerateInterpolator;

    .line 35
    .line 36
    invoke-virtual {p1, v0}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 37
    .line 38
    .line 39
    if-eqz p2, :cond_2c

    .line 40
    .line 41
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 42
    .line 43
    iput-object p2, p1, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 44
    .line 45
    :cond_2c
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 46
    .line 47
    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    .line 48
    .line 49
    .line 50
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 51
    .line 52
    iget-object p0, p0, Lj21;->mAnimateToCorrectPosition:Landroid/view/animation/Animation;

    .line 53
    .line 54
    invoke-virtual {p1, p0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 55
    .line 56
    .line 57
    return-void

    .line 58
    :cond_39
    iget-object p1, p0, Lj21;->mRefreshListener:Landroid/view/animation/Animation$AnimationListener;

    .line 59
    .line 60
    invoke-virtual {p0, p1}, Lj21;->startScaleDownAnimation(Landroid/view/animation/Animation$AnimationListener;)V

    .line 61
    .line 62
    .line 63
    :cond_3e
    return-void
.end method

.method public dispatchNestedFling(FFZ)Z
    .registers 4

    .line 1
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2, p3}, Lfg0;->a(FFZ)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public dispatchNestedPreFling(FF)Z
    .registers 3

    .line 1
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2}, Lfg0;->b(FF)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    return p0
.end method

.method public dispatchNestedPreScroll(II[I[I)Z
    .registers 11

    .line 13
    iget-object v0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    const/4 v5, 0x0

    move v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    .line 14
    invoke-virtual/range {v0 .. v5}, Lfg0;->c(II[I[II)Z

    move-result p0

    return p0
.end method

.method public dispatchNestedPreScroll(II[I[II)Z
    .registers 6

    .line 1
    if-nez p5, :cond_a

    .line 2
    .line 3
    invoke-virtual {p0, p1, p2, p3, p4}, Lj21;->dispatchNestedPreScroll(II[I[I)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    if-eqz p0, :cond_a

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_a
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public dispatchNestedScroll(IIII[II[I)V
    .registers 8

    if-nez p6, :cond_7

    .line 22
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 23
    invoke-virtual/range {p0 .. p7}, Lfg0;->d(IIII[II[I)Z

    :cond_7
    return-void
.end method

.method public dispatchNestedScroll(IIII[I)Z
    .registers 14

    .line 24
    iget-object v0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    .line 25
    invoke-virtual/range {v0 .. v7}, Lfg0;->d(IIII[II[I)Z

    move-result p0

    return p0
.end method

.method public dispatchNestedScroll(IIII[II)Z
    .registers 15

    .line 1
    if-nez p6, :cond_13

    .line 2
    .line 3
    iget-object v0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 4
    .line 5
    const/4 v7, 0x0

    .line 6
    move v1, p1

    .line 7
    move v2, p2

    .line 8
    move v3, p3

    .line 9
    move v4, p4

    .line 10
    move-object v5, p5

    .line 11
    move v6, p6

    .line 12
    invoke-virtual/range {v0 .. v7}, Lfg0;->d(IIII[II[I)Z

    .line 13
    .line 14
    .line 15
    move-result p0

    .line 16
    if-eqz p0, :cond_13

    .line 17
    .line 18
    const/4 p0, 0x1

    .line 19
    return p0

    .line 20
    :cond_13
    const/4 p0, 0x0

    .line 21
    return p0
.end method

.method public final e(F)V
    .registers 5

    .line 1
    iget v0, p0, Lj21;->mInitialDownY:F

    .line 2
    .line 3
    sub-float/2addr p1, v0

    .line 4
    iget v1, p0, Lj21;->mTouchSlop:I

    .line 5
    .line 6
    int-to-float v2, v1

    .line 7
    cmpl-float p1, p1, v2

    .line 8
    .line 9
    if-lez p1, :cond_1c

    .line 10
    .line 11
    iget-boolean p1, p0, Lj21;->mIsBeingDragged:Z

    .line 12
    .line 13
    if-nez p1, :cond_1c

    .line 14
    .line 15
    int-to-float p1, v1

    .line 16
    add-float/2addr v0, p1

    .line 17
    iput v0, p0, Lj21;->mInitialMotionY:F

    .line 18
    .line 19
    const/4 p1, 0x1

    .line 20
    iput-boolean p1, p0, Lj21;->mIsBeingDragged:Z

    .line 21
    .line 22
    iget-object p0, p0, Lj21;->mProgress:Lgd;

    .line 23
    .line 24
    const/16 p1, 0x4c

    .line 25
    .line 26
    invoke-virtual {p0, p1}, Lgd;->setAlpha(I)V

    .line 27
    .line 28
    .line 29
    :cond_1c
    return-void
.end method

.method public getChildDrawingOrder(II)I
    .registers 3

    .line 1
    iget p0, p0, Lj21;->mCircleViewIndex:I

    .line 2
    .line 3
    if-gez p0, :cond_5

    .line 4
    .line 5
    goto :goto_e

    .line 6
    :cond_5
    add-int/lit8 p1, p1, -0x1

    .line 7
    .line 8
    if-ne p2, p1, :cond_a

    .line 9
    .line 10
    return p0

    .line 11
    :cond_a
    if-lt p2, p0, :cond_e

    .line 12
    .line 13
    add-int/lit8 p2, p2, 0x1

    .line 14
    .line 15
    :cond_e
    :goto_e
    return p2
.end method

.method public getNestedScrollAxes()I
    .registers 2

    .line 1
    iget-object p0, p0, Lj21;->mNestedScrollingParentHelper:Lig0;

    .line 2
    .line 3
    iget v0, p0, Lig0;->a:I

    .line 4
    .line 5
    iget p0, p0, Lig0;->b:I

    .line 6
    .line 7
    or-int/2addr p0, v0

    .line 8
    return p0
.end method

.method public getProgressCircleDiameter()I
    .registers 1

    .line 1
    iget p0, p0, Lj21;->mCircleDiameter:I

    .line 2
    .line 3
    return p0
.end method

.method public getProgressViewEndOffset()I
    .registers 1

    .line 1
    iget p0, p0, Lj21;->mSpinnerOffsetEnd:I

    .line 2
    .line 3
    return p0
.end method

.method public getProgressViewStartOffset()I
    .registers 1

    .line 1
    iget p0, p0, Lj21;->mOriginalOffsetTop:I

    .line 2
    .line 3
    return p0
.end method

.method public hasNestedScrollingParent()Z
    .registers 2

    .line 13
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    const/4 v0, 0x0

    .line 14
    invoke-virtual {p0, v0}, Lfg0;->f(I)Z

    move-result p0

    return p0
.end method

.method public hasNestedScrollingParent(I)Z
    .registers 2

    .line 1
    if-nez p1, :cond_a

    .line 2
    .line 3
    invoke-virtual {p0}, Lj21;->hasNestedScrollingParent()Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    if-eqz p0, :cond_a

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_a
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public isNestedScrollingEnabled()Z
    .registers 1

    .line 1
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 2
    .line 3
    iget-boolean p0, p0, Lfg0;->d:Z

    .line 4
    .line 5
    return p0
.end method

.method public isRefreshing()Z
    .registers 1

    .line 1
    iget-boolean p0, p0, Lj21;->mRefreshing:Z

    .line 2
    .line 3
    return p0
.end method

.method public moveToStart(F)V
    .registers 4

    .line 1
    iget v0, p0, Lj21;->mFrom:I

    .line 2
    .line 3
    iget v1, p0, Lj21;->mOriginalOffsetTop:I

    .line 4
    .line 5
    sub-int/2addr v1, v0

    .line 6
    int-to-float v1, v1

    .line 7
    mul-float/2addr v1, p1

    .line 8
    float-to-int p1, v1

    .line 9
    add-int/2addr v0, p1

    .line 10
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 11
    .line 12
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    sub-int/2addr v0, p1

    .line 17
    invoke-virtual {p0, v0}, Lj21;->setTargetOffsetTopAndBottom(I)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public onDetachedFromWindow()V
    .registers 1

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lj21;->reset()V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 7

    .line 1
    invoke-virtual {p0}, Lj21;->a()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    iget-boolean v1, p0, Lj21;->mReturningToStart:Z

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    if-eqz v1, :cond_10

    .line 12
    .line 13
    if-nez v0, :cond_10

    .line 14
    .line 15
    iput-boolean v2, p0, Lj21;->mReturningToStart:Z

    .line 16
    .line 17
    :cond_10
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_94

    .line 22
    .line 23
    iget-boolean v1, p0, Lj21;->mReturningToStart:Z

    .line 24
    .line 25
    if-nez v1, :cond_94

    .line 26
    .line 27
    invoke-virtual {p0}, Lj21;->canChildScrollUp()Z

    .line 28
    .line 29
    .line 30
    move-result v1

    .line 31
    if-nez v1, :cond_94

    .line 32
    .line 33
    iget-boolean v1, p0, Lj21;->mRefreshing:Z

    .line 34
    .line 35
    if-nez v1, :cond_94

    .line 36
    .line 37
    iget-boolean v1, p0, Lj21;->mNestedScrollInProgress:Z

    .line 38
    .line 39
    if-eqz v1, :cond_2a

    .line 40
    .line 41
    goto/16 :goto_94

    .line 42
    .line 43
    :cond_2a
    if-eqz v0, :cond_70

    .line 44
    .line 45
    const/4 v1, 0x1

    .line 46
    const/4 v3, -0x1

    .line 47
    if-eq v0, v1, :cond_6b

    .line 48
    .line 49
    const/4 v4, 0x2

    .line 50
    if-eq v0, v4, :cond_50

    .line 51
    .line 52
    const/4 v4, 0x3

    .line 53
    if-eq v0, v4, :cond_6b

    .line 54
    .line 55
    const/4 v3, 0x6

    .line 56
    if-eq v0, v3, :cond_3a

    .line 57
    .line 58
    goto :goto_91

    .line 59
    :cond_3a
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 60
    .line 61
    .line 62
    move-result v0

    .line 63
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 64
    .line 65
    .line 66
    move-result v3

    .line 67
    iget v4, p0, Lj21;->mActivePointerId:I

    .line 68
    .line 69
    if-ne v3, v4, :cond_91

    .line 70
    .line 71
    if-nez v0, :cond_49

    .line 72
    .line 73
    move v2, v1

    .line 74
    :cond_49
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 75
    .line 76
    .line 77
    move-result p1

    .line 78
    iput p1, p0, Lj21;->mActivePointerId:I

    .line 79
    .line 80
    goto :goto_91

    .line 81
    :cond_50
    iget v0, p0, Lj21;->mActivePointerId:I

    .line 82
    .line 83
    if-ne v0, v3, :cond_5c

    .line 84
    .line 85
    sget-object p0, Lj21;->LOG_TAG:Ljava/lang/String;

    .line 86
    .line 87
    const-string p1, "Got ACTION_MOVE event but don\'t have an active pointer id."

    .line 88
    .line 89
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 90
    .line 91
    .line 92
    return v2

    .line 93
    :cond_5c
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    if-gez v0, :cond_63

    .line 98
    .line 99
    goto :goto_94

    .line 100
    :cond_63
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 101
    .line 102
    .line 103
    move-result p1

    .line 104
    invoke-virtual {p0, p1}, Lj21;->e(F)V

    .line 105
    .line 106
    .line 107
    goto :goto_91

    .line 108
    :cond_6b
    iput-boolean v2, p0, Lj21;->mIsBeingDragged:Z

    .line 109
    .line 110
    iput v3, p0, Lj21;->mActivePointerId:I

    .line 111
    .line 112
    goto :goto_91

    .line 113
    :cond_70
    iget v0, p0, Lj21;->mOriginalOffsetTop:I

    .line 114
    .line 115
    iget-object v1, p0, Lj21;->mCircleView:Lbd;

    .line 116
    .line 117
    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    .line 118
    .line 119
    .line 120
    move-result v1

    .line 121
    sub-int/2addr v0, v1

    .line 122
    invoke-virtual {p0, v0}, Lj21;->setTargetOffsetTopAndBottom(I)V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 126
    .line 127
    .line 128
    move-result v0

    .line 129
    iput v0, p0, Lj21;->mActivePointerId:I

    .line 130
    .line 131
    iput-boolean v2, p0, Lj21;->mIsBeingDragged:Z

    .line 132
    .line 133
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 134
    .line 135
    .line 136
    move-result v0

    .line 137
    if-gez v0, :cond_8b

    .line 138
    .line 139
    goto :goto_94

    .line 140
    :cond_8b
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 141
    .line 142
    .line 143
    move-result p1

    .line 144
    iput p1, p0, Lj21;->mInitialDownY:F

    .line 145
    .line 146
    :cond_91
    :goto_91
    iget-boolean p0, p0, Lj21;->mIsBeingDragged:Z

    .line 147
    .line 148
    return p0

    .line 149
    :cond_94
    :goto_94
    return v2
.end method

.method public onLayout(ZIIII)V
    .registers 8

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 6
    .line 7
    .line 8
    move-result p2

    .line 9
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 10
    .line 11
    .line 12
    move-result p3

    .line 13
    if-nez p3, :cond_f

    .line 14
    .line 15
    goto :goto_1a

    .line 16
    :cond_f
    iget-object p3, p0, Lj21;->mTarget:Landroid/view/View;

    .line 17
    .line 18
    if-nez p3, :cond_16

    .line 19
    .line 20
    invoke-virtual {p0}, Lj21;->a()V

    .line 21
    .line 22
    .line 23
    :cond_16
    iget-object p3, p0, Lj21;->mTarget:Landroid/view/View;

    .line 24
    .line 25
    if-nez p3, :cond_1b

    .line 26
    .line 27
    :goto_1a
    return-void

    .line 28
    :cond_1b
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 29
    .line 30
    .line 31
    move-result p4

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 33
    .line 34
    .line 35
    move-result p5

    .line 36
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    sub-int v0, p1, v0

    .line 41
    .line 42
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 43
    .line 44
    .line 45
    move-result v1

    .line 46
    sub-int/2addr v0, v1

    .line 47
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 48
    .line 49
    .line 50
    move-result v1

    .line 51
    sub-int/2addr p2, v1

    .line 52
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 53
    .line 54
    .line 55
    move-result v1

    .line 56
    sub-int/2addr p2, v1

    .line 57
    add-int/2addr v0, p4

    .line 58
    add-int/2addr p2, p5

    .line 59
    invoke-virtual {p3, p4, p5, v0, p2}, Landroid/view/View;->layout(IIII)V

    .line 60
    .line 61
    .line 62
    iget-object p2, p0, Lj21;->mCircleView:Lbd;

    .line 63
    .line 64
    invoke-virtual {p2}, Landroid/view/View;->getMeasuredWidth()I

    .line 65
    .line 66
    .line 67
    move-result p2

    .line 68
    iget-object p3, p0, Lj21;->mCircleView:Lbd;

    .line 69
    .line 70
    invoke-virtual {p3}, Landroid/view/View;->getMeasuredHeight()I

    .line 71
    .line 72
    .line 73
    move-result p3

    .line 74
    iget-object p4, p0, Lj21;->mCircleView:Lbd;

    .line 75
    .line 76
    div-int/lit8 p1, p1, 0x2

    .line 77
    .line 78
    div-int/lit8 p2, p2, 0x2

    .line 79
    .line 80
    sub-int p5, p1, p2

    .line 81
    .line 82
    iget p0, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 83
    .line 84
    add-int/2addr p1, p2

    .line 85
    add-int/2addr p3, p0

    .line 86
    invoke-virtual {p4, p5, p0, p1, p3}, Landroid/view/View;->layout(IIII)V

    .line 87
    .line 88
    .line 89
    return-void
.end method

.method public onMeasure(II)V
    .registers 6

    .line 1
    invoke-super {p0, p1, p2}, Landroid/view/View;->onMeasure(II)V

    .line 2
    .line 3
    .line 4
    iget-object p1, p0, Lj21;->mTarget:Landroid/view/View;

    .line 5
    .line 6
    if-nez p1, :cond_a

    .line 7
    .line 8
    invoke-virtual {p0}, Lj21;->a()V

    .line 9
    .line 10
    .line 11
    :cond_a
    iget-object p1, p0, Lj21;->mTarget:Landroid/view/View;

    .line 12
    .line 13
    if-nez p1, :cond_f

    .line 14
    .line 15
    goto :goto_61

    .line 16
    :cond_f
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 17
    .line 18
    .line 19
    move-result p2

    .line 20
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    sub-int/2addr p2, v0

    .line 25
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 26
    .line 27
    .line 28
    move-result v0

    .line 29
    sub-int/2addr p2, v0

    .line 30
    const/high16 v0, 0x40000000    # 2.0f

    .line 31
    .line 32
    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 33
    .line 34
    .line 35
    move-result p2

    .line 36
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 37
    .line 38
    .line 39
    move-result v1

    .line 40
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    sub-int/2addr v1, v2

    .line 45
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 46
    .line 47
    .line 48
    move-result v2

    .line 49
    sub-int/2addr v1, v2

    .line 50
    invoke-static {v1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 51
    .line 52
    .line 53
    move-result v1

    .line 54
    invoke-virtual {p1, p2, v1}, Landroid/view/View;->measure(II)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 58
    .line 59
    iget p2, p0, Lj21;->mCircleDiameter:I

    .line 60
    .line 61
    invoke-static {p2, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 62
    .line 63
    .line 64
    move-result p2

    .line 65
    iget v1, p0, Lj21;->mCircleDiameter:I

    .line 66
    .line 67
    invoke-static {v1, v0}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 68
    .line 69
    .line 70
    move-result v0

    .line 71
    invoke-virtual {p1, p2, v0}, Landroid/view/View;->measure(II)V

    .line 72
    .line 73
    .line 74
    const/4 p1, -0x1

    .line 75
    iput p1, p0, Lj21;->mCircleViewIndex:I

    .line 76
    .line 77
    const/4 p1, 0x0

    .line 78
    :goto_4d
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    .line 79
    .line 80
    .line 81
    move-result p2

    .line 82
    if-ge p1, p2, :cond_61

    .line 83
    .line 84
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 85
    .line 86
    .line 87
    move-result-object p2

    .line 88
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 89
    .line 90
    if-ne p2, v0, :cond_5e

    .line 91
    .line 92
    iput p1, p0, Lj21;->mCircleViewIndex:I

    .line 93
    .line 94
    return-void

    .line 95
    :cond_5e
    add-int/lit8 p1, p1, 0x1

    .line 96
    .line 97
    goto :goto_4d

    .line 98
    :cond_61
    :goto_61
    return-void
.end method

.method public onNestedFling(Landroid/view/View;FFZ)Z
    .registers 5

    .line 1
    invoke-virtual {p0, p2, p3, p4}, Lj21;->dispatchNestedFling(FFZ)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public onNestedPreFling(Landroid/view/View;FF)Z
    .registers 4

    .line 1
    invoke-virtual {p0, p2, p3}, Lj21;->dispatchNestedPreFling(FF)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public onNestedPreScroll(Landroid/view/View;II[I)V
    .registers 9

    .line 1
    const/4 p1, 0x0

    .line 2
    const/4 v0, 0x1

    .line 3
    if-lez p3, :cond_1f

    .line 4
    .line 5
    iget v1, p0, Lj21;->mTotalUnconsumed:F

    .line 6
    .line 7
    cmpl-float v2, v1, p1

    .line 8
    .line 9
    if-lez v2, :cond_1f

    .line 10
    .line 11
    int-to-float v2, p3

    .line 12
    cmpl-float v3, v2, v1

    .line 13
    .line 14
    if-lez v3, :cond_15

    .line 15
    .line 16
    float-to-int v1, v1

    .line 17
    aput v1, p4, v0

    .line 18
    .line 19
    iput p1, p0, Lj21;->mTotalUnconsumed:F

    .line 20
    .line 21
    goto :goto_1a

    .line 22
    :cond_15
    sub-float/2addr v1, v2

    .line 23
    iput v1, p0, Lj21;->mTotalUnconsumed:F

    .line 24
    .line 25
    aput p3, p4, v0

    .line 26
    .line 27
    :goto_1a
    iget v1, p0, Lj21;->mTotalUnconsumed:F

    .line 28
    .line 29
    invoke-virtual {p0, v1}, Lj21;->c(F)V

    .line 30
    .line 31
    .line 32
    :cond_1f
    iget-boolean v1, p0, Lj21;->mUsingCustomStart:Z

    .line 33
    .line 34
    if-eqz v1, :cond_3c

    .line 35
    .line 36
    if-lez p3, :cond_3c

    .line 37
    .line 38
    iget v1, p0, Lj21;->mTotalUnconsumed:F

    .line 39
    .line 40
    cmpl-float p1, v1, p1

    .line 41
    .line 42
    if-nez p1, :cond_3c

    .line 43
    .line 44
    aget p1, p4, v0

    .line 45
    .line 46
    sub-int p1, p3, p1

    .line 47
    .line 48
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    .line 49
    .line 50
    .line 51
    move-result p1

    .line 52
    if-lez p1, :cond_3c

    .line 53
    .line 54
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 55
    .line 56
    const/16 v1, 0x8

    .line 57
    .line 58
    invoke-virtual {p1, v1}, Landroid/view/View;->setVisibility(I)V

    .line 59
    .line 60
    .line 61
    :cond_3c
    iget-object p1, p0, Lj21;->mParentScrollConsumed:[I

    .line 62
    .line 63
    const/4 v1, 0x0

    .line 64
    aget v2, p4, v1

    .line 65
    .line 66
    sub-int/2addr p2, v2

    .line 67
    aget v2, p4, v0

    .line 68
    .line 69
    sub-int/2addr p3, v2

    .line 70
    const/4 v2, 0x0

    .line 71
    invoke-virtual {p0, p2, p3, p1, v2}, Lj21;->dispatchNestedPreScroll(II[I[I)Z

    .line 72
    .line 73
    .line 74
    move-result p0

    .line 75
    if-eqz p0, :cond_5a

    .line 76
    .line 77
    aget p0, p4, v1

    .line 78
    .line 79
    aget p2, p1, v1

    .line 80
    .line 81
    add-int/2addr p0, p2

    .line 82
    aput p0, p4, v1

    .line 83
    .line 84
    aget p0, p4, v0

    .line 85
    .line 86
    aget p1, p1, v0

    .line 87
    .line 88
    add-int/2addr p0, p1

    .line 89
    aput p0, p4, v0

    .line 90
    .line 91
    :cond_5a
    return-void
.end method

.method public onNestedPreScroll(Landroid/view/View;II[II)V
    .registers 6

    if-nez p5, :cond_5

    .line 92
    invoke-virtual {p0, p1, p2, p3, p4}, Lj21;->onNestedPreScroll(Landroid/view/View;II[I)V

    :cond_5
    return-void
.end method

.method public onNestedScroll(Landroid/view/View;IIII)V
    .registers 14

    const/4 v6, 0x0

    .line 62
    iget-object v7, p0, Lj21;->mNestedScrollingV2ConsumedCompat:[I

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v7}, Lj21;->onNestedScroll(Landroid/view/View;IIIII[I)V

    return-void
.end method

.method public onNestedScroll(Landroid/view/View;IIIII)V
    .registers 15

    .line 61
    iget-object v7, p0, Lj21;->mNestedScrollingV2ConsumedCompat:[I

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move v6, p6

    invoke-virtual/range {v0 .. v7}, Lj21;->onNestedScroll(Landroid/view/View;IIIII[I)V

    return-void
.end method

.method public onNestedScroll(Landroid/view/View;IIIII[I)V
    .registers 17

    .line 1
    if-eqz p6, :cond_3

    .line 2
    .line 3
    goto :goto_3b

    .line 4
    :cond_3
    const/4 p1, 0x1

    .line 5
    aget v0, p7, p1

    .line 6
    .line 7
    iget-object v6, p0, Lj21;->mParentOffsetInWindow:[I

    .line 8
    .line 9
    move-object v1, p0

    .line 10
    move v2, p2

    .line 11
    move v3, p3

    .line 12
    move v4, p4

    .line 13
    move v5, p5

    .line 14
    move v7, p6

    .line 15
    move-object/from16 v8, p7

    .line 16
    .line 17
    invoke-virtual/range {v1 .. v8}, Lj21;->dispatchNestedScroll(IIII[II[I)V

    .line 18
    .line 19
    .line 20
    aget p2, p7, p1

    .line 21
    .line 22
    sub-int/2addr p2, v0

    .line 23
    sub-int p2, p5, p2

    .line 24
    .line 25
    if-nez p2, :cond_20

    .line 26
    .line 27
    iget-object p3, p0, Lj21;->mParentOffsetInWindow:[I

    .line 28
    .line 29
    aget p3, p3, p1

    .line 30
    .line 31
    add-int/2addr p5, p3

    .line 32
    goto :goto_21

    .line 33
    :cond_20
    move p5, p2

    .line 34
    :goto_21
    if-gez p5, :cond_3b

    .line 35
    .line 36
    invoke-virtual {p0}, Lj21;->canChildScrollUp()Z

    .line 37
    .line 38
    .line 39
    move-result p3

    .line 40
    if-nez p3, :cond_3b

    .line 41
    .line 42
    iget p3, p0, Lj21;->mTotalUnconsumed:F

    .line 43
    .line 44
    invoke-static {p5}, Ljava/lang/Math;->abs(I)I

    .line 45
    .line 46
    .line 47
    move-result p4

    .line 48
    int-to-float p4, p4

    .line 49
    add-float/2addr p3, p4

    .line 50
    iput p3, p0, Lj21;->mTotalUnconsumed:F

    .line 51
    .line 52
    invoke-virtual {p0, p3}, Lj21;->c(F)V

    .line 53
    .line 54
    .line 55
    aget p0, p7, p1

    .line 56
    .line 57
    add-int/2addr p0, p2

    .line 58
    aput p0, p7, p1

    .line 59
    .line 60
    :cond_3b
    :goto_3b
    return-void
.end method

.method public onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V
    .registers 4

    .line 1
    iget-object p1, p0, Lj21;->mNestedScrollingParentHelper:Lig0;

    .line 2
    .line 3
    iput p3, p1, Lig0;->a:I

    .line 4
    .line 5
    and-int/lit8 p1, p3, 0x2

    .line 6
    .line 7
    invoke-virtual {p0, p1}, Lj21;->startNestedScroll(I)Z

    .line 8
    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    iput p1, p0, Lj21;->mTotalUnconsumed:F

    .line 12
    .line 13
    const/4 p1, 0x1

    .line 14
    iput-boolean p1, p0, Lj21;->mNestedScrollInProgress:Z

    .line 15
    .line 16
    return-void
.end method

.method public onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;II)V
    .registers 5

    if-nez p4, :cond_5

    .line 17
    invoke-virtual {p0, p1, p2, p3}, Lj21;->onNestedScrollAccepted(Landroid/view/View;Landroid/view/View;I)V

    :cond_5
    return-void
.end method

.method public onRestoreInstanceState(Landroid/os/Parcelable;)V
    .registers 3

    .line 1
    check-cast p1, Li21;

    .line 2
    .line 3
    invoke-virtual {p1}, Landroid/view/AbsSavedState;->getSuperState()Landroid/os/Parcelable;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-super {p0, v0}, Landroid/view/View;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    iget-boolean p1, p1, Li21;->f:Z

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Lj21;->setRefreshing(Z)V

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onSaveInstanceState()Landroid/os/Parcelable;
    .registers 3

    .line 1
    invoke-super {p0}, Landroid/view/View;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Li21;

    .line 6
    .line 7
    iget-boolean p0, p0, Lj21;->mRefreshing:Z

    .line 8
    .line 9
    invoke-direct {v1, v0, p0}, Li21;-><init>(Landroid/os/Parcelable;Z)V

    .line 10
    .line 11
    .line 12
    return-object v1
.end method

.method public onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z
    .registers 4

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-eqz p1, :cond_14

    .line 6
    .line 7
    iget-boolean p1, p0, Lj21;->mReturningToStart:Z

    .line 8
    .line 9
    if-nez p1, :cond_14

    .line 10
    .line 11
    iget-boolean p0, p0, Lj21;->mRefreshing:Z

    .line 12
    .line 13
    if-nez p0, :cond_14

    .line 14
    .line 15
    and-int/lit8 p0, p3, 0x2

    .line 16
    .line 17
    if-eqz p0, :cond_14

    .line 18
    .line 19
    const/4 p0, 0x1

    .line 20
    return p0

    .line 21
    :cond_14
    const/4 p0, 0x0

    .line 22
    return p0
.end method

.method public onStartNestedScroll(Landroid/view/View;Landroid/view/View;II)Z
    .registers 5

    if-nez p4, :cond_7

    .line 23
    invoke-virtual {p0, p1, p2, p3}, Lj21;->onStartNestedScroll(Landroid/view/View;Landroid/view/View;I)Z

    move-result p0

    return p0

    :cond_7
    const/4 p0, 0x0

    return p0
.end method

.method public onStopNestedScroll(Landroid/view/View;)V
    .registers 4

    .line 1
    iget-object p1, p0, Lj21;->mNestedScrollingParentHelper:Lig0;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    iput v0, p1, Lig0;->a:I

    .line 5
    .line 6
    iput-boolean v0, p0, Lj21;->mNestedScrollInProgress:Z

    .line 7
    .line 8
    iget p1, p0, Lj21;->mTotalUnconsumed:F

    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    cmpl-float v1, p1, v0

    .line 12
    .line 13
    if-lez v1, :cond_13

    .line 14
    .line 15
    invoke-virtual {p0, p1}, Lj21;->b(F)V

    .line 16
    .line 17
    .line 18
    iput v0, p0, Lj21;->mTotalUnconsumed:F

    .line 19
    .line 20
    :cond_13
    invoke-virtual {p0}, Lj21;->stopNestedScroll()V

    .line 21
    .line 22
    .line 23
    return-void
.end method

.method public onStopNestedScroll(Landroid/view/View;I)V
    .registers 3

    if-nez p2, :cond_5

    .line 24
    invoke-virtual {p0, p1}, Lj21;->onStopNestedScroll(Landroid/view/View;)V

    :cond_5
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 7

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-boolean v1, p0, Lj21;->mReturningToStart:Z

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_d

    .line 9
    .line 10
    if-nez v0, :cond_d

    .line 11
    .line 12
    iput-boolean v2, p0, Lj21;->mReturningToStart:Z

    .line 13
    .line 14
    :cond_d
    invoke-virtual {p0}, Landroid/view/View;->isEnabled()Z

    .line 15
    .line 16
    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_c3

    .line 19
    .line 20
    iget-boolean v1, p0, Lj21;->mReturningToStart:Z

    .line 21
    .line 22
    if-nez v1, :cond_c3

    .line 23
    .line 24
    invoke-virtual {p0}, Lj21;->canChildScrollUp()Z

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    if-nez v1, :cond_c3

    .line 29
    .line 30
    iget-boolean v1, p0, Lj21;->mRefreshing:Z

    .line 31
    .line 32
    if-nez v1, :cond_c3

    .line 33
    .line 34
    iget-boolean v1, p0, Lj21;->mNestedScrollInProgress:Z

    .line 35
    .line 36
    if-eqz v1, :cond_27

    .line 37
    .line 38
    goto/16 :goto_c3

    .line 39
    .line 40
    :cond_27
    const/4 v1, 0x1

    .line 41
    if-eqz v0, :cond_ba

    .line 42
    .line 43
    const/high16 v3, 0x3f000000    # 0.5f

    .line 44
    .line 45
    if-eq v0, v1, :cond_95

    .line 46
    .line 47
    const/4 v4, 0x2

    .line 48
    if-eq v0, v4, :cond_66

    .line 49
    .line 50
    const/4 v3, 0x3

    .line 51
    if-eq v0, v3, :cond_c3

    .line 52
    .line 53
    const/4 v3, 0x5

    .line 54
    if-eq v0, v3, :cond_51

    .line 55
    .line 56
    const/4 v3, 0x6

    .line 57
    if-eq v0, v3, :cond_3b

    .line 58
    .line 59
    goto :goto_94

    .line 60
    :cond_3b
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 61
    .line 62
    .line 63
    move-result v0

    .line 64
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 65
    .line 66
    .line 67
    move-result v3

    .line 68
    iget v4, p0, Lj21;->mActivePointerId:I

    .line 69
    .line 70
    if-ne v3, v4, :cond_94

    .line 71
    .line 72
    if-nez v0, :cond_4a

    .line 73
    .line 74
    move v2, v1

    .line 75
    :cond_4a
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 76
    .line 77
    .line 78
    move-result p1

    .line 79
    iput p1, p0, Lj21;->mActivePointerId:I

    .line 80
    .line 81
    return v1

    .line 82
    :cond_51
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 83
    .line 84
    .line 85
    move-result v0

    .line 86
    if-gez v0, :cond_5f

    .line 87
    .line 88
    sget-object p0, Lj21;->LOG_TAG:Ljava/lang/String;

    .line 89
    .line 90
    const-string p1, "Got ACTION_POINTER_DOWN event but have an invalid action index."

    .line 91
    .line 92
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 93
    .line 94
    .line 95
    return v2

    .line 96
    :cond_5f
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 97
    .line 98
    .line 99
    move-result p1

    .line 100
    iput p1, p0, Lj21;->mActivePointerId:I

    .line 101
    .line 102
    return v1

    .line 103
    :cond_66
    iget v0, p0, Lj21;->mActivePointerId:I

    .line 104
    .line 105
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 106
    .line 107
    .line 108
    move-result v0

    .line 109
    if-gez v0, :cond_76

    .line 110
    .line 111
    sget-object p0, Lj21;->LOG_TAG:Ljava/lang/String;

    .line 112
    .line 113
    const-string p1, "Got ACTION_MOVE event but have an invalid active pointer id."

    .line 114
    .line 115
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 116
    .line 117
    .line 118
    return v2

    .line 119
    :cond_76
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 120
    .line 121
    .line 122
    move-result p1

    .line 123
    invoke-virtual {p0, p1}, Lj21;->e(F)V

    .line 124
    .line 125
    .line 126
    iget-boolean v0, p0, Lj21;->mIsBeingDragged:Z

    .line 127
    .line 128
    if-eqz v0, :cond_94

    .line 129
    .line 130
    iget v0, p0, Lj21;->mInitialMotionY:F

    .line 131
    .line 132
    sub-float/2addr p1, v0

    .line 133
    mul-float/2addr p1, v3

    .line 134
    const/4 v0, 0x0

    .line 135
    cmpl-float v0, p1, v0

    .line 136
    .line 137
    if-lez v0, :cond_c3

    .line 138
    .line 139
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 140
    .line 141
    .line 142
    move-result-object v0

    .line 143
    invoke-interface {v0, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 144
    .line 145
    .line 146
    invoke-virtual {p0, p1}, Lj21;->c(F)V

    .line 147
    .line 148
    .line 149
    :cond_94
    :goto_94
    return v1

    .line 150
    :cond_95
    iget v0, p0, Lj21;->mActivePointerId:I

    .line 151
    .line 152
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 153
    .line 154
    .line 155
    move-result v0

    .line 156
    if-gez v0, :cond_a5

    .line 157
    .line 158
    sget-object p0, Lj21;->LOG_TAG:Ljava/lang/String;

    .line 159
    .line 160
    const-string p1, "Got ACTION_UP event but don\'t have an active pointer id."

    .line 161
    .line 162
    invoke-static {p0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 163
    .line 164
    .line 165
    return v2

    .line 166
    :cond_a5
    iget-boolean v1, p0, Lj21;->mIsBeingDragged:Z

    .line 167
    .line 168
    if-eqz v1, :cond_b6

    .line 169
    .line 170
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 171
    .line 172
    .line 173
    move-result p1

    .line 174
    iget v0, p0, Lj21;->mInitialMotionY:F

    .line 175
    .line 176
    sub-float/2addr p1, v0

    .line 177
    mul-float/2addr p1, v3

    .line 178
    iput-boolean v2, p0, Lj21;->mIsBeingDragged:Z

    .line 179
    .line 180
    invoke-virtual {p0, p1}, Lj21;->b(F)V

    .line 181
    .line 182
    .line 183
    :cond_b6
    const/4 p1, -0x1

    .line 184
    iput p1, p0, Lj21;->mActivePointerId:I

    .line 185
    .line 186
    return v2

    .line 187
    :cond_ba
    invoke-virtual {p1, v2}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 188
    .line 189
    .line 190
    move-result p1

    .line 191
    iput p1, p0, Lj21;->mActivePointerId:I

    .line 192
    .line 193
    iput-boolean v2, p0, Lj21;->mIsBeingDragged:Z

    .line 194
    .line 195
    return v1

    .line 196
    :cond_c3
    :goto_c3
    return v2
.end method

.method public requestDisallowInterceptTouchEvent(Z)V
    .registers 4

    .line 1
    iget-object v0, p0, Lj21;->mTarget:Landroid/view/View;

    .line 2
    .line 3
    if-eqz v0, :cond_1b

    .line 4
    .line 5
    sget-object v1, Lj91;->a:Ljava/util/WeakHashMap;

    .line 6
    .line 7
    invoke-static {v0}, Ld91;->f(Landroid/view/View;)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_1b

    .line 12
    .line 13
    iget-boolean v0, p0, Lj21;->mEnableLegacyRequestDisallowInterceptTouch:Z

    .line 14
    .line 15
    if-eqz v0, :cond_11

    .line 16
    .line 17
    goto :goto_1a

    .line 18
    :cond_11
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    if-eqz p0, :cond_1a

    .line 23
    .line 24
    invoke-interface {p0, p1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 25
    .line 26
    .line 27
    :cond_1a
    :goto_1a
    return-void

    .line 28
    :cond_1b
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    .line 29
    .line 30
    .line 31
    return-void
.end method

.method public reset()V
    .registers 3

    .line 1
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lj21;->mProgress:Lgd;

    .line 7
    .line 8
    invoke-virtual {v0}, Lgd;->stop()V

    .line 9
    .line 10
    .line 11
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 12
    .line 13
    const/16 v1, 0x8

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    .line 16
    .line 17
    .line 18
    const/16 v0, 0xff

    .line 19
    .line 20
    invoke-direct {p0, v0}, Lj21;->setColorViewAlpha(I)V

    .line 21
    .line 22
    .line 23
    iget-boolean v0, p0, Lj21;->mScale:Z

    .line 24
    .line 25
    if-eqz v0, :cond_1f

    .line 26
    .line 27
    const/4 v0, 0x0

    .line 28
    invoke-virtual {p0, v0}, Lj21;->setAnimationProgress(F)V

    .line 29
    .line 30
    .line 31
    goto :goto_27

    .line 32
    :cond_1f
    iget v0, p0, Lj21;->mOriginalOffsetTop:I

    .line 33
    .line 34
    iget v1, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 35
    .line 36
    sub-int/2addr v0, v1

    .line 37
    invoke-virtual {p0, v0}, Lj21;->setTargetOffsetTopAndBottom(I)V

    .line 38
    .line 39
    .line 40
    :goto_27
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 41
    .line 42
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    iput v0, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 47
    .line 48
    return-void
.end method

.method public setAnimationProgress(F)V
    .registers 3

    .line 1
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 2
    .line 3
    invoke-virtual {v0, p1}, Landroid/view/View;->setScaleX(F)V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lj21;->mCircleView:Lbd;

    .line 7
    .line 8
    invoke-virtual {p0, p1}, Landroid/view/View;->setScaleY(F)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public varargs setColorScheme([I)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    invoke-virtual {p0, p1}, Lj21;->setColorSchemeResources([I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public varargs setColorSchemeColors([I)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Lj21;->a()V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lj21;->mProgress:Lgd;

    .line 5
    .line 6
    iget-object v0, p0, Lgd;->f:Lfd;

    .line 7
    .line 8
    iput-object p1, v0, Lfd;->i:[I

    .line 9
    .line 10
    const/4 p1, 0x0

    .line 11
    invoke-virtual {v0, p1}, Lfd;->a(I)V

    .line 12
    .line 13
    .line 14
    invoke-virtual {v0, p1}, Lfd;->a(I)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p0}, Landroid/graphics/drawable/Drawable;->invalidateSelf()V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public varargs setColorSchemeResources([I)V
    .registers 6

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    array-length v1, p1

    .line 6
    new-array v1, v1, [I

    .line 7
    .line 8
    const/4 v2, 0x0

    .line 9
    :goto_8
    array-length v3, p1

    .line 10
    if-ge v2, v3, :cond_16

    .line 11
    .line 12
    aget v3, p1, v2

    .line 13
    .line 14
    invoke-virtual {v0, v3}, Landroid/content/Context;->getColor(I)I

    .line 15
    .line 16
    .line 17
    move-result v3

    .line 18
    aput v3, v1, v2

    .line 19
    .line 20
    add-int/lit8 v2, v2, 0x1

    .line 21
    .line 22
    goto :goto_8

    .line 23
    :cond_16
    invoke-virtual {p0, v1}, Lj21;->setColorSchemeColors([I)V

    .line 24
    .line 25
    .line 26
    return-void
.end method

.method public setDistanceToTriggerSync(I)V
    .registers 2

    .line 1
    int-to-float p1, p1

    .line 2
    iput p1, p0, Lj21;->mTotalDragDistance:F

    .line 3
    .line 4
    return-void
.end method

.method public setEnabled(Z)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->setEnabled(Z)V

    .line 2
    .line 3
    .line 4
    if-nez p1, :cond_8

    .line 5
    .line 6
    invoke-virtual {p0}, Lj21;->reset()V

    .line 7
    .line 8
    .line 9
    :cond_8
    return-void
.end method

.method public setLegacyRequestDisallowInterceptTouchEventEnabled(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    iput-boolean p1, p0, Lj21;->mEnableLegacyRequestDisallowInterceptTouch:Z

    .line 2
    .line 3
    return-void
.end method

.method public setNestedScrollingEnabled(Z)V
    .registers 4

    .line 1
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 2
    .line 3
    iget-boolean v0, p0, Lfg0;->d:Z

    .line 4
    .line 5
    if-eqz v0, :cond_d

    .line 6
    .line 7
    iget-object v0, p0, Lfg0;->c:Landroid/view/ViewGroup;

    .line 8
    .line 9
    sget-object v1, Lj91;->a:Ljava/util/WeakHashMap;

    .line 10
    .line 11
    invoke-static {v0}, Ld91;->k(Landroid/view/View;)V

    .line 12
    .line 13
    .line 14
    :cond_d
    iput-boolean p1, p0, Lfg0;->d:Z

    .line 15
    .line 16
    return-void
.end method

.method public setOnChildScrollUpCallback(Lg21;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lj21;->mChildScrollUpCallback:Lg21;

    .line 2
    .line 3
    return-void
.end method

.method public setOnRefreshListener(Lh21;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lj21;->mListener:Lh21;

    .line 2
    .line 3
    return-void
.end method

.method public setProgressBackgroundColor(I)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    invoke-virtual {p0, p1}, Lj21;->setProgressBackgroundColorSchemeResource(I)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public setProgressBackgroundColorSchemeColor(I)V
    .registers 2

    .line 1
    iget-object p0, p0, Lj21;->mCircleView:Lbd;

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lbd;->setBackgroundColor(I)V

    .line 4
    .line 5
    .line 6
    return-void
.end method

.method public setProgressBackgroundColorSchemeResource(I)V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0, p1}, Landroid/content/Context;->getColor(I)I

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    invoke-virtual {p0, p1}, Lj21;->setProgressBackgroundColorSchemeColor(I)V

    .line 10
    .line 11
    .line 12
    return-void
.end method

.method public setProgressViewEndTarget(ZI)V
    .registers 3

    .line 1
    iput p2, p0, Lj21;->mSpinnerOffsetEnd:I

    .line 2
    .line 3
    iput-boolean p1, p0, Lj21;->mScale:Z

    .line 4
    .line 5
    iget-object p0, p0, Lj21;->mCircleView:Lbd;

    .line 6
    .line 7
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    .line 8
    .line 9
    .line 10
    return-void
.end method

.method public setProgressViewOffset(ZII)V
    .registers 4

    .line 1
    iput-boolean p1, p0, Lj21;->mScale:Z

    .line 2
    .line 3
    iput p2, p0, Lj21;->mOriginalOffsetTop:I

    .line 4
    .line 5
    iput p3, p0, Lj21;->mSpinnerOffsetEnd:I

    .line 6
    .line 7
    const/4 p1, 0x1

    .line 8
    iput-boolean p1, p0, Lj21;->mUsingCustomStart:Z

    .line 9
    .line 10
    invoke-virtual {p0}, Lj21;->reset()V

    .line 11
    .line 12
    .line 13
    const/4 p1, 0x0

    .line 14
    iput-boolean p1, p0, Lj21;->mRefreshing:Z

    .line 15
    .line 16
    return-void
.end method

.method public setRefreshing(Z)V
    .registers 5

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_49

    .line 3
    .line 4
    iget-boolean v1, p0, Lj21;->mRefreshing:Z

    .line 5
    .line 6
    if-eq v1, p1, :cond_49

    .line 7
    .line 8
    iput-boolean p1, p0, Lj21;->mRefreshing:Z

    .line 9
    .line 10
    iget-boolean p1, p0, Lj21;->mUsingCustomStart:Z

    .line 11
    .line 12
    iget v1, p0, Lj21;->mSpinnerOffsetEnd:I

    .line 13
    .line 14
    if-nez p1, :cond_12

    .line 15
    .line 16
    iget p1, p0, Lj21;->mOriginalOffsetTop:I

    .line 17
    .line 18
    add-int/2addr v1, p1

    .line 19
    :cond_12
    iget p1, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 20
    .line 21
    sub-int/2addr v1, p1

    .line 22
    invoke-virtual {p0, v1}, Lj21;->setTargetOffsetTopAndBottom(I)V

    .line 23
    .line 24
    .line 25
    iput-boolean v0, p0, Lj21;->mNotify:Z

    .line 26
    .line 27
    iget-object p1, p0, Lj21;->mRefreshListener:Landroid/view/animation/Animation$AnimationListener;

    .line 28
    .line 29
    iget-object v1, p0, Lj21;->mCircleView:Lbd;

    .line 30
    .line 31
    invoke-virtual {v1, v0}, Landroid/view/View;->setVisibility(I)V

    .line 32
    .line 33
    .line 34
    iget-object v0, p0, Lj21;->mProgress:Lgd;

    .line 35
    .line 36
    const/16 v1, 0xff

    .line 37
    .line 38
    invoke-virtual {v0, v1}, Lgd;->setAlpha(I)V

    .line 39
    .line 40
    .line 41
    new-instance v0, Lf21;

    .line 42
    .line 43
    const/4 v1, 0x2

    .line 44
    invoke-direct {v0, p0, v1}, Lf21;-><init>(Lj21;I)V

    .line 45
    .line 46
    .line 47
    iput-object v0, p0, Lj21;->mScaleAnimation:Landroid/view/animation/Animation;

    .line 48
    .line 49
    iget v1, p0, Lj21;->mMediumAnimationDuration:I

    .line 50
    .line 51
    int-to-long v1, v1

    .line 52
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 53
    .line 54
    .line 55
    if-eqz p1, :cond_3c

    .line 56
    .line 57
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 58
    .line 59
    iput-object p1, v0, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 60
    .line 61
    :cond_3c
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 62
    .line 63
    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    .line 64
    .line 65
    .line 66
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 67
    .line 68
    iget-object p0, p0, Lj21;->mScaleAnimation:Landroid/view/animation/Animation;

    .line 69
    .line 70
    invoke-virtual {p1, p0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 71
    .line 72
    .line 73
    return-void

    .line 74
    :cond_49
    invoke-virtual {p0, p1, v0}, Lj21;->d(ZZ)V

    .line 75
    .line 76
    .line 77
    return-void
.end method

.method public setSize(I)V
    .registers 4

    .line 1
    if-eqz p1, :cond_6

    .line 2
    .line 3
    const/4 v0, 0x1

    .line 4
    if-eq p1, v0, :cond_6

    .line 5
    .line 6
    return-void

    .line 7
    :cond_6
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 8
    .line 9
    .line 10
    move-result-object v0

    .line 11
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    if-nez p1, :cond_19

    .line 16
    .line 17
    const/high16 v1, 0x42600000    # 56.0f

    .line 18
    .line 19
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 20
    .line 21
    mul-float/2addr v0, v1

    .line 22
    float-to-int v0, v0

    .line 23
    iput v0, p0, Lj21;->mCircleDiameter:I

    .line 24
    .line 25
    goto :goto_21

    .line 26
    :cond_19
    const/high16 v1, 0x42200000    # 40.0f

    .line 27
    .line 28
    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    .line 29
    .line 30
    mul-float/2addr v0, v1

    .line 31
    float-to-int v0, v0

    .line 32
    iput v0, p0, Lj21;->mCircleDiameter:I

    .line 33
    .line 34
    :goto_21
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 35
    .line 36
    const/4 v1, 0x0

    .line 37
    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 38
    .line 39
    .line 40
    iget-object v0, p0, Lj21;->mProgress:Lgd;

    .line 41
    .line 42
    invoke-virtual {v0, p1}, Lgd;->c(I)V

    .line 43
    .line 44
    .line 45
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 46
    .line 47
    iget-object p0, p0, Lj21;->mProgress:Lgd;

    .line 48
    .line 49
    invoke-virtual {p1, p0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 50
    .line 51
    .line 52
    return-void
.end method

.method public setSlingshotDistance(I)V
    .registers 2

    .line 1
    iput p1, p0, Lj21;->mCustomSlingshotDistance:I

    .line 2
    .line 3
    return-void
.end method

.method public setTargetOffsetTopAndBottom(I)V
    .registers 4

    .line 1
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/View;->bringToFront()V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 7
    .line 8
    sget-object v1, Lj91;->a:Ljava/util/WeakHashMap;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Landroid/view/View;->offsetTopAndBottom(I)V

    .line 11
    .line 12
    .line 13
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 14
    .line 15
    invoke-virtual {p1}, Landroid/view/View;->getTop()I

    .line 16
    .line 17
    .line 18
    move-result p1

    .line 19
    iput p1, p0, Lj21;->mCurrentTargetOffsetTop:I

    .line 20
    .line 21
    return-void
.end method

.method public startNestedScroll(I)Z
    .registers 3

    .line 13
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    const/4 v0, 0x0

    .line 14
    invoke-virtual {p0, p1, v0}, Lfg0;->g(II)Z

    move-result p0

    return p0
.end method

.method public startNestedScroll(II)Z
    .registers 3

    .line 1
    if-nez p2, :cond_a

    .line 2
    .line 3
    invoke-virtual {p0, p1}, Lj21;->startNestedScroll(I)Z

    .line 4
    .line 5
    .line 6
    move-result p0

    .line 7
    if-eqz p0, :cond_a

    .line 8
    .line 9
    const/4 p0, 0x1

    .line 10
    return p0

    .line 11
    :cond_a
    const/4 p0, 0x0

    .line 12
    return p0
.end method

.method public startScaleDownAnimation(Landroid/view/animation/Animation$AnimationListener;)V
    .registers 5

    .line 1
    new-instance v0, Lf21;

    .line 2
    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-direct {v0, p0, v1}, Lf21;-><init>(Lj21;I)V

    .line 5
    .line 6
    .line 7
    iput-object v0, p0, Lj21;->mScaleDownAnimation:Landroid/view/animation/Animation;

    .line 8
    .line 9
    const-wide/16 v1, 0x96

    .line 10
    .line 11
    invoke-virtual {v0, v1, v2}, Landroid/view/animation/Animation;->setDuration(J)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Lj21;->mCircleView:Lbd;

    .line 15
    .line 16
    iput-object p1, v0, Lbd;->f:Landroid/view/animation/Animation$AnimationListener;

    .line 17
    .line 18
    invoke-virtual {v0}, Landroid/view/View;->clearAnimation()V

    .line 19
    .line 20
    .line 21
    iget-object p1, p0, Lj21;->mCircleView:Lbd;

    .line 22
    .line 23
    iget-object p0, p0, Lj21;->mScaleDownAnimation:Landroid/view/animation/Animation;

    .line 24
    .line 25
    invoke-virtual {p1, p0}, Landroid/view/View;->startAnimation(Landroid/view/animation/Animation;)V

    .line 26
    .line 27
    .line 28
    return-void
.end method

.method public stopNestedScroll()V
    .registers 2

    .line 1
    iget-object p0, p0, Lj21;->mNestedScrollingChildHelper:Lfg0;

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    invoke-virtual {p0, v0}, Lfg0;->h(I)V

    .line 5
    .line 6
    .line 7
    return-void
.end method

.method public stopNestedScroll(I)V
    .registers 2

    if-nez p1, :cond_5

    .line 8
    invoke-virtual {p0}, Lj21;->stopNestedScroll()V

    :cond_5
    return-void
.end method
