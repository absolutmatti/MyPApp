###### Class defpackage.gz (gz)
.class public final Lgz;
.super Ljava/lang/RuntimeException;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final f:Lhz;

.field public final g:Ljava/lang/Throwable;


# direct methods
.method public constructor <init>(Lhz;Ljava/lang/Throwable;)V
    .registers 3

    .line 1
    invoke-direct {p0, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lgz;->f:Lhz;

    .line 5
    .line 6
    iput-object p2, p0, Lgz;->g:Ljava/lang/Throwable;

    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final getCause()Ljava/lang/Throwable;
    .registers 1

    .line 1
    iget-object p0, p0, Lgz;->g:Ljava/lang/Throwable;

    .line 2
    .line 3
    return-object p0
.end method
