###### Class defpackage.xf0 (xf0)
.class public final Lxf0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/util/RandomAccess;


# instance fields
.field public f:[Ljava/lang/Object;

.field public g:I


# direct methods
.method public constructor <init>([Ljava/lang/Object;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lxf0;->f:[Ljava/lang/Object;

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput p1, p0, Lxf0;->g:I

    .line 8
    .line 9
    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;)V
    .registers 5

    .line 1
    iget v0, p0, Lxf0;->g:I

    .line 2
    .line 3
    add-int/lit8 v0, v0, 0x1

    .line 4
    .line 5
    iget-object v1, p0, Lxf0;->f:[Ljava/lang/Object;

    .line 6
    .line 7
    array-length v2, v1

    .line 8
    if-ge v2, v0, :cond_16

    .line 9
    .line 10
    array-length v2, v1

    .line 11
    mul-int/lit8 v2, v2, 0x2

    .line 12
    .line 13
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    .line 14
    .line 15
    .line 16
    move-result v0

    .line 17
    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    iput-object v0, p0, Lxf0;->f:[Ljava/lang/Object;

    .line 22
    .line 23
    :cond_16
    iget-object v0, p0, Lxf0;->f:[Ljava/lang/Object;

    .line 24
    .line 25
    iget v1, p0, Lxf0;->g:I

    .line 26
    .line 27
    aput-object p1, v0, v1

    .line 28
    .line 29
    add-int/lit8 v1, v1, 0x1

    .line 30
    .line 31
    iput v1, p0, Lxf0;->g:I

    .line 32
    .line 33
    return-void
.end method

.method public final c()V
    .registers 4

    .line 1
    iget-object v0, p0, Lxf0;->f:[Ljava/lang/Object;

    .line 2
    .line 3
    iget v1, p0, Lxf0;->g:I

    .line 4
    .line 5
    add-int/lit8 v1, v1, -0x1

    .line 6
    .line 7
    :goto_6
    const/4 v2, -0x1

    .line 8
    if-ge v2, v1, :cond_f

    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    aput-object v2, v0, v1

    .line 12
    .line 13
    add-int/lit8 v1, v1, -0x1

    .line 14
    .line 15
    goto :goto_6

    .line 16
    :cond_f
    const/4 v0, 0x0

    .line 17
    iput v0, p0, Lxf0;->g:I

    .line 18
    .line 19
    return-void
.end method
