###### Class defpackage.ga0 (ga0)
.class public abstract Lga0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# direct methods
.method public static a(Lp80;)Lia0;
    .registers 3

    .line 1
    new-instance v0, Lia0;

    .line 2
    .line 3
    move-object v1, p0

    .line 4
    check-cast v1, Lp91;

    .line 5
    .line 6
    invoke-interface {v1}, Lp91;->getViewModelStore()Lo91;

    .line 7
    .line 8
    .line 9
    move-result-object v1

    .line 10
    invoke-direct {v0, p0, v1}, Lia0;-><init>(Lp80;Lo91;)V

    .line 11
    .line 12
    .line 13
    return-object v0
.end method
