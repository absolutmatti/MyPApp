###### Class defpackage.cd1 (cd1)
.class public interface abstract Lcd1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final a:Ls10;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    sget-object v0, Ls10;->p:Ls10;

    .line 2
    .line 3
    sput-object v0, Lcd1;->a:Ls10;

    .line 4
    .line 5
    return-void
.end method
