###### Class defpackage.dd1 (dd1)
.class public final Ldd1;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lcd1;


# static fields
.field public static final synthetic b:I


# direct methods
.method static constructor <clinit>()V
    .registers 9

    .line 1
    const/4 v0, 0x1

    .line 2
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 3
    .line 4
    .line 5
    move-result-object v1

    .line 6
    const/4 v0, 0x2

    .line 7
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 8
    .line 9
    .line 10
    move-result-object v2

    .line 11
    const/4 v0, 0x4

    .line 12
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 13
    .line 14
    .line 15
    move-result-object v3

    .line 16
    const/16 v0, 0x8

    .line 17
    .line 18
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    const/16 v0, 0x10

    .line 23
    .line 24
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 25
    .line 26
    .line 27
    move-result-object v5

    .line 28
    const/16 v0, 0x20

    .line 29
    .line 30
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 31
    .line 32
    .line 33
    move-result-object v6

    .line 34
    const/16 v0, 0x40

    .line 35
    .line 36
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 37
    .line 38
    .line 39
    move-result-object v7

    .line 40
    const/16 v0, 0x80

    .line 41
    .line 42
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 43
    .line 44
    .line 45
    move-result-object v8

    .line 46
    filled-new-array/range {v1 .. v8}, [Ljava/lang/Integer;

    .line 47
    .line 48
    .line 49
    move-result-object v0

    .line 50
    new-instance v1, Ljava/util/ArrayList;

    .line 51
    .line 52
    new-instance v2, Ly8;

    .line 53
    .line 54
    invoke-direct {v2, v0}, Ly8;-><init>([Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 58
    .line 59
    .line 60
    return-void
.end method

.method public static a(Landroid/app/Activity;)Lbd1;
    .registers 8

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 2
    .line 3
    const/16 v1, 0x1d

    .line 4
    .line 5
    const/16 v2, 0x1e

    .line 6
    .line 7
    if-lt v0, v2, :cond_1c

    .line 8
    .line 9
    const-class v0, Landroid/view/WindowManager;

    .line 10
    .line 11
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Landroid/view/WindowManager;

    .line 16
    .line 17
    invoke-static {v0}, Le1;->z(Landroid/view/WindowManager;)Landroid/view/WindowMetrics;

    .line 18
    .line 19
    .line 20
    move-result-object v0

    .line 21
    invoke-static {v0}, Le1;->j(Landroid/view/WindowMetrics;)Landroid/graphics/Rect;

    .line 22
    .line 23
    .line 24
    move-result-object v0

    .line 25
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    .line 27
    .line 28
    goto :goto_7f

    .line 29
    :cond_1c
    if-lt v0, v1, :cond_7b

    .line 30
    .line 31
    const-string v0, "dd1"

    .line 32
    .line 33
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 34
    .line 35
    .line 36
    move-result-object v3

    .line 37
    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 38
    .line 39
    .line 40
    move-result-object v3

    .line 41
    :try_start_28
    const-class v4, Landroid/content/res/Configuration;

    .line 42
    .line 43
    const-string v5, "windowConfiguration"

    .line 44
    .line 45
    invoke-virtual {v4, v5}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 46
    .line 47
    .line 48
    move-result-object v4

    .line 49
    const/4 v5, 0x1

    .line 50
    invoke-virtual {v4, v5}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v4, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v3

    .line 57
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    const-string v5, "getBounds"

    .line 62
    .line 63
    const/4 v6, 0x0

    .line 64
    invoke-virtual {v4, v5, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 65
    .line 66
    .line 67
    move-result-object v4

    .line 68
    new-instance v5, Landroid/graphics/Rect;

    .line 69
    .line 70
    invoke-virtual {v4, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 71
    .line 72
    .line 73
    move-result-object v3

    .line 74
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    .line 76
    .line 77
    check-cast v3, Landroid/graphics/Rect;

    .line 78
    .line 79
    invoke-direct {v5, v3}, Landroid/graphics/Rect;-><init>(Landroid/graphics/Rect;)V
    :try_end_51
    .catch Ljava/lang/NoSuchFieldException; {:try_start_28 .. :try_end_51} :catch_59
    .catch Ljava/lang/NoSuchMethodException; {:try_start_28 .. :try_end_51} :catch_57
    .catch Ljava/lang/IllegalAccessException; {:try_start_28 .. :try_end_51} :catch_55
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_28 .. :try_end_51} :catch_53

    .line 80
    .line 81
    .line 82
    move-object v0, v5

    .line 83
    goto :goto_7f

    .line 84
    :catch_53
    move-exception v3

    .line 85
    goto :goto_5b

    .line 86
    :catch_55
    move-exception v3

    .line 87
    goto :goto_63

    .line 88
    :catch_57
    move-exception v3

    .line 89
    goto :goto_6b

    .line 90
    :catch_59
    move-exception v3

    .line 91
    goto :goto_73

    .line 92
    :goto_5b
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 93
    .line 94
    .line 95
    invoke-static {p0}, Ldd1;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    goto :goto_7f

    .line 100
    :goto_63
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 101
    .line 102
    .line 103
    invoke-static {p0}, Ldd1;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 104
    .line 105
    .line 106
    move-result-object v0

    .line 107
    goto :goto_7f

    .line 108
    :goto_6b
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 109
    .line 110
    .line 111
    invoke-static {p0}, Ldd1;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    goto :goto_7f

    .line 116
    :goto_73
    invoke-static {v0, v3}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 117
    .line 118
    .line 119
    invoke-static {p0}, Ldd1;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 120
    .line 121
    .line 122
    move-result-object v0

    .line 123
    goto :goto_7f

    .line 124
    :cond_7b
    invoke-static {p0}, Ldd1;->b(Landroid/app/Activity;)Landroid/graphics/Rect;

    .line 125
    .line 126
    .line 127
    move-result-object v0

    .line 128
    :goto_7f
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 129
    .line 130
    if-lt v3, v2, :cond_94

    .line 131
    .line 132
    if-lt v3, v2, :cond_8c

    .line 133
    .line 134
    sget-object v1, Loh;->a:Loh;

    .line 135
    .line 136
    invoke-virtual {v1, p0}, Loh;->a(Landroid/content/Context;)Lvc1;

    .line 137
    .line 138
    .line 139
    move-result-object p0

    .line 140
    goto :goto_c4

    .line 141
    :cond_8c
    new-instance p0, Ljava/lang/Exception;

    .line 142
    .line 143
    const-string v0, "Incompatible SDK version"

    .line 144
    .line 145
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 146
    .line 147
    .line 148
    throw p0

    .line 149
    :cond_94
    const/16 p0, 0x22

    .line 150
    .line 151
    if-lt v3, p0, :cond_9e

    .line 152
    .line 153
    new-instance p0, Ljc1;

    .line 154
    .line 155
    invoke-direct {p0}, Ljc1;-><init>()V

    .line 156
    .line 157
    .line 158
    goto :goto_bd

    .line 159
    :cond_9e
    const/16 p0, 0x1f

    .line 160
    .line 161
    if-lt v3, p0, :cond_a8

    .line 162
    .line 163
    new-instance p0, Lic1;

    .line 164
    .line 165
    invoke-direct {p0}, Lic1;-><init>()V

    .line 166
    .line 167
    .line 168
    goto :goto_bd

    .line 169
    :cond_a8
    if-lt v3, v2, :cond_b0

    .line 170
    .line 171
    new-instance p0, Lhc1;

    .line 172
    .line 173
    invoke-direct {p0}, Lhc1;-><init>()V

    .line 174
    .line 175
    .line 176
    goto :goto_bd

    .line 177
    :cond_b0
    if-lt v3, v1, :cond_b8

    .line 178
    .line 179
    new-instance p0, Lgc1;

    .line 180
    .line 181
    invoke-direct {p0}, Lgc1;-><init>()V

    .line 182
    .line 183
    .line 184
    goto :goto_bd

    .line 185
    :cond_b8
    new-instance p0, Lfc1;

    .line 186
    .line 187
    invoke-direct {p0}, Lfc1;-><init>()V

    .line 188
    .line 189
    .line 190
    :goto_bd
    invoke-virtual {p0}, Lkc1;->b()Lvc1;

    .line 191
    .line 192
    .line 193
    move-result-object p0

    .line 194
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 195
    .line 196
    .line 197
    :goto_c4
    new-instance v1, Lbd1;

    .line 198
    .line 199
    new-instance v2, Lta;

    .line 200
    .line 201
    invoke-direct {v2, v0}, Lta;-><init>(Landroid/graphics/Rect;)V

    .line 202
    .line 203
    .line 204
    invoke-direct {v1, v2, p0}, Lbd1;-><init>(Lta;Lvc1;)V

    .line 205
    .line 206
    .line 207
    return-object v1
.end method

.method public static b(Landroid/app/Activity;)Landroid/graphics/Rect;
    .registers 12

    .line 1
    const-string v0, "dd1"

    .line 2
    .line 3
    new-instance v1, Landroid/graphics/Rect;

    .line 4
    .line 5
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 9
    .line 10
    .line 11
    move-result-object v2

    .line 12
    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 13
    .line 14
    .line 15
    move-result-object v2

    .line 16
    const/4 v3, 0x1

    .line 17
    const/4 v4, 0x0

    .line 18
    :try_start_11
    const-class v5, Landroid/content/res/Configuration;

    .line 19
    .line 20
    const-string v6, "windowConfiguration"

    .line 21
    .line 22
    invoke-virtual {v5, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 23
    .line 24
    .line 25
    move-result-object v5

    .line 26
    invoke-virtual {v5, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 27
    .line 28
    .line 29
    invoke-virtual {v5, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v2

    .line 33
    invoke-virtual {p0}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    if-eqz v5, :cond_45

    .line 38
    .line 39
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    .line 41
    .line 42
    move-result-object v5

    .line 43
    const-string v6, "getBounds"

    .line 44
    .line 45
    invoke-virtual {v5, v6, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 46
    .line 47
    .line 48
    move-result-object v5

    .line 49
    invoke-virtual {v5, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object v2

    .line 53
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 54
    .line 55
    .line 56
    check-cast v2, Landroid/graphics/Rect;

    .line 57
    .line 58
    invoke-virtual {v1, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V

    .line 59
    .line 60
    .line 61
    goto :goto_97

    .line 62
    :catch_3d
    move-exception v2

    .line 63
    goto :goto_5c

    .line 64
    :catch_3f
    move-exception v2

    .line 65
    goto :goto_6b

    .line 66
    :catch_41
    move-exception v2

    .line 67
    goto :goto_7a

    .line 68
    :catch_43
    move-exception v2

    .line 69
    goto :goto_89

    .line 70
    :cond_45
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 71
    .line 72
    .line 73
    move-result-object v5

    .line 74
    const-string v6, "getAppBounds"

    .line 75
    .line 76
    invoke-virtual {v5, v6, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 77
    .line 78
    .line 79
    move-result-object v5

    .line 80
    invoke-virtual {v5, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    check-cast v2, Landroid/graphics/Rect;

    .line 88
    .line 89
    invoke-virtual {v1, v2}, Landroid/graphics/Rect;->set(Landroid/graphics/Rect;)V
    :try_end_5b
    .catch Ljava/lang/NoSuchFieldException; {:try_start_11 .. :try_end_5b} :catch_43
    .catch Ljava/lang/NoSuchMethodException; {:try_start_11 .. :try_end_5b} :catch_41
    .catch Ljava/lang/IllegalAccessException; {:try_start_11 .. :try_end_5b} :catch_3f
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_11 .. :try_end_5b} :catch_3d

    .line 90
    .line 91
    .line 92
    goto :goto_97

    .line 93
    :goto_5c
    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 94
    .line 95
    .line 96
    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 97
    .line 98
    .line 99
    move-result-object v2

    .line 100
    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 101
    .line 102
    .line 103
    move-result-object v2

    .line 104
    invoke-virtual {v2, v1}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 105
    .line 106
    .line 107
    goto :goto_97

    .line 108
    :goto_6b
    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 109
    .line 110
    .line 111
    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 112
    .line 113
    .line 114
    move-result-object v2

    .line 115
    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 116
    .line 117
    .line 118
    move-result-object v2

    .line 119
    invoke-virtual {v2, v1}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 120
    .line 121
    .line 122
    goto :goto_97

    .line 123
    :goto_7a
    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 124
    .line 125
    .line 126
    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 127
    .line 128
    .line 129
    move-result-object v2

    .line 130
    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 131
    .line 132
    .line 133
    move-result-object v2

    .line 134
    invoke-virtual {v2, v1}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 135
    .line 136
    .line 137
    goto :goto_97

    .line 138
    :goto_89
    invoke-static {v0, v2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 139
    .line 140
    .line 141
    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 146
    .line 147
    .line 148
    move-result-object v2

    .line 149
    invoke-virtual {v2, v1}, Landroid/view/Display;->getRectSize(Landroid/graphics/Rect;)V

    .line 150
    .line 151
    .line 152
    :goto_97
    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    invoke-interface {v2}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    .line 157
    .line 158
    .line 159
    move-result-object v2

    .line 160
    new-instance v5, Landroid/graphics/Point;

    .line 161
    .line 162
    invoke-direct {v5}, Landroid/graphics/Point;-><init>()V

    .line 163
    .line 164
    .line 165
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v2, v5}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    .line 169
    .line 170
    .line 171
    invoke-virtual {p0}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 172
    .line 173
    .line 174
    move-result v6

    .line 175
    const/4 v7, 0x0

    .line 176
    if-nez v6, :cond_e1

    .line 177
    .line 178
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 179
    .line 180
    .line 181
    move-result-object v6

    .line 182
    const-string v8, "dimen"

    .line 183
    .line 184
    const-string v9, "android"

    .line 185
    .line 186
    const-string v10, "navigation_bar_height"

    .line 187
    .line 188
    invoke-virtual {v6, v10, v8, v9}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    .line 189
    .line 190
    .line 191
    move-result v8

    .line 192
    if-lez v8, :cond_c6

    .line 193
    .line 194
    invoke-virtual {v6, v8}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 195
    .line 196
    .line 197
    move-result v6

    .line 198
    goto :goto_c7

    .line 199
    :cond_c6
    move v6, v7

    .line 200
    :goto_c7
    iget v8, v1, Landroid/graphics/Rect;->bottom:I

    .line 201
    .line 202
    add-int/2addr v8, v6

    .line 203
    iget v9, v5, Landroid/graphics/Point;->y:I

    .line 204
    .line 205
    if-ne v8, v9, :cond_d1

    .line 206
    .line 207
    iput v8, v1, Landroid/graphics/Rect;->bottom:I

    .line 208
    .line 209
    goto :goto_e1

    .line 210
    :cond_d1
    iget v8, v1, Landroid/graphics/Rect;->right:I

    .line 211
    .line 212
    add-int/2addr v8, v6

    .line 213
    iget v9, v5, Landroid/graphics/Point;->x:I

    .line 214
    .line 215
    if-ne v8, v9, :cond_db

    .line 216
    .line 217
    iput v8, v1, Landroid/graphics/Rect;->right:I

    .line 218
    .line 219
    goto :goto_e1

    .line 220
    :cond_db
    iget v8, v1, Landroid/graphics/Rect;->left:I

    .line 221
    .line 222
    if-ne v8, v6, :cond_e1

    .line 223
    .line 224
    iput v7, v1, Landroid/graphics/Rect;->left:I

    .line 225
    .line 226
    :cond_e1
    :goto_e1
    invoke-virtual {v1}, Landroid/graphics/Rect;->width()I

    .line 227
    .line 228
    .line 229
    move-result v6

    .line 230
    iget v8, v5, Landroid/graphics/Point;->x:I

    .line 231
    .line 232
    if-lt v6, v8, :cond_f1

    .line 233
    .line 234
    invoke-virtual {v1}, Landroid/graphics/Rect;->height()I

    .line 235
    .line 236
    .line 237
    move-result v6

    .line 238
    iget v8, v5, Landroid/graphics/Point;->y:I

    .line 239
    .line 240
    if-ge v6, v8, :cond_19e

    .line 241
    .line 242
    :cond_f1
    invoke-virtual {p0}, Landroid/app/Activity;->isInMultiWindowMode()Z

    .line 243
    .line 244
    .line 245
    move-result p0

    .line 246
    if-nez p0, :cond_19e

    .line 247
    .line 248
    :try_start_f7
    const-string p0, "android.view.DisplayInfo"

    .line 249
    .line 250
    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    .line 251
    .line 252
    .line 253
    move-result-object p0

    .line 254
    invoke-virtual {p0, v4}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 255
    .line 256
    .line 257
    move-result-object p0

    .line 258
    invoke-virtual {p0, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {p0, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object p0

    .line 265
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 266
    .line 267
    .line 268
    move-result-object v6

    .line 269
    const-string v8, "getDisplayInfo"

    .line 270
    .line 271
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 272
    .line 273
    .line 274
    move-result-object v9

    .line 275
    filled-new-array {v9}, [Ljava/lang/Class;

    .line 276
    .line 277
    .line 278
    move-result-object v9

    .line 279
    invoke-virtual {v6, v8, v9}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 280
    .line 281
    .line 282
    move-result-object v6

    .line 283
    invoke-virtual {v6, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 284
    .line 285
    .line 286
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 287
    .line 288
    .line 289
    move-result-object v8

    .line 290
    invoke-virtual {v6, v2, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 294
    .line 295
    .line 296
    move-result-object v2

    .line 297
    const-string v6, "displayCutout"

    .line 298
    .line 299
    invoke-virtual {v2, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    .line 300
    .line 301
    .line 302
    move-result-object v2

    .line 303
    invoke-virtual {v2, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 304
    .line 305
    .line 306
    invoke-virtual {v2, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 307
    .line 308
    .line 309
    move-result-object p0

    .line 310
    instance-of v2, p0, Landroid/view/DisplayCutout;

    .line 311
    .line 312
    if-eqz v2, :cond_160

    .line 313
    .line 314
    check-cast p0, Landroid/view/DisplayCutout;
    :try_end_13b
    .catch Ljava/lang/ClassNotFoundException; {:try_start_f7 .. :try_end_13b} :catch_147
    .catch Ljava/lang/NoSuchMethodException; {:try_start_f7 .. :try_end_13b} :catch_145
    .catch Ljava/lang/NoSuchFieldException; {:try_start_f7 .. :try_end_13b} :catch_143
    .catch Ljava/lang/IllegalAccessException; {:try_start_f7 .. :try_end_13b} :catch_141
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_f7 .. :try_end_13b} :catch_13f
    .catch Ljava/lang/InstantiationException; {:try_start_f7 .. :try_end_13b} :catch_13d

    .line 315
    .line 316
    move-object v4, p0

    .line 317
    goto :goto_160

    .line 318
    :catch_13d
    move-exception p0

    .line 319
    goto :goto_149

    .line 320
    :catch_13f
    move-exception p0

    .line 321
    goto :goto_14d

    .line 322
    :catch_141
    move-exception p0

    .line 323
    goto :goto_151

    .line 324
    :catch_143
    move-exception p0

    .line 325
    goto :goto_155

    .line 326
    :catch_145
    move-exception p0

    .line 327
    goto :goto_159

    .line 328
    :catch_147
    move-exception p0

    .line 329
    goto :goto_15d

    .line 330
    :goto_149
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 331
    .line 332
    .line 333
    goto :goto_160

    .line 334
    :goto_14d
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 335
    .line 336
    .line 337
    goto :goto_160

    .line 338
    :goto_151
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 339
    .line 340
    .line 341
    goto :goto_160

    .line 342
    :goto_155
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 343
    .line 344
    .line 345
    goto :goto_160

    .line 346
    :goto_159
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 347
    .line 348
    .line 349
    goto :goto_160

    .line 350
    :goto_15d
    invoke-static {v0, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 351
    .line 352
    .line 353
    :cond_160
    :goto_160
    if-eqz v4, :cond_19e

    .line 354
    .line 355
    iget p0, v1, Landroid/graphics/Rect;->left:I

    .line 356
    .line 357
    invoke-virtual {v4}, Landroid/view/DisplayCutout;->getSafeInsetLeft()I

    .line 358
    .line 359
    .line 360
    move-result v0

    .line 361
    if-ne p0, v0, :cond_16c

    .line 362
    .line 363
    iput v7, v1, Landroid/graphics/Rect;->left:I

    .line 364
    .line 365
    :cond_16c
    iget p0, v5, Landroid/graphics/Point;->x:I

    .line 366
    .line 367
    iget v0, v1, Landroid/graphics/Rect;->right:I

    .line 368
    .line 369
    sub-int/2addr p0, v0

    .line 370
    invoke-virtual {v4}, Landroid/view/DisplayCutout;->getSafeInsetRight()I

    .line 371
    .line 372
    .line 373
    move-result v0

    .line 374
    if-ne p0, v0, :cond_180

    .line 375
    .line 376
    iget p0, v1, Landroid/graphics/Rect;->right:I

    .line 377
    .line 378
    invoke-virtual {v4}, Landroid/view/DisplayCutout;->getSafeInsetRight()I

    .line 379
    .line 380
    .line 381
    move-result v0

    .line 382
    add-int/2addr v0, p0

    .line 383
    iput v0, v1, Landroid/graphics/Rect;->right:I

    .line 384
    .line 385
    :cond_180
    iget p0, v1, Landroid/graphics/Rect;->top:I

    .line 386
    .line 387
    invoke-virtual {v4}, Landroid/view/DisplayCutout;->getSafeInsetTop()I

    .line 388
    .line 389
    .line 390
    move-result v0

    .line 391
    if-ne p0, v0, :cond_18a

    .line 392
    .line 393
    iput v7, v1, Landroid/graphics/Rect;->top:I

    .line 394
    .line 395
    :cond_18a
    iget p0, v5, Landroid/graphics/Point;->y:I

    .line 396
    .line 397
    iget v0, v1, Landroid/graphics/Rect;->bottom:I

    .line 398
    .line 399
    sub-int/2addr p0, v0

    .line 400
    invoke-virtual {v4}, Landroid/view/DisplayCutout;->getSafeInsetBottom()I

    .line 401
    .line 402
    .line 403
    move-result v0

    .line 404
    if-ne p0, v0, :cond_19e

    .line 405
    .line 406
    iget p0, v1, Landroid/graphics/Rect;->bottom:I

    .line 407
    .line 408
    invoke-virtual {v4}, Landroid/view/DisplayCutout;->getSafeInsetBottom()I

    .line 409
    .line 410
    .line 411
    move-result v0

    .line 412
    add-int/2addr v0, p0

    .line 413
    iput v0, v1, Landroid/graphics/Rect;->bottom:I

    .line 414
    .line 415
    :cond_19e
    return-object v1
.end method
