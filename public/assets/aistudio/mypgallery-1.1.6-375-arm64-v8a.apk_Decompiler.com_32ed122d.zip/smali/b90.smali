###### Class defpackage.b90 (b90)
.class public final Lb90;
.super Loa0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final i:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    .line 1
    invoke-direct {p0}, Loa0;-><init>()V

    .line 2
    .line 3
    .line 4
    iput p1, p0, Lb90;->i:I

    .line 5
    .line 6
    return-void
.end method
