###### Class defpackage.sc (sc)
.class public final Lsc;
.super Lqc;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final i:Leu;


# direct methods
.method public constructor <init>(Leu;Lyh;ILab;)V
    .registers 5

    .line 1
    invoke-direct {p0, p2, p3, p4}, Lqc;-><init>(Lyh;ILab;)V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lsc;->i:Leu;

    .line 5
    .line 6
    return-void
.end method


# virtual methods
.method public final c(Lfu;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Lqc;->g:I

    .line 2
    .line 3
    const/4 v1, -0x3

    .line 4
    if-ne v0, v1, :cond_84

    .line 5
    .line 6
    invoke-interface {p2}, Lkotlin/coroutines/Continuation;->getContext()Lyh;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 11
    .line 12
    new-instance v2, Ln8;

    .line 13
    .line 14
    const/4 v3, 0x4

    .line 15
    invoke-direct {v2, v3}, Ln8;-><init>(I)V

    .line 16
    .line 17
    .line 18
    iget-object v3, p0, Lqc;->f:Lyh;

    .line 19
    .line 20
    invoke-interface {v3, v1, v2}, Lyh;->k(Ljava/lang/Object;Lsz;)Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    check-cast v1, Ljava/lang/Boolean;

    .line 25
    .line 26
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    if-nez v1, :cond_24

    .line 31
    .line 32
    invoke-interface {v0, v3}, Lyh;->n(Lyh;)Lyh;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    goto :goto_29

    .line 37
    :cond_24
    const/4 v1, 0x0

    .line 38
    invoke-static {v0, v3, v1}, Lrl;->D(Lyh;Lyh;Z)Lyh;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    :goto_29
    invoke-static {v1, v0}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    if-eqz v2, :cond_48

    .line 47
    .line 48
    iget-object p0, p0, Lsc;->i:Leu;

    .line 49
    .line 50
    invoke-interface {p0, p1, p2}, Leu;->c(Lfu;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 51
    .line 52
    .line 53
    move-result-object p0

    .line 54
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    if-ne p0, p1, :cond_3c

    .line 59
    .line 60
    goto :goto_3e

    .line 61
    :cond_3c
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 62
    .line 63
    :goto_3e
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 64
    .line 65
    .line 66
    move-result-object p1

    .line 67
    if-ne p0, p1, :cond_45

    .line 68
    .line 69
    return-object p0

    .line 70
    :cond_45
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 71
    .line 72
    return-object p0

    .line 73
    :cond_48
    sget-object v2, Lmp;->h:Lmp;

    .line 74
    .line 75
    invoke-interface {v1, v2}, Lyh;->q(Lxh;)Lwh;

    .line 76
    .line 77
    .line 78
    move-result-object v3

    .line 79
    invoke-interface {v0, v2}, Lyh;->q(Lxh;)Lwh;

    .line 80
    .line 81
    .line 82
    move-result-object v0

    .line 83
    invoke-static {v3, v0}, Ln40;->c(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 84
    .line 85
    .line 86
    move-result v0

    .line 87
    if-eqz v0, :cond_84

    .line 88
    .line 89
    invoke-interface {p2}, Lkotlin/coroutines/Continuation;->getContext()Lyh;

    .line 90
    .line 91
    .line 92
    move-result-object v0

    .line 93
    instance-of v2, p1, Lot0;

    .line 94
    .line 95
    if-nez v2, :cond_6b

    .line 96
    .line 97
    instance-of v2, p1, Lxg0;

    .line 98
    .line 99
    if-eqz v2, :cond_65

    .line 100
    .line 101
    goto :goto_6b

    .line 102
    :cond_65
    new-instance v2, Lqu;

    .line 103
    .line 104
    invoke-direct {v2, p1, v0}, Lqu;-><init>(Lfu;Lyh;)V

    .line 105
    .line 106
    .line 107
    move-object p1, v2

    .line 108
    :cond_6b
    :goto_6b
    new-instance v0, Lq8;

    .line 109
    .line 110
    const/4 v2, 0x0

    .line 111
    const/4 v3, 0x5

    .line 112
    invoke-direct {v0, p0, v2, v3}, Lq8;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 113
    .line 114
    .line 115
    invoke-static {v1}, Lfo0;->P(Lyh;)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    invoke-static {v1, p1, p0, v0, p2}, Lrl;->d0(Lyh;Ljava/lang/Object;Ljava/lang/Object;Lsz;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 120
    .line 121
    .line 122
    move-result-object p0

    .line 123
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 124
    .line 125
    .line 126
    move-result-object p1

    .line 127
    if-ne p0, p1, :cond_81

    .line 128
    .line 129
    return-object p0

    .line 130
    :cond_81
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 131
    .line 132
    return-object p0

    .line 133
    :cond_84
    invoke-super {p0, p1, p2}, Lqc;->c(Lfu;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 134
    .line 135
    .line 136
    move-result-object p0

    .line 137
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p1

    .line 141
    if-ne p0, p1, :cond_8f

    .line 142
    .line 143
    return-object p0

    .line 144
    :cond_8f
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 145
    .line 146
    return-object p0
.end method

.method public final d(Lum0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 4

    .line 1
    new-instance v0, Lot0;

    .line 2
    .line 3
    invoke-direct {v0, p1}, Lot0;-><init>(Lum0;)V

    .line 4
    .line 5
    .line 6
    iget-object p0, p0, Lsc;->i:Leu;

    .line 7
    .line 8
    invoke-interface {p0, v0, p2}, Leu;->c(Lfu;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 9
    .line 10
    .line 11
    move-result-object p0

    .line 12
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 13
    .line 14
    .line 15
    move-result-object p1

    .line 16
    if-ne p0, p1, :cond_12

    .line 17
    .line 18
    goto :goto_14

    .line 19
    :cond_12
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 20
    .line 21
    :goto_14
    invoke-static {}, Lv40;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object p1

    .line 25
    if-ne p0, p1, :cond_1b

    .line 26
    .line 27
    return-object p0

    .line 28
    :cond_1b
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 29
    .line 30
    return-object p0
.end method

.method public final e(Lyh;ILab;)Lqc;
    .registers 5

    .line 1
    new-instance v0, Lsc;

    .line 2
    .line 3
    iget-object p0, p0, Lsc;->i:Leu;

    .line 4
    .line 5
    invoke-direct {v0, p0, p1, p2, p3}, Lsc;-><init>(Leu;Lyh;ILab;)V

    .line 6
    .line 7
    .line 8
    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lsc;->i:Leu;

    .line 7
    .line 8
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 9
    .line 10
    .line 11
    const-string v1, " -> "

    .line 12
    .line 13
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 14
    .line 15
    .line 16
    invoke-super {p0}, Lqc;->toString()Ljava/lang/String;

    .line 17
    .line 18
    .line 19
    move-result-object p0

    .line 20
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    return-object p0
.end method
