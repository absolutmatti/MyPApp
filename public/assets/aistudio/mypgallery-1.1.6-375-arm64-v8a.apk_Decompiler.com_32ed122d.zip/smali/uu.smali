###### Class defpackage.uu (uu)
.class public final Luu;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lfu;


# instance fields
.field public final synthetic f:I

.field public final synthetic g:Lvo0;


# direct methods
.method public synthetic constructor <init>(Lvo0;I)V
    .registers 3

    .line 1
    iput p2, p0, Luu;->f:I

    .line 2
    .line 3
    iput-object p1, p0, Luu;->g:Lvo0;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final j(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget p2, p0, Luu;->f:I

    .line 2
    .line 3
    iget-object v0, p0, Luu;->g:Lvo0;

    .line 4
    .line 5
    packed-switch p2, :pswitch_data_18

    .line 6
    .line 7
    .line 8
    iput-object p1, v0, Lvo0;->f:Ljava/lang/Object;

    .line 9
    .line 10
    new-instance p1, La;

    .line 11
    .line 12
    invoke-direct {p1, p0}, La;-><init>(Lfu;)V

    .line 13
    .line 14
    .line 15
    throw p1

    .line 16
    :pswitch_f
    iput-object p1, v0, Lvo0;->f:Ljava/lang/Object;

    .line 17
    .line 18
    new-instance p1, La;

    .line 19
    .line 20
    invoke-direct {p1, p0}, La;-><init>(Lfu;)V

    .line 21
    .line 22
    .line 23
    throw p1

    .line 24
    nop

    .line 25
    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_f
    .end packed-switch
.end method
