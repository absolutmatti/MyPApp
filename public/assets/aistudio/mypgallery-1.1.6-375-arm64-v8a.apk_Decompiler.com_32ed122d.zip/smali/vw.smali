###### Class defpackage.vw (vw)
.class public final Lvw;
.super Landroid/widget/FrameLayout;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final A:Lqi;

.field public final B:Ltw;

.field public final C:Lev;

.field public D:Lsw;

.field public E:I

.field public F:I

.field public G:Lxw;

.field public f:Z

.field public final g:Lmw;

.field public final h:Lpw;

.field public i:Ltv;

.field public j:Lep0;

.field public k:Lep0;

.field public final l:Ljava/util/HashSet;

.field public m:Z

.field public n:Ljv;

.field public final o:Ljava/util/HashSet;

.field public p:Lu6;

.field public q:Lio/flutter/plugin/editing/b;

.field public r:Llz0;

.field public s:Lma0;

.field public t:Ld8;

.field public u:Lk4;

.field public v:Lio/flutter/view/b;

.field public w:Landroid/view/textservice/TextServicesManager;

.field public x:Lns0;

.field public final y:Lkw;

.field public final z:Lnw;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lmw;)V
    .registers 6

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-direct {p0, p1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 3
    .line 4
    .line 5
    const/4 p1, 0x0

    .line 6
    iput-boolean p1, p0, Lvw;->f:Z

    .line 7
    .line 8
    new-instance p1, Ljava/util/HashSet;

    .line 9
    .line 10
    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    .line 11
    .line 12
    .line 13
    iput-object p1, p0, Lvw;->l:Ljava/util/HashSet;

    .line 14
    .line 15
    new-instance p1, Ljava/util/HashSet;

    .line 16
    .line 17
    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    .line 18
    .line 19
    .line 20
    iput-object p1, p0, Lvw;->o:Ljava/util/HashSet;

    .line 21
    .line 22
    new-instance p1, Lkw;

    .line 23
    .line 24
    invoke-direct {p1}, Lkw;-><init>()V

    .line 25
    .line 26
    .line 27
    iput-object p1, p0, Lvw;->y:Lkw;

    .line 28
    .line 29
    new-instance p1, Lnw;

    .line 30
    .line 31
    const/4 v0, 0x1

    .line 32
    invoke-direct {p1, v0, p0}, Lnw;-><init>(ILjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    iput-object p1, p0, Lvw;->z:Lnw;

    .line 36
    .line 37
    new-instance p1, Lqi;

    .line 38
    .line 39
    new-instance v1, Landroid/os/Handler;

    .line 40
    .line 41
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 42
    .line 43
    .line 44
    move-result-object v2

    .line 45
    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 46
    .line 47
    .line 48
    invoke-direct {p1, p0, v1, v0}, Lqi;-><init>(Ljava/lang/Object;Landroid/os/Handler;I)V

    .line 49
    .line 50
    .line 51
    iput-object p1, p0, Lvw;->A:Lqi;

    .line 52
    .line 53
    new-instance p1, Ltw;

    .line 54
    .line 55
    invoke-direct {p1, p0}, Ltw;-><init>(Lvw;)V

    .line 56
    .line 57
    .line 58
    iput-object p1, p0, Lvw;->B:Ltw;

    .line 59
    .line 60
    new-instance p1, Lev;

    .line 61
    .line 62
    const/4 v0, 0x2

    .line 63
    invoke-direct {p1, v0, p0}, Lev;-><init>(ILjava/lang/Object;)V

    .line 64
    .line 65
    .line 66
    iput-object p1, p0, Lvw;->C:Lev;

    .line 67
    .line 68
    new-instance p1, Lxw;

    .line 69
    .line 70
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 71
    .line 72
    .line 73
    iput-object p1, p0, Lvw;->G:Lxw;

    .line 74
    .line 75
    iput-object p2, p0, Lvw;->g:Lmw;

    .line 76
    .line 77
    iput-object p2, p0, Lvw;->j:Lep0;

    .line 78
    .line 79
    invoke-virtual {p0}, Lvw;->b()V

    .line 80
    .line 81
    .line 82
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lpw;)V
    .registers 6

    const/4 v0, 0x0

    .line 83
    invoke-direct {p0, p1, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    const/4 p1, 0x0

    .line 84
    iput-boolean p1, p0, Lvw;->f:Z

    .line 85
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, Lvw;->l:Ljava/util/HashSet;

    .line 86
    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, Lvw;->o:Ljava/util/HashSet;

    .line 87
    new-instance p1, Lkw;

    invoke-direct {p1}, Lkw;-><init>()V

    iput-object p1, p0, Lvw;->y:Lkw;

    .line 88
    new-instance p1, Lnw;

    const/4 v0, 0x1

    invoke-direct {p1, v0, p0}, Lnw;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, Lvw;->z:Lnw;

    .line 89
    new-instance p1, Lqi;

    new-instance v1, Landroid/os/Handler;

    .line 90
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    invoke-direct {p1, p0, v1, v0}, Lqi;-><init>(Ljava/lang/Object;Landroid/os/Handler;I)V

    iput-object p1, p0, Lvw;->A:Lqi;

    .line 91
    new-instance p1, Ltw;

    invoke-direct {p1, p0}, Ltw;-><init>(Lvw;)V

    iput-object p1, p0, Lvw;->B:Ltw;

    .line 92
    new-instance p1, Lev;

    const/4 v0, 0x2

    invoke-direct {p1, v0, p0}, Lev;-><init>(ILjava/lang/Object;)V

    iput-object p1, p0, Lvw;->C:Lev;

    .line 93
    new-instance p1, Lxw;

    .line 94
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 95
    iput-object p1, p0, Lvw;->G:Lxw;

    .line 96
    iput-object p2, p0, Lvw;->h:Lpw;

    .line 97
    iput-object p2, p0, Lvw;->j:Lep0;

    .line 98
    invoke-virtual {p0}, Lvw;->b()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 9

    .line 1
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 2
    .line 3
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Lvw;->c()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_c

    .line 11
    .line 12
    return-void

    .line 13
    :cond_c
    iget-object v0, p0, Lvw;->o:Ljava/util/HashSet;

    .line 14
    .line 15
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-nez v1, :cond_1c3

    .line 24
    .line 25
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 30
    .line 31
    .line 32
    move-result-object v0

    .line 33
    iget-object v1, p0, Lvw;->A:Lqi;

    .line 34
    .line 35
    invoke-virtual {v0, v1}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 36
    .line 37
    .line 38
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 39
    .line 40
    iget-object v0, v0, Ljv;->r:Lio/flutter/plugin/platform/c;

    .line 41
    .line 42
    iget-object v1, v0, Lio/flutter/plugin/platform/c;->q:Landroid/util/SparseArray;

    .line 43
    .line 44
    iget-object v2, v0, Lio/flutter/plugin/platform/c;->r:Landroid/util/SparseArray;

    .line 45
    .line 46
    iget-object v3, v0, Lio/flutter/plugin/platform/c;->t:Landroid/util/SparseArray;

    .line 47
    .line 48
    const/4 v4, 0x0

    .line 49
    move v5, v4

    .line 50
    :goto_31
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 51
    .line 52
    .line 53
    move-result v6

    .line 54
    if-ge v5, v6, :cond_45

    .line 55
    .line 56
    invoke-virtual {v3, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 57
    .line 58
    .line 59
    move-result-object v6

    .line 60
    check-cast v6, Ltk0;

    .line 61
    .line 62
    iget-object v7, v0, Lio/flutter/plugin/platform/c;->i:Lvw;

    .line 63
    .line 64
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 65
    .line 66
    .line 67
    add-int/lit8 v5, v5, 0x1

    .line 68
    .line 69
    goto :goto_31

    .line 70
    :cond_45
    move v3, v4

    .line 71
    :goto_46
    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    .line 72
    .line 73
    .line 74
    move-result v5

    .line 75
    if-ge v3, v5, :cond_5a

    .line 76
    .line 77
    invoke-virtual {v2, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 78
    .line 79
    .line 80
    move-result-object v5

    .line 81
    check-cast v5, Lcw;

    .line 82
    .line 83
    iget-object v6, v0, Lio/flutter/plugin/platform/c;->i:Lvw;

    .line 84
    .line 85
    invoke-virtual {v6, v5}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 86
    .line 87
    .line 88
    add-int/lit8 v3, v3, 0x1

    .line 89
    .line 90
    goto :goto_46

    .line 91
    :cond_5a
    invoke-virtual {v0}, Lio/flutter/plugin/platform/c;->d()V

    .line 92
    .line 93
    .line 94
    iget-object v2, v0, Lio/flutter/plugin/platform/c;->s:Landroid/util/SparseArray;

    .line 95
    .line 96
    iget-object v3, v0, Lio/flutter/plugin/platform/c;->i:Lvw;

    .line 97
    .line 98
    if-nez v3, :cond_6b

    .line 99
    .line 100
    const-string v2, "PlatformViewsController"

    .line 101
    .line 102
    const-string v3, "removeOverlaySurfaces called while flutter view is null"

    .line 103
    .line 104
    invoke-static {v2, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 105
    .line 106
    .line 107
    goto :goto_83

    .line 108
    :cond_6b
    move v3, v4

    .line 109
    :goto_6c
    invoke-virtual {v2}, Landroid/util/SparseArray;->size()I

    .line 110
    .line 111
    .line 112
    move-result v5

    .line 113
    if-ge v3, v5, :cond_80

    .line 114
    .line 115
    iget-object v5, v0, Lio/flutter/plugin/platform/c;->i:Lvw;

    .line 116
    .line 117
    invoke-virtual {v2, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v6

    .line 121
    check-cast v6, Landroid/view/View;

    .line 122
    .line 123
    invoke-virtual {v5, v6}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 124
    .line 125
    .line 126
    add-int/lit8 v3, v3, 0x1

    .line 127
    .line 128
    goto :goto_6c

    .line 129
    :cond_80
    invoke-virtual {v2}, Landroid/util/SparseArray;->clear()V

    .line 130
    .line 131
    .line 132
    :goto_83
    const/4 v2, 0x0

    .line 133
    iput-object v2, v0, Lio/flutter/plugin/platform/c;->i:Lvw;

    .line 134
    .line 135
    iput-boolean v4, v0, Lio/flutter/plugin/platform/c;->v:Z

    .line 136
    .line 137
    move v0, v4

    .line 138
    :goto_89
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 139
    .line 140
    .line 141
    move-result v3

    .line 142
    if-ge v0, v3, :cond_9b

    .line 143
    .line 144
    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 145
    .line 146
    .line 147
    move-result-object v3

    .line 148
    check-cast v3, Lnk0;

    .line 149
    .line 150
    invoke-interface {v3}, Lnk0;->onFlutterViewDetached()V

    .line 151
    .line 152
    .line 153
    add-int/lit8 v0, v0, 0x1

    .line 154
    .line 155
    goto :goto_89

    .line 156
    :cond_9b
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 157
    .line 158
    iget-object v0, v0, Ljv;->s:Lal0;

    .line 159
    .line 160
    iget-object v1, v0, Lal0;->n:Landroid/util/SparseArray;

    .line 161
    .line 162
    iget-object v3, v0, Lal0;->o:Landroid/util/SparseArray;

    .line 163
    .line 164
    move v5, v4

    .line 165
    :goto_a4
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 166
    .line 167
    .line 168
    move-result v6

    .line 169
    if-ge v5, v6, :cond_b8

    .line 170
    .line 171
    invoke-virtual {v3, v5}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object v6

    .line 175
    check-cast v6, Lcw;

    .line 176
    .line 177
    iget-object v7, v0, Lal0;->i:Lvw;

    .line 178
    .line 179
    invoke-virtual {v7, v6}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 180
    .line 181
    .line 182
    add-int/lit8 v5, v5, 0x1

    .line 183
    .line 184
    goto :goto_a4

    .line 185
    :cond_b8
    iget-object v3, v0, Lal0;->s:Landroid/view/Surface;

    .line 186
    .line 187
    if-eqz v3, :cond_c3

    .line 188
    .line 189
    invoke-virtual {v3}, Landroid/view/Surface;->release()V

    .line 190
    .line 191
    .line 192
    iput-object v2, v0, Lal0;->s:Landroid/view/Surface;

    .line 193
    .line 194
    iput-object v2, v0, Lal0;->t:Landroid/view/SurfaceControl;

    .line 195
    .line 196
    :cond_c3
    iput-object v2, v0, Lal0;->i:Lvw;

    .line 197
    .line 198
    move v0, v4

    .line 199
    :goto_c6
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 200
    .line 201
    .line 202
    move-result v3

    .line 203
    if-ge v0, v3, :cond_d8

    .line 204
    .line 205
    invoke-virtual {v1, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object v3

    .line 209
    check-cast v3, Lnk0;

    .line 210
    .line 211
    invoke-interface {v3}, Lnk0;->onFlutterViewDetached()V

    .line 212
    .line 213
    .line 214
    add-int/lit8 v0, v0, 0x1

    .line 215
    .line 216
    goto :goto_c6

    .line 217
    :cond_d8
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 218
    .line 219
    iget-object v0, v0, Ljv;->r:Lio/flutter/plugin/platform/c;

    .line 220
    .line 221
    invoke-virtual {v0}, Lio/flutter/plugin/platform/c;->k()V

    .line 222
    .line 223
    .line 224
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 225
    .line 226
    iget-object v0, v0, Ljv;->s:Lal0;

    .line 227
    .line 228
    invoke-virtual {v0}, Lal0;->k()V

    .line 229
    .line 230
    .line 231
    iget-object v0, p0, Lvw;->v:Lio/flutter/view/b;

    .line 232
    .line 233
    const/4 v1, 0x1

    .line 234
    iput-boolean v1, v0, Lio/flutter/view/b;->u:Z

    .line 235
    .line 236
    iget-object v1, v0, Lio/flutter/view/b;->e:Luk0;

    .line 237
    .line 238
    invoke-interface {v1}, Luk0;->k()V

    .line 239
    .line 240
    .line 241
    iput-object v2, v0, Lio/flutter/view/b;->s:Lnw;

    .line 242
    .line 243
    iget-object v1, v0, Lio/flutter/view/b;->c:Landroid/view/accessibility/AccessibilityManager;

    .line 244
    .line 245
    iget-object v3, v0, Lio/flutter/view/b;->v:Lo0;

    .line 246
    .line 247
    invoke-virtual {v1, v3}, Landroid/view/accessibility/AccessibilityManager;->removeAccessibilityStateChangeListener(Landroid/view/accessibility/AccessibilityManager$AccessibilityStateChangeListener;)Z

    .line 248
    .line 249
    .line 250
    iget-object v3, v0, Lio/flutter/view/b;->w:Lp0;

    .line 251
    .line 252
    invoke-virtual {v1, v3}, Landroid/view/accessibility/AccessibilityManager;->removeTouchExplorationStateChangeListener(Landroid/view/accessibility/AccessibilityManager$TouchExplorationStateChangeListener;)Z

    .line 253
    .line 254
    .line 255
    iget-object v1, v0, Lio/flutter/view/b;->f:Landroid/content/ContentResolver;

    .line 256
    .line 257
    iget-object v3, v0, Lio/flutter/view/b;->z:Lw0;

    .line 258
    .line 259
    invoke-virtual {v1, v3}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 260
    .line 261
    .line 262
    iget-object v3, v0, Lio/flutter/view/b;->y:Lx0;

    .line 263
    .line 264
    invoke-virtual {v1, v3}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 265
    .line 266
    .line 267
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 268
    .line 269
    const/16 v3, 0x22

    .line 270
    .line 271
    if-lt v1, v3, :cond_129

    .line 272
    .line 273
    iget-object v1, v0, Lio/flutter/view/b;->a:Landroid/view/View;

    .line 274
    .line 275
    invoke-virtual {v1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 276
    .line 277
    .line 278
    move-result-object v1

    .line 279
    const-string v3, "uimode"

    .line 280
    .line 281
    invoke-virtual {v1, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 282
    .line 283
    .line 284
    move-result-object v1

    .line 285
    check-cast v1, Landroid/app/UiModeManager;

    .line 286
    .line 287
    if-eqz v1, :cond_129

    .line 288
    .line 289
    iget-object v3, v0, Lio/flutter/view/b;->x:Lu0;

    .line 290
    .line 291
    invoke-static {v3}, Lk0;->f(Ljava/lang/Object;)Landroid/app/UiModeManager$ContrastChangeListener;

    .line 292
    .line 293
    .line 294
    move-result-object v3

    .line 295
    invoke-static {v1, v3}, Lk0;->h(Landroid/app/UiModeManager;Landroid/app/UiModeManager$ContrastChangeListener;)V

    .line 296
    .line 297
    .line 298
    :cond_129
    iget-object v0, v0, Lio/flutter/view/b;->b:Ld8;

    .line 299
    .line 300
    iput-object v2, v0, Ld8;->h:Ljava/lang/Object;

    .line 301
    .line 302
    iget-object v0, v0, Ld8;->g:Ljava/lang/Object;

    .line 303
    .line 304
    check-cast v0, Lio/flutter/embedding/engine/FlutterJNI;

    .line 305
    .line 306
    invoke-virtual {v0, v2}, Lio/flutter/embedding/engine/FlutterJNI;->setAccessibilityDelegate(Lwv;)V

    .line 307
    .line 308
    .line 309
    iput-object v2, p0, Lvw;->v:Lio/flutter/view/b;

    .line 310
    .line 311
    iget-object v0, p0, Lvw;->q:Lio/flutter/plugin/editing/b;

    .line 312
    .line 313
    iget-object v0, v0, Lio/flutter/plugin/editing/b;->b:Landroid/view/inputmethod/InputMethodManager;

    .line 314
    .line 315
    invoke-virtual {v0, p0}, Landroid/view/inputmethod/InputMethodManager;->restartInput(Landroid/view/View;)V

    .line 316
    .line 317
    .line 318
    iget-object v0, p0, Lvw;->q:Lio/flutter/plugin/editing/b;

    .line 319
    .line 320
    invoke-virtual {v0}, Lio/flutter/plugin/editing/b;->c()V

    .line 321
    .line 322
    .line 323
    iget-object v0, p0, Lvw;->t:Ld8;

    .line 324
    .line 325
    iget-object v0, v0, Ld8;->g:Ljava/lang/Object;

    .line 326
    .line 327
    check-cast v0, Ljava/util/HashSet;

    .line 328
    .line 329
    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    .line 330
    .line 331
    .line 332
    move-result v0

    .line 333
    if-lez v0, :cond_166

    .line 334
    .line 335
    new-instance v1, Ljava/lang/StringBuilder;

    .line 336
    .line 337
    const-string v3, "A KeyboardManager was destroyed with "

    .line 338
    .line 339
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 340
    .line 341
    .line 342
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 343
    .line 344
    .line 345
    const-string v0, " unhandled redispatch event(s)."

    .line 346
    .line 347
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 348
    .line 349
    .line 350
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 351
    .line 352
    .line 353
    move-result-object v0

    .line 354
    const-string v1, "KeyboardManager"

    .line 355
    .line 356
    invoke-static {v1, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 357
    .line 358
    .line 359
    :cond_166
    iget-object v0, p0, Lvw;->r:Llz0;

    .line 360
    .line 361
    if-eqz v0, :cond_175

    .line 362
    .line 363
    iget-object v1, v0, Llz0;->a:Lns0;

    .line 364
    .line 365
    iput-object v2, v1, Lns0;->g:Ljava/lang/Object;

    .line 366
    .line 367
    iget-object v0, v0, Llz0;->c:Landroid/view/textservice/SpellCheckerSession;

    .line 368
    .line 369
    if-eqz v0, :cond_175

    .line 370
    .line 371
    invoke-virtual {v0}, Landroid/view/textservice/SpellCheckerSession;->close()V

    .line 372
    .line 373
    .line 374
    :cond_175
    iget-object v0, p0, Lvw;->p:Lu6;

    .line 375
    .line 376
    if-eqz v0, :cond_17f

    .line 377
    .line 378
    iget-object v0, v0, Lu6;->h:Ljava/lang/Object;

    .line 379
    .line 380
    check-cast v0, Lnw;

    .line 381
    .line 382
    iput-object v2, v0, Lnw;->g:Ljava/lang/Object;

    .line 383
    .line 384
    :cond_17f
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 385
    .line 386
    iget-object v0, v0, Ljv;->a:Lio/flutter/embedding/engine/renderer/e;

    .line 387
    .line 388
    iput-boolean v4, p0, Lvw;->m:Z

    .line 389
    .line 390
    iget-object v1, p0, Lvw;->C:Lev;

    .line 391
    .line 392
    iget-object v3, v0, Lio/flutter/embedding/engine/renderer/e;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 393
    .line 394
    invoke-virtual {v3, v1}, Lio/flutter/embedding/engine/FlutterJNI;->removeIsDisplayingFlutterUiListener(Lqw;)V

    .line 395
    .line 396
    .line 397
    iget-object v1, v0, Lio/flutter/embedding/engine/renderer/e;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 398
    .line 399
    iget-boolean v3, p0, Lvw;->f:Z

    .line 400
    .line 401
    if-eqz v3, :cond_197

    .line 402
    .line 403
    iget-object v3, p0, Lvw;->B:Ltw;

    .line 404
    .line 405
    invoke-virtual {v1, v3}, Lio/flutter/embedding/engine/FlutterJNI;->removeResizingFlutterUiListener(Lrw;)V

    .line 406
    .line 407
    .line 408
    :cond_197
    invoke-virtual {v0}, Lio/flutter/embedding/engine/renderer/e;->h()V

    .line 409
    .line 410
    .line 411
    invoke-virtual {v1, v4}, Lio/flutter/embedding/engine/FlutterJNI;->setSemanticsEnabled(Z)V

    .line 412
    .line 413
    .line 414
    iget-object v0, p0, Lvw;->k:Lep0;

    .line 415
    .line 416
    if-eqz v0, :cond_1a9

    .line 417
    .line 418
    iget-object v1, p0, Lvw;->j:Lep0;

    .line 419
    .line 420
    iget-object v3, p0, Lvw;->i:Ltv;

    .line 421
    .line 422
    if-ne v1, v3, :cond_1a9

    .line 423
    .line 424
    iput-object v0, p0, Lvw;->j:Lep0;

    .line 425
    .line 426
    :cond_1a9
    iget-object v0, p0, Lvw;->j:Lep0;

    .line 427
    .line 428
    invoke-interface {v0}, Lep0;->a()V

    .line 429
    .line 430
    .line 431
    iget-object v0, p0, Lvw;->i:Ltv;

    .line 432
    .line 433
    if-eqz v0, :cond_1be

    .line 434
    .line 435
    iget-object v0, v0, Ltv;->f:Landroid/media/ImageReader;

    .line 436
    .line 437
    invoke-virtual {v0}, Landroid/media/ImageReader;->close()V

    .line 438
    .line 439
    .line 440
    iget-object v0, p0, Lvw;->i:Ltv;

    .line 441
    .line 442
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 443
    .line 444
    .line 445
    iput-object v2, p0, Lvw;->i:Ltv;

    .line 446
    .line 447
    :cond_1be
    iput-object v2, p0, Lvw;->k:Lep0;

    .line 448
    .line 449
    iput-object v2, p0, Lvw;->n:Ljv;

    .line 450
    .line 451
    return-void

    .line 452
    :cond_1c3
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 453
    .line 454
    .line 455
    move-result-object p0

    .line 456
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 457
    .line 458
    .line 459
    invoke-static {}, Lm0;->o()V

    .line 460
    .line 461
    .line 462
    return-void
.end method

.method public final autofill(Landroid/util/SparseArray;)V
    .registers 14

    .line 1
    iget-object p0, p0, Lvw;->q:Lio/flutter/plugin/editing/b;

    .line 2
    .line 3
    if-eqz p0, :cond_c3

    .line 4
    .line 5
    iget-object v0, p0, Lio/flutter/plugin/editing/b;->f:Lf31;

    .line 6
    .line 7
    if-eqz v0, :cond_c3

    .line 8
    .line 9
    iget-object v1, p0, Lio/flutter/plugin/editing/b;->g:Landroid/util/SparseArray;

    .line 10
    .line 11
    if-eqz v1, :cond_c3

    .line 12
    .line 13
    iget-object v0, v0, Lf31;->j:Lq1;

    .line 14
    .line 15
    if-nez v0, :cond_12

    .line 16
    .line 17
    goto/16 :goto_c3

    .line 18
    .line 19
    :cond_12
    new-instance v1, Ljava/util/HashMap;

    .line 20
    .line 21
    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    .line 22
    .line 23
    .line 24
    const/4 v2, 0x0

    .line 25
    move v3, v2

    .line 26
    :goto_19
    invoke-virtual {p1}, Landroid/util/SparseArray;->size()I

    .line 27
    .line 28
    .line 29
    move-result v4

    .line 30
    if-ge v3, v4, :cond_69

    .line 31
    .line 32
    invoke-virtual {p1, v3}, Landroid/util/SparseArray;->keyAt(I)I

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    iget-object v5, p0, Lio/flutter/plugin/editing/b;->g:Landroid/util/SparseArray;

    .line 37
    .line 38
    invoke-virtual {v5, v4}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 39
    .line 40
    .line 41
    move-result-object v4

    .line 42
    check-cast v4, Lf31;

    .line 43
    .line 44
    if-eqz v4, :cond_66

    .line 45
    .line 46
    iget-object v4, v4, Lf31;->j:Lq1;

    .line 47
    .line 48
    if-nez v4, :cond_32

    .line 49
    .line 50
    goto :goto_66

    .line 51
    :cond_32
    iget-object v4, v4, Lq1;->f:Ljava/lang/Object;

    .line 52
    .line 53
    check-cast v4, Ljava/lang/String;

    .line 54
    .line 55
    invoke-virtual {p1, v3}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v5

    .line 59
    check-cast v5, Landroid/view/autofill/AutofillValue;

    .line 60
    .line 61
    invoke-virtual {v5}, Landroid/view/autofill/AutofillValue;->getTextValue()Ljava/lang/CharSequence;

    .line 62
    .line 63
    .line 64
    move-result-object v5

    .line 65
    invoke-interface {v5}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    .line 66
    .line 67
    .line 68
    move-result-object v7

    .line 69
    new-instance v6, Lh31;

    .line 70
    .line 71
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 72
    .line 73
    .line 74
    move-result v8

    .line 75
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 76
    .line 77
    .line 78
    move-result v9

    .line 79
    const/4 v10, -0x1

    .line 80
    const/4 v11, -0x1

    .line 81
    invoke-direct/range {v6 .. v11}, Lh31;-><init>(Ljava/lang/String;IIII)V

    .line 82
    .line 83
    .line 84
    iget-object v5, v0, Lq1;->f:Ljava/lang/Object;

    .line 85
    .line 86
    check-cast v5, Ljava/lang/String;

    .line 87
    .line 88
    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 89
    .line 90
    .line 91
    move-result v5

    .line 92
    if-eqz v5, :cond_63

    .line 93
    .line 94
    iget-object v4, p0, Lio/flutter/plugin/editing/b;->h:Lv90;

    .line 95
    .line 96
    invoke-virtual {v4, v6}, Lv90;->f(Lh31;)V

    .line 97
    .line 98
    .line 99
    goto :goto_66

    .line 100
    :cond_63
    invoke-virtual {v1, v4, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    :cond_66
    :goto_66
    add-int/lit8 v3, v3, 0x1

    .line 104
    .line 105
    goto :goto_19

    .line 106
    :cond_69
    iget-object p1, p0, Lio/flutter/plugin/editing/b;->d:Lbl0;

    .line 107
    .line 108
    iget-object p0, p0, Lio/flutter/plugin/editing/b;->e:Lk31;

    .line 109
    .line 110
    iget p0, p0, Lk31;->b:I

    .line 111
    .line 112
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    .line 114
    .line 115
    invoke-virtual {v1}, Ljava/util/HashMap;->size()I

    .line 116
    .line 117
    .line 118
    new-instance v0, Ljava/util/HashMap;

    .line 119
    .line 120
    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v1}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    .line 124
    .line 125
    .line 126
    move-result-object v1

    .line 127
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 128
    .line 129
    .line 130
    move-result-object v1

    .line 131
    :goto_82
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 132
    .line 133
    .line 134
    move-result v3

    .line 135
    if-eqz v3, :cond_a9

    .line 136
    .line 137
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v3

    .line 141
    check-cast v3, Ljava/util/Map$Entry;

    .line 142
    .line 143
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    check-cast v4, Lh31;

    .line 148
    .line 149
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 150
    .line 151
    .line 152
    move-result-object v3

    .line 153
    check-cast v3, Ljava/lang/String;

    .line 154
    .line 155
    iget-object v5, v4, Lh31;->a:Ljava/lang/String;

    .line 156
    .line 157
    iget v6, v4, Lh31;->b:I

    .line 158
    .line 159
    iget v4, v4, Lh31;->c:I

    .line 160
    .line 161
    const/4 v7, -0x1

    .line 162
    invoke-static {v5, v6, v4, v7, v7}, Lbl0;->r(Ljava/lang/String;IIII)Ljava/util/HashMap;

    .line 163
    .line 164
    .line 165
    move-result-object v4

    .line 166
    invoke-virtual {v0, v3, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 167
    .line 168
    .line 169
    goto :goto_82

    .line 170
    :cond_a9
    iget-object p1, p1, Lbl0;->f:Ljava/lang/Object;

    .line 171
    .line 172
    check-cast p1, Lte0;

    .line 173
    .line 174
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 175
    .line 176
    .line 177
    move-result-object p0

    .line 178
    const/4 v1, 0x2

    .line 179
    new-array v1, v1, [Ljava/io/Serializable;

    .line 180
    .line 181
    aput-object p0, v1, v2

    .line 182
    .line 183
    const/4 p0, 0x1

    .line 184
    aput-object v0, v1, p0

    .line 185
    .line 186
    invoke-static {v1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    .line 187
    .line 188
    .line 189
    move-result-object p0

    .line 190
    const/4 v0, 0x0

    .line 191
    const-string v1, "TextInputClient.updateEditingStateWithTag"

    .line 192
    .line 193
    invoke-virtual {p1, v1, p0, v0}, Lte0;->a(Ljava/lang/String;Ljava/lang/Object;Lse0;)V

    .line 194
    .line 195
    .line 196
    :cond_c3
    :goto_c3
    return-void
.end method

.method public final b()V
    .registers 2

    .line 1
    iget-object v0, p0, Lvw;->g:Lmw;

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 6
    .line 7
    .line 8
    goto :goto_15

    .line 9
    :cond_8
    iget-object v0, p0, Lvw;->h:Lpw;

    .line 10
    .line 11
    if-eqz v0, :cond_10

    .line 12
    .line 13
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 14
    .line 15
    .line 16
    goto :goto_15

    .line 17
    :cond_10
    iget-object v0, p0, Lvw;->i:Ltv;

    .line 18
    .line 19
    invoke-virtual {p0, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    .line 20
    .line 21
    .line 22
    :goto_15
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-static {v0}, Lt51;->u(Landroid/content/Context;)Z

    .line 27
    .line 28
    .line 29
    move-result v0

    .line 30
    iput-boolean v0, p0, Lvw;->f:Z

    .line 31
    .line 32
    const/4 v0, 0x1

    .line 33
    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusable(Z)V

    .line 34
    .line 35
    .line 36
    invoke-virtual {p0, v0}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p0, v0}, Landroid/view/View;->setImportantForAutofill(I)V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public final c()Z
    .registers 2

    .line 1
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 2
    .line 3
    if-eqz v0, :cond_10

    .line 4
    .line 5
    iget-object v0, v0, Ljv;->a:Lio/flutter/embedding/engine/renderer/e;

    .line 6
    .line 7
    iget-object p0, p0, Lvw;->j:Lep0;

    .line 8
    .line 9
    invoke-interface {p0}, Lep0;->getAttachedRenderer()Lio/flutter/embedding/engine/renderer/e;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    if-ne v0, p0, :cond_10

    .line 14
    .line 15
    const/4 p0, 0x1

    .line 16
    return p0

    .line 17
    :cond_10
    const/4 p0, 0x0

    .line 18
    return p0
.end method

.method public final checkInputConnectionProxy(Landroid/view/View;)Z
    .registers 3

    .line 1
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 2
    .line 3
    if-eqz v0, :cond_2a

    .line 4
    .line 5
    iget-object p0, v0, Ljv;->r:Lio/flutter/plugin/platform/c;

    .line 6
    .line 7
    iget-object p0, p0, Lio/flutter/plugin/platform/c;->p:Ljava/util/HashMap;

    .line 8
    .line 9
    if-nez p1, :cond_b

    .line 10
    .line 11
    goto :goto_15

    .line 12
    :cond_b
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 13
    .line 14
    .line 15
    move-result-object v0

    .line 16
    invoke-virtual {p0, v0}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_17

    .line 21
    .line 22
    :goto_15
    const/4 p0, 0x0

    .line 23
    return p0

    .line 24
    :cond_17
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 25
    .line 26
    .line 27
    move-result-object v0

    .line 28
    invoke-virtual {p0, v0}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    .line 30
    .line 31
    move-result-object p0

    .line 32
    check-cast p0, Landroid/view/View;

    .line 33
    .line 34
    if-ne p0, p1, :cond_25

    .line 35
    .line 36
    const/4 p0, 0x1

    .line 37
    return p0

    .line 38
    :cond_25
    invoke-virtual {p0, p1}, Landroid/view/View;->checkInputConnectionProxy(Landroid/view/View;)Z

    .line 39
    .line 40
    .line 41
    move-result p0

    .line 42
    return p0

    .line 43
    :cond_2a
    invoke-super {p0, p1}, Landroid/view/View;->checkInputConnectionProxy(Landroid/view/View;)Z

    .line 44
    .line 45
    .line 46
    move-result p0

    .line 47
    return p0
.end method

.method public final d()V
    .registers 12

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    iget v0, v0, Landroid/content/res/Configuration;->uiMode:I

    .line 10
    .line 11
    and-int/lit8 v0, v0, 0x30

    .line 12
    .line 13
    const/16 v1, 0x20

    .line 14
    .line 15
    const/4 v2, 0x2

    .line 16
    const/4 v3, 0x1

    .line 17
    if-ne v0, v1, :cond_14

    .line 18
    .line 19
    move v0, v2

    .line 20
    goto :goto_15

    .line 21
    :cond_14
    move v0, v3

    .line 22
    :goto_15
    iget-object v1, p0, Lvw;->w:Landroid/view/textservice/TextServicesManager;

    .line 23
    .line 24
    const/4 v4, 0x0

    .line 25
    if-eqz v1, :cond_4f

    .line 26
    .line 27
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 28
    .line 29
    const/16 v6, 0x1f

    .line 30
    .line 31
    if-lt v5, v6, :cond_4d

    .line 32
    .line 33
    invoke-static {v1}, Ls0;->l(Landroid/view/textservice/TextServicesManager;)Ljava/util/List;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 38
    .line 39
    .line 40
    move-result-object v1

    .line 41
    :cond_28
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 42
    .line 43
    .line 44
    move-result v5

    .line 45
    if-eqz v5, :cond_42

    .line 46
    .line 47
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v5

    .line 51
    check-cast v5, Landroid/view/textservice/SpellCheckerInfo;

    .line 52
    .line 53
    invoke-virtual {v5}, Landroid/view/textservice/SpellCheckerInfo;->getPackageName()Ljava/lang/String;

    .line 54
    .line 55
    .line 56
    move-result-object v5

    .line 57
    const-string v6, "com.google.android.inputmethod.latin"

    .line 58
    .line 59
    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    if-eqz v5, :cond_28

    .line 64
    .line 65
    move v1, v3

    .line 66
    goto :goto_43

    .line 67
    :cond_42
    move v1, v4

    .line 68
    :goto_43
    iget-object v5, p0, Lvw;->w:Landroid/view/textservice/TextServicesManager;

    .line 69
    .line 70
    invoke-static {v5}, Ls0;->w(Landroid/view/textservice/TextServicesManager;)Z

    .line 71
    .line 72
    .line 73
    move-result v5

    .line 74
    if-eqz v5, :cond_4f

    .line 75
    .line 76
    if-eqz v1, :cond_4f

    .line 77
    .line 78
    :cond_4d
    move v1, v3

    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    move v1, v4

    .line 81
    :goto_50
    iget-object v5, p0, Lvw;->n:Ljv;

    .line 82
    .line 83
    iget-object v5, v5, Ljv;->n:Ldu0;

    .line 84
    .line 85
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 86
    .line 87
    .line 88
    iget-object v6, v5, Ldu0;->b:Ld8;

    .line 89
    .line 90
    new-instance v7, Ljava/util/HashMap;

    .line 91
    .line 92
    invoke-direct {v7}, Ljava/util/HashMap;-><init>()V

    .line 93
    .line 94
    .line 95
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 96
    .line 97
    .line 98
    move-result-object v8

    .line 99
    invoke-virtual {v8}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 100
    .line 101
    .line 102
    move-result-object v8

    .line 103
    iget v8, v8, Landroid/content/res/Configuration;->fontScale:F

    .line 104
    .line 105
    invoke-static {v8}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 106
    .line 107
    .line 108
    move-result-object v8

    .line 109
    const-string v9, "textScaleFactor"

    .line 110
    .line 111
    invoke-virtual {v7, v9, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 112
    .line 113
    .line 114
    invoke-virtual {p0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 115
    .line 116
    .line 117
    move-result-object v8

    .line 118
    invoke-virtual {v8}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 119
    .line 120
    .line 121
    move-result-object v8

    .line 122
    const-string v10, "nativeSpellCheckServiceDefined"

    .line 123
    .line 124
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 125
    .line 126
    .line 127
    move-result-object v1

    .line 128
    invoke-virtual {v7, v10, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 129
    .line 130
    .line 131
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 132
    .line 133
    .line 134
    move-result-object v1

    .line 135
    invoke-virtual {v1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    const-string v10, "show_password"

    .line 140
    .line 141
    invoke-static {v1, v10, v3}, Landroid/provider/Settings$System;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;I)I

    .line 142
    .line 143
    .line 144
    move-result v1

    .line 145
    if-ne v1, v3, :cond_93

    .line 146
    .line 147
    move v4, v3

    .line 148
    :cond_93
    const-string v1, "brieflyShowPassword"

    .line 149
    .line 150
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 151
    .line 152
    .line 153
    move-result-object v4

    .line 154
    invoke-virtual {v7, v1, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 158
    .line 159
    .line 160
    move-result-object p0

    .line 161
    invoke-static {p0}, Landroid/text/format/DateFormat;->is24HourFormat(Landroid/content/Context;)Z

    .line 162
    .line 163
    .line 164
    move-result p0

    .line 165
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 166
    .line 167
    .line 168
    move-result-object p0

    .line 169
    const-string v1, "alwaysUse24HourFormat"

    .line 170
    .line 171
    invoke-virtual {v7, v1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    const/4 p0, 0x0

    .line 175
    if-eq v0, v3, :cond_b6

    .line 176
    .line 177
    if-ne v0, v2, :cond_b5

    .line 178
    .line 179
    const-string v0, "dark"

    .line 180
    .line 181
    goto :goto_b8

    .line 182
    :cond_b5
    throw p0

    .line 183
    :cond_b6
    const-string v0, "light"

    .line 184
    .line 185
    :goto_b8
    const-string v2, "platformBrightness"

    .line 186
    .line 187
    invoke-virtual {v7, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    invoke-virtual {v7, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v0

    .line 194
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 195
    .line 196
    .line 197
    invoke-virtual {v7, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 198
    .line 199
    .line 200
    move-result-object v0

    .line 201
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    invoke-virtual {v7, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 209
    .line 210
    .line 211
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 212
    .line 213
    const/16 v1, 0x22

    .line 214
    .line 215
    if-lt v0, v1, :cond_106

    .line 216
    .line 217
    if-nez v8, :cond_db

    .line 218
    .line 219
    goto :goto_106

    .line 220
    :cond_db
    new-instance v0, Lcu0;

    .line 221
    .line 222
    invoke-direct {v0, v8}, Lcu0;-><init>(Landroid/util/DisplayMetrics;)V

    .line 223
    .line 224
    .line 225
    iget-object v1, v5, Ldu0;->a:Ld8;

    .line 226
    .line 227
    iget-object v2, v1, Ld8;->f:Ljava/lang/Object;

    .line 228
    .line 229
    check-cast v2, Ljava/util/concurrent/ConcurrentLinkedQueue;

    .line 230
    .line 231
    invoke-virtual {v2, v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->add(Ljava/lang/Object;)Z

    .line 232
    .line 233
    .line 234
    iget-object v2, v1, Ld8;->h:Ljava/lang/Object;

    .line 235
    .line 236
    check-cast v2, Lcu0;

    .line 237
    .line 238
    iput-object v0, v1, Ld8;->h:Ljava/lang/Object;

    .line 239
    .line 240
    if-nez v2, :cond_f2

    .line 241
    .line 242
    goto :goto_f7

    .line 243
    :cond_f2
    new-instance p0, Lbl0;

    .line 244
    .line 245
    invoke-direct {p0, v1, v2}, Lbl0;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 246
    .line 247
    .line 248
    :goto_f7
    iget v0, v0, Lcu0;->a:I

    .line 249
    .line 250
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 251
    .line 252
    .line 253
    move-result-object v0

    .line 254
    const-string v1, "configurationId"

    .line 255
    .line 256
    invoke-virtual {v7, v1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    invoke-virtual {v6, v7, p0}, Ld8;->x(Ljava/io/Serializable;Lda;)V

    .line 260
    .line 261
    .line 262
    return-void

    .line 263
    :cond_106
    :goto_106
    invoke-virtual {v6, v7, p0}, Ld8;->x(Ljava/io/Serializable;Lda;)V

    .line 264
    .line 265
    .line 266
    return-void
.end method

.method public final dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 4

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x1

    .line 6
    if-nez v0, :cond_15

    .line 7
    .line 8
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I

    .line 9
    .line 10
    .line 11
    move-result v0

    .line 12
    if-nez v0, :cond_15

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    .line 15
    .line 16
    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {v0, p1, p0}, Landroid/view/KeyEvent$DispatcherState;->startTracking(Landroid/view/KeyEvent;Ljava/lang/Object;)V

    .line 19
    .line 20
    .line 21
    goto :goto_22

    .line 22
    :cond_15
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I

    .line 23
    .line 24
    .line 25
    move-result v0

    .line 26
    if-ne v0, v1, :cond_22

    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/view/View;->getKeyDispatcherState()Landroid/view/KeyEvent$DispatcherState;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    invoke-virtual {v0, p1}, Landroid/view/KeyEvent$DispatcherState;->handleUpEvent(Landroid/view/KeyEvent;)V

    .line 33
    .line 34
    .line 35
    :cond_22
    :goto_22
    invoke-virtual {p0}, Lvw;->c()Z

    .line 36
    .line 37
    .line 38
    move-result v0

    .line 39
    if-eqz v0, :cond_30

    .line 40
    .line 41
    iget-object v0, p0, Lvw;->t:Ld8;

    .line 42
    .line 43
    invoke-virtual {v0, p1}, Ld8;->p(Landroid/view/KeyEvent;)Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-nez v0, :cond_36

    .line 48
    .line 49
    :cond_30
    invoke-super {p0, p1}, Landroid/view/View;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 50
    .line 51
    .line 52
    move-result p0

    .line 53
    if-eqz p0, :cond_37

    .line 54
    .line 55
    :cond_36
    return v1

    .line 56
    :cond_37
    const/4 p0, 0x0

    .line 57
    return p0
.end method

.method public final e()V
    .registers 35

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    invoke-virtual {v0}, Lvw;->c()Z

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_10

    .line 8
    .line 9
    const-string v0, "FlutterView"

    .line 10
    .line 11
    const-string v1, "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine."

    .line 12
    .line 13
    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :cond_10
    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 18
    .line 19
    .line 20
    move-result-object v1

    .line 21
    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 22
    .line 23
    .line 24
    move-result-object v1

    .line 25
    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 26
    .line 27
    iget-object v2, v0, Lvw;->y:Lkw;

    .line 28
    .line 29
    iput v1, v2, Lkw;->a:F

    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-static {v1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 36
    .line 37
    .line 38
    move-result-object v1

    .line 39
    invoke-virtual {v1}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    .line 40
    .line 41
    .line 42
    move-result v1

    .line 43
    iput v1, v2, Lkw;->t:I

    .line 44
    .line 45
    iget-object v0, v0, Lvw;->n:Ljv;

    .line 46
    .line 47
    iget-object v0, v0, Ljv;->a:Lio/flutter/embedding/engine/renderer/e;

    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 50
    .line 51
    .line 52
    iget v1, v2, Lkw;->b:I

    .line 53
    .line 54
    iget-object v3, v2, Lkw;->z:Ljava/util/ArrayList;

    .line 55
    .line 56
    iget-object v4, v2, Lkw;->y:Ljava/util/ArrayList;

    .line 57
    .line 58
    if-nez v1, :cond_44

    .line 59
    .line 60
    iget v1, v2, Lkw;->d:I

    .line 61
    .line 62
    iget v5, v2, Lkw;->e:I

    .line 63
    .line 64
    if-gtz v1, :cond_5c

    .line 65
    .line 66
    if-lez v5, :cond_155

    .line 67
    .line 68
    goto :goto_5c

    .line 69
    :cond_44
    iget v5, v2, Lkw;->c:I

    .line 70
    .line 71
    if-nez v5, :cond_51

    .line 72
    .line 73
    iget v1, v2, Lkw;->f:I

    .line 74
    .line 75
    iget v5, v2, Lkw;->g:I

    .line 76
    .line 77
    if-gtz v1, :cond_5c

    .line 78
    .line 79
    if-lez v5, :cond_155

    .line 80
    .line 81
    goto :goto_5c

    .line 82
    :cond_51
    if-lez v1, :cond_155

    .line 83
    .line 84
    if-lez v5, :cond_155

    .line 85
    .line 86
    iget v1, v2, Lkw;->a:F

    .line 87
    .line 88
    const/4 v5, 0x0

    .line 89
    cmpl-float v1, v1, v5

    .line 90
    .line 91
    if-lez v1, :cond_155

    .line 92
    .line 93
    :cond_5c
    :goto_5c
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 94
    .line 95
    .line 96
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 97
    .line 98
    .line 99
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 100
    .line 101
    .line 102
    move-result v1

    .line 103
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 104
    .line 105
    .line 106
    move-result v5

    .line 107
    add-int/2addr v5, v1

    .line 108
    mul-int/lit8 v1, v5, 0x4

    .line 109
    .line 110
    new-array v1, v1, [I

    .line 111
    .line 112
    new-array v6, v5, [I

    .line 113
    .line 114
    new-array v5, v5, [I

    .line 115
    .line 116
    const/4 v7, 0x0

    .line 117
    move v8, v7

    .line 118
    :goto_75
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 119
    .line 120
    .line 121
    move-result v9

    .line 122
    if-ge v8, v9, :cond_ae

    .line 123
    .line 124
    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 125
    .line 126
    .line 127
    move-result-object v9

    .line 128
    check-cast v9, Lgw;

    .line 129
    .line 130
    mul-int/lit8 v10, v8, 0x4

    .line 131
    .line 132
    iget-object v11, v9, Lgw;->a:Landroid/graphics/Rect;

    .line 133
    .line 134
    iget v12, v11, Landroid/graphics/Rect;->left:I

    .line 135
    .line 136
    aput v12, v1, v10

    .line 137
    .line 138
    add-int/lit8 v12, v10, 0x1

    .line 139
    .line 140
    iget v13, v11, Landroid/graphics/Rect;->top:I

    .line 141
    .line 142
    aput v13, v1, v12

    .line 143
    .line 144
    add-int/lit8 v12, v10, 0x2

    .line 145
    .line 146
    iget v13, v11, Landroid/graphics/Rect;->right:I

    .line 147
    .line 148
    aput v13, v1, v12

    .line 149
    .line 150
    add-int/lit8 v10, v10, 0x3

    .line 151
    .line 152
    iget v11, v11, Landroid/graphics/Rect;->bottom:I

    .line 153
    .line 154
    aput v11, v1, v10

    .line 155
    .line 156
    iget v10, v9, Lgw;->b:I

    .line 157
    .line 158
    invoke-static {v10}, Lzi0;->y(I)I

    .line 159
    .line 160
    .line 161
    move-result v10

    .line 162
    aput v10, v6, v8

    .line 163
    .line 164
    iget v9, v9, Lgw;->c:I

    .line 165
    .line 166
    invoke-static {v9}, Lzi0;->y(I)I

    .line 167
    .line 168
    .line 169
    move-result v9

    .line 170
    aput v9, v5, v8

    .line 171
    .line 172
    add-int/lit8 v8, v8, 0x1

    .line 173
    .line 174
    goto :goto_75

    .line 175
    :cond_ae
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 176
    .line 177
    .line 178
    move-result v8

    .line 179
    mul-int/lit8 v8, v8, 0x4

    .line 180
    .line 181
    :goto_b4
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 182
    .line 183
    .line 184
    move-result v9

    .line 185
    if-ge v7, v9, :cond_f8

    .line 186
    .line 187
    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 188
    .line 189
    .line 190
    move-result-object v9

    .line 191
    check-cast v9, Lgw;

    .line 192
    .line 193
    mul-int/lit8 v10, v7, 0x4

    .line 194
    .line 195
    add-int/2addr v10, v8

    .line 196
    iget-object v11, v9, Lgw;->a:Landroid/graphics/Rect;

    .line 197
    .line 198
    iget v12, v11, Landroid/graphics/Rect;->left:I

    .line 199
    .line 200
    aput v12, v1, v10

    .line 201
    .line 202
    add-int/lit8 v12, v10, 0x1

    .line 203
    .line 204
    iget v13, v11, Landroid/graphics/Rect;->top:I

    .line 205
    .line 206
    aput v13, v1, v12

    .line 207
    .line 208
    add-int/lit8 v12, v10, 0x2

    .line 209
    .line 210
    iget v13, v11, Landroid/graphics/Rect;->right:I

    .line 211
    .line 212
    aput v13, v1, v12

    .line 213
    .line 214
    add-int/lit8 v10, v10, 0x3

    .line 215
    .line 216
    iget v11, v11, Landroid/graphics/Rect;->bottom:I

    .line 217
    .line 218
    aput v11, v1, v10

    .line 219
    .line 220
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 221
    .line 222
    .line 223
    move-result v10

    .line 224
    add-int/2addr v10, v7

    .line 225
    iget v11, v9, Lgw;->b:I

    .line 226
    .line 227
    invoke-static {v11}, Lzi0;->y(I)I

    .line 228
    .line 229
    .line 230
    move-result v11

    .line 231
    aput v11, v6, v10

    .line 232
    .line 233
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 234
    .line 235
    .line 236
    move-result v10

    .line 237
    add-int/2addr v10, v7

    .line 238
    iget v9, v9, Lgw;->c:I

    .line 239
    .line 240
    invoke-static {v9}, Lzi0;->y(I)I

    .line 241
    .line 242
    .line 243
    move-result v9

    .line 244
    aput v9, v5, v10

    .line 245
    .line 246
    add-int/lit8 v7, v7, 0x1

    .line 247
    .line 248
    goto :goto_b4

    .line 249
    :cond_f8
    iget-object v0, v0, Lio/flutter/embedding/engine/renderer/e;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 250
    .line 251
    iget v7, v2, Lkw;->a:F

    .line 252
    .line 253
    iget v8, v2, Lkw;->b:I

    .line 254
    .line 255
    iget v9, v2, Lkw;->c:I

    .line 256
    .line 257
    iget v10, v2, Lkw;->h:I

    .line 258
    .line 259
    iget v11, v2, Lkw;->i:I

    .line 260
    .line 261
    iget v12, v2, Lkw;->j:I

    .line 262
    .line 263
    iget v13, v2, Lkw;->k:I

    .line 264
    .line 265
    iget v14, v2, Lkw;->l:I

    .line 266
    .line 267
    iget v15, v2, Lkw;->m:I

    .line 268
    .line 269
    iget v3, v2, Lkw;->n:I

    .line 270
    .line 271
    iget v4, v2, Lkw;->o:I

    .line 272
    .line 273
    move-object/from16 v16, v0

    .line 274
    .line 275
    iget v0, v2, Lkw;->p:I

    .line 276
    .line 277
    move/from16 v18, v0

    .line 278
    .line 279
    iget v0, v2, Lkw;->q:I

    .line 280
    .line 281
    move/from16 v19, v0

    .line 282
    .line 283
    iget v0, v2, Lkw;->r:I

    .line 284
    .line 285
    move/from16 v20, v0

    .line 286
    .line 287
    iget v0, v2, Lkw;->s:I

    .line 288
    .line 289
    move/from16 v21, v0

    .line 290
    .line 291
    iget v0, v2, Lkw;->t:I

    .line 292
    .line 293
    move/from16 v22, v0

    .line 294
    .line 295
    iget v0, v2, Lkw;->d:I

    .line 296
    .line 297
    move/from16 v26, v0

    .line 298
    .line 299
    iget v0, v2, Lkw;->e:I

    .line 300
    .line 301
    move/from16 v27, v0

    .line 302
    .line 303
    iget v0, v2, Lkw;->f:I

    .line 304
    .line 305
    move/from16 v28, v0

    .line 306
    .line 307
    iget v0, v2, Lkw;->g:I

    .line 308
    .line 309
    move/from16 v29, v0

    .line 310
    .line 311
    iget v0, v2, Lkw;->u:I

    .line 312
    .line 313
    move/from16 v30, v0

    .line 314
    .line 315
    iget v0, v2, Lkw;->v:I

    .line 316
    .line 317
    move/from16 v31, v0

    .line 318
    .line 319
    iget v0, v2, Lkw;->w:I

    .line 320
    .line 321
    iget v2, v2, Lkw;->x:I

    .line 322
    .line 323
    move/from16 v32, v0

    .line 324
    .line 325
    move-object/from16 v23, v1

    .line 326
    .line 327
    move/from16 v33, v2

    .line 328
    .line 329
    move/from16 v17, v4

    .line 330
    .line 331
    move-object/from16 v25, v5

    .line 332
    .line 333
    move-object/from16 v24, v6

    .line 334
    .line 335
    move-object/from16 v6, v16

    .line 336
    .line 337
    move/from16 v16, v3

    .line 338
    .line 339
    invoke-virtual/range {v6 .. v33}, Lio/flutter/embedding/engine/FlutterJNI;->setViewportMetrics(FIIIIIIIIIIIIIII[I[I[IIIIIIIII)V

    .line 340
    .line 341
    .line 342
    :cond_155
    return-void
.end method

.method public getAccessibilityNodeProvider()Landroid/view/accessibility/AccessibilityNodeProvider;
    .registers 2

    .line 1
    iget-object v0, p0, Lvw;->v:Lio/flutter/view/b;

    .line 2
    .line 3
    if-eqz v0, :cond_f

    .line 4
    .line 5
    iget-object v0, v0, Lio/flutter/view/b;->c:Landroid/view/accessibility/AccessibilityManager;

    .line 6
    .line 7
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-eqz v0, :cond_f

    .line 12
    .line 13
    iget-object p0, p0, Lvw;->v:Lio/flutter/view/b;

    .line 14
    .line 15
    return-object p0

    .line 16
    :cond_f
    const/4 p0, 0x0

    .line 17
    return-object p0
.end method

.method public getAttachedFlutterEngine()Ljv;
    .registers 1

    .line 1
    iget-object p0, p0, Lvw;->n:Ljv;

    .line 2
    .line 3
    return-object p0
.end method

.method public getBinaryMessenger()Lla;
    .registers 1

    .line 1
    iget-object p0, p0, Lvw;->n:Ljv;

    .line 2
    .line 3
    iget-object p0, p0, Ljv;->b:Lrj;

    .line 4
    .line 5
    return-object p0
.end method

.method public getCurrentImageSurface()Ltv;
    .registers 1

    .line 1
    iget-object p0, p0, Lvw;->i:Ltv;

    .line 2
    .line 3
    return-object p0
.end method

.method public getViewportMetrics()Lkw;
    .registers 1

    .line 1
    iget-object p0, p0, Lvw;->y:Lkw;

    .line 2
    .line 3
    return-object p0
.end method

.method public final onApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .registers 16

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onApplyWindowInsets(Landroid/view/WindowInsets;)Landroid/view/WindowInsets;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 6
    .line 7
    const/16 v2, 0x1d

    .line 8
    .line 9
    iget-object v3, p0, Lvw;->y:Lkw;

    .line 10
    .line 11
    if-ne v1, v2, :cond_28

    .line 12
    .line 13
    invoke-static {p1}, Lu51;->s(Landroid/view/WindowInsets;)Landroid/graphics/Insets;

    .line 14
    .line 15
    .line 16
    move-result-object v2

    .line 17
    invoke-static {v2}, Ln30;->a(Landroid/graphics/Insets;)I

    .line 18
    .line 19
    .line 20
    move-result v4

    .line 21
    iput v4, v3, Lkw;->p:I

    .line 22
    .line 23
    invoke-static {v2}, Ld1;->a(Landroid/graphics/Insets;)I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    iput v4, v3, Lkw;->q:I

    .line 28
    .line 29
    invoke-static {v2}, Lu51;->r(Landroid/graphics/Insets;)I

    .line 30
    .line 31
    .line 32
    move-result v4

    .line 33
    iput v4, v3, Lkw;->r:I

    .line 34
    .line 35
    invoke-static {v2}, Lu51;->a(Landroid/graphics/Insets;)I

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    iput v2, v3, Lkw;->s:I

    .line 40
    .line 41
    :cond_28
    invoke-virtual {p0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 42
    .line 43
    .line 44
    move-result v2

    .line 45
    const/4 v4, 0x4

    .line 46
    and-int/2addr v2, v4

    .line 47
    const/4 v5, 0x1

    .line 48
    const/4 v6, 0x0

    .line 49
    if-nez v2, :cond_34

    .line 50
    .line 51
    move v2, v5

    .line 52
    goto :goto_35

    .line 53
    :cond_34
    move v2, v6

    .line 54
    :goto_35
    invoke-virtual {p0}, Landroid/view/View;->getWindowSystemUiVisibility()I

    .line 55
    .line 56
    .line 57
    move-result v7

    .line 58
    const/4 v8, 0x2

    .line 59
    and-int/2addr v7, v8

    .line 60
    if-nez v7, :cond_3f

    .line 61
    .line 62
    move v7, v5

    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    move v7, v6

    .line 65
    :goto_40
    const/16 v9, 0x1e

    .line 66
    .line 67
    if-lt v1, v9, :cond_100

    .line 68
    .line 69
    invoke-static {}, Le1;->a()I

    .line 70
    .line 71
    .line 72
    move-result v1

    .line 73
    invoke-static {p1, v1}, Le1;->y(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 74
    .line 75
    .line 76
    move-result-object v1

    .line 77
    invoke-static {v1}, Ln30;->a(Landroid/graphics/Insets;)I

    .line 78
    .line 79
    .line 80
    move-result v2

    .line 81
    iput v2, v3, Lkw;->h:I

    .line 82
    .line 83
    invoke-static {v1}, Ld1;->a(Landroid/graphics/Insets;)I

    .line 84
    .line 85
    .line 86
    move-result v2

    .line 87
    iput v2, v3, Lkw;->i:I

    .line 88
    .line 89
    invoke-static {v1}, Lu51;->r(Landroid/graphics/Insets;)I

    .line 90
    .line 91
    .line 92
    move-result v2

    .line 93
    iput v2, v3, Lkw;->j:I

    .line 94
    .line 95
    invoke-static {v1}, Lu51;->a(Landroid/graphics/Insets;)I

    .line 96
    .line 97
    .line 98
    move-result v1

    .line 99
    iput v1, v3, Lkw;->k:I

    .line 100
    .line 101
    invoke-static {}, Lc81;->l()I

    .line 102
    .line 103
    .line 104
    move-result v1

    .line 105
    invoke-static {p1, v1}, Le1;->i(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 106
    .line 107
    .line 108
    move-result-object v1

    .line 109
    invoke-static {v1}, Ln30;->a(Landroid/graphics/Insets;)I

    .line 110
    .line 111
    .line 112
    move-result v2

    .line 113
    iput v2, v3, Lkw;->l:I

    .line 114
    .line 115
    invoke-static {v1}, Ld1;->a(Landroid/graphics/Insets;)I

    .line 116
    .line 117
    .line 118
    move-result v2

    .line 119
    iput v2, v3, Lkw;->m:I

    .line 120
    .line 121
    invoke-static {v1}, Lu51;->r(Landroid/graphics/Insets;)I

    .line 122
    .line 123
    .line 124
    move-result v2

    .line 125
    iput v2, v3, Lkw;->n:I

    .line 126
    .line 127
    invoke-static {v1}, Lu51;->a(Landroid/graphics/Insets;)I

    .line 128
    .line 129
    .line 130
    move-result v1

    .line 131
    iput v1, v3, Lkw;->o:I

    .line 132
    .line 133
    invoke-static {}, Lc81;->n()I

    .line 134
    .line 135
    .line 136
    move-result v1

    .line 137
    invoke-static {p1, v1}, Le1;->i(Landroid/view/WindowInsets;I)Landroid/graphics/Insets;

    .line 138
    .line 139
    .line 140
    move-result-object v1

    .line 141
    invoke-static {v1}, Ln30;->a(Landroid/graphics/Insets;)I

    .line 142
    .line 143
    .line 144
    move-result v2

    .line 145
    iput v2, v3, Lkw;->p:I

    .line 146
    .line 147
    invoke-static {v1}, Ld1;->a(Landroid/graphics/Insets;)I

    .line 148
    .line 149
    .line 150
    move-result v2

    .line 151
    iput v2, v3, Lkw;->q:I

    .line 152
    .line 153
    invoke-static {v1}, Lu51;->r(Landroid/graphics/Insets;)I

    .line 154
    .line 155
    .line 156
    move-result v2

    .line 157
    iput v2, v3, Lkw;->r:I

    .line 158
    .line 159
    invoke-static {v1}, Lu51;->a(Landroid/graphics/Insets;)I

    .line 160
    .line 161
    .line 162
    move-result v1

    .line 163
    iput v1, v3, Lkw;->s:I

    .line 164
    .line 165
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getDisplayCutout()Landroid/view/DisplayCutout;

    .line 166
    .line 167
    .line 168
    move-result-object v1

    .line 169
    if-eqz v1, :cond_1a1

    .line 170
    .line 171
    invoke-static {v1}, Le1;->h(Landroid/view/DisplayCutout;)Landroid/graphics/Insets;

    .line 172
    .line 173
    .line 174
    move-result-object v2

    .line 175
    iget v7, v3, Lkw;->h:I

    .line 176
    .line 177
    invoke-static {v2}, Ln30;->a(Landroid/graphics/Insets;)I

    .line 178
    .line 179
    .line 180
    move-result v8

    .line 181
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 182
    .line 183
    .line 184
    move-result v7

    .line 185
    invoke-virtual {v1}, Landroid/view/DisplayCutout;->getSafeInsetTop()I

    .line 186
    .line 187
    .line 188
    move-result v8

    .line 189
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 190
    .line 191
    .line 192
    move-result v7

    .line 193
    iput v7, v3, Lkw;->h:I

    .line 194
    .line 195
    iget v7, v3, Lkw;->i:I

    .line 196
    .line 197
    invoke-static {v2}, Ld1;->a(Landroid/graphics/Insets;)I

    .line 198
    .line 199
    .line 200
    move-result v8

    .line 201
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 202
    .line 203
    .line 204
    move-result v7

    .line 205
    invoke-virtual {v1}, Landroid/view/DisplayCutout;->getSafeInsetRight()I

    .line 206
    .line 207
    .line 208
    move-result v8

    .line 209
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 210
    .line 211
    .line 212
    move-result v7

    .line 213
    iput v7, v3, Lkw;->i:I

    .line 214
    .line 215
    iget v7, v3, Lkw;->j:I

    .line 216
    .line 217
    invoke-static {v2}, Lu51;->r(Landroid/graphics/Insets;)I

    .line 218
    .line 219
    .line 220
    move-result v8

    .line 221
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 222
    .line 223
    .line 224
    move-result v7

    .line 225
    invoke-virtual {v1}, Landroid/view/DisplayCutout;->getSafeInsetBottom()I

    .line 226
    .line 227
    .line 228
    move-result v8

    .line 229
    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    .line 230
    .line 231
    .line 232
    move-result v7

    .line 233
    iput v7, v3, Lkw;->j:I

    .line 234
    .line 235
    iget v7, v3, Lkw;->k:I

    .line 236
    .line 237
    invoke-static {v2}, Lu51;->a(Landroid/graphics/Insets;)I

    .line 238
    .line 239
    .line 240
    move-result v2

    .line 241
    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    .line 242
    .line 243
    .line 244
    move-result v2

    .line 245
    invoke-virtual {v1}, Landroid/view/DisplayCutout;->getSafeInsetLeft()I

    .line 246
    .line 247
    .line 248
    move-result v1

    .line 249
    invoke-static {v2, v1}, Ljava/lang/Math;->max(II)I

    .line 250
    .line 251
    .line 252
    move-result v1

    .line 253
    iput v1, v3, Lkw;->k:I

    .line 254
    .line 255
    goto/16 :goto_1a1

    .line 256
    .line 257
    :cond_100
    const/4 v1, 0x3

    .line 258
    if-nez v7, :cond_131

    .line 259
    .line 260
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 261
    .line 262
    .line 263
    move-result-object v9

    .line 264
    invoke-virtual {v9}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 265
    .line 266
    .line 267
    move-result-object v10

    .line 268
    invoke-virtual {v10}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 269
    .line 270
    .line 271
    move-result-object v10

    .line 272
    iget v10, v10, Landroid/content/res/Configuration;->orientation:I

    .line 273
    .line 274
    if-ne v10, v8, :cond_131

    .line 275
    .line 276
    const-string v10, "display"

    .line 277
    .line 278
    invoke-virtual {v9, v10}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 279
    .line 280
    .line 281
    move-result-object v9

    .line 282
    check-cast v9, Landroid/hardware/display/DisplayManager;

    .line 283
    .line 284
    invoke-virtual {v9, v6}, Landroid/hardware/display/DisplayManager;->getDisplay(I)Landroid/view/Display;

    .line 285
    .line 286
    .line 287
    move-result-object v9

    .line 288
    invoke-virtual {v9}, Landroid/view/Display;->getRotation()I

    .line 289
    .line 290
    .line 291
    move-result v9

    .line 292
    if-ne v9, v5, :cond_127

    .line 293
    .line 294
    move v9, v1

    .line 295
    goto :goto_132

    .line 296
    :cond_127
    if-ne v9, v1, :cond_12b

    .line 297
    .line 298
    move v9, v8

    .line 299
    goto :goto_132

    .line 300
    :cond_12b
    if-eqz v9, :cond_12f

    .line 301
    .line 302
    if-ne v9, v8, :cond_131

    .line 303
    .line 304
    :cond_12f
    move v9, v4

    .line 305
    goto :goto_132

    .line 306
    :cond_131
    move v9, v5

    .line 307
    :goto_132
    if-eqz v2, :cond_139

    .line 308
    .line 309
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetTop()I

    .line 310
    .line 311
    .line 312
    move-result v2

    .line 313
    goto :goto_13a

    .line 314
    :cond_139
    move v2, v6

    .line 315
    :goto_13a
    iput v2, v3, Lkw;->h:I

    .line 316
    .line 317
    if-eq v9, v1, :cond_146

    .line 318
    .line 319
    if-ne v9, v4, :cond_141

    .line 320
    .line 321
    goto :goto_146

    .line 322
    :cond_141
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetRight()I

    .line 323
    .line 324
    .line 325
    move-result v1

    .line 326
    goto :goto_147

    .line 327
    :cond_146
    :goto_146
    move v1, v6

    .line 328
    :goto_147
    iput v1, v3, Lkw;->i:I

    .line 329
    .line 330
    const-wide v1, 0x3fc70a3d70a3d70aL    # 0.18

    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    if-eqz v7, :cond_170

    .line 336
    .line 337
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 338
    .line 339
    .line 340
    move-result-object v7

    .line 341
    invoke-virtual {v7}, Landroid/view/View;->getHeight()I

    .line 342
    .line 343
    .line 344
    move-result v7

    .line 345
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 346
    .line 347
    .line 348
    move-result v10

    .line 349
    int-to-double v10, v10

    .line 350
    int-to-double v12, v7

    .line 351
    mul-double/2addr v12, v1

    .line 352
    cmpg-double v7, v10, v12

    .line 353
    .line 354
    if-gez v7, :cond_165

    .line 355
    .line 356
    move v7, v6

    .line 357
    goto :goto_169

    .line 358
    :cond_165
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 359
    .line 360
    .line 361
    move-result v7

    .line 362
    :goto_169
    if-nez v7, :cond_170

    .line 363
    .line 364
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 365
    .line 366
    .line 367
    move-result v7

    .line 368
    goto :goto_171

    .line 369
    :cond_170
    move v7, v6

    .line 370
    :goto_171
    iput v7, v3, Lkw;->j:I

    .line 371
    .line 372
    if-eq v9, v8, :cond_17d

    .line 373
    .line 374
    if-ne v9, v4, :cond_178

    .line 375
    .line 376
    goto :goto_17d

    .line 377
    :cond_178
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetLeft()I

    .line 378
    .line 379
    .line 380
    move-result v7

    .line 381
    goto :goto_17e

    .line 382
    :cond_17d
    :goto_17d
    move v7, v6

    .line 383
    :goto_17e
    iput v7, v3, Lkw;->k:I

    .line 384
    .line 385
    iput v6, v3, Lkw;->l:I

    .line 386
    .line 387
    iput v6, v3, Lkw;->m:I

    .line 388
    .line 389
    invoke-virtual {p0}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 390
    .line 391
    .line 392
    move-result-object v7

    .line 393
    invoke-virtual {v7}, Landroid/view/View;->getHeight()I

    .line 394
    .line 395
    .line 396
    move-result v7

    .line 397
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 398
    .line 399
    .line 400
    move-result v8

    .line 401
    int-to-double v8, v8

    .line 402
    int-to-double v10, v7

    .line 403
    mul-double/2addr v10, v1

    .line 404
    cmpg-double v1, v8, v10

    .line 405
    .line 406
    if-gez v1, :cond_199

    .line 407
    .line 408
    move v1, v6

    .line 409
    goto :goto_19d

    .line 410
    :cond_199
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getSystemWindowInsetBottom()I

    .line 411
    .line 412
    .line 413
    move-result v1

    .line 414
    :goto_19d
    iput v1, v3, Lkw;->n:I

    .line 415
    .line 416
    iput v6, v3, Lkw;->o:I

    .line 417
    .line 418
    :cond_1a1
    :goto_1a1
    new-instance v1, Ljava/util/ArrayList;

    .line 419
    .line 420
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 421
    .line 422
    .line 423
    invoke-virtual {p1}, Landroid/view/WindowInsets;->getDisplayCutout()Landroid/view/DisplayCutout;

    .line 424
    .line 425
    .line 426
    move-result-object v2

    .line 427
    if-eqz v2, :cond_1cc

    .line 428
    .line 429
    invoke-virtual {v2}, Landroid/view/DisplayCutout;->getBoundingRects()Ljava/util/List;

    .line 430
    .line 431
    .line 432
    move-result-object v2

    .line 433
    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 434
    .line 435
    .line 436
    move-result-object v2

    .line 437
    :goto_1b4
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 438
    .line 439
    .line 440
    move-result v7

    .line 441
    if-eqz v7, :cond_1cc

    .line 442
    .line 443
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 444
    .line 445
    .line 446
    move-result-object v7

    .line 447
    check-cast v7, Landroid/graphics/Rect;

    .line 448
    .line 449
    invoke-virtual {v7}, Landroid/graphics/Rect;->toString()Ljava/lang/String;

    .line 450
    .line 451
    .line 452
    new-instance v8, Lgw;

    .line 453
    .line 454
    invoke-direct {v8, v7, v4, v5}, Lgw;-><init>(Landroid/graphics/Rect;II)V

    .line 455
    .line 456
    .line 457
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 458
    .line 459
    .line 460
    goto :goto_1b4

    .line 461
    :cond_1cc
    iget-object v2, v3, Lkw;->z:Ljava/util/ArrayList;

    .line 462
    .line 463
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 464
    .line 465
    .line 466
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 467
    .line 468
    .line 469
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 470
    .line 471
    const/16 v2, 0x23

    .line 472
    .line 473
    if-lt v1, v2, :cond_222

    .line 474
    .line 475
    iget-object v1, p0, Lvw;->G:Lxw;

    .line 476
    .line 477
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 478
    .line 479
    .line 480
    move-result-object v2

    .line 481
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 482
    .line 483
    .line 484
    invoke-static {v2}, Lsa;->C(Landroid/content/Context;)Landroid/app/Activity;

    .line 485
    .line 486
    .line 487
    move-result-object v1

    .line 488
    const/4 v2, 0x0

    .line 489
    if-nez v1, :cond_1eb

    .line 490
    .line 491
    goto :goto_1fa

    .line 492
    :cond_1eb
    invoke-virtual {v1}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 493
    .line 494
    .line 495
    move-result-object v1

    .line 496
    if-nez v1, :cond_1f2

    .line 497
    .line 498
    goto :goto_1fa

    .line 499
    :cond_1f2
    invoke-virtual {v1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 500
    .line 501
    .line 502
    move-result-object v1

    .line 503
    invoke-virtual {v1}, Landroid/view/View;->getRootWindowInsets()Landroid/view/WindowInsets;

    .line 504
    .line 505
    .line 506
    move-result-object v2

    .line 507
    :goto_1fa
    if-nez v2, :cond_1ff

    .line 508
    .line 509
    sget-object v1, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    .line 510
    .line 511
    goto :goto_207

    .line 512
    :cond_1ff
    invoke-static {}, Lc81;->j()I

    .line 513
    .line 514
    .line 515
    move-result v1

    .line 516
    invoke-static {v2, v1}, Lww;->b(Landroid/view/WindowInsets;I)Ljava/util/List;

    .line 517
    .line 518
    .line 519
    move-result-object v1

    .line 520
    :goto_207
    iget v2, v3, Lkw;->h:I

    .line 521
    .line 522
    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 523
    .line 524
    .line 525
    move-result-object v1

    .line 526
    :goto_20d
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 527
    .line 528
    .line 529
    move-result v4

    .line 530
    if-eqz v4, :cond_220

    .line 531
    .line 532
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 533
    .line 534
    .line 535
    move-result-object v4

    .line 536
    check-cast v4, Landroid/graphics/Rect;

    .line 537
    .line 538
    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    .line 539
    .line 540
    invoke-static {v2, v4}, Ljava/lang/Math;->max(II)I

    .line 541
    .line 542
    .line 543
    move-result v2

    .line 544
    goto :goto_20d

    .line 545
    :cond_220
    iput v2, v3, Lkw;->h:I

    .line 546
    .line 547
    :cond_222
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 548
    .line 549
    const/16 v2, 0x1f

    .line 550
    .line 551
    if-lt v1, v2, :cond_25e

    .line 552
    .line 553
    invoke-static {p1}, Ls0;->j(Landroid/view/WindowInsets;)Landroid/view/RoundedCorner;

    .line 554
    .line 555
    .line 556
    move-result-object v1

    .line 557
    invoke-static {p1}, Ls0;->z(Landroid/view/WindowInsets;)Landroid/view/RoundedCorner;

    .line 558
    .line 559
    .line 560
    move-result-object v2

    .line 561
    invoke-static {p1}, Ls0;->C(Landroid/view/WindowInsets;)Landroid/view/RoundedCorner;

    .line 562
    .line 563
    .line 564
    move-result-object v4

    .line 565
    invoke-static {p1}, Ls0;->D(Landroid/view/WindowInsets;)Landroid/view/RoundedCorner;

    .line 566
    .line 567
    .line 568
    move-result-object p1

    .line 569
    if-eqz v1, :cond_23f

    .line 570
    .line 571
    invoke-static {v1}, Ls0;->c(Landroid/view/RoundedCorner;)I

    .line 572
    .line 573
    .line 574
    move-result v1

    .line 575
    goto :goto_240

    .line 576
    :cond_23f
    move v1, v6

    .line 577
    :goto_240
    iput v1, v3, Lkw;->u:I

    .line 578
    .line 579
    if-eqz v2, :cond_249

    .line 580
    .line 581
    invoke-static {v2}, Ls0;->c(Landroid/view/RoundedCorner;)I

    .line 582
    .line 583
    .line 584
    move-result v1

    .line 585
    goto :goto_24a

    .line 586
    :cond_249
    move v1, v6

    .line 587
    :goto_24a
    iput v1, v3, Lkw;->v:I

    .line 588
    .line 589
    if-eqz v4, :cond_253

    .line 590
    .line 591
    invoke-static {v4}, Ls0;->c(Landroid/view/RoundedCorner;)I

    .line 592
    .line 593
    .line 594
    move-result v1

    .line 595
    goto :goto_254

    .line 596
    :cond_253
    move v1, v6

    .line 597
    :goto_254
    iput v1, v3, Lkw;->w:I

    .line 598
    .line 599
    if-eqz p1, :cond_25c

    .line 600
    .line 601
    invoke-static {p1}, Ls0;->c(Landroid/view/RoundedCorner;)I

    .line 602
    .line 603
    .line 604
    move-result v6

    .line 605
    :cond_25c
    iput v6, v3, Lkw;->x:I

    .line 606
    .line 607
    :cond_25e
    invoke-virtual {p0}, Lvw;->e()V

    .line 608
    .line 609
    .line 610
    return-object v0
.end method

.method public final onAttachedToWindow()V
    .registers 10

    .line 1
    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    :try_start_4
    new-instance v1, Lns0;

    .line 6
    .line 7
    new-instance v2, Lbl0;

    .line 8
    .line 9
    sget-object v3, Lec1;->e:Ldc1;

    .line 10
    .line 11
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 12
    .line 13
    .line 14
    move-result-object v4

    .line 15
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    .line 17
    .line 18
    invoke-static {v4}, Ldc1;->a(Landroid/content/Context;)Lns0;

    .line 19
    .line 20
    .line 21
    move-result-object v3

    .line 22
    new-instance v4, Lu6;

    .line 23
    .line 24
    const/16 v5, 0xa

    .line 25
    .line 26
    invoke-direct {v4, v5}, Lu6;-><init>(I)V

    .line 27
    .line 28
    .line 29
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 30
    .line 31
    .line 32
    iput-object v3, v2, Lbl0;->f:Ljava/lang/Object;

    .line 33
    .line 34
    iput-object v4, v2, Lbl0;->g:Ljava/lang/Object;

    .line 35
    .line 36
    const/16 v3, 0x16

    .line 37
    .line 38
    invoke-direct {v1, v3, v2}, Lns0;-><init>(ILjava/lang/Object;)V
    :try_end_28
    .catch Ljava/lang/NoClassDefFoundError; {:try_start_4 .. :try_end_28} :catch_29

    .line 39
    .line 40
    .line 41
    goto :goto_2a

    .line 42
    :catch_29
    move-object v1, v0

    .line 43
    :goto_2a
    iput-object v1, p0, Lvw;->x:Lns0;

    .line 44
    .line 45
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    invoke-static {v1}, Lsa;->C(Landroid/content/Context;)Landroid/app/Activity;

    .line 50
    .line 51
    .line 52
    move-result-object v1

    .line 53
    iget-object v2, p0, Lvw;->x:Lns0;

    .line 54
    .line 55
    if-eqz v2, :cond_d8

    .line 56
    .line 57
    if-eqz v1, :cond_d8

    .line 58
    .line 59
    new-instance v3, Lsw;

    .line 60
    .line 61
    const/4 v4, 0x0

    .line 62
    invoke-direct {v3, v4, p0}, Lsw;-><init>(ILjava/lang/Object;)V

    .line 63
    .line 64
    .line 65
    iput-object v3, p0, Lvw;->D:Lsw;

    .line 66
    .line 67
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 68
    .line 69
    .line 70
    move-result-object v3

    .line 71
    invoke-virtual {v3}, Landroid/content/Context;->getMainExecutor()Ljava/util/concurrent/Executor;

    .line 72
    .line 73
    .line 74
    move-result-object v3

    .line 75
    iget-object p0, p0, Lvw;->D:Lsw;

    .line 76
    .line 77
    iget-object v2, v2, Lns0;->g:Ljava/lang/Object;

    .line 78
    .line 79
    check-cast v2, Lbl0;

    .line 80
    .line 81
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    .line 83
    .line 84
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    .line 86
    .line 87
    iget-object v5, v2, Lbl0;->g:Ljava/lang/Object;

    .line 88
    .line 89
    check-cast v5, Lu6;

    .line 90
    .line 91
    iget-object v2, v2, Lbl0;->f:Ljava/lang/Object;

    .line 92
    .line 93
    check-cast v2, Lns0;

    .line 94
    .line 95
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 96
    .line 97
    .line 98
    new-instance v6, Lpc;

    .line 99
    .line 100
    const/16 v7, 0xc

    .line 101
    .line 102
    invoke-direct {v6, v2, v1, v0, v7}, Lpc;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 103
    .line 104
    .line 105
    new-instance v1, Lub;

    .line 106
    .line 107
    const/4 v2, -0x2

    .line 108
    sget-object v7, Lab;->f:Lab;

    .line 109
    .line 110
    sget-object v8, Lsq;->f:Lsq;

    .line 111
    .line 112
    invoke-direct {v1, v6, v8, v2, v7}, Lub;-><init>(Lsz;Lyh;ILab;)V

    .line 113
    .line 114
    .line 115
    sget-object v2, Ltn;->a:Lam;

    .line 116
    .line 117
    sget-object v2, Lza0;->a:Lz10;

    .line 118
    .line 119
    sget-object v6, Liq0;->j:Liq0;

    .line 120
    .line 121
    invoke-virtual {v2, v6}, Lbi;->q(Lxh;)Lwh;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    if-nez v6, :cond_c0

    .line 126
    .line 127
    invoke-virtual {v2, v8}, Lz10;->equals(Ljava/lang/Object;)Z

    .line 128
    .line 129
    .line 130
    move-result v6

    .line 131
    if-eqz v6, :cond_85

    .line 132
    .line 133
    goto :goto_8a

    .line 134
    :cond_85
    const/4 v6, 0x6

    .line 135
    invoke-static {v1, v2, v4, v0, v6}, Lzz;->b(Lzz;Lz10;ILab;I)Leu;

    .line 136
    .line 137
    .line 138
    move-result-object v1

    .line 139
    :goto_8a
    iget-object v2, v5, Lu6;->h:Ljava/lang/Object;

    .line 140
    .line 141
    check-cast v2, Ljava/util/LinkedHashMap;

    .line 142
    .line 143
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 144
    .line 145
    .line 146
    iget-object v4, v5, Lu6;->g:Ljava/lang/Object;

    .line 147
    .line 148
    check-cast v4, Ljava/util/concurrent/locks/ReentrantLock;

    .line 149
    .line 150
    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 151
    .line 152
    .line 153
    :try_start_98
    invoke-virtual {v2, p0}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    .line 155
    .line 156
    move-result-object v5

    .line 157
    if-nez v5, :cond_b6

    .line 158
    .line 159
    invoke-static {v3}, Lrl;->E(Ljava/util/concurrent/Executor;)Lbi;

    .line 160
    .line 161
    .line 162
    move-result-object v3

    .line 163
    invoke-static {v3}, Lfo0;->a(Lyh;)Lph;

    .line 164
    .line 165
    .line 166
    move-result-object v3

    .line 167
    new-instance v5, Lq8;

    .line 168
    .line 169
    const/4 v6, 0x3

    .line 170
    invoke-direct {v5, v1, p0, v0, v6}, Lq8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 171
    .line 172
    .line 173
    invoke-static {v3, v0, v0, v5, v6}, Lr30;->E(Lhi;Lwh;Lji;Lsz;I)Lvz0;

    .line 174
    .line 175
    .line 176
    move-result-object v0

    .line 177
    invoke-interface {v2, p0, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 178
    .line 179
    .line 180
    goto :goto_b6

    .line 181
    :catchall_b4
    move-exception p0

    .line 182
    goto :goto_bc

    .line 183
    :cond_b6
    :goto_b6
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_b8
    .catchall {:try_start_98 .. :try_end_b8} :catchall_b4

    .line 184
    .line 185
    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 186
    .line 187
    .line 188
    goto :goto_d8

    .line 189
    :goto_bc
    invoke-virtual {v4}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 190
    .line 191
    .line 192
    throw p0

    .line 193
    :cond_c0
    new-instance p0, Ljava/lang/StringBuilder;

    .line 194
    .line 195
    const-string v0, "Flow context cannot contain job in it. Had "

    .line 196
    .line 197
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 198
    .line 199
    .line 200
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 201
    .line 202
    .line 203
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 204
    .line 205
    .line 206
    move-result-object p0

    .line 207
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 208
    .line 209
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 210
    .line 211
    .line 212
    move-result-object p0

    .line 213
    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 214
    .line 215
    .line 216
    throw v0

    .line 217
    :cond_d8
    :goto_d8
    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lvw;->n:Ljv;

    .line 5
    .line 6
    if-eqz v0, :cond_18

    .line 7
    .line 8
    iget-object v0, p0, Lvw;->s:Lma0;

    .line 9
    .line 10
    invoke-virtual {v0, p1}, Lma0;->b(Landroid/content/res/Configuration;)V

    .line 11
    .line 12
    .line 13
    invoke-virtual {p0}, Lvw;->d()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 17
    .line 18
    .line 19
    move-result-object p1

    .line 20
    iget-object p0, p0, Lvw;->n:Ljv;

    .line 21
    .line 22
    invoke-static {p1, p0}, Lsa;->j(Landroid/content/Context;Ljv;)V

    .line 23
    .line 24
    .line 25
    :cond_18
    return-void
.end method

.method public final onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .registers 18

    .line 1
    move-object/from16 v1, p0

    .line 2
    .line 3
    move-object/from16 v6, p1

    .line 4
    .line 5
    invoke-virtual {v1}, Lvw;->c()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_f

    .line 10
    .line 11
    invoke-super/range {p0 .. p1}, Landroid/view/View;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    return-object v0

    .line 16
    :cond_f
    iget-object v7, v1, Lvw;->q:Lio/flutter/plugin/editing/b;

    .line 17
    .line 18
    iget-object v4, v1, Lvw;->t:Ld8;

    .line 19
    .line 20
    iget-object v0, v7, Lio/flutter/plugin/editing/b;->e:Lk31;

    .line 21
    .line 22
    iget v2, v0, Lk31;->a:I

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    const/4 v5, 0x0

    .line 26
    if-ne v2, v3, :cond_1e

    .line 27
    .line 28
    iput-object v5, v7, Lio/flutter/plugin/editing/b;->j:Landroid/view/inputmethod/InputConnection;

    .line 29
    .line 30
    return-object v5

    .line 31
    :cond_1e
    const/4 v8, 0x4

    .line 32
    if-ne v2, v8, :cond_22

    .line 33
    .line 34
    return-object v5

    .line 35
    :cond_22
    const/4 v5, 0x3

    .line 36
    if-ne v2, v5, :cond_3b

    .line 37
    .line 38
    iget-boolean v1, v7, Lio/flutter/plugin/editing/b;->p:Z

    .line 39
    .line 40
    if-eqz v1, :cond_2c

    .line 41
    .line 42
    iget-object v0, v7, Lio/flutter/plugin/editing/b;->j:Landroid/view/inputmethod/InputConnection;

    .line 43
    .line 44
    return-object v0

    .line 45
    :cond_2c
    iget-object v1, v7, Lio/flutter/plugin/editing/b;->k:Lio/flutter/plugin/platform/c;

    .line 46
    .line 47
    iget v0, v0, Lk31;->b:I

    .line 48
    .line 49
    invoke-virtual {v1, v0}, Lio/flutter/plugin/platform/c;->i(I)Landroid/view/View;

    .line 50
    .line 51
    .line 52
    move-result-object v0

    .line 53
    invoke-virtual {v0, v6}, Landroid/view/View;->onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;

    .line 54
    .line 55
    .line 56
    move-result-object v0

    .line 57
    iput-object v0, v7, Lio/flutter/plugin/editing/b;->j:Landroid/view/inputmethod/InputConnection;

    .line 58
    .line 59
    return-object v0

    .line 60
    :cond_3b
    iget-object v0, v7, Lio/flutter/plugin/editing/b;->f:Lf31;

    .line 61
    .line 62
    iget-object v2, v0, Lf31;->g:Lg31;

    .line 63
    .line 64
    iget-boolean v9, v0, Lf31;->a:Z

    .line 65
    .line 66
    iget-boolean v10, v0, Lf31;->b:Z

    .line 67
    .line 68
    iget-boolean v11, v0, Lf31;->c:Z

    .line 69
    .line 70
    iget-boolean v12, v0, Lf31;->d:Z

    .line 71
    .line 72
    iget v13, v0, Lf31;->f:I

    .line 73
    .line 74
    iget v14, v2, Lg31;->a:I

    .line 75
    .line 76
    const/4 v15, 0x2

    .line 77
    if-ne v14, v15, :cond_50

    .line 78
    .line 79
    goto/16 :goto_c2

    .line 80
    .line 81
    :cond_50
    const/4 v15, 0x5

    .line 82
    if-ne v14, v15, :cond_64

    .line 83
    .line 84
    iget-boolean v5, v2, Lg31;->b:Z

    .line 85
    .line 86
    if-eqz v5, :cond_5b

    .line 87
    .line 88
    const/16 v5, 0x1002

    .line 89
    .line 90
    move v8, v5

    .line 91
    goto :goto_5c

    .line 92
    :cond_5b
    const/4 v8, 0x2

    .line 93
    :goto_5c
    iget-boolean v2, v2, Lg31;->c:Z

    .line 94
    .line 95
    if-eqz v2, :cond_c2

    .line 96
    .line 97
    :goto_60
    or-int/lit16 v8, v8, 0x2000

    .line 98
    .line 99
    goto/16 :goto_c2

    .line 100
    .line 101
    :cond_64
    const/4 v2, 0x6

    .line 102
    if-ne v14, v2, :cond_6a

    .line 103
    .line 104
    move v8, v5

    .line 105
    goto/16 :goto_c2

    .line 106
    .line 107
    :cond_6a
    const/16 v2, 0xb

    .line 108
    .line 109
    if-ne v14, v2, :cond_70

    .line 110
    .line 111
    const/4 v8, 0x0

    .line 112
    goto :goto_c2

    .line 113
    :cond_70
    const/4 v2, 0x7

    .line 114
    if-ne v14, v2, :cond_77

    .line 115
    .line 116
    const v2, 0x20001

    .line 117
    .line 118
    .line 119
    goto :goto_a1

    .line 120
    :cond_77
    const/16 v2, 0x8

    .line 121
    .line 122
    if-eq v14, v2, :cond_9f

    .line 123
    .line 124
    const/16 v2, 0xd

    .line 125
    .line 126
    if-ne v14, v2, :cond_80

    .line 127
    .line 128
    goto :goto_9f

    .line 129
    :cond_80
    const/16 v2, 0x9

    .line 130
    .line 131
    if-eq v14, v2, :cond_9c

    .line 132
    .line 133
    const/16 v2, 0xc

    .line 134
    .line 135
    if-ne v14, v2, :cond_89

    .line 136
    .line 137
    goto :goto_9c

    .line 138
    :cond_89
    const/16 v2, 0xa

    .line 139
    .line 140
    if-ne v14, v2, :cond_90

    .line 141
    .line 142
    const/16 v2, 0x91

    .line 143
    .line 144
    goto :goto_a1

    .line 145
    :cond_90
    if-ne v14, v5, :cond_95

    .line 146
    .line 147
    const/16 v2, 0x61

    .line 148
    .line 149
    goto :goto_a1

    .line 150
    :cond_95
    if-ne v14, v8, :cond_9a

    .line 151
    .line 152
    const/16 v2, 0x71

    .line 153
    .line 154
    goto :goto_a1

    .line 155
    :cond_9a
    move v2, v3

    .line 156
    goto :goto_a1

    .line 157
    :cond_9c
    :goto_9c
    const/16 v2, 0x11

    .line 158
    .line 159
    goto :goto_a1

    .line 160
    :cond_9f
    :goto_9f
    const/16 v2, 0x21

    .line 161
    .line 162
    :goto_a1
    if-eqz v9, :cond_a9

    .line 163
    .line 164
    const v8, 0x80080

    .line 165
    .line 166
    .line 167
    :goto_a6
    or-int/2addr v2, v8

    .line 168
    :cond_a7
    move v8, v2

    .line 169
    goto :goto_b5

    .line 170
    :cond_a9
    if-eqz v10, :cond_af

    .line 171
    .line 172
    const v8, 0x8000

    .line 173
    .line 174
    .line 175
    or-int/2addr v2, v8

    .line 176
    :cond_af
    if-nez v11, :cond_a7

    .line 177
    .line 178
    const v8, 0x80090

    .line 179
    .line 180
    .line 181
    goto :goto_a6

    .line 182
    :goto_b5
    if-ne v13, v3, :cond_ba

    .line 183
    .line 184
    or-int/lit16 v8, v8, 0x1000

    .line 185
    .line 186
    goto :goto_c2

    .line 187
    :cond_ba
    const/4 v2, 0x2

    .line 188
    if-ne v13, v2, :cond_be

    .line 189
    .line 190
    goto :goto_60

    .line 191
    :cond_be
    if-ne v13, v5, :cond_c2

    .line 192
    .line 193
    or-int/lit16 v8, v8, 0x4000

    .line 194
    .line 195
    :cond_c2
    :goto_c2
    iput v8, v6, Landroid/view/inputmethod/EditorInfo;->inputType:I

    .line 196
    .line 197
    const/high16 v2, 0x2000000

    .line 198
    .line 199
    iput v2, v6, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 200
    .line 201
    if-nez v12, :cond_ce

    .line 202
    .line 203
    const/high16 v2, 0x3000000

    .line 204
    .line 205
    iput v2, v6, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 206
    .line 207
    :cond_ce
    iget-object v0, v0, Lf31;->h:Ljava/lang/Integer;

    .line 208
    .line 209
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 210
    .line 211
    .line 212
    move-result v0

    .line 213
    iget-object v2, v7, Lio/flutter/plugin/editing/b;->f:Lf31;

    .line 214
    .line 215
    iget-object v5, v2, Lf31;->i:Ljava/lang/String;

    .line 216
    .line 217
    if-eqz v5, :cond_de

    .line 218
    .line 219
    iput-object v5, v6, Landroid/view/inputmethod/EditorInfo;->actionLabel:Ljava/lang/CharSequence;

    .line 220
    .line 221
    iput v0, v6, Landroid/view/inputmethod/EditorInfo;->actionId:I

    .line 222
    .line 223
    :cond_de
    iget v5, v6, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 224
    .line 225
    or-int/2addr v0, v5

    .line 226
    iput v0, v6, Landroid/view/inputmethod/EditorInfo;->imeOptions:I

    .line 227
    .line 228
    iget-object v0, v2, Lf31;->m:[Ljava/util/Locale;

    .line 229
    .line 230
    if-eqz v0, :cond_f2

    .line 231
    .line 232
    new-instance v0, Landroid/os/LocaleList;

    .line 233
    .line 234
    iget-object v2, v7, Lio/flutter/plugin/editing/b;->f:Lf31;

    .line 235
    .line 236
    iget-object v2, v2, Lf31;->m:[Ljava/util/Locale;

    .line 237
    .line 238
    invoke-direct {v0, v2}, Landroid/os/LocaleList;-><init>([Ljava/util/Locale;)V

    .line 239
    .line 240
    .line 241
    iput-object v0, v6, Landroid/view/inputmethod/EditorInfo;->hintLocales:Landroid/os/LocaleList;

    .line 242
    .line 243
    :cond_f2
    iget-object v0, v7, Lio/flutter/plugin/editing/b;->f:Lf31;

    .line 244
    .line 245
    iget-object v0, v0, Lf31;->k:[Ljava/lang/String;

    .line 246
    .line 247
    if-eqz v0, :cond_fa

    .line 248
    .line 249
    iput-object v0, v6, Landroid/view/inputmethod/EditorInfo;->contentMimeTypes:[Ljava/lang/String;

    .line 250
    .line 251
    :cond_fa
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 252
    .line 253
    const/16 v2, 0x22

    .line 254
    .line 255
    if-lt v0, v2, :cond_119

    .line 256
    .line 257
    const/16 v2, 0x23

    .line 258
    .line 259
    if-lt v0, v2, :cond_107

    .line 260
    .line 261
    invoke-static {v6}, Lnp;->b(Landroid/view/inputmethod/EditorInfo;)V

    .line 262
    .line 263
    .line 264
    :cond_107
    iget-object v0, v6, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 265
    .line 266
    if-nez v0, :cond_112

    .line 267
    .line 268
    new-instance v0, Landroid/os/Bundle;

    .line 269
    .line 270
    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    .line 271
    .line 272
    .line 273
    iput-object v0, v6, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 274
    .line 275
    :cond_112
    iget-object v0, v6, Landroid/view/inputmethod/EditorInfo;->extras:Landroid/os/Bundle;

    .line 276
    .line 277
    const-string v2, "androidx.core.view.inputmethod.EditorInfoCompat.STYLUS_HANDWRITING_ENABLED"

    .line 278
    .line 279
    invoke-virtual {v0, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    .line 280
    .line 281
    .line 282
    :cond_119
    new-instance v0, Lj30;

    .line 283
    .line 284
    iget-object v2, v7, Lio/flutter/plugin/editing/b;->e:Lk31;

    .line 285
    .line 286
    iget v2, v2, Lk31;->b:I

    .line 287
    .line 288
    iget-object v3, v7, Lio/flutter/plugin/editing/b;->d:Lbl0;

    .line 289
    .line 290
    iget-object v5, v7, Lio/flutter/plugin/editing/b;->h:Lv90;

    .line 291
    .line 292
    invoke-direct/range {v0 .. v6}, Lj30;-><init>(Lvw;ILbl0;Ld8;Lv90;Landroid/view/inputmethod/EditorInfo;)V

    .line 293
    .line 294
    .line 295
    iget-object v1, v7, Lio/flutter/plugin/editing/b;->h:Lv90;

    .line 296
    .line 297
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 298
    .line 299
    .line 300
    invoke-static {v1}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    .line 301
    .line 302
    .line 303
    move-result v1

    .line 304
    iput v1, v6, Landroid/view/inputmethod/EditorInfo;->initialSelStart:I

    .line 305
    .line 306
    iget-object v1, v7, Lio/flutter/plugin/editing/b;->h:Lv90;

    .line 307
    .line 308
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 309
    .line 310
    .line 311
    invoke-static {v1}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    .line 312
    .line 313
    .line 314
    move-result v1

    .line 315
    iput v1, v6, Landroid/view/inputmethod/EditorInfo;->initialSelEnd:I

    .line 316
    .line 317
    iput-object v0, v7, Lio/flutter/plugin/editing/b;->j:Landroid/view/inputmethod/InputConnection;

    .line 318
    .line 319
    return-object v0
.end method

.method public final onDetachedFromWindow()V
    .registers 6

    .line 1
    iget-object v0, p0, Lvw;->x:Lns0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_38

    .line 5
    .line 6
    iget-object v2, p0, Lvw;->D:Lsw;

    .line 7
    .line 8
    if-eqz v2, :cond_38

    .line 9
    .line 10
    iget-object v0, v0, Lns0;->g:Ljava/lang/Object;

    .line 11
    .line 12
    check-cast v0, Lbl0;

    .line 13
    .line 14
    iget-object v0, v0, Lbl0;->g:Ljava/lang/Object;

    .line 15
    .line 16
    check-cast v0, Lu6;

    .line 17
    .line 18
    iget-object v3, v0, Lu6;->h:Ljava/lang/Object;

    .line 19
    .line 20
    check-cast v3, Ljava/util/LinkedHashMap;

    .line 21
    .line 22
    iget-object v0, v0, Lu6;->g:Ljava/lang/Object;

    .line 23
    .line 24
    check-cast v0, Ljava/util/concurrent/locks/ReentrantLock;

    .line 25
    .line 26
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    .line 27
    .line 28
    .line 29
    :try_start_1c
    invoke-virtual {v3, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 30
    .line 31
    .line 32
    move-result-object v4

    .line 33
    check-cast v4, Lp50;

    .line 34
    .line 35
    if-eqz v4, :cond_2a

    .line 36
    .line 37
    invoke-interface {v4, v1}, Lp50;->d(Ljava/util/concurrent/CancellationException;)V

    .line 38
    .line 39
    .line 40
    goto :goto_2a

    .line 41
    :catchall_28
    move-exception p0

    .line 42
    goto :goto_34

    .line 43
    :cond_2a
    :goto_2a
    invoke-interface {v3, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    .line 45
    .line 46
    move-result-object v2

    .line 47
    check-cast v2, Lp50;
    :try_end_30
    .catchall {:try_start_1c .. :try_end_30} :catchall_28

    .line 48
    .line 49
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 50
    .line 51
    .line 52
    goto :goto_38

    .line 53
    :goto_34
    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V

    .line 54
    .line 55
    .line 56
    throw p0

    .line 57
    :cond_38
    :goto_38
    iput-object v1, p0, Lvw;->D:Lsw;

    .line 58
    .line 59
    iput-object v1, p0, Lvw;->x:Lns0;

    .line 60
    .line 61
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    .line 62
    .line 63
    .line 64
    return-void
.end method

.method public final onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 12

    .line 1
    invoke-virtual {p0}, Lvw;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_6b

    .line 6
    .line 7
    iget-object v1, p0, Lvw;->u:Lk4;

    .line 8
    .line 9
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 10
    .line 11
    .line 12
    move-result-object v8

    .line 13
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x2

    .line 17
    invoke-virtual {p1, v0}, Landroid/view/InputEvent;->isFromSource(I)Z

    .line 18
    .line 19
    .line 20
    move-result v0

    .line 21
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 22
    .line 23
    .line 24
    move-result v2

    .line 25
    const/4 v3, 0x7

    .line 26
    const/4 v9, 0x1

    .line 27
    if-eq v2, v3, :cond_27

    .line 28
    .line 29
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 30
    .line 31
    .line 32
    move-result v2

    .line 33
    const/16 v3, 0x8

    .line 34
    .line 35
    if-ne v2, v3, :cond_25

    .line 36
    .line 37
    goto :goto_27

    .line 38
    :cond_25
    const/4 v2, 0x0

    .line 39
    goto :goto_28

    .line 40
    :cond_27
    :goto_27
    move v2, v9

    .line 41
    :goto_28
    if-eqz v0, :cond_6b

    .line 42
    .line 43
    if-nez v2, :cond_2d

    .line 44
    .line 45
    goto :goto_6b

    .line 46
    :cond_2d
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 47
    .line 48
    .line 49
    move-result p0

    .line 50
    invoke-static {p0}, Lk4;->b(I)I

    .line 51
    .line 52
    .line 53
    move-result v4

    .line 54
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    .line 55
    .line 56
    .line 57
    move-result p0

    .line 58
    mul-int/lit16 p0, p0, 0x120

    .line 59
    .line 60
    invoke-static {p0}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    .line 61
    .line 62
    .line 63
    move-result-object v7

    .line 64
    sget-object p0, Ljava/nio/ByteOrder;->LITTLE_ENDIAN:Ljava/nio/ByteOrder;

    .line 65
    .line 66
    invoke-virtual {v7, p0}, Ljava/nio/ByteBuffer;->order(Ljava/nio/ByteOrder;)Ljava/nio/ByteBuffer;

    .line 67
    .line 68
    .line 69
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 70
    .line 71
    .line 72
    move-result v3

    .line 73
    const/4 v5, 0x0

    .line 74
    sget-object v6, Lk4;->e:Landroid/graphics/Matrix;

    .line 75
    .line 76
    move-object v2, p1

    .line 77
    invoke-virtual/range {v1 .. v8}, Lk4;->a(Landroid/view/MotionEvent;IIILandroid/graphics/Matrix;Ljava/nio/ByteBuffer;Landroid/content/Context;)V

    .line 78
    .line 79
    .line 80
    invoke-virtual {v7}, Ljava/nio/Buffer;->position()I

    .line 81
    .line 82
    .line 83
    move-result p0

    .line 84
    rem-int/lit16 p0, p0, 0x120

    .line 85
    .line 86
    if-nez p0, :cond_63

    .line 87
    .line 88
    iget-object p0, v1, Lk4;->a:Lio/flutter/embedding/engine/renderer/e;

    .line 89
    .line 90
    invoke-virtual {v7}, Ljava/nio/Buffer;->position()I

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    iget-object p0, p0, Lio/flutter/embedding/engine/renderer/e;->a:Lio/flutter/embedding/engine/FlutterJNI;

    .line 95
    .line 96
    invoke-virtual {p0, v7, p1}, Lio/flutter/embedding/engine/FlutterJNI;->dispatchPointerDataPacket(Ljava/nio/ByteBuffer;I)V

    .line 97
    .line 98
    .line 99
    return v9

    .line 100
    :cond_63
    new-instance p0, Ljava/lang/AssertionError;

    .line 101
    .line 102
    const-string p1, "Packet position is not on field boundary."

    .line 103
    .line 104
    invoke-direct {p0, p1}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    .line 105
    .line 106
    .line 107
    throw p0

    .line 108
    :cond_6b
    :goto_6b
    move-object v2, p1

    .line 109
    invoke-super {p0, v2}, Landroid/view/View;->onGenericMotionEvent(Landroid/view/MotionEvent;)Z

    .line 110
    .line 111
    .line 112
    move-result p0

    .line 113
    return p0
.end method

.method public final onHoverEvent(Landroid/view/MotionEvent;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Lvw;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->onHoverEvent(Landroid/view/MotionEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_b
    iget-object p0, p0, Lvw;->v:Lio/flutter/view/b;

    .line 13
    .line 14
    const/4 v0, 0x0

    .line 15
    invoke-virtual {p0, p1, v0}, Lio/flutter/view/b;->f(Landroid/view/MotionEvent;Z)Z

    .line 16
    .line 17
    .line 18
    move-result p0

    .line 19
    return p0
.end method

.method public final onMeasure(II)V
    .registers 4

    .line 1
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iput v0, p0, Lvw;->E:I

    .line 6
    .line 7
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iput v0, p0, Lvw;->F:I

    .line 12
    .line 13
    invoke-super {p0, p1, p2}, Landroid/widget/FrameLayout;->onMeasure(II)V

    .line 14
    .line 15
    .line 16
    return-void
.end method

.method public final onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V
    .registers 16

    .line 1
    invoke-super {p0, p1, p2}, Landroid/view/View;->onProvideAutofillVirtualStructure(Landroid/view/ViewStructure;I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lvw;->q:Lio/flutter/plugin/editing/b;

    .line 5
    .line 6
    if-eqz p0, :cond_98

    .line 7
    .line 8
    iget-object p2, p0, Lio/flutter/plugin/editing/b;->g:Landroid/util/SparseArray;

    .line 9
    .line 10
    if-eqz p2, :cond_98

    .line 11
    .line 12
    iget-object p2, p0, Lio/flutter/plugin/editing/b;->f:Lf31;

    .line 13
    .line 14
    iget-object p2, p2, Lf31;->j:Lq1;

    .line 15
    .line 16
    iget-object p2, p2, Lq1;->f:Ljava/lang/Object;

    .line 17
    .line 18
    check-cast p2, Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {p1}, Landroid/view/ViewStructure;->getAutofillId()Landroid/view/autofill/AutofillId;

    .line 21
    .line 22
    .line 23
    move-result-object v0

    .line 24
    const/4 v1, 0x0

    .line 25
    move v2, v1

    .line 26
    :goto_19
    iget-object v3, p0, Lio/flutter/plugin/editing/b;->g:Landroid/util/SparseArray;

    .line 27
    .line 28
    invoke-virtual {v3}, Landroid/util/SparseArray;->size()I

    .line 29
    .line 30
    .line 31
    move-result v3

    .line 32
    if-ge v2, v3, :cond_98

    .line 33
    .line 34
    iget-object v3, p0, Lio/flutter/plugin/editing/b;->g:Landroid/util/SparseArray;

    .line 35
    .line 36
    invoke-virtual {v3, v2}, Landroid/util/SparseArray;->keyAt(I)I

    .line 37
    .line 38
    .line 39
    move-result v3

    .line 40
    iget-object v4, p0, Lio/flutter/plugin/editing/b;->g:Landroid/util/SparseArray;

    .line 41
    .line 42
    invoke-virtual {v4, v2}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    check-cast v4, Lf31;

    .line 47
    .line 48
    iget-object v4, v4, Lf31;->j:Lq1;

    .line 49
    .line 50
    if-nez v4, :cond_34

    .line 51
    .line 52
    goto :goto_95

    .line 53
    :cond_34
    const/4 v5, 0x1

    .line 54
    invoke-virtual {p1, v5}, Landroid/view/ViewStructure;->addChildCount(I)I

    .line 55
    .line 56
    .line 57
    invoke-virtual {p1, v2}, Landroid/view/ViewStructure;->newChild(I)Landroid/view/ViewStructure;

    .line 58
    .line 59
    .line 60
    move-result-object v6

    .line 61
    invoke-virtual {v6, v0, v3}, Landroid/view/ViewStructure;->setAutofillId(Landroid/view/autofill/AutofillId;I)V

    .line 62
    .line 63
    .line 64
    iget-object v7, v4, Lq1;->h:Ljava/lang/Object;

    .line 65
    .line 66
    check-cast v7, [Ljava/lang/String;

    .line 67
    .line 68
    array-length v8, v7

    .line 69
    if-lez v8, :cond_49

    .line 70
    .line 71
    invoke-virtual {v6, v7}, Landroid/view/ViewStructure;->setAutofillHints([Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    :cond_49
    invoke-virtual {v6, v5}, Landroid/view/ViewStructure;->setAutofillType(I)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v6, v1}, Landroid/view/ViewStructure;->setVisibility(I)V

    .line 78
    .line 79
    .line 80
    iget-object v5, v4, Lq1;->g:Ljava/lang/Object;

    .line 81
    .line 82
    check-cast v5, Ljava/lang/String;

    .line 83
    .line 84
    if-eqz v5, :cond_58

    .line 85
    .line 86
    invoke-virtual {v6, v5}, Landroid/view/ViewStructure;->setHint(Ljava/lang/CharSequence;)V

    .line 87
    .line 88
    .line 89
    :cond_58
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    .line 90
    .line 91
    .line 92
    move-result v5

    .line 93
    if-ne v5, v3, :cond_7f

    .line 94
    .line 95
    iget-object v3, p0, Lio/flutter/plugin/editing/b;->m:Landroid/graphics/Rect;

    .line 96
    .line 97
    if-eqz v3, :cond_7f

    .line 98
    .line 99
    iget v7, v3, Landroid/graphics/Rect;->left:I

    .line 100
    .line 101
    iget v8, v3, Landroid/graphics/Rect;->top:I

    .line 102
    .line 103
    invoke-virtual {v3}, Landroid/graphics/Rect;->width()I

    .line 104
    .line 105
    .line 106
    move-result v11

    .line 107
    iget-object v3, p0, Lio/flutter/plugin/editing/b;->m:Landroid/graphics/Rect;

    .line 108
    .line 109
    invoke-virtual {v3}, Landroid/graphics/Rect;->height()I

    .line 110
    .line 111
    .line 112
    move-result v12

    .line 113
    const/4 v9, 0x0

    .line 114
    const/4 v10, 0x0

    .line 115
    invoke-virtual/range {v6 .. v12}, Landroid/view/ViewStructure;->setDimens(IIIIII)V

    .line 116
    .line 117
    .line 118
    iget-object v3, p0, Lio/flutter/plugin/editing/b;->h:Lv90;

    .line 119
    .line 120
    invoke-static {v3}, Landroid/view/autofill/AutofillValue;->forText(Ljava/lang/CharSequence;)Landroid/view/autofill/AutofillValue;

    .line 121
    .line 122
    .line 123
    move-result-object v3

    .line 124
    invoke-virtual {v6, v3}, Landroid/view/ViewStructure;->setAutofillValue(Landroid/view/autofill/AutofillValue;)V

    .line 125
    .line 126
    .line 127
    goto :goto_95

    .line 128
    :cond_7f
    const/4 v11, 0x1

    .line 129
    const/4 v12, 0x1

    .line 130
    const/4 v7, 0x0

    .line 131
    const/4 v8, 0x0

    .line 132
    const/4 v9, 0x0

    .line 133
    const/4 v10, 0x0

    .line 134
    invoke-virtual/range {v6 .. v12}, Landroid/view/ViewStructure;->setDimens(IIIIII)V

    .line 135
    .line 136
    .line 137
    iget-object v3, v4, Lq1;->i:Ljava/lang/Object;

    .line 138
    .line 139
    check-cast v3, Lh31;

    .line 140
    .line 141
    iget-object v3, v3, Lh31;->a:Ljava/lang/String;

    .line 142
    .line 143
    invoke-static {v3}, Landroid/view/autofill/AutofillValue;->forText(Ljava/lang/CharSequence;)Landroid/view/autofill/AutofillValue;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    invoke-virtual {v6, v3}, Landroid/view/ViewStructure;->setAutofillValue(Landroid/view/autofill/AutofillValue;)V

    .line 148
    .line 149
    .line 150
    :goto_95
    add-int/lit8 v2, v2, 0x1

    .line 151
    .line 152
    goto :goto_19

    .line 153
    :cond_98
    return-void
.end method

.method public final onSizeChanged(IIII)V
    .registers 8

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/View;->onSizeChanged(IIII)V

    .line 2
    .line 3
    .line 4
    iget-object p3, p0, Lvw;->y:Lkw;

    .line 5
    .line 6
    iput p1, p3, Lkw;->b:I

    .line 7
    .line 8
    iput p2, p3, Lkw;->c:I

    .line 9
    .line 10
    iget-boolean p4, p0, Lvw;->f:Z

    .line 11
    .line 12
    const/16 v0, 0x2000

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    if-eqz p4, :cond_19

    .line 16
    .line 17
    iget v2, p0, Lvw;->F:I

    .line 18
    .line 19
    if-nez v2, :cond_19

    .line 20
    .line 21
    iput v1, p3, Lkw;->f:I

    .line 22
    .line 23
    iput v0, p3, Lkw;->g:I

    .line 24
    .line 25
    goto :goto_1d

    .line 26
    :cond_19
    iput p2, p3, Lkw;->f:I

    .line 27
    .line 28
    iput p2, p3, Lkw;->g:I

    .line 29
    .line 30
    :goto_1d
    if-eqz p4, :cond_28

    .line 31
    .line 32
    iget p2, p0, Lvw;->E:I

    .line 33
    .line 34
    if-nez p2, :cond_28

    .line 35
    .line 36
    iput v1, p3, Lkw;->d:I

    .line 37
    .line 38
    iput v0, p3, Lkw;->e:I

    .line 39
    .line 40
    goto :goto_2c

    .line 41
    :cond_28
    iput p1, p3, Lkw;->d:I

    .line 42
    .line 43
    iput p1, p3, Lkw;->e:I

    .line 44
    .line 45
    :goto_2c
    invoke-virtual {p0}, Lvw;->e()V

    .line 46
    .line 47
    .line 48
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 3

    .line 1
    invoke-virtual {p0}, Lvw;->c()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_b

    .line 6
    .line 7
    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 8
    .line 9
    .line 10
    move-result p0

    .line 11
    return p0

    .line 12
    :cond_b
    invoke-virtual {p0, p1}, Landroid/view/View;->requestUnbufferedDispatch(Landroid/view/MotionEvent;)V

    .line 13
    .line 14
    .line 15
    iget-object p0, p0, Lvw;->u:Lk4;

    .line 16
    .line 17
    sget-object v0, Lk4;->e:Landroid/graphics/Matrix;

    .line 18
    .line 19
    invoke-virtual {p0, p1, v0}, Lk4;->c(Landroid/view/MotionEvent;Landroid/graphics/Matrix;)V

    .line 20
    .line 21
    .line 22
    const/4 p0, 0x1

    .line 23
    return p0
.end method

.method public setDelegate(Lxw;)V
    .registers 2

    .line 1
    iput-object p1, p0, Lvw;->G:Lxw;

    .line 2
    .line 3
    return-void
.end method

.method public setVisibility(I)V
    .registers 3

    .line 1
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 2
    .line 3
    .line 4
    iget-object p0, p0, Lvw;->j:Lep0;

    .line 5
    .line 6
    instance-of v0, p0, Lmw;

    .line 7
    .line 8
    if-eqz v0, :cond_e

    .line 9
    .line 10
    check-cast p0, Lmw;

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 13
    .line 14
    .line 15
    :cond_e
    return-void
.end method

.method public setWindowInfoListenerDisplayFeatures(Lzc1;)V
    .registers 11

    .line 1
    sget-object v0, Lyw;->d:Lyw;

    .line 2
    .line 3
    iget-object p1, p1, Lzc1;->a:Ljava/util/List;

    .line 4
    .line 5
    new-instance v1, Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 8
    .line 9
    .line 10
    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 11
    .line 12
    .line 13
    move-result-object p1

    .line 14
    :goto_d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-eqz v2, :cond_6c

    .line 19
    .line 20
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 21
    .line 22
    .line 23
    move-result-object v2

    .line 24
    check-cast v2, Lb20;

    .line 25
    .line 26
    iget-object v3, v2, Lb20;->a:Lta;

    .line 27
    .line 28
    invoke-virtual {v3}, Lta;->a()Landroid/graphics/Rect;

    .line 29
    .line 30
    .line 31
    move-result-object v3

    .line 32
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 33
    .line 34
    .line 35
    instance-of v3, v2, Lb20;

    .line 36
    .line 37
    const/4 v4, 0x1

    .line 38
    if-eqz v3, :cond_5d

    .line 39
    .line 40
    iget-object v3, v2, Lb20;->a:Lta;

    .line 41
    .line 42
    iget v5, v3, Lta;->c:I

    .line 43
    .line 44
    iget v6, v3, Lta;->a:I

    .line 45
    .line 46
    sub-int/2addr v5, v6

    .line 47
    if-eqz v5, :cond_3a

    .line 48
    .line 49
    iget v5, v3, Lta;->d:I

    .line 50
    .line 51
    iget v6, v3, Lta;->b:I

    .line 52
    .line 53
    sub-int/2addr v5, v6

    .line 54
    if-nez v5, :cond_38

    .line 55
    .line 56
    goto :goto_3a

    .line 57
    :cond_38
    move-object v5, v0

    .line 58
    goto :goto_3c

    .line 59
    :cond_3a
    :goto_3a
    sget-object v5, Lyw;->c:Lyw;

    .line 60
    .line 61
    :goto_3c
    const/4 v6, 0x2

    .line 62
    const/4 v7, 0x3

    .line 63
    if-ne v5, v0, :cond_42

    .line 64
    .line 65
    move v5, v7

    .line 66
    goto :goto_43

    .line 67
    :cond_42
    move v5, v6

    .line 68
    :goto_43
    iget-object v2, v2, Lb20;->c:Lyw;

    .line 69
    .line 70
    sget-object v8, Lyw;->e:Lyw;

    .line 71
    .line 72
    if-ne v2, v8, :cond_4b

    .line 73
    .line 74
    move v4, v6

    .line 75
    goto :goto_50

    .line 76
    :cond_4b
    sget-object v6, Lyw;->f:Lyw;

    .line 77
    .line 78
    if-ne v2, v6, :cond_50

    .line 79
    .line 80
    move v4, v7

    .line 81
    :cond_50
    :goto_50
    new-instance v2, Lgw;

    .line 82
    .line 83
    invoke-virtual {v3}, Lta;->a()Landroid/graphics/Rect;

    .line 84
    .line 85
    .line 86
    move-result-object v3

    .line 87
    invoke-direct {v2, v3, v5, v4}, Lgw;-><init>(Landroid/graphics/Rect;II)V

    .line 88
    .line 89
    .line 90
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 91
    .line 92
    .line 93
    goto :goto_d

    .line 94
    :cond_5d
    new-instance v3, Lgw;

    .line 95
    .line 96
    iget-object v2, v2, Lb20;->a:Lta;

    .line 97
    .line 98
    invoke-virtual {v2}, Lta;->a()Landroid/graphics/Rect;

    .line 99
    .line 100
    .line 101
    move-result-object v2

    .line 102
    invoke-direct {v3, v2, v4, v4}, Lgw;-><init>(Landroid/graphics/Rect;II)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 106
    .line 107
    .line 108
    goto :goto_d

    .line 109
    :cond_6c
    iget-object p1, p0, Lvw;->y:Lkw;

    .line 110
    .line 111
    iget-object p1, p1, Lkw;->y:Ljava/util/ArrayList;

    .line 112
    .line 113
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    .line 114
    .line 115
    .line 116
    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 117
    .line 118
    .line 119
    invoke-virtual {p0}, Lvw;->e()V

    .line 120
    .line 121
    .line 122
    return-void
.end method
