###### Class defpackage.f6 (f6)
.class public abstract Lf6;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Lf6;->a:Ljava/lang/Object;

    .line 5
    .line 6
    return-void
.end method

.method public constructor <init>(Li6;)V
    .registers 2

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lf6;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public c()V
    .registers 3

    .line 1
    iget-object v0, p0, Lf6;->a:Ljava/lang/Object;

    .line 2
    .line 3
    check-cast v0, Le6;

    .line 4
    .line 5
    if-eqz v0, :cond_12

    .line 6
    .line 7
    :try_start_6
    iget-object v1, p0, Lf6;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v1, Li6;

    .line 10
    .line 11
    iget-object v1, v1, Li6;->p:Landroid/content/Context;

    .line 12
    .line 13
    invoke-virtual {v1, v0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_f
    .catch Ljava/lang/IllegalArgumentException; {:try_start_6 .. :try_end_f} :catch_f

    .line 14
    .line 15
    .line 16
    :catch_f
    const/4 v0, 0x0

    .line 17
    iput-object v0, p0, Lf6;->a:Ljava/lang/Object;

    .line 18
    .line 19
    :cond_12
    return-void
.end method

.method public abstract d()Landroid/content/IntentFilter;
.end method

.method public abstract e()I
.end method

.method public f(Landroid/view/MenuItem;)Landroid/view/MenuItem;
    .registers 4

    .line 1
    instance-of v0, p1, Lm11;

    .line 2
    .line 3
    if-eqz v0, :cond_31

    .line 4
    .line 5
    check-cast p1, Lm11;

    .line 6
    .line 7
    iget-object v0, p0, Lf6;->b:Ljava/lang/Object;

    .line 8
    .line 9
    check-cast v0, Lxx0;

    .line 10
    .line 11
    if-nez v0, :cond_14

    .line 12
    .line 13
    new-instance v0, Lxx0;

    .line 14
    .line 15
    const/4 v1, 0x0

    .line 16
    invoke-direct {v0, v1}, Lxx0;-><init>(I)V

    .line 17
    .line 18
    .line 19
    iput-object v0, p0, Lf6;->b:Ljava/lang/Object;

    .line 20
    .line 21
    :cond_14
    iget-object v0, p0, Lf6;->b:Ljava/lang/Object;

    .line 22
    .line 23
    check-cast v0, Lxx0;

    .line 24
    .line 25
    invoke-virtual {v0, p1}, Lxx0;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    check-cast v0, Landroid/view/MenuItem;

    .line 30
    .line 31
    if-nez v0, :cond_30

    .line 32
    .line 33
    new-instance v0, Lbd0;

    .line 34
    .line 35
    iget-object v1, p0, Lf6;->a:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast v1, Landroid/content/Context;

    .line 38
    .line 39
    invoke-direct {v0, v1, p1}, Lbd0;-><init>(Landroid/content/Context;Lm11;)V

    .line 40
    .line 41
    .line 42
    iget-object p0, p0, Lf6;->b:Ljava/lang/Object;

    .line 43
    .line 44
    check-cast p0, Lxx0;

    .line 45
    .line 46
    invoke-virtual {p0, p1, v0}, Lxx0;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    .line 48
    .line 49
    :cond_30
    return-object v0

    .line 50
    :cond_31
    return-object p1
.end method

.method public abstract g()V
.end method

.method public h()V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lf6;->c()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lf6;->d()Landroid/content/IntentFilter;

    .line 5
    .line 6
    .line 7
    move-result-object v0

    .line 8
    invoke-virtual {v0}, Landroid/content/IntentFilter;->countActions()I

    .line 9
    .line 10
    .line 11
    move-result v1

    .line 12
    if-nez v1, :cond_e

    .line 13
    .line 14
    return-void

    .line 15
    :cond_e
    iget-object v1, p0, Lf6;->a:Ljava/lang/Object;

    .line 16
    .line 17
    check-cast v1, Le6;

    .line 18
    .line 19
    if-nez v1, :cond_1c

    .line 20
    .line 21
    new-instance v1, Le6;

    .line 22
    .line 23
    const/4 v2, 0x0

    .line 24
    invoke-direct {v1, v2, p0}, Le6;-><init>(ILjava/lang/Object;)V

    .line 25
    .line 26
    .line 27
    iput-object v1, p0, Lf6;->a:Ljava/lang/Object;

    .line 28
    .line 29
    :cond_1c
    iget-object v1, p0, Lf6;->b:Ljava/lang/Object;

    .line 30
    .line 31
    check-cast v1, Li6;

    .line 32
    .line 33
    iget-object v1, v1, Li6;->p:Landroid/content/Context;

    .line 34
    .line 35
    iget-object p0, p0, Lf6;->a:Ljava/lang/Object;

    .line 36
    .line 37
    check-cast p0, Le6;

    .line 38
    .line 39
    invoke-virtual {v1, p0, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    .line 40
    .line 41
    .line 42
    return-void
.end method
