###### Class defpackage.k5 (k5)
.class public abstract Lk5;
.super Lay;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lo5;


# static fields
.field private static final DELEGATE_TAG:Ljava/lang/String; = "androidx:appcompat"


# instance fields
.field private mDelegate:Lv5;

.field private mResources:Landroid/content/res/Resources;


# virtual methods
.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lk5;->e()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Li6;

    .line 9
    .line 10
    invoke-virtual {p0}, Li6;->x()V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Li6;->F:Landroid/view/ViewGroup;

    .line 14
    .line 15
    const v1, 0x1020002

    .line 16
    .line 17
    .line 18
    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    check-cast v0, Landroid/view/ViewGroup;

    .line 23
    .line 24
    invoke-virtual {v0, p1, p2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 25
    .line 26
    .line 27
    iget-object p1, p0, Li6;->r:Lc6;

    .line 28
    .line 29
    iget-object p0, p0, Li6;->q:Landroid/view/Window;

    .line 30
    .line 31
    invoke-virtual {p0}, Landroid/view/Window;->getCallback()Landroid/view/Window$Callback;

    .line 32
    .line 33
    .line 34
    move-result-object p0

    .line 35
    invoke-virtual {p1, p0}, Lc6;->a(Landroid/view/Window$Callback;)V

    .line 36
    .line 37
    .line 38
    return-void
.end method

.method public attachBaseContext(Landroid/content/Context;)V
    .registers 11

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Li6;

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    iput-boolean v1, v0, Li6;->T:Z

    .line 9
    .line 10
    iget v2, v0, Li6;->X:I

    .line 11
    .line 12
    const/16 v3, -0x64

    .line 13
    .line 14
    if-eq v2, v3, :cond_10

    .line 15
    .line 16
    goto :goto_12

    .line 17
    :cond_10
    sget v2, Lv5;->g:I

    .line 18
    .line 19
    :goto_12
    invoke-virtual {v0, p1, v2}, Li6;->D(Landroid/content/Context;I)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {p1}, Lv5;->c(Landroid/content/Context;)Z

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    const/4 v3, 0x0

    .line 28
    if-eqz v2, :cond_7f

    .line 29
    .line 30
    invoke-static {p1}, Lv5;->c(Landroid/content/Context;)Z

    .line 31
    .line 32
    .line 33
    move-result v2

    .line 34
    if-nez v2, :cond_24

    .line 35
    .line 36
    goto :goto_7f

    .line 37
    :cond_24
    invoke-static {}, Lhb;->a()Z

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    if-eqz v2, :cond_39

    .line 42
    .line 43
    sget-boolean v2, Lv5;->k:Z

    .line 44
    .line 45
    if-nez v2, :cond_7f

    .line 46
    .line 47
    sget-object v2, Lv5;->f:Lut0;

    .line 48
    .line 49
    new-instance v4, Ls5;

    .line 50
    .line 51
    invoke-direct {v4, p1, v3}, Ls5;-><init>(Landroid/content/Context;I)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {v2, v4}, Lut0;->execute(Ljava/lang/Runnable;)V

    .line 55
    .line 56
    .line 57
    goto :goto_7f

    .line 58
    :cond_39
    sget-object v2, Lv5;->n:Ljava/lang/Object;

    .line 59
    .line 60
    monitor-enter v2

    .line 61
    :try_start_3c
    sget-object v4, Lv5;->h:Lka0;

    .line 62
    .line 63
    if-nez v4, :cond_64

    .line 64
    .line 65
    sget-object v4, Lv5;->i:Lka0;

    .line 66
    .line 67
    if-nez v4, :cond_51

    .line 68
    .line 69
    invoke-static {p1}, Lsa;->O(Landroid/content/Context;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v4

    .line 73
    invoke-static {v4}, Lka0;->a(Ljava/lang/String;)Lka0;

    .line 74
    .line 75
    .line 76
    move-result-object v4

    .line 77
    sput-object v4, Lv5;->i:Lka0;

    .line 78
    .line 79
    goto :goto_51

    .line 80
    :catchall_4f
    move-exception p0

    .line 81
    goto :goto_7d

    .line 82
    :cond_51
    :goto_51
    sget-object v4, Lv5;->i:Lka0;

    .line 83
    .line 84
    iget-object v4, v4, Lka0;->a:Lla0;

    .line 85
    .line 86
    iget-object v4, v4, Lla0;->a:Landroid/os/LocaleList;

    .line 87
    .line 88
    invoke-virtual {v4}, Landroid/os/LocaleList;->isEmpty()Z

    .line 89
    .line 90
    .line 91
    move-result v4

    .line 92
    if-eqz v4, :cond_5f

    .line 93
    .line 94
    monitor-exit v2

    .line 95
    goto :goto_7f

    .line 96
    :cond_5f
    sget-object v4, Lv5;->i:Lka0;

    .line 97
    .line 98
    sput-object v4, Lv5;->h:Lka0;

    .line 99
    .line 100
    goto :goto_7b

    .line 101
    :cond_64
    sget-object v5, Lv5;->i:Lka0;

    .line 102
    .line 103
    invoke-virtual {v4, v5}, Lka0;->equals(Ljava/lang/Object;)Z

    .line 104
    .line 105
    .line 106
    move-result v4

    .line 107
    if-nez v4, :cond_7b

    .line 108
    .line 109
    sget-object v4, Lv5;->h:Lka0;

    .line 110
    .line 111
    sput-object v4, Lv5;->i:Lka0;

    .line 112
    .line 113
    iget-object v4, v4, Lka0;->a:Lla0;

    .line 114
    .line 115
    iget-object v4, v4, Lla0;->a:Landroid/os/LocaleList;

    .line 116
    .line 117
    invoke-virtual {v4}, Landroid/os/LocaleList;->toLanguageTags()Ljava/lang/String;

    .line 118
    .line 119
    .line 120
    move-result-object v4

    .line 121
    invoke-static {p1, v4}, Lsa;->L(Landroid/content/Context;Ljava/lang/String;)V

    .line 122
    .line 123
    .line 124
    :cond_7b
    :goto_7b
    monitor-exit v2

    .line 125
    goto :goto_7f

    .line 126
    :goto_7d
    monitor-exit v2
    :try_end_7e
    .catchall {:try_start_3c .. :try_end_7e} :catchall_4f

    .line 127
    throw p0

    .line 128
    :cond_7f
    :goto_7f
    invoke-static {p1}, Li6;->q(Landroid/content/Context;)Lka0;

    .line 129
    .line 130
    .line 131
    move-result-object v2

    .line 132
    sget-boolean v4, Li6;->p0:Z

    .line 133
    .line 134
    const/4 v5, 0x0

    .line 135
    if-eqz v4, :cond_98

    .line 136
    .line 137
    instance-of v4, p1, Landroid/view/ContextThemeWrapper;

    .line 138
    .line 139
    if-eqz v4, :cond_98

    .line 140
    .line 141
    invoke-static {p1, v0, v2, v5, v3}, Li6;->u(Landroid/content/Context;ILka0;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;

    .line 142
    .line 143
    .line 144
    move-result-object v4

    .line 145
    :try_start_90
    move-object v6, p1

    .line 146
    check-cast v6, Landroid/view/ContextThemeWrapper;

    .line 147
    .line 148
    invoke-virtual {v6, v4}, Landroid/view/ContextThemeWrapper;->applyOverrideConfiguration(Landroid/content/res/Configuration;)V
    :try_end_96
    .catch Ljava/lang/IllegalStateException; {:try_start_90 .. :try_end_96} :catch_98

    .line 149
    .line 150
    .line 151
    goto/16 :goto_22a

    .line 152
    .line 153
    :catch_98
    :cond_98
    instance-of v4, p1, Lrh;

    .line 154
    .line 155
    if-eqz v4, :cond_a8

    .line 156
    .line 157
    invoke-static {p1, v0, v2, v5, v3}, Li6;->u(Landroid/content/Context;ILka0;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;

    .line 158
    .line 159
    .line 160
    move-result-object v3

    .line 161
    :try_start_a0
    move-object v4, p1

    .line 162
    check-cast v4, Lrh;

    .line 163
    .line 164
    invoke-virtual {v4, v3}, Lrh;->a(Landroid/content/res/Configuration;)V
    :try_end_a6
    .catch Ljava/lang/IllegalStateException; {:try_start_a0 .. :try_end_a6} :catch_a8

    .line 165
    .line 166
    .line 167
    goto/16 :goto_22a

    .line 168
    .line 169
    :catch_a8
    :cond_a8
    sget-boolean v3, Li6;->o0:Z

    .line 170
    .line 171
    if-nez v3, :cond_ae

    .line 172
    .line 173
    goto/16 :goto_22a

    .line 174
    .line 175
    :cond_ae
    new-instance v3, Landroid/content/res/Configuration;

    .line 176
    .line 177
    invoke-direct {v3}, Landroid/content/res/Configuration;-><init>()V

    .line 178
    .line 179
    .line 180
    const/4 v4, -0x1

    .line 181
    iput v4, v3, Landroid/content/res/Configuration;->uiMode:I

    .line 182
    .line 183
    const/4 v4, 0x0

    .line 184
    iput v4, v3, Landroid/content/res/Configuration;->fontScale:F

    .line 185
    .line 186
    invoke-virtual {p1, v3}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    .line 187
    .line 188
    .line 189
    move-result-object v3

    .line 190
    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 191
    .line 192
    .line 193
    move-result-object v3

    .line 194
    invoke-virtual {v3}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 195
    .line 196
    .line 197
    move-result-object v3

    .line 198
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 199
    .line 200
    .line 201
    move-result-object v6

    .line 202
    invoke-virtual {v6}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 203
    .line 204
    .line 205
    move-result-object v6

    .line 206
    iget v7, v6, Landroid/content/res/Configuration;->uiMode:I

    .line 207
    .line 208
    iput v7, v3, Landroid/content/res/Configuration;->uiMode:I

    .line 209
    .line 210
    invoke-virtual {v3, v6}, Landroid/content/res/Configuration;->equals(Landroid/content/res/Configuration;)Z

    .line 211
    .line 212
    .line 213
    move-result v7

    .line 214
    if-nez v7, :cond_1cc

    .line 215
    .line 216
    new-instance v7, Landroid/content/res/Configuration;

    .line 217
    .line 218
    invoke-direct {v7}, Landroid/content/res/Configuration;-><init>()V

    .line 219
    .line 220
    .line 221
    iput v4, v7, Landroid/content/res/Configuration;->fontScale:F

    .line 222
    .line 223
    invoke-virtual {v3, v6}, Landroid/content/res/Configuration;->diff(Landroid/content/res/Configuration;)I

    .line 224
    .line 225
    .line 226
    move-result v4

    .line 227
    if-nez v4, :cond_e6

    .line 228
    .line 229
    goto/16 :goto_1cd

    .line 230
    .line 231
    :cond_e6
    iget v4, v3, Landroid/content/res/Configuration;->fontScale:F

    .line 232
    .line 233
    iget v8, v6, Landroid/content/res/Configuration;->fontScale:F

    .line 234
    .line 235
    cmpl-float v4, v4, v8

    .line 236
    .line 237
    if-eqz v4, :cond_f0

    .line 238
    .line 239
    iput v8, v7, Landroid/content/res/Configuration;->fontScale:F

    .line 240
    .line 241
    :cond_f0
    iget v4, v3, Landroid/content/res/Configuration;->mcc:I

    .line 242
    .line 243
    iget v8, v6, Landroid/content/res/Configuration;->mcc:I

    .line 244
    .line 245
    if-eq v4, v8, :cond_f8

    .line 246
    .line 247
    iput v8, v7, Landroid/content/res/Configuration;->mcc:I

    .line 248
    .line 249
    :cond_f8
    iget v4, v3, Landroid/content/res/Configuration;->mnc:I

    .line 250
    .line 251
    iget v8, v6, Landroid/content/res/Configuration;->mnc:I

    .line 252
    .line 253
    if-eq v4, v8, :cond_100

    .line 254
    .line 255
    iput v8, v7, Landroid/content/res/Configuration;->mnc:I

    .line 256
    .line 257
    :cond_100
    invoke-static {v3, v6, v7}, Lz5;->a(Landroid/content/res/Configuration;Landroid/content/res/Configuration;Landroid/content/res/Configuration;)V

    .line 258
    .line 259
    .line 260
    iget v4, v3, Landroid/content/res/Configuration;->touchscreen:I

    .line 261
    .line 262
    iget v8, v6, Landroid/content/res/Configuration;->touchscreen:I

    .line 263
    .line 264
    if-eq v4, v8, :cond_10b

    .line 265
    .line 266
    iput v8, v7, Landroid/content/res/Configuration;->touchscreen:I

    .line 267
    .line 268
    :cond_10b
    iget v4, v3, Landroid/content/res/Configuration;->keyboard:I

    .line 269
    .line 270
    iget v8, v6, Landroid/content/res/Configuration;->keyboard:I

    .line 271
    .line 272
    if-eq v4, v8, :cond_113

    .line 273
    .line 274
    iput v8, v7, Landroid/content/res/Configuration;->keyboard:I

    .line 275
    .line 276
    :cond_113
    iget v4, v3, Landroid/content/res/Configuration;->keyboardHidden:I

    .line 277
    .line 278
    iget v8, v6, Landroid/content/res/Configuration;->keyboardHidden:I

    .line 279
    .line 280
    if-eq v4, v8, :cond_11b

    .line 281
    .line 282
    iput v8, v7, Landroid/content/res/Configuration;->keyboardHidden:I

    .line 283
    .line 284
    :cond_11b
    iget v4, v3, Landroid/content/res/Configuration;->navigation:I

    .line 285
    .line 286
    iget v8, v6, Landroid/content/res/Configuration;->navigation:I

    .line 287
    .line 288
    if-eq v4, v8, :cond_123

    .line 289
    .line 290
    iput v8, v7, Landroid/content/res/Configuration;->navigation:I

    .line 291
    .line 292
    :cond_123
    iget v4, v3, Landroid/content/res/Configuration;->navigationHidden:I

    .line 293
    .line 294
    iget v8, v6, Landroid/content/res/Configuration;->navigationHidden:I

    .line 295
    .line 296
    if-eq v4, v8, :cond_12b

    .line 297
    .line 298
    iput v8, v7, Landroid/content/res/Configuration;->navigationHidden:I

    .line 299
    .line 300
    :cond_12b
    iget v4, v3, Landroid/content/res/Configuration;->orientation:I

    .line 301
    .line 302
    iget v8, v6, Landroid/content/res/Configuration;->orientation:I

    .line 303
    .line 304
    if-eq v4, v8, :cond_133

    .line 305
    .line 306
    iput v8, v7, Landroid/content/res/Configuration;->orientation:I

    .line 307
    .line 308
    :cond_133
    iget v4, v3, Landroid/content/res/Configuration;->screenLayout:I

    .line 309
    .line 310
    and-int/lit8 v4, v4, 0xf

    .line 311
    .line 312
    iget v8, v6, Landroid/content/res/Configuration;->screenLayout:I

    .line 313
    .line 314
    and-int/lit8 v8, v8, 0xf

    .line 315
    .line 316
    if-eq v4, v8, :cond_142

    .line 317
    .line 318
    iget v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 319
    .line 320
    or-int/2addr v4, v8

    .line 321
    iput v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 322
    .line 323
    :cond_142
    iget v4, v3, Landroid/content/res/Configuration;->screenLayout:I

    .line 324
    .line 325
    and-int/lit16 v4, v4, 0xc0

    .line 326
    .line 327
    iget v8, v6, Landroid/content/res/Configuration;->screenLayout:I

    .line 328
    .line 329
    and-int/lit16 v8, v8, 0xc0

    .line 330
    .line 331
    if-eq v4, v8, :cond_151

    .line 332
    .line 333
    iget v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 334
    .line 335
    or-int/2addr v4, v8

    .line 336
    iput v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 337
    .line 338
    :cond_151
    iget v4, v3, Landroid/content/res/Configuration;->screenLayout:I

    .line 339
    .line 340
    and-int/lit8 v4, v4, 0x30

    .line 341
    .line 342
    iget v8, v6, Landroid/content/res/Configuration;->screenLayout:I

    .line 343
    .line 344
    and-int/lit8 v8, v8, 0x30

    .line 345
    .line 346
    if-eq v4, v8, :cond_160

    .line 347
    .line 348
    iget v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 349
    .line 350
    or-int/2addr v4, v8

    .line 351
    iput v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 352
    .line 353
    :cond_160
    iget v4, v3, Landroid/content/res/Configuration;->screenLayout:I

    .line 354
    .line 355
    and-int/lit16 v4, v4, 0x300

    .line 356
    .line 357
    iget v8, v6, Landroid/content/res/Configuration;->screenLayout:I

    .line 358
    .line 359
    and-int/lit16 v8, v8, 0x300

    .line 360
    .line 361
    if-eq v4, v8, :cond_16f

    .line 362
    .line 363
    iget v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 364
    .line 365
    or-int/2addr v4, v8

    .line 366
    iput v4, v7, Landroid/content/res/Configuration;->screenLayout:I

    .line 367
    .line 368
    :cond_16f
    iget v4, v3, Landroid/content/res/Configuration;->colorMode:I

    .line 369
    .line 370
    and-int/lit8 v4, v4, 0x3

    .line 371
    .line 372
    iget v8, v6, Landroid/content/res/Configuration;->colorMode:I

    .line 373
    .line 374
    and-int/lit8 v8, v8, 0x3

    .line 375
    .line 376
    if-eq v4, v8, :cond_17e

    .line 377
    .line 378
    iget v4, v7, Landroid/content/res/Configuration;->colorMode:I

    .line 379
    .line 380
    or-int/2addr v4, v8

    .line 381
    iput v4, v7, Landroid/content/res/Configuration;->colorMode:I

    .line 382
    .line 383
    :cond_17e
    iget v4, v3, Landroid/content/res/Configuration;->colorMode:I

    .line 384
    .line 385
    and-int/lit8 v4, v4, 0xc

    .line 386
    .line 387
    iget v8, v6, Landroid/content/res/Configuration;->colorMode:I

    .line 388
    .line 389
    and-int/lit8 v8, v8, 0xc

    .line 390
    .line 391
    if-eq v4, v8, :cond_18d

    .line 392
    .line 393
    iget v4, v7, Landroid/content/res/Configuration;->colorMode:I

    .line 394
    .line 395
    or-int/2addr v4, v8

    .line 396
    iput v4, v7, Landroid/content/res/Configuration;->colorMode:I

    .line 397
    .line 398
    :cond_18d
    iget v4, v3, Landroid/content/res/Configuration;->uiMode:I

    .line 399
    .line 400
    and-int/lit8 v4, v4, 0xf

    .line 401
    .line 402
    iget v8, v6, Landroid/content/res/Configuration;->uiMode:I

    .line 403
    .line 404
    and-int/lit8 v8, v8, 0xf

    .line 405
    .line 406
    if-eq v4, v8, :cond_19c

    .line 407
    .line 408
    iget v4, v7, Landroid/content/res/Configuration;->uiMode:I

    .line 409
    .line 410
    or-int/2addr v4, v8

    .line 411
    iput v4, v7, Landroid/content/res/Configuration;->uiMode:I

    .line 412
    .line 413
    :cond_19c
    iget v4, v3, Landroid/content/res/Configuration;->uiMode:I

    .line 414
    .line 415
    and-int/lit8 v4, v4, 0x30

    .line 416
    .line 417
    iget v8, v6, Landroid/content/res/Configuration;->uiMode:I

    .line 418
    .line 419
    and-int/lit8 v8, v8, 0x30

    .line 420
    .line 421
    if-eq v4, v8, :cond_1ab

    .line 422
    .line 423
    iget v4, v7, Landroid/content/res/Configuration;->uiMode:I

    .line 424
    .line 425
    or-int/2addr v4, v8

    .line 426
    iput v4, v7, Landroid/content/res/Configuration;->uiMode:I

    .line 427
    .line 428
    :cond_1ab
    iget v4, v3, Landroid/content/res/Configuration;->screenWidthDp:I

    .line 429
    .line 430
    iget v8, v6, Landroid/content/res/Configuration;->screenWidthDp:I

    .line 431
    .line 432
    if-eq v4, v8, :cond_1b3

    .line 433
    .line 434
    iput v8, v7, Landroid/content/res/Configuration;->screenWidthDp:I

    .line 435
    .line 436
    :cond_1b3
    iget v4, v3, Landroid/content/res/Configuration;->screenHeightDp:I

    .line 437
    .line 438
    iget v8, v6, Landroid/content/res/Configuration;->screenHeightDp:I

    .line 439
    .line 440
    if-eq v4, v8, :cond_1bb

    .line 441
    .line 442
    iput v8, v7, Landroid/content/res/Configuration;->screenHeightDp:I

    .line 443
    .line 444
    :cond_1bb
    iget v4, v3, Landroid/content/res/Configuration;->smallestScreenWidthDp:I

    .line 445
    .line 446
    iget v8, v6, Landroid/content/res/Configuration;->smallestScreenWidthDp:I

    .line 447
    .line 448
    if-eq v4, v8, :cond_1c3

    .line 449
    .line 450
    iput v8, v7, Landroid/content/res/Configuration;->smallestScreenWidthDp:I

    .line 451
    .line 452
    :cond_1c3
    iget v3, v3, Landroid/content/res/Configuration;->densityDpi:I

    .line 453
    .line 454
    iget v4, v6, Landroid/content/res/Configuration;->densityDpi:I

    .line 455
    .line 456
    if-eq v3, v4, :cond_1cd

    .line 457
    .line 458
    iput v4, v7, Landroid/content/res/Configuration;->densityDpi:I

    .line 459
    .line 460
    goto :goto_1cd

    .line 461
    :cond_1cc
    move-object v7, v5

    .line 462
    :cond_1cd
    :goto_1cd
    invoke-static {p1, v0, v2, v7, v1}, Li6;->u(Landroid/content/Context;ILka0;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;

    .line 463
    .line 464
    .line 465
    move-result-object v0

    .line 466
    new-instance v2, Lrh;

    .line 467
    .line 468
    const v3, 0x7f120236

    .line 469
    .line 470
    .line 471
    invoke-direct {v2, p1, v3}, Lrh;-><init>(Landroid/content/Context;I)V

    .line 472
    .line 473
    .line 474
    invoke-virtual {v2, v0}, Lrh;->a(Landroid/content/res/Configuration;)V

    .line 475
    .line 476
    .line 477
    :try_start_1dc
    invoke-virtual {p1}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    .line 478
    .line 479
    .line 480
    move-result-object p1
    :try_end_1e0
    .catch Ljava/lang/NullPointerException; {:try_start_1dc .. :try_end_1e0} :catch_229

    .line 481
    if-eqz p1, :cond_229

    .line 482
    .line 483
    invoke-virtual {v2}, Lrh;->getTheme()Landroid/content/res/Resources$Theme;

    .line 484
    .line 485
    .line 486
    move-result-object p1

    .line 487
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 488
    .line 489
    const/16 v3, 0x1d

    .line 490
    .line 491
    if-lt v0, v3, :cond_1f0

    .line 492
    .line 493
    invoke-static {p1}, Li8;->c(Landroid/content/res/Resources$Theme;)V

    .line 494
    .line 495
    .line 496
    goto :goto_229

    .line 497
    :cond_1f0
    sget-object v0, Lt51;->m:Ljava/lang/Object;

    .line 498
    .line 499
    monitor-enter v0

    .line 500
    :try_start_1f3
    sget-boolean v3, Lt51;->o:Z
    :try_end_1f5
    .catchall {:try_start_1f3 .. :try_end_1f5} :catchall_205

    .line 501
    .line 502
    if-nez v3, :cond_211

    .line 503
    .line 504
    :try_start_1f7
    const-class v3, Landroid/content/res/Resources$Theme;

    .line 505
    .line 506
    const-string v4, "rebase"

    .line 507
    .line 508
    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 509
    .line 510
    .line 511
    move-result-object v3

    .line 512
    sput-object v3, Lt51;->n:Ljava/lang/reflect/Method;

    .line 513
    .line 514
    invoke-virtual {v3, v1}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_204
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1f7 .. :try_end_204} :catch_207
    .catchall {:try_start_1f7 .. :try_end_204} :catchall_205

    .line 515
    .line 516
    .line 517
    goto :goto_20f

    .line 518
    :catchall_205
    move-exception p0

    .line 519
    goto :goto_227

    .line 520
    :catch_207
    move-exception v3

    .line 521
    :try_start_208
    const-string v4, "ResourcesCompat"

    .line 522
    .line 523
    const-string v6, "Failed to retrieve rebase() method"

    .line 524
    .line 525
    invoke-static {v4, v6, v3}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 526
    .line 527
    .line 528
    :goto_20f
    sput-boolean v1, Lt51;->o:Z

    .line 529
    .line 530
    :cond_211
    sget-object v1, Lt51;->n:Ljava/lang/reflect/Method;
    :try_end_213
    .catchall {:try_start_208 .. :try_end_213} :catchall_205

    .line 531
    .line 532
    if-eqz v1, :cond_225

    .line 533
    .line 534
    :try_start_215
    invoke-virtual {v1, p1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_218
    .catch Ljava/lang/IllegalAccessException; {:try_start_215 .. :try_end_218} :catch_21b
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_215 .. :try_end_218} :catch_219
    .catchall {:try_start_215 .. :try_end_218} :catchall_205

    .line 535
    .line 536
    .line 537
    goto :goto_225

    .line 538
    :catch_219
    move-exception p1

    .line 539
    goto :goto_21c

    .line 540
    :catch_21b
    move-exception p1

    .line 541
    :goto_21c
    :try_start_21c
    const-string v1, "ResourcesCompat"

    .line 542
    .line 543
    const-string v3, "Failed to invoke rebase() method via reflection"

    .line 544
    .line 545
    invoke-static {v1, v3, p1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 546
    .line 547
    .line 548
    sput-object v5, Lt51;->n:Ljava/lang/reflect/Method;

    .line 549
    .line 550
    :cond_225
    :goto_225
    monitor-exit v0

    .line 551
    goto :goto_229

    .line 552
    :goto_227
    monitor-exit v0
    :try_end_228
    .catchall {:try_start_21c .. :try_end_228} :catchall_205

    .line 553
    throw p0

    .line 554
    :catch_229
    :cond_229
    :goto_229
    move-object p1, v2

    .line 555
    :goto_22a
    invoke-super {p0, p1}, Landroid/content/ContextWrapper;->attachBaseContext(Landroid/content/Context;)V

    .line 556
    .line 557
    .line 558
    return-void
.end method

.method public closeOptionsMenu()V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lk5;->getSupportActionBar()Lb2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v1, v2}, Landroid/view/Window;->hasFeature(I)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_1a

    .line 15
    .line 16
    if-eqz v0, :cond_17

    .line 17
    .line 18
    invoke-virtual {v0}, Lb2;->a()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_1a

    .line 23
    .line 24
    :cond_17
    invoke-super {p0}, Landroid/app/Activity;->closeOptionsMenu()V

    .line 25
    .line 26
    .line 27
    :cond_1a
    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .registers 5

    .line 1
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Lk5;->getSupportActionBar()Lb2;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/16 v2, 0x52

    .line 10
    .line 11
    if-ne v0, v2, :cond_16

    .line 12
    .line 13
    if-eqz v1, :cond_16

    .line 14
    .line 15
    invoke-virtual {v1, p1}, Lb2;->l(Landroid/view/KeyEvent;)Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_16

    .line 20
    .line 21
    const/4 p0, 0x1

    .line 22
    return p0

    .line 23
    :cond_16
    invoke-super {p0, p1}, Lmf;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z

    .line 24
    .line 25
    .line 26
    move-result p0

    .line 27
    return p0
.end method

.method public final e()V
    .registers 3

    .line 1
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    .line 11
    .line 12
    const v1, 0x7f080429

    .line 13
    .line 14
    .line 15
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    .line 28
    .line 29
    const v1, 0x7f08042c

    .line 30
    .line 31
    .line 32
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 33
    .line 34
    .line 35
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 36
    .line 37
    .line 38
    move-result-object v0

    .line 39
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 40
    .line 41
    .line 42
    move-result-object v0

    .line 43
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    .line 45
    .line 46
    const v1, 0x7f08042b

    .line 47
    .line 48
    .line 49
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 53
    .line 54
    .line 55
    move-result-object v0

    .line 56
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v0

    .line 60
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    .line 62
    .line 63
    const v1, 0x7f08042a

    .line 64
    .line 65
    .line 66
    invoke-virtual {v0, v1, p0}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 67
    .line 68
    .line 69
    return-void
.end method

.method public findViewById(I)Landroid/view/View;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Landroid/view/View;",
            ">(I)TT;"
        }
    .end annotation

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Li6;

    .line 6
    .line 7
    invoke-virtual {p0}, Li6;->x()V

    .line 8
    .line 9
    .line 10
    iget-object p0, p0, Li6;->q:Landroid/view/Window;

    .line 11
    .line 12
    invoke-virtual {p0, p1}, Landroid/view/Window;->findViewById(I)Landroid/view/View;

    .line 13
    .line 14
    .line 15
    move-result-object p0

    .line 16
    return-object p0
.end method

.method public getDelegate()Lv5;
    .registers 3

    .line 1
    iget-object v0, p0, Lk5;->mDelegate:Lv5;

    .line 2
    .line 3
    if-nez v0, :cond_e

    .line 4
    .line 5
    sget-object v0, Lv5;->f:Lut0;

    .line 6
    .line 7
    new-instance v0, Li6;

    .line 8
    .line 9
    const/4 v1, 0x0

    .line 10
    invoke-direct {v0, p0, v1, p0, p0}, Li6;-><init>(Landroid/content/Context;Landroid/view/Window;Lo5;Ljava/lang/Object;)V

    .line 11
    .line 12
    .line 13
    iput-object v0, p0, Lk5;->mDelegate:Lv5;

    .line 14
    .line 15
    :cond_e
    iget-object p0, p0, Lk5;->mDelegate:Lv5;

    .line 16
    .line 17
    return-object p0
.end method

.method public getDrawerToggleDelegate()Le2;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Li6;

    .line 6
    .line 7
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    .line 9
    .line 10
    new-instance p0, Lmp;

    .line 11
    .line 12
    const/16 v0, 0xb

    .line 13
    .line 14
    invoke-direct {p0, v0}, Lmp;-><init>(I)V

    .line 15
    .line 16
    .line 17
    return-object p0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .registers 3

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Li6;

    .line 6
    .line 7
    iget-object v0, p0, Li6;->u:Ll11;

    .line 8
    .line 9
    if-nez v0, :cond_1f

    .line 10
    .line 11
    invoke-virtual {p0}, Li6;->B()V

    .line 12
    .line 13
    .line 14
    new-instance v0, Ll11;

    .line 15
    .line 16
    iget-object v1, p0, Li6;->t:Lb2;

    .line 17
    .line 18
    if-eqz v1, :cond_18

    .line 19
    .line 20
    invoke-virtual {v1}, Lb2;->e()Landroid/content/Context;

    .line 21
    .line 22
    .line 23
    move-result-object v1

    .line 24
    goto :goto_1a

    .line 25
    :cond_18
    iget-object v1, p0, Li6;->p:Landroid/content/Context;

    .line 26
    .line 27
    :goto_1a
    invoke-direct {v0, v1}, Ll11;-><init>(Landroid/content/Context;)V

    .line 28
    .line 29
    .line 30
    iput-object v0, p0, Li6;->u:Ll11;

    .line 31
    .line 32
    :cond_1f
    iget-object p0, p0, Li6;->u:Ll11;

    .line 33
    .line 34
    return-object p0
.end method

.method public getResources()Landroid/content/res/Resources;
    .registers 3

    .line 1
    iget-object v0, p0, Lk5;->mResources:Landroid/content/res/Resources;

    .line 2
    .line 3
    if-nez v0, :cond_6

    .line 4
    .line 5
    sget v1, Lp81;->a:I

    .line 6
    .line 7
    :cond_6
    if-nez v0, :cond_d

    .line 8
    .line 9
    invoke-super {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 10
    .line 11
    .line 12
    move-result-object p0

    .line 13
    return-object p0

    .line 14
    :cond_d
    return-object v0
.end method

.method public getSupportActionBar()Lb2;
    .registers 1

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Li6;

    .line 6
    .line 7
    invoke-virtual {p0}, Li6;->B()V

    .line 8
    .line 9
    .line 10
    iget-object p0, p0, Li6;->t:Lb2;

    .line 11
    .line 12
    return-object p0
.end method

.method public getSupportParentActivityIntent()Landroid/content/Intent;
    .registers 1

    .line 1
    invoke-static {p0}, Lge1;->D(Lk5;)Landroid/content/Intent;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method

.method public invalidateOptionsMenu()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lv5;->b()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 10

    .line 1
    invoke-super {p0, p1}, Lnf;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    check-cast p1, Li6;

    .line 9
    .line 10
    iget-boolean v0, p1, Li6;->K:Z

    .line 11
    .line 12
    if-eqz v0, :cond_1b

    .line 13
    .line 14
    iget-boolean v0, p1, Li6;->E:Z

    .line 15
    .line 16
    if-eqz v0, :cond_1b

    .line 17
    .line 18
    invoke-virtual {p1}, Li6;->B()V

    .line 19
    .line 20
    .line 21
    iget-object v0, p1, Li6;->t:Lb2;

    .line 22
    .line 23
    if-eqz v0, :cond_1b

    .line 24
    .line 25
    invoke-virtual {v0}, Lb2;->i()V

    .line 26
    .line 27
    .line 28
    :cond_1b
    invoke-static {}, Ll6;->a()Ll6;

    .line 29
    .line 30
    .line 31
    move-result-object v0

    .line 32
    iget-object v1, p1, Li6;->p:Landroid/content/Context;

    .line 33
    .line 34
    monitor-enter v0

    .line 35
    :try_start_22
    iget-object v2, v0, Ll6;->a:Lup0;

    .line 36
    .line 37
    monitor-enter v2
    :try_end_25
    .catchall {:try_start_22 .. :try_end_25} :catchall_74

    .line 38
    :try_start_25
    iget-object v3, v2, Lup0;->b:Ljava/util/WeakHashMap;

    .line 39
    .line 40
    invoke-virtual {v3, v1}, Ljava/util/WeakHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 41
    .line 42
    .line 43
    move-result-object v1

    .line 44
    check-cast v1, Lwa0;

    .line 45
    .line 46
    const/4 v3, 0x0

    .line 47
    if-eqz v1, :cond_41

    .line 48
    .line 49
    iget v4, v1, Lwa0;->i:I

    .line 50
    .line 51
    iget-object v5, v1, Lwa0;->h:[Ljava/lang/Object;

    .line 52
    .line 53
    move v6, v3

    .line 54
    :goto_35
    if-ge v6, v4, :cond_3d

    .line 55
    .line 56
    const/4 v7, 0x0

    .line 57
    aput-object v7, v5, v6

    .line 58
    .line 59
    add-int/lit8 v6, v6, 0x1

    .line 60
    .line 61
    goto :goto_35

    .line 62
    :cond_3d
    iput v3, v1, Lwa0;->i:I

    .line 63
    .line 64
    iput-boolean v3, v1, Lwa0;->f:Z
    :try_end_41
    .catchall {:try_start_25 .. :try_end_41} :catchall_71

    .line 65
    .line 66
    :cond_41
    :try_start_41
    monitor-exit v2
    :try_end_42
    .catchall {:try_start_41 .. :try_end_42} :catchall_74

    .line 67
    monitor-exit v0

    .line 68
    new-instance v0, Landroid/content/res/Configuration;

    .line 69
    .line 70
    iget-object v1, p1, Li6;->p:Landroid/content/Context;

    .line 71
    .line 72
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 73
    .line 74
    .line 75
    move-result-object v1

    .line 76
    invoke-virtual {v1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 77
    .line 78
    .line 79
    move-result-object v1

    .line 80
    invoke-direct {v0, v1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    .line 81
    .line 82
    .line 83
    iput-object v0, p1, Li6;->W:Landroid/content/res/Configuration;

    .line 84
    .line 85
    invoke-virtual {p1, v3, v3}, Li6;->n(ZZ)Z

    .line 86
    .line 87
    .line 88
    iget-object p1, p0, Lk5;->mResources:Landroid/content/res/Resources;

    .line 89
    .line 90
    if-eqz p1, :cond_70

    .line 91
    .line 92
    invoke-super {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 93
    .line 94
    .line 95
    move-result-object p1

    .line 96
    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 97
    .line 98
    .line 99
    move-result-object p1

    .line 100
    invoke-super {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 101
    .line 102
    .line 103
    move-result-object v0

    .line 104
    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 105
    .line 106
    .line 107
    move-result-object v0

    .line 108
    iget-object p0, p0, Lk5;->mResources:Landroid/content/res/Resources;

    .line 109
    .line 110
    invoke-virtual {p0, p1, v0}, Landroid/content/res/Resources;->updateConfiguration(Landroid/content/res/Configuration;Landroid/util/DisplayMetrics;)V

    .line 111
    .line 112
    .line 113
    :cond_70
    return-void

    .line 114
    :catchall_71
    move-exception p0

    .line 115
    :try_start_72
    monitor-exit v2
    :try_end_73
    .catchall {:try_start_72 .. :try_end_73} :catchall_71

    .line 116
    :try_start_73
    throw p0

    .line 117
    :catchall_74
    move-exception p0

    .line 118
    monitor-exit v0
    :try_end_76
    .catchall {:try_start_73 .. :try_end_76} :catchall_74

    .line 119
    throw p0
.end method

.method public onContentChanged()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lk5;->onSupportContentChanged()V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onCreateSupportNavigateUpTaskStack(La31;)V
    .registers 5

    .line 1
    iget-object v0, p1, La31;->f:Ljava/util/ArrayList;

    .line 2
    .line 3
    iget-object p1, p1, La31;->g:Lk5;

    .line 4
    .line 5
    invoke-virtual {p0}, Lk5;->getSupportParentActivityIntent()Landroid/content/Intent;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    if-nez v1, :cond_e

    .line 10
    .line 11
    invoke-static {p0}, Lge1;->D(Lk5;)Landroid/content/Intent;

    .line 12
    .line 13
    .line 14
    move-result-object v1

    .line 15
    :cond_e
    if-eqz v1, :cond_46

    .line 16
    .line 17
    invoke-virtual {v1}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    if-nez p0, :cond_1e

    .line 22
    .line 23
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 24
    .line 25
    .line 26
    move-result-object p0

    .line 27
    invoke-virtual {v1, p0}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    :cond_1e
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 32
    .line 33
    .line 34
    move-result v2

    .line 35
    :try_start_22
    invoke-static {p1, p0}, Lge1;->E(Lk5;Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    :goto_26
    if-eqz p0, :cond_34

    .line 40
    .line 41
    invoke-virtual {v0, v2, p0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 42
    .line 43
    .line 44
    invoke-virtual {p0}, Landroid/content/Intent;->getComponent()Landroid/content/ComponentName;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    invoke-static {p1, p0}, Lge1;->E(Lk5;Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 49
    .line 50
    .line 51
    move-result-object p0
    :try_end_33
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_22 .. :try_end_33} :catch_38

    .line 52
    goto :goto_26

    .line 53
    :cond_34
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 54
    .line 55
    .line 56
    return-void

    .line 57
    :catch_38
    move-exception p0

    .line 58
    const-string p1, "TaskStackBuilder"

    .line 59
    .line 60
    const-string v0, "Bad ComponentName while traversing activity parent metadata"

    .line 61
    .line 62
    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 63
    .line 64
    .line 65
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 66
    .line 67
    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/Throwable;)V

    .line 68
    .line 69
    .line 70
    throw p1

    .line 71
    :cond_46
    return-void
.end method

.method public onDestroy()V
    .registers 1

    .line 1
    invoke-super {p0}, Lay;->onDestroy()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0}, Lv5;->f()V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onLocalesChanged(Lka0;)V
    .registers 2

    .line 1
    return-void
.end method

.method public final onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .registers 4

    .line 1
    invoke-super {p0, p1, p2}, Lay;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 2
    .line 3
    .line 4
    move-result p1

    .line 5
    if-eqz p1, :cond_8

    .line 6
    .line 7
    const/4 p0, 0x1

    .line 8
    return p0

    .line 9
    :cond_8
    invoke-virtual {p0}, Lk5;->getSupportActionBar()Lb2;

    .line 10
    .line 11
    .line 12
    move-result-object p1

    .line 13
    invoke-interface {p2}, Landroid/view/MenuItem;->getItemId()I

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    const v0, 0x102002c

    .line 18
    .line 19
    .line 20
    if-ne p2, v0, :cond_24

    .line 21
    .line 22
    if-eqz p1, :cond_24

    .line 23
    .line 24
    invoke-virtual {p1}, Lb2;->d()I

    .line 25
    .line 26
    .line 27
    move-result p1

    .line 28
    and-int/lit8 p1, p1, 0x4

    .line 29
    .line 30
    if-eqz p1, :cond_24

    .line 31
    .line 32
    invoke-virtual {p0}, Lk5;->onSupportNavigateUp()Z

    .line 33
    .line 34
    .line 35
    move-result p0

    .line 36
    return p0

    .line 37
    :cond_24
    const/4 p0, 0x0

    .line 38
    return p0
.end method

.method public onMenuOpened(ILandroid/view/Menu;)Z
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onMenuOpened(ILandroid/view/Menu;)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method

.method public onNightModeChanged(I)V
    .registers 2

    .line 1
    return-void
.end method

.method public onPanelClosed(ILandroid/view/Menu;)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Lnf;->onPanelClosed(ILandroid/view/Menu;)V

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public onPostCreate(Landroid/os/Bundle;)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroid/app/Activity;->onPostCreate(Landroid/os/Bundle;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Li6;

    .line 9
    .line 10
    invoke-virtual {p0}, Li6;->x()V

    .line 11
    .line 12
    .line 13
    return-void
.end method

.method public onPostResume()V
    .registers 2

    .line 1
    invoke-super {p0}, Lay;->onPostResume()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Li6;

    .line 9
    .line 10
    invoke-virtual {p0}, Li6;->B()V

    .line 11
    .line 12
    .line 13
    iget-object p0, p0, Li6;->t:Lb2;

    .line 14
    .line 15
    if-eqz p0, :cond_14

    .line 16
    .line 17
    const/4 v0, 0x1

    .line 18
    invoke-virtual {p0, v0}, Lb2;->q(Z)V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public onPrepareSupportNavigateUpTaskStack(La31;)V
    .registers 2

    .line 1
    return-void
.end method

.method public onStart()V
    .registers 3

    .line 1
    invoke-super {p0}, Lay;->onStart()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Li6;

    .line 9
    .line 10
    const/4 v0, 0x1

    .line 11
    const/4 v1, 0x0

    .line 12
    invoke-virtual {p0, v0, v1}, Li6;->n(ZZ)Z

    .line 13
    .line 14
    .line 15
    return-void
.end method

.method public onStop()V
    .registers 2

    .line 1
    invoke-super {p0}, Lay;->onStop()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Li6;

    .line 9
    .line 10
    invoke-virtual {p0}, Li6;->B()V

    .line 11
    .line 12
    .line 13
    iget-object p0, p0, Li6;->t:Lb2;

    .line 14
    .line 15
    if-eqz p0, :cond_14

    .line 16
    .line 17
    const/4 v0, 0x0

    .line 18
    invoke-virtual {p0, v0}, Lb2;->q(Z)V

    .line 19
    .line 20
    .line 21
    :cond_14
    return-void
.end method

.method public onSupportActionModeFinished(Ly2;)V
    .registers 2

    .line 1
    return-void
.end method

.method public onSupportActionModeStarted(Ly2;)V
    .registers 2

    .line 1
    return-void
.end method

.method public onSupportContentChanged()V
    .registers 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public onSupportNavigateUp()Z
    .registers 6

    .line 1
    invoke-virtual {p0}, Lk5;->getSupportParentActivityIntent()Landroid/content/Intent;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_51

    .line 7
    .line 8
    invoke-virtual {p0, v0}, Lk5;->supportShouldUpRecreateTask(Landroid/content/Intent;)Z

    .line 9
    .line 10
    .line 11
    move-result v2

    .line 12
    if-eqz v2, :cond_4c

    .line 13
    .line 14
    new-instance v0, La31;

    .line 15
    .line 16
    invoke-direct {v0, p0}, La31;-><init>(Lk5;)V

    .line 17
    .line 18
    .line 19
    invoke-virtual {p0, v0}, Lk5;->onCreateSupportNavigateUpTaskStack(La31;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p0, v0}, Lk5;->onPrepareSupportNavigateUpTaskStack(La31;)V

    .line 23
    .line 24
    .line 25
    iget-object v2, v0, La31;->f:Ljava/util/ArrayList;

    .line 26
    .line 27
    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    .line 28
    .line 29
    .line 30
    move-result v3

    .line 31
    if-nez v3, :cond_46

    .line 32
    .line 33
    new-array v3, v1, [Landroid/content/Intent;

    .line 34
    .line 35
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object v2

    .line 39
    check-cast v2, [Landroid/content/Intent;

    .line 40
    .line 41
    new-instance v3, Landroid/content/Intent;

    .line 42
    .line 43
    aget-object v4, v2, v1

    .line 44
    .line 45
    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    .line 46
    .line 47
    .line 48
    const v4, 0x1000c000

    .line 49
    .line 50
    .line 51
    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 52
    .line 53
    .line 54
    move-result-object v3

    .line 55
    aput-object v3, v2, v1

    .line 56
    .line 57
    iget-object v0, v0, La31;->g:Lk5;

    .line 58
    .line 59
    const/4 v1, 0x0

    .line 60
    invoke-virtual {v0, v2, v1}, Landroid/content/Context;->startActivities([Landroid/content/Intent;Landroid/os/Bundle;)V

    .line 61
    .line 62
    .line 63
    :try_start_3e
    invoke-virtual {p0}, Landroid/app/Activity;->finishAffinity()V
    :try_end_41
    .catch Ljava/lang/IllegalStateException; {:try_start_3e .. :try_end_41} :catch_42

    .line 64
    .line 65
    .line 66
    goto :goto_4f

    .line 67
    :catch_42
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    .line 68
    .line 69
    .line 70
    goto :goto_4f

    .line 71
    :cond_46
    const-string p0, "No intents added to TaskStackBuilder; cannot startActivities"

    .line 72
    .line 73
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 74
    .line 75
    .line 76
    return v1

    .line 77
    :cond_4c
    invoke-virtual {p0, v0}, Lk5;->supportNavigateUpTo(Landroid/content/Intent;)V

    .line 78
    .line 79
    .line 80
    :goto_4f
    const/4 p0, 0x1

    .line 81
    return p0

    .line 82
    :cond_51
    return v1
.end method

.method public onTitleChanged(Ljava/lang/CharSequence;I)V
    .registers 3

    .line 1
    invoke-super {p0, p1, p2}, Landroid/app/Activity;->onTitleChanged(Ljava/lang/CharSequence;I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0, p1}, Lv5;->l(Ljava/lang/CharSequence;)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public onWindowStartingSupportActionMode(Lx2;)Ly2;
    .registers 2

    .line 1
    const/4 p0, 0x0

    .line 2
    return-object p0
.end method

.method public openOptionsMenu()V
    .registers 4

    .line 1
    invoke-virtual {p0}, Lk5;->getSupportActionBar()Lb2;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 6
    .line 7
    .line 8
    move-result-object v1

    .line 9
    const/4 v2, 0x0

    .line 10
    invoke-virtual {v1, v2}, Landroid/view/Window;->hasFeature(I)Z

    .line 11
    .line 12
    .line 13
    move-result v1

    .line 14
    if-eqz v1, :cond_1a

    .line 15
    .line 16
    if-eqz v0, :cond_17

    .line 17
    .line 18
    invoke-virtual {v0}, Lb2;->m()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    if-nez v0, :cond_1a

    .line 23
    .line 24
    :cond_17
    invoke-super {p0}, Landroid/app/Activity;->openOptionsMenu()V

    .line 25
    .line 26
    .line 27
    :cond_1a
    return-void
.end method

.method public setContentView(I)V
    .registers 2

    .line 1
    invoke-virtual {p0}, Lk5;->e()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    invoke-virtual {p0, p1}, Lv5;->i(I)V

    .line 9
    .line 10
    .line 11
    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .registers 2

    .line 12
    invoke-virtual {p0}, Lk5;->e()V

    .line 13
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    move-result-object p0

    invoke-virtual {p0, p1}, Lv5;->j(Landroid/view/View;)V

    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 3

    .line 14
    invoke-virtual {p0}, Lk5;->e()V

    .line 15
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    move-result-object p0

    invoke-virtual {p0, p1, p2}, Lv5;->k(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public setSupportActionBar(Landroidx/appcompat/widget/Toolbar;)V
    .registers 5

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    check-cast p0, Li6;

    .line 6
    .line 7
    iget-object v0, p0, Li6;->o:Ljava/lang/Object;

    .line 8
    .line 9
    instance-of v0, v0, Landroid/app/Activity;

    .line 10
    .line 11
    if-nez v0, :cond_d

    .line 12
    .line 13
    return-void

    .line 14
    :cond_d
    invoke-virtual {p0}, Li6;->B()V

    .line 15
    .line 16
    .line 17
    iget-object v0, p0, Li6;->t:Lb2;

    .line 18
    .line 19
    instance-of v1, v0, Lcc1;

    .line 20
    .line 21
    if-nez v1, :cond_4d

    .line 22
    .line 23
    const/4 v1, 0x0

    .line 24
    iput-object v1, p0, Li6;->u:Ll11;

    .line 25
    .line 26
    if-eqz v0, :cond_1e

    .line 27
    .line 28
    invoke-virtual {v0}, Lb2;->j()V

    .line 29
    .line 30
    .line 31
    :cond_1e
    iput-object v1, p0, Li6;->t:Lb2;

    .line 32
    .line 33
    if-eqz p1, :cond_45

    .line 34
    .line 35
    new-instance v0, Lm41;

    .line 36
    .line 37
    iget-object v1, p0, Li6;->o:Ljava/lang/Object;

    .line 38
    .line 39
    instance-of v2, v1, Landroid/app/Activity;

    .line 40
    .line 41
    if-eqz v2, :cond_31

    .line 42
    .line 43
    check-cast v1, Landroid/app/Activity;

    .line 44
    .line 45
    invoke-virtual {v1}, Landroid/app/Activity;->getTitle()Ljava/lang/CharSequence;

    .line 46
    .line 47
    .line 48
    move-result-object v1

    .line 49
    goto :goto_33

    .line 50
    :cond_31
    iget-object v1, p0, Li6;->v:Ljava/lang/CharSequence;

    .line 51
    .line 52
    :goto_33
    iget-object v2, p0, Li6;->r:Lc6;

    .line 53
    .line 54
    invoke-direct {v0, p1, v1, v2}, Lm41;-><init>(Landroidx/appcompat/widget/Toolbar;Ljava/lang/CharSequence;Lc6;)V

    .line 55
    .line 56
    .line 57
    iput-object v0, p0, Li6;->t:Lb2;

    .line 58
    .line 59
    iget-object v1, p0, Li6;->r:Lc6;

    .line 60
    .line 61
    iget-object v0, v0, Lm41;->c:Ll41;

    .line 62
    .line 63
    iput-object v0, v1, Lc6;->g:Ll41;

    .line 64
    .line 65
    const/4 v0, 0x1

    .line 66
    invoke-virtual {p1, v0}, Landroidx/appcompat/widget/Toolbar;->setBackInvokedCallbackEnabled(Z)V

    .line 67
    .line 68
    .line 69
    goto :goto_49

    .line 70
    :cond_45
    iget-object p1, p0, Li6;->r:Lc6;

    .line 71
    .line 72
    iput-object v1, p1, Lc6;->g:Ll41;

    .line 73
    .line 74
    :goto_49
    invoke-virtual {p0}, Li6;->b()V

    .line 75
    .line 76
    .line 77
    return-void

    .line 78
    :cond_4d
    const-string p0, "This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead."

    .line 79
    .line 80
    invoke-static {p0}, Lm0;->g(Ljava/lang/String;)V

    .line 81
    .line 82
    .line 83
    return-void
.end method

.method public setSupportProgress(I)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public setSupportProgressBarIndeterminate(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public setSupportProgressBarIndeterminateVisibility(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public setSupportProgressBarVisibility(Z)V
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .line 1
    return-void
.end method

.method public setTheme(I)V
    .registers 2

    .line 1
    invoke-super {p0, p1}, Landroid/content/Context;->setTheme(I)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 5
    .line 6
    .line 7
    move-result-object p0

    .line 8
    check-cast p0, Li6;

    .line 9
    .line 10
    iput p1, p0, Li6;->Y:I

    .line 11
    .line 12
    return-void
.end method

.method public startSupportActionMode(Lx2;)Ly2;
    .registers 2

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Lv5;->m(Lx2;)Ly2;

    .line 6
    .line 7
    .line 8
    move-result-object p0

    .line 9
    return-object p0
.end method

.method public supportInvalidateOptionsMenu()V
    .registers 1

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0}, Lv5;->b()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public supportNavigateUpTo(Landroid/content/Intent;)V
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroid/app/Activity;->navigateUpTo(Landroid/content/Intent;)Z

    .line 2
    .line 3
    .line 4
    return-void
.end method

.method public supportRequestWindowFeature(I)Z
    .registers 2

    .line 1
    invoke-virtual {p0}, Lk5;->getDelegate()Lv5;

    .line 2
    .line 3
    .line 4
    move-result-object p0

    .line 5
    invoke-virtual {p0, p1}, Lv5;->h(I)Z

    .line 6
    .line 7
    .line 8
    move-result p0

    .line 9
    return p0
.end method

.method public supportShouldUpRecreateTask(Landroid/content/Intent;)Z
    .registers 2

    .line 1
    invoke-virtual {p0, p1}, Landroid/app/Activity;->shouldUpRecreateTask(Landroid/content/Intent;)Z

    .line 2
    .line 3
    .line 4
    move-result p0

    .line 5
    return p0
.end method
