###### Class defpackage.hl0 (hl0)
.class public final Lhl0;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Lbo0;
.implements Lfl0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Lhl0;->a:I

    .line 2
    .line 3
    iput-object p2, p0, Lhl0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final b()Loq0;
    .registers 2

    .line 1
    iget v0, p0, Lhl0;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Lhl0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_12

    .line 6
    .line 7
    .line 8
    check-cast p0, Ls11;

    .line 9
    .line 10
    iget-object p0, p0, Ls11;->a:Ln11;

    .line 11
    .line 12
    return-object p0

    .line 13
    :pswitch_c
    check-cast p0, Lnl0;

    .line 14
    .line 15
    iget-object p0, p0, Lnl0;->a:Ltg;

    .line 16
    .line 17
    return-object p0

    .line 18
    nop

    .line 19
    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_c
    .end packed-switch
.end method

.method public final d(Ljava/lang/String;Lqz;Lsh;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Lhl0;->a:I

    .line 2
    .line 3
    iget-object p0, p0, Lhl0;->b:Ljava/lang/Object;

    .line 4
    .line 5
    packed-switch v0, :pswitch_data_16

    .line 6
    .line 7
    .line 8
    check-cast p0, Ls11;

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2, p3}, Ls11;->d(Ljava/lang/String;Lqz;Lsh;)Ljava/lang/Object;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    return-object p0

    .line 15
    :pswitch_e
    check-cast p0, Lnl0;

    .line 16
    .line 17
    invoke-virtual {p0, p1, p2, p3}, Lnl0;->d(Ljava/lang/String;Lqz;Lsh;)Ljava/lang/Object;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    nop

    .line 23
    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e
    .end packed-switch
.end method
