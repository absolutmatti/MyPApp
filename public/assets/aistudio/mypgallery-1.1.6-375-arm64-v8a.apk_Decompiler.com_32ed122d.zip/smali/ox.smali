###### Class defpackage.ox (ox)
.class public final Lox;
.super Ljava/lang/Object;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"

# interfaces
.implements Ljava/lang/Runnable;


# static fields
.field public static final j:Ljava/lang/String;

.field public static final k:J


# instance fields
.field public final f:Landroid/content/Context;

.field public final g:Lee1;

.field public final h:Lw20;

.field public i:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    const-string v0, "ForceStopRunnable"

    .line 2
    .line 3
    invoke-static {v0}, Lta0;->i(Ljava/lang/String;)Ljava/lang/String;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    sput-object v0, Lox;->j:Ljava/lang/String;

    .line 8
    .line 9
    const-wide v0, 0x496cebb800L

    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    sput-wide v0, Lox;->k:J

    .line 15
    .line 16
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lee1;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 5
    .line 6
    .line 7
    move-result-object p1

    .line 8
    iput-object p1, p0, Lox;->f:Landroid/content/Context;

    .line 9
    .line 10
    iput-object p2, p0, Lox;->g:Lee1;

    .line 11
    .line 12
    iget-object p1, p2, Lee1;->g:Lw20;

    .line 13
    .line 14
    iput-object p1, p0, Lox;->h:Lw20;

    .line 15
    .line 16
    const/4 p1, 0x0

    .line 17
    iput p1, p0, Lox;->i:I

    .line 18
    .line 19
    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .registers 6

    .line 1
    const-string v0, "alarm"

    .line 2
    .line 3
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    check-cast v0, Landroid/app/AlarmManager;

    .line 8
    .line 9
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 10
    .line 11
    const/16 v2, 0x1f

    .line 12
    .line 13
    if-lt v1, v2, :cond_11

    .line 14
    .line 15
    const/high16 v1, 0xa000000

    .line 16
    .line 17
    goto :goto_13

    .line 18
    :cond_11
    const/high16 v1, 0x8000000

    .line 19
    .line 20
    :goto_13
    new-instance v2, Landroid/content/Intent;

    .line 21
    .line 22
    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    .line 23
    .line 24
    .line 25
    new-instance v3, Landroid/content/ComponentName;

    .line 26
    .line 27
    const-class v4, Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;

    .line 28
    .line 29
    invoke-direct {v3, p0, v4}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 30
    .line 31
    .line 32
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 33
    .line 34
    .line 35
    const-string v3, "ACTION_FORCE_STOP_RESCHEDULE"

    .line 36
    .line 37
    invoke-virtual {v2, v3}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 38
    .line 39
    .line 40
    const/4 v3, -0x1

    .line 41
    invoke-static {p0, v3, v2, v1}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 42
    .line 43
    .line 44
    move-result-object p0

    .line 45
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 46
    .line 47
    .line 48
    move-result-wide v1

    .line 49
    sget-wide v3, Lox;->k:J

    .line 50
    .line 51
    add-long/2addr v1, v3

    .line 52
    if-eqz v0, :cond_39

    .line 53
    .line 54
    const/4 v3, 0x0

    .line 55
    invoke-virtual {v0, v3, v1, v2, p0}, Landroid/app/AlarmManager;->setExact(IJLandroid/app/PendingIntent;)V

    .line 56
    .line 57
    .line 58
    :cond_39
    return-void
.end method


# virtual methods
.method public final a()V
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    const-string v1, "last_force_stop_ms"

    .line 4
    .line 5
    iget-object v2, v0, Lox;->h:Lw20;

    .line 6
    .line 7
    iget-object v3, v0, Lox;->g:Lee1;

    .line 8
    .line 9
    iget-object v4, v3, Lee1;->c:Landroidx/work/impl/WorkDatabase;

    .line 10
    .line 11
    iget-object v5, v3, Lee1;->b:Lig;

    .line 12
    .line 13
    iget-object v6, v3, Lee1;->g:Lw20;

    .line 14
    .line 15
    iget-object v7, v3, Lee1;->c:Landroidx/work/impl/WorkDatabase;

    .line 16
    .line 17
    sget-object v8, Lq21;->k:Ljava/lang/String;

    .line 18
    .line 19
    iget-object v0, v0, Lox;->f:Landroid/content/Context;

    .line 20
    .line 21
    invoke-static {v0}, Lt50;->a(Landroid/content/Context;)Landroid/app/job/JobScheduler;

    .line 22
    .line 23
    .line 24
    move-result-object v8

    .line 25
    invoke-static {v0, v8}, Lq21;->d(Landroid/content/Context;Landroid/app/job/JobScheduler;)Ljava/util/ArrayList;

    .line 26
    .line 27
    .line 28
    move-result-object v9

    .line 29
    invoke-virtual {v4}, Landroidx/work/impl/WorkDatabase;->s()Lo21;

    .line 30
    .line 31
    .line 32
    move-result-object v10

    .line 33
    iget-object v10, v10, Lo21;->a:Lgq0;

    .line 34
    .line 35
    new-instance v11, Lzh;

    .line 36
    .line 37
    const/16 v12, 0xd

    .line 38
    .line 39
    invoke-direct {v11, v12}, Lzh;-><init>(I)V

    .line 40
    .line 41
    .line 42
    const/4 v12, 0x1

    .line 43
    const/4 v13, 0x0

    .line 44
    invoke-static {v10, v12, v13, v11}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v10

    .line 48
    check-cast v10, Ljava/util/List;

    .line 49
    .line 50
    if-eqz v9, :cond_38

    .line 51
    .line 52
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 53
    .line 54
    .line 55
    move-result v11

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    move v11, v13

    .line 58
    :goto_39
    new-instance v14, Ljava/util/HashSet;

    .line 59
    .line 60
    invoke-direct {v14, v11}, Ljava/util/HashSet;-><init>(I)V

    .line 61
    .line 62
    .line 63
    if-eqz v9, :cond_6a

    .line 64
    .line 65
    invoke-virtual {v9}, Ljava/util/ArrayList;->isEmpty()Z

    .line 66
    .line 67
    .line 68
    move-result v11

    .line 69
    if-nez v11, :cond_6a

    .line 70
    .line 71
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 72
    .line 73
    .line 74
    move-result v11

    .line 75
    move v15, v13

    .line 76
    :goto_4b
    if-ge v15, v11, :cond_6a

    .line 77
    .line 78
    invoke-virtual {v9, v15}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v16

    .line 82
    add-int/lit8 v15, v15, 0x1

    .line 83
    .line 84
    check-cast v16, Landroid/app/job/JobInfo;

    .line 85
    .line 86
    invoke-static/range {v16 .. v16}, Lq21;->f(Landroid/app/job/JobInfo;)Lce1;

    .line 87
    .line 88
    .line 89
    move-result-object v12

    .line 90
    if-eqz v12, :cond_61

    .line 91
    .line 92
    iget-object v12, v12, Lce1;->a:Ljava/lang/String;

    .line 93
    .line 94
    invoke-virtual {v14, v12}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 95
    .line 96
    .line 97
    goto :goto_68

    .line 98
    :cond_61
    invoke-virtual/range {v16 .. v16}, Landroid/app/job/JobInfo;->getId()I

    .line 99
    .line 100
    .line 101
    move-result v12

    .line 102
    invoke-static {v8, v12}, Lq21;->b(Landroid/app/job/JobScheduler;I)V

    .line 103
    .line 104
    .line 105
    :goto_68
    const/4 v12, 0x1

    .line 106
    goto :goto_4b

    .line 107
    :cond_6a
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 108
    .line 109
    .line 110
    move-result-object v8

    .line 111
    :cond_6e
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 112
    .line 113
    .line 114
    move-result v9

    .line 115
    if-eqz v9, :cond_8d

    .line 116
    .line 117
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object v9

    .line 121
    check-cast v9, Ljava/lang/String;

    .line 122
    .line 123
    invoke-virtual {v14, v9}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    .line 124
    .line 125
    .line 126
    move-result v9

    .line 127
    if-nez v9, :cond_6e

    .line 128
    .line 129
    invoke-static {}, Lta0;->g()Lta0;

    .line 130
    .line 131
    .line 132
    move-result-object v8

    .line 133
    sget-object v9, Lq21;->k:Ljava/lang/String;

    .line 134
    .line 135
    const-string v11, "Reconciling jobs"

    .line 136
    .line 137
    invoke-virtual {v8, v9, v11}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 138
    .line 139
    .line 140
    const/4 v8, 0x1

    .line 141
    goto :goto_8e

    .line 142
    :cond_8d
    move v8, v13

    .line 143
    :goto_8e
    const-wide/16 v11, -0x1

    .line 144
    .line 145
    if-eqz v8, :cond_ba

    .line 146
    .line 147
    invoke-virtual {v4}, Lgq0;->b()V

    .line 148
    .line 149
    .line 150
    :try_start_95
    invoke-virtual {v4}, Landroidx/work/impl/WorkDatabase;->v()Lre1;

    .line 151
    .line 152
    .line 153
    move-result-object v9

    .line 154
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 155
    .line 156
    .line 157
    move-result-object v10

    .line 158
    :goto_9d
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 159
    .line 160
    .line 161
    move-result v14

    .line 162
    if-eqz v14, :cond_af

    .line 163
    .line 164
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v14

    .line 168
    check-cast v14, Ljava/lang/String;

    .line 169
    .line 170
    invoke-virtual {v9, v11, v12, v14}, Lre1;->c(JLjava/lang/String;)V

    .line 171
    .line 172
    .line 173
    goto :goto_9d

    .line 174
    :catchall_ad
    move-exception v0

    .line 175
    goto :goto_b6

    .line 176
    :cond_af
    invoke-virtual {v4}, Lgq0;->o()V
    :try_end_b2
    .catchall {:try_start_95 .. :try_end_b2} :catchall_ad

    .line 177
    .line 178
    .line 179
    invoke-virtual {v4}, Lgq0;->l()V

    .line 180
    .line 181
    .line 182
    goto :goto_ba

    .line 183
    :goto_b6
    invoke-virtual {v4}, Lgq0;->l()V

    .line 184
    .line 185
    .line 186
    throw v0

    .line 187
    :cond_ba
    :goto_ba
    invoke-virtual {v7}, Landroidx/work/impl/WorkDatabase;->v()Lre1;

    .line 188
    .line 189
    .line 190
    move-result-object v4

    .line 191
    invoke-virtual {v7}, Landroidx/work/impl/WorkDatabase;->u()Lje1;

    .line 192
    .line 193
    .line 194
    move-result-object v9

    .line 195
    invoke-virtual {v7}, Lgq0;->b()V

    .line 196
    .line 197
    .line 198
    :try_start_c5
    iget-object v10, v4, Lre1;->a:Lgq0;

    .line 199
    .line 200
    new-instance v14, Lzh;

    .line 201
    .line 202
    const/16 v15, 0x12

    .line 203
    .line 204
    invoke-direct {v14, v15}, Lzh;-><init>(I)V

    .line 205
    .line 206
    .line 207
    const/4 v15, 0x1

    .line 208
    invoke-static {v10, v15, v13, v14}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v10

    .line 212
    check-cast v10, Ljava/util/List;

    .line 213
    .line 214
    if-eqz v10, :cond_e2

    .line 215
    .line 216
    invoke-interface {v10}, Ljava/util/List;->isEmpty()Z

    .line 217
    .line 218
    .line 219
    move-result v14

    .line 220
    if-nez v14, :cond_e2

    .line 221
    .line 222
    const/4 v14, 0x1

    .line 223
    goto :goto_e3

    .line 224
    :catchall_df
    move-exception v0

    .line 225
    goto/16 :goto_23c

    .line 226
    .line 227
    :cond_e2
    move v14, v13

    .line 228
    :goto_e3
    if-eqz v14, :cond_106

    .line 229
    .line 230
    invoke-interface {v10}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    .line 231
    .line 232
    .line 233
    move-result-object v10

    .line 234
    :goto_e9
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 235
    .line 236
    .line 237
    move-result v15

    .line 238
    if-eqz v15, :cond_106

    .line 239
    .line 240
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 241
    .line 242
    .line 243
    move-result-object v15

    .line 244
    check-cast v15, Lne1;

    .line 245
    .line 246
    sget-object v13, Lde1;->f:Lde1;

    .line 247
    .line 248
    iget-object v15, v15, Lne1;->a:Ljava/lang/String;

    .line 249
    .line 250
    invoke-virtual {v4, v13, v15}, Lre1;->f(Lde1;Ljava/lang/String;)V

    .line 251
    .line 252
    .line 253
    const/16 v13, -0x200

    .line 254
    .line 255
    invoke-virtual {v4, v13, v15}, Lre1;->g(ILjava/lang/String;)V

    .line 256
    .line 257
    .line 258
    invoke-virtual {v4, v11, v12, v15}, Lre1;->c(JLjava/lang/String;)V

    .line 259
    .line 260
    .line 261
    const/4 v13, 0x0

    .line 262
    goto :goto_e9

    .line 263
    :cond_106
    iget-object v4, v9, Lje1;->a:Lgq0;

    .line 264
    .line 265
    new-instance v9, Lzh;

    .line 266
    .line 267
    const/16 v10, 0x10

    .line 268
    .line 269
    invoke-direct {v9, v10}, Lzh;-><init>(I)V

    .line 270
    .line 271
    .line 272
    const/4 v10, 0x0

    .line 273
    const/4 v15, 0x1

    .line 274
    invoke-static {v4, v10, v15, v9}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 275
    .line 276
    .line 277
    invoke-virtual {v7}, Lgq0;->o()V
    :try_end_117
    .catchall {:try_start_c5 .. :try_end_117} :catchall_df

    .line 278
    .line 279
    .line 280
    invoke-virtual {v7}, Lgq0;->l()V

    .line 281
    .line 282
    .line 283
    if-nez v14, :cond_121

    .line 284
    .line 285
    if-eqz v8, :cond_11f

    .line 286
    .line 287
    goto :goto_121

    .line 288
    :cond_11f
    const/4 v15, 0x0

    .line 289
    goto :goto_122

    .line 290
    :cond_121
    :goto_121
    const/4 v15, 0x1

    .line 291
    :goto_122
    iget-object v4, v6, Lw20;->a:Landroidx/work/impl/WorkDatabase;

    .line 292
    .line 293
    invoke-virtual {v4}, Landroidx/work/impl/WorkDatabase;->r()Ltl0;

    .line 294
    .line 295
    .line 296
    move-result-object v4

    .line 297
    const-string v8, "reschedule_needed"

    .line 298
    .line 299
    invoke-virtual {v4, v8}, Ltl0;->a(Ljava/lang/String;)Ljava/lang/Long;

    .line 300
    .line 301
    .line 302
    move-result-object v4

    .line 303
    const/4 v9, 0x4

    .line 304
    const-wide/16 v10, 0x0

    .line 305
    .line 306
    sget-object v12, Lox;->j:Ljava/lang/String;

    .line 307
    .line 308
    if-eqz v4, :cond_16a

    .line 309
    .line 310
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 311
    .line 312
    .line 313
    move-result-wide v13

    .line 314
    const-wide/16 v17, 0x1

    .line 315
    .line 316
    cmp-long v4, v13, v17

    .line 317
    .line 318
    if-nez v4, :cond_16a

    .line 319
    .line 320
    invoke-static {}, Lta0;->g()Lta0;

    .line 321
    .line 322
    .line 323
    move-result-object v0

    .line 324
    const-string v1, "Rescheduling Workers."

    .line 325
    .line 326
    invoke-virtual {v0, v12, v1}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 327
    .line 328
    .line 329
    invoke-virtual {v3}, Lee1;->d()V

    .line 330
    .line 331
    .line 332
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 333
    .line 334
    .line 335
    new-instance v0, Lsl0;

    .line 336
    .line 337
    invoke-static {v10, v11}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 338
    .line 339
    .line 340
    move-result-object v1

    .line 341
    invoke-direct {v0, v8, v1}, Lsl0;-><init>(Ljava/lang/String;Ljava/lang/Long;)V

    .line 342
    .line 343
    .line 344
    iget-object v1, v6, Lw20;->a:Landroidx/work/impl/WorkDatabase;

    .line 345
    .line 346
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->r()Ltl0;

    .line 347
    .line 348
    .line 349
    move-result-object v1

    .line 350
    iget-object v2, v1, Ltl0;->a:Lgq0;

    .line 351
    .line 352
    new-instance v3, Ltm;

    .line 353
    .line 354
    invoke-direct {v3, v1, v9, v0}, Ltm;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 355
    .line 356
    .line 357
    const/4 v10, 0x0

    .line 358
    const/4 v15, 0x1

    .line 359
    invoke-static {v2, v10, v15, v3}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 360
    .line 361
    .line 362
    return-void

    .line 363
    :cond_16a
    :try_start_16a
    sget v4, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 364
    .line 365
    const/16 v6, 0x1f

    .line 366
    .line 367
    if-lt v4, v6, :cond_173

    .line 368
    .line 369
    const/high16 v6, 0x22000000

    .line 370
    .line 371
    goto :goto_175

    .line 372
    :cond_173
    const/high16 v6, 0x20000000

    .line 373
    .line 374
    :goto_175
    new-instance v8, Landroid/content/Intent;

    .line 375
    .line 376
    invoke-direct {v8}, Landroid/content/Intent;-><init>()V

    .line 377
    .line 378
    .line 379
    new-instance v13, Landroid/content/ComponentName;

    .line 380
    .line 381
    const-class v14, Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;

    .line 382
    .line 383
    invoke-direct {v13, v0, v14}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 384
    .line 385
    .line 386
    invoke-virtual {v8, v13}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 387
    .line 388
    .line 389
    const-string v13, "ACTION_FORCE_STOP_RESCHEDULE"

    .line 390
    .line 391
    invoke-virtual {v8, v13}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    .line 392
    .line 393
    .line 394
    const/4 v13, -0x1

    .line 395
    invoke-static {v0, v13, v8, v6}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    .line 396
    .line 397
    .line 398
    move-result-object v6

    .line 399
    const/16 v8, 0x1e

    .line 400
    .line 401
    if-lt v4, v8, :cond_1e3

    .line 402
    .line 403
    if-eqz v6, :cond_19c

    .line 404
    .line 405
    invoke-virtual {v6}, Landroid/app/PendingIntent;->cancel()V

    .line 406
    .line 407
    .line 408
    goto :goto_19c

    .line 409
    :catch_198
    move-exception v0

    .line 410
    goto :goto_1fa

    .line 411
    :catch_19a
    move-exception v0

    .line 412
    goto :goto_1fa

    .line 413
    :cond_19c
    :goto_19c
    const-string v4, "activity"

    .line 414
    .line 415
    invoke-virtual {v0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 416
    .line 417
    .line 418
    move-result-object v0

    .line 419
    check-cast v0, Landroid/app/ActivityManager;

    .line 420
    .line 421
    invoke-static {v0}, Le1;->s(Landroid/app/ActivityManager;)Ljava/util/List;

    .line 422
    .line 423
    .line 424
    move-result-object v0

    .line 425
    if-eqz v0, :cond_1e9

    .line 426
    .line 427
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 428
    .line 429
    .line 430
    move-result v4

    .line 431
    if-nez v4, :cond_1e9

    .line 432
    .line 433
    iget-object v4, v2, Lw20;->a:Landroidx/work/impl/WorkDatabase;

    .line 434
    .line 435
    invoke-virtual {v4}, Landroidx/work/impl/WorkDatabase;->r()Ltl0;

    .line 436
    .line 437
    .line 438
    move-result-object v4

    .line 439
    invoke-virtual {v4, v1}, Ltl0;->a(Ljava/lang/String;)Ljava/lang/Long;

    .line 440
    .line 441
    .line 442
    move-result-object v4

    .line 443
    if-eqz v4, :cond_1c0

    .line 444
    .line 445
    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    .line 446
    .line 447
    .line 448
    move-result-wide v10

    .line 449
    :cond_1c0
    const/4 v4, 0x0

    .line 450
    :goto_1c1
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 451
    .line 452
    .line 453
    move-result v6

    .line 454
    if-ge v4, v6, :cond_1e9

    .line 455
    .line 456
    invoke-interface {v0, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 457
    .line 458
    .line 459
    move-result-object v6

    .line 460
    invoke-static {v6}, Le1;->f(Ljava/lang/Object;)Landroid/app/ApplicationExitInfo;

    .line 461
    .line 462
    .line 463
    move-result-object v6

    .line 464
    invoke-static {v6}, Le1;->b(Landroid/app/ApplicationExitInfo;)I

    .line 465
    .line 466
    .line 467
    move-result v8

    .line 468
    const/16 v13, 0xa

    .line 469
    .line 470
    if-ne v8, v13, :cond_1e0

    .line 471
    .line 472
    invoke-static {v6}, Le1;->e(Landroid/app/ApplicationExitInfo;)J

    .line 473
    .line 474
    .line 475
    move-result-wide v13

    .line 476
    cmp-long v6, v13, v10

    .line 477
    .line 478
    if-ltz v6, :cond_1e0

    .line 479
    .line 480
    goto :goto_208

    .line 481
    :cond_1e0
    add-int/lit8 v4, v4, 0x1

    .line 482
    .line 483
    goto :goto_1c1

    .line 484
    :cond_1e3
    if-nez v6, :cond_1e9

    .line 485
    .line 486
    invoke-static {v0}, Lox;->c(Landroid/content/Context;)V
    :try_end_1e8
    .catch Ljava/lang/SecurityException; {:try_start_16a .. :try_end_1e8} :catch_19a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_16a .. :try_end_1e8} :catch_198

    .line 487
    .line 488
    .line 489
    goto :goto_208

    .line 490
    :cond_1e9
    if-eqz v15, :cond_1f9

    .line 491
    .line 492
    invoke-static {}, Lta0;->g()Lta0;

    .line 493
    .line 494
    .line 495
    move-result-object v0

    .line 496
    const-string v1, "Found unfinished work, scheduling it."

    .line 497
    .line 498
    invoke-virtual {v0, v12, v1}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 499
    .line 500
    .line 501
    iget-object v0, v3, Lee1;->e:Ljava/util/List;

    .line 502
    .line 503
    invoke-static {v5, v7, v0}, Lcs0;->b(Lig;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    .line 504
    .line 505
    .line 506
    :cond_1f9
    return-void

    .line 507
    :goto_1fa
    invoke-static {}, Lta0;->g()Lta0;

    .line 508
    .line 509
    .line 510
    move-result-object v4

    .line 511
    iget v4, v4, Lta0;->a:I

    .line 512
    .line 513
    const/4 v6, 0x5

    .line 514
    if-gt v4, v6, :cond_208

    .line 515
    .line 516
    const-string v4, "Ignoring exception"

    .line 517
    .line 518
    invoke-static {v12, v4, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 519
    .line 520
    .line 521
    :cond_208
    :goto_208
    invoke-static {}, Lta0;->g()Lta0;

    .line 522
    .line 523
    .line 524
    move-result-object v0

    .line 525
    const-string v4, "Application was force-stopped, rescheduling."

    .line 526
    .line 527
    invoke-virtual {v0, v12, v4}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 528
    .line 529
    .line 530
    invoke-virtual {v3}, Lee1;->d()V

    .line 531
    .line 532
    .line 533
    iget-object v0, v5, Lig;->d:Lkr0;

    .line 534
    .line 535
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 536
    .line 537
    .line 538
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 539
    .line 540
    .line 541
    move-result-wide v3

    .line 542
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 543
    .line 544
    .line 545
    new-instance v0, Lsl0;

    .line 546
    .line 547
    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 548
    .line 549
    .line 550
    move-result-object v3

    .line 551
    invoke-direct {v0, v1, v3}, Lsl0;-><init>(Ljava/lang/String;Ljava/lang/Long;)V

    .line 552
    .line 553
    .line 554
    iget-object v1, v2, Lw20;->a:Landroidx/work/impl/WorkDatabase;

    .line 555
    .line 556
    invoke-virtual {v1}, Landroidx/work/impl/WorkDatabase;->r()Ltl0;

    .line 557
    .line 558
    .line 559
    move-result-object v1

    .line 560
    iget-object v2, v1, Ltl0;->a:Lgq0;

    .line 561
    .line 562
    new-instance v3, Ltm;

    .line 563
    .line 564
    invoke-direct {v3, v1, v9, v0}, Ltm;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    .line 565
    .line 566
    .line 567
    const/4 v10, 0x0

    .line 568
    const/4 v15, 0x1

    .line 569
    invoke-static {v2, v10, v15, v3}, Lt51;->D(Lgq0;ZZLqz;)Ljava/lang/Object;

    .line 570
    .line 571
    .line 572
    return-void

    .line 573
    :goto_23c
    invoke-virtual {v7}, Lgq0;->l()V

    .line 574
    .line 575
    .line 576
    throw v0
.end method

.method public final b()Z
    .registers 5

    .line 1
    iget-object v0, p0, Lox;->g:Lee1;

    .line 2
    .line 3
    iget-object v0, v0, Lee1;->b:Lig;

    .line 4
    .line 5
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 10
    .line 11
    .line 12
    move-result v1

    .line 13
    sget-object v2, Lox;->j:Ljava/lang/String;

    .line 14
    .line 15
    if-eqz v1, :cond_1b

    .line 16
    .line 17
    invoke-static {}, Lta0;->g()Lta0;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    const-string v0, "The default process name was not specified."

    .line 22
    .line 23
    invoke-virtual {p0, v2, v0}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    const/4 p0, 0x1

    .line 27
    return p0

    .line 28
    :cond_1b
    iget-object p0, p0, Lox;->f:Landroid/content/Context;

    .line 29
    .line 30
    invoke-static {p0, v0}, Lpm0;->a(Landroid/content/Context;Lig;)Z

    .line 31
    .line 32
    .line 33
    move-result p0

    .line 34
    invoke-static {}, Lta0;->g()Lta0;

    .line 35
    .line 36
    .line 37
    move-result-object v0

    .line 38
    new-instance v1, Ljava/lang/StringBuilder;

    .line 39
    .line 40
    const-string v3, "Is default app process = "

    .line 41
    .line 42
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 46
    .line 47
    .line 48
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    invoke-virtual {v0, v2, v1}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 53
    .line 54
    .line 55
    return p0
.end method

.method public final run()V
    .registers 13

    .line 1
    iget-object v0, p0, Lox;->f:Landroid/content/Context;

    .line 2
    .line 3
    sget-object v1, Lox;->j:Ljava/lang/String;

    .line 4
    .line 5
    iget-object v2, p0, Lox;->g:Lee1;

    .line 6
    .line 7
    :try_start_6
    invoke-virtual {p0}, Lox;->b()Z

    .line 8
    .line 9
    .line 10
    move-result v3
    :try_end_a
    .catchall {:try_start_6 .. :try_end_a} :catchall_23

    .line 11
    if-nez v3, :cond_10

    .line 12
    .line 13
    invoke-virtual {v2}, Lee1;->c()V

    .line 14
    .line 15
    .line 16
    return-void

    .line 17
    :catch_10
    :cond_10
    :goto_10
    :try_start_10
    invoke-static {v0}, Llf1;->A(Landroid/content/Context;)V
    :try_end_13
    .catch Landroid/database/sqlite/SQLiteException; {:try_start_10 .. :try_end_13} :catch_8b
    .catchall {:try_start_10 .. :try_end_13} :catchall_23

    .line 18
    .line 19
    .line 20
    :try_start_13
    invoke-static {}, Lta0;->g()Lta0;

    .line 21
    .line 22
    .line 23
    move-result-object v3

    .line 24
    const-string v4, "Performing cleanup operations."

    .line 25
    .line 26
    invoke-virtual {v3, v1, v4}, Lta0;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1c
    .catchall {:try_start_13 .. :try_end_1c} :catchall_23

    .line 27
    .line 28
    .line 29
    :try_start_1c
    invoke-virtual {p0}, Lox;->a()V
    :try_end_1f
    .catch Landroid/database/sqlite/SQLiteAccessPermException; {:try_start_1c .. :try_end_1f} :catch_34
    .catch Landroid/database/sqlite/SQLiteCantOpenDatabaseException; {:try_start_1c .. :try_end_1f} :catch_32
    .catch Landroid/database/sqlite/SQLiteConstraintException; {:try_start_1c .. :try_end_1f} :catch_30
    .catch Landroid/database/sqlite/SQLiteDatabaseCorruptException; {:try_start_1c .. :try_end_1f} :catch_2e
    .catch Landroid/database/sqlite/SQLiteDatabaseLockedException; {:try_start_1c .. :try_end_1f} :catch_2c
    .catch Landroid/database/sqlite/SQLiteDiskIOException; {:try_start_1c .. :try_end_1f} :catch_2a
    .catch Landroid/database/sqlite/SQLiteFullException; {:try_start_1c .. :try_end_1f} :catch_28
    .catch Landroid/database/sqlite/SQLiteTableLockedException; {:try_start_1c .. :try_end_1f} :catch_26
    .catchall {:try_start_1c .. :try_end_1f} :catchall_23

    .line 30
    .line 31
    .line 32
    invoke-virtual {v2}, Lee1;->c()V

    .line 33
    .line 34
    .line 35
    return-void

    .line 36
    :catchall_23
    move-exception p0

    .line 37
    goto/16 :goto_a0

    .line 38
    .line 39
    :catch_26
    move-exception v3

    .line 40
    goto :goto_35

    .line 41
    :catch_28
    move-exception v3

    .line 42
    goto :goto_35

    .line 43
    :catch_2a
    move-exception v3

    .line 44
    goto :goto_35

    .line 45
    :catch_2c
    move-exception v3

    .line 46
    goto :goto_35

    .line 47
    :catch_2e
    move-exception v3

    .line 48
    goto :goto_35

    .line 49
    :catch_30
    move-exception v3

    .line 50
    goto :goto_35

    .line 51
    :catch_32
    move-exception v3

    .line 52
    goto :goto_35

    .line 53
    :catch_34
    move-exception v3

    .line 54
    :goto_35
    :try_start_35
    iget v4, p0, Lox;->i:I

    .line 55
    .line 56
    add-int/lit8 v4, v4, 0x1

    .line 57
    .line 58
    iput v4, p0, Lox;->i:I

    .line 59
    .line 60
    const/4 v5, 0x3

    .line 61
    if-lt v4, v5, :cond_63

    .line 62
    .line 63
    const-class p0, Landroid/os/UserManager;

    .line 64
    .line 65
    invoke-virtual {v0, p0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object p0

    .line 69
    check-cast p0, Landroid/os/UserManager;

    .line 70
    .line 71
    invoke-virtual {p0}, Landroid/os/UserManager;->isUserUnlocked()Z

    .line 72
    .line 73
    .line 74
    move-result p0

    .line 75
    if-eqz p0, :cond_4f

    .line 76
    .line 77
    const-string p0, "The file system on the device is in a bad state. WorkManager cannot access the app\'s internal data store."

    .line 78
    .line 79
    goto :goto_51

    .line 80
    :cond_4f
    const-string p0, "WorkManager can\'t be accessed from direct boot, because credential encrypted storage isn\'t accessible.\nDon\'t access or initialise WorkManager from directAware components. See https://developer.android.com/training/articles/direct-boot"

    .line 81
    .line 82
    :goto_51
    invoke-static {}, Lta0;->g()Lta0;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    invoke-virtual {v0, v1, p0, v3}, Lta0;->f(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 87
    .line 88
    .line 89
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 90
    .line 91
    invoke-direct {v0, p0, v3}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 92
    .line 93
    .line 94
    iget-object p0, v2, Lee1;->b:Lig;

    .line 95
    .line 96
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 97
    .line 98
    .line 99
    throw v0

    .line 100
    :cond_63
    int-to-long v6, v4

    .line 101
    const-wide/16 v8, 0x12c

    .line 102
    .line 103
    mul-long/2addr v6, v8

    .line 104
    invoke-static {}, Lta0;->g()Lta0;

    .line 105
    .line 106
    .line 107
    move-result-object v4

    .line 108
    new-instance v10, Ljava/lang/StringBuilder;

    .line 109
    .line 110
    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    .line 111
    .line 112
    .line 113
    const-string v11, "Retrying after "

    .line 114
    .line 115
    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 116
    .line 117
    .line 118
    invoke-virtual {v10, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 119
    .line 120
    .line 121
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object v6

    .line 125
    iget v4, v4, Lta0;->a:I

    .line 126
    .line 127
    if-gt v4, v5, :cond_83

    .line 128
    .line 129
    invoke-static {v1, v6, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 130
    .line 131
    .line 132
    :cond_83
    iget v3, p0, Lox;->i:I
    :try_end_85
    .catchall {:try_start_35 .. :try_end_85} :catchall_23

    .line 133
    .line 134
    int-to-long v3, v3

    .line 135
    mul-long/2addr v3, v8

    .line 136
    :try_start_87
    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_8a
    .catch Ljava/lang/InterruptedException; {:try_start_87 .. :try_end_8a} :catch_10
    .catchall {:try_start_87 .. :try_end_8a} :catchall_23

    .line 137
    .line 138
    .line 139
    goto :goto_10

    .line 140
    :catch_8b
    move-exception p0

    .line 141
    :try_start_8c
    const-string v0, "Unexpected SQLite exception during migrations"

    .line 142
    .line 143
    invoke-static {}, Lta0;->g()Lta0;

    .line 144
    .line 145
    .line 146
    move-result-object v3

    .line 147
    invoke-virtual {v3, v1, v0}, Lta0;->e(Ljava/lang/String;Ljava/lang/String;)V

    .line 148
    .line 149
    .line 150
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 151
    .line 152
    invoke-direct {v1, v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 153
    .line 154
    .line 155
    iget-object p0, v2, Lee1;->b:Lig;

    .line 156
    .line 157
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 158
    .line 159
    .line 160
    throw v1
    :try_end_a0
    .catchall {:try_start_8c .. :try_end_a0} :catchall_23

    .line 161
    :goto_a0
    invoke-virtual {v2}, Lee1;->c()V

    .line 162
    .line 163
    .line 164
    throw p0
.end method
