###### Class defpackage.a7 (a7)
.class public final La7;
.super Lsx;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# instance fields
.field public final synthetic o:Lj7;

.field public final synthetic p:Lm7;


# direct methods
.method public constructor <init>(Lm7;Lm7;Lj7;)V
    .registers 4

    .line 1
    iput-object p1, p0, La7;->p:Lm7;

    .line 2
    .line 3
    iput-object p3, p0, La7;->o:Lj7;

    .line 4
    .line 5
    invoke-direct {p0, p2}, Lsx;-><init>(Landroid/view/View;)V

    .line 6
    .line 7
    .line 8
    return-void
.end method


# virtual methods
.method public final b()Lix0;
    .registers 1

    .line 1
    iget-object p0, p0, La7;->o:Lj7;

    .line 2
    .line 3
    return-object p0
.end method

.method public final c()Z
    .registers 3

    .line 1
    iget-object p0, p0, La7;->p:Lm7;

    .line 2
    .line 3
    invoke-virtual {p0}, Lm7;->getInternalPopup()Ll7;

    .line 4
    .line 5
    .line 6
    move-result-object v0

    .line 7
    invoke-interface {v0}, Ll7;->b()Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    if-nez v0, :cond_19

    .line 12
    .line 13
    iget-object v0, p0, Lm7;->k:Ll7;

    .line 14
    .line 15
    invoke-static {p0}, Ld7;->b(Landroid/view/View;)I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    invoke-static {p0}, Ld7;->a(Landroid/view/View;)I

    .line 20
    .line 21
    .line 22
    move-result p0

    .line 23
    invoke-interface {v0, v1, p0}, Ll7;->n(II)V

    .line 24
    .line 25
    .line 26
    :cond_19
    const/4 p0, 0x1

    .line 27
    return p0
.end method
