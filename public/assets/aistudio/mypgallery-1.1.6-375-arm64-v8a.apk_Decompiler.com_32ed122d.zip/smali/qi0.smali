###### Class defpackage.qi0 (qi0)
.class public final Lqi0;
.super Lxi0;
.source "r8-map-id-5cf2f1eed1938cc05a9a9d535d72bccb6d08b9eea652c51a494965c93fbd0a29"


# static fields
.field public static final c:Lqi0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Lqi0;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x3

    .line 5
    invoke-direct {v0, v1, v1, v2}, Lxi0;-><init>(III)V

    .line 6
    .line 7
    .line 8
    sput-object v0, Lqi0;->c:Lqi0;

    .line 9
    .line 10
    return-void
.end method


# virtual methods
.method public final a(Lcd;Lt8;Loy0;Lzf;)V
    .registers 5

    .line 1
    iget p0, p3, Loy0;->n:I

    .line 2
    .line 3
    if-nez p0, :cond_1a

    .line 4
    .line 5
    invoke-virtual {p3}, Loy0;->x()V

    .line 6
    .line 7
    .line 8
    const/4 p0, 0x0

    .line 9
    iput p0, p3, Loy0;->t:I

    .line 10
    .line 11
    invoke-virtual {p3}, Loy0;->m()I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    iget p2, p3, Loy0;->h:I

    .line 16
    .line 17
    sub-int/2addr p1, p2

    .line 18
    iput p1, p3, Loy0;->u:I

    .line 19
    .line 20
    iput p0, p3, Loy0;->i:I

    .line 21
    .line 22
    iput p0, p3, Loy0;->j:I

    .line 23
    .line 24
    iput p0, p3, Loy0;->o:I

    .line 25
    .line 26
    return-void

    .line 27
    :cond_1a
    const-string p0, "Cannot reset when inserting"

    .line 28
    .line 29
    invoke-static {p0}, Lt51;->g(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    const/4 p0, 0x0

    .line 33
    throw p0
.end method
